using System;

namespace PAI.Drayage.Optimization.Geography
{
    public interface ITravelTimeEstimator
    {
        /// <summary>
        /// Calculates the travel time 
        /// </summary>
        /// <param name="distance"></param>
        /// <returns></returns>
        TimeSpan CalculateTravelTime(double distance);
    }
}