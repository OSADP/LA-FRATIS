using System;

namespace PAI.Drayage.Optimization.Geography
{
    /// <summary>
    /// The travel time estimator.
    /// </summary>
    public class TravelTimeEstimator : ITravelTimeEstimator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TravelTimeEstimator"/> class.
        /// </summary>
        public TravelTimeEstimator()
        {
            AverageCitySpeed = 30;
            AverageHighwaySpeed = 50;
            SpeedThreshold = 50;
        }

        /// <summary>
        /// Gets or sets the average city speed.
        /// </summary>
        public double AverageCitySpeed { get; set; }

        /// <summary>
        /// Gets or sets the average highway speed.
        /// </summary>
        public double AverageHighwaySpeed { get; set; }

        /// <summary>
        /// Gets or sets the speed threshold.
        /// </summary>
        public double SpeedThreshold { get; set; }

        /// <summary>
        /// Calculates the travel time 
        /// </summary>
        /// <param name="distance"></param>
        /// <returns>Total travel time represented as TimeSpan</returns>
        public TimeSpan CalculateTravelTime(double distance)
        {
            var speed = distance < SpeedThreshold ? AverageCitySpeed : AverageHighwaySpeed;
            var travelTime = distance / speed;
            return TimeSpan.FromHours(travelTime);
        }
    }
}