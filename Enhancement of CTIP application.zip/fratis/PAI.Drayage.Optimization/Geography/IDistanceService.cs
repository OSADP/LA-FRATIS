using System;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Geography
{
    public interface IDistanceService
    {
        /// <summary>
        /// Calculates the trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <param name="startTime"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        TripLength CalculateDistance(Location startLocation, Location endLocation, DateTime startTime, bool useTraffic);
    }
}
