using System;
using System.Collections.Concurrent;
using System.Runtime.Caching;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Geography
{
    public class CachedDistanceService : IDistanceService
    {
        private readonly IDistanceService _distanceService;

        public CachedDistanceService(IDistanceService distanceService)
        {
            _distanceService = distanceService;
        }

        private MemoryCache MemoryCache { get; } = new MemoryCache("CachedDistanceService");

        /// <summary>
        ///     Calculates the trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <param name="startTime"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        public TripLength CalculateDistance(Location startLocation, Location endLocation, DateTime startTime, bool useTraffic)
        {
            var result = TripLength.Zero;

            try
            {
                if (!startLocation.Equals(endLocation))
                {
                    var locationsTuple = GetLocationsTuple(startLocation, endLocation, startTime, useTraffic);
                    var hashString = locationsTuple.GetHashCode().ToString();

                    if (MemoryCache.Contains(hashString))
                    {
                        var cacheItem = MemoryCache.GetCacheItem(hashString);
                        if (cacheItem != null)
                            result = (TripLength)cacheItem.Value;
                        else
                            result = TripLength.Zero;
                    }
                    else
                    {
                        result = _distanceService.CalculateDistance(startLocation, endLocation, startTime, useTraffic);
                        MemoryCache.Add(hashString, result,
                            new CacheItemPolicy {AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(30)});
                    }
                    return result;
                }
            }
            catch
            {
                result = TripLength.Zero;
            }

            return result;
        }

        /// <summary>
        ///     Gets a Tuple in the pre-defined required sequence
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <param name="timeRequested"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        private Tuple<Location, Location, long> GetLocationsTuple(Location startLocation, Location endLocation,
            DateTime timeRequested, bool useTraffic)
        {
            long ticks = 0;
            if (useTraffic)
            {
                var timeRoundOffToHour = new DateTime(timeRequested.Year, timeRequested.Month,
                    timeRequested.Day, timeRequested.Hour, 0, 0);
                ticks = timeRoundOffToHour.Ticks;
            }

            var result = new Tuple<Location, Location, long>(startLocation, endLocation, ticks);

            return result;
        }
    }
}