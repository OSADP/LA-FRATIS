﻿using System;
using System.Threading;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Gis.Routing.Core.Domain;
using PAI.Gis.Routing.Core.Routing;

namespace PAI.Drayage.Optimization.Geography
{
    public class DistanceService : IDistanceService
    {
        private const double EarthRadius = 3963.2;
        private readonly IRoutingProvider _routingProvider;

        private readonly ITravelTimeEstimator _travelTimeEstimator;

        public DistanceService(ITravelTimeEstimator travelTimeEstimator, IRoutingProvider routingProvider)
        {
            _travelTimeEstimator = travelTimeEstimator;
            _routingProvider = routingProvider;
        }

        /// <summary>
        ///     Calculates the trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <param name="timeOfDay"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        public TripLength CalculateDistance(Location startLocation, Location endLocation, DateTime timeOfDay, bool useTraffic)
        {
            if (startLocation == null) throw new ArgumentNullException("startLocation");
            if (endLocation == null) throw new ArgumentNullException("endLocation");

            if (_routingProvider != null)
            {
                // TODO: Refactor the data type of startTime to use DateTime in the future.  This is not simple
                // since this call is bury deep under so many layer that operate using TimeSpan
                var routeOption = new RouteOptions
                {
                    UseTraffic = useTraffic,
                    Time = new DateTime(timeOfDay.Ticks)
                };

                var awaiter =
                    _routingProvider.GenerateRoute(
                        new GeoLocation {Lat = startLocation.Latitude, Long = startLocation.Longitude},
                        new GeoLocation {Lat = endLocation.Latitude, Long = endLocation.Longitude},
                        routeOption,
                        CancellationToken.None).GetAwaiter();

                // Block async call since the older design doesn't support async this should wait on current context
                var result = awaiter.GetResult();

                if (result.IsValid)
                {
                    return new TripLength(Convert.ToDouble(result.Distance*0.000621371),
                        TimeSpan.FromSeconds(result.TravelTime));
                }

                // Execute fallback if it's not working
            }

            //Fallback with the taxicab & euclidian
            if (startLocation.Latitude == 0 && startLocation.Longitude == 0) return new TripLength(0, TimeSpan.Zero);
            if (endLocation.Latitude == 0 && endLocation.Longitude == 0) return new TripLength(0, TimeSpan.Zero);

            var tDistance = CalculateTaxicabDistance(startLocation, endLocation);
            var eDistance = CalculateEuclidianDistance(startLocation, endLocation);
            var totalDistance = tDistance + eDistance;
            return new TripLength(totalDistance.Distance/2, new TimeSpan(totalDistance.Time.Ticks/2));
        }


        /// <summary>
        ///     Convert degrees to Radians
        /// </summary>
        /// <param name="x">Degrees</param>
        /// <returns>The equivalent in radians</returns>
        private static double Radians(double x)
        {
            return x*Math.PI/180;
        }

        /// <summary>
        ///     Calculates the taxi cab trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <returns></returns>
        public TripLength CalculateTaxicabDistance(Location startLocation, Location endLocation)
        {
            var lon1 = startLocation.Longitude;
            var lat1 = startLocation.Latitude;
            var lon2 = endLocation.Longitude;
            var lat2 = endLocation.Latitude;

            var maxLat = Math.Max(lat1, lat2);
            var k = Math.Cos(Radians(maxLat));
            var distance = 69.172*(Math.Abs(lat2 - lat1) + k*Math.Abs(lon2 - lon1));

            var result = new TripLength
            {
                Distance = distance,
                Time = _travelTimeEstimator.CalculateTravelTime(distance)
            };

            return result;
        }

        /// <summary>
        ///     calculates the euclidian trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <returns></returns>
        public TripLength CalculateEuclidianDistance(Location startLocation, Location endLocation)
        {
            var lon1 = startLocation.Longitude;
            var lat1 = startLocation.Latitude;
            var lon2 = endLocation.Longitude;
            var lat2 = endLocation.Latitude;

            var dlon = Radians(lon2 - lon1);
            var dlat = Radians(lat2 - lat1);

            var a = Math.Sin(dlat/2)*Math.Sin(dlat/2) +
                    Math.Cos(Radians(lat1))*Math.Cos(Radians(lat2))*(Math.Sin(dlon/2)*Math.Sin(dlon/2));
            var angle = 2*Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            var distance = angle*EarthRadius;

            var result = new TripLength
            {
                Distance = distance,
                Time = _travelTimeEstimator.CalculateTravelTime(distance)
            };

            return result;
        }
    }
}