using PAI.Drayage.Optimization.Model;

namespace PAI.Drayage.Optimization.Geography
{
    public interface IGeoCodingService
    {
        /// <summary>
        /// Gets the geographical coordinates from address
        /// </summary>
        /// <returns></returns>
        bool GeoCode(Location location);
    }
}