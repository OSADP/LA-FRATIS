using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Infrastructure;
using System.Text.RegularExpressions;
using PAI.Drayage.Optimization.Geography;

namespace PAI.Drayage.Optimization.Services
{
    public class DrayageOptimizer : IDrayageOptimizer
    {
        protected readonly ILogger _logger;
        protected readonly IRouteService _routeService;
        protected readonly IRouteStatisticsService _routeStatisticsService;
        protected readonly IPheromoneMatrix _pheromoneMatrix;
        protected readonly IRouteExitFunction _routeExitFunction;
        protected readonly IProbabilityMatrix _probabilityMatrix;
        private DriverStartingTimeProbabilityMatrix _driverStartingTimeProbabilityMatrix;
        private readonly IRandomNumberGenerator _randomNumberGenerator;

        private readonly IRouteStopService _routeStopService;
        private readonly IDistanceService _distanceService;
        private readonly ISolutionComparer _solutionComparer;
        private readonly IObjectiveFunction _objectiveFunction;
        private readonly IJobNodeService _jobNodeService;

        protected readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim();
        protected bool _isCancelling;
        protected bool _isExecuting;
        private Solution _currentBestSolution;
        private CompareNoCaseComparer _noCaseComparer;

        public bool EnableParallelism { get; set; }
        public int PheromoneUpdateFrequency { get; set; }
        public int MaxIterations { get; set; }
        public int MaxIterationSinceBestResult { get; set; }
        public int MaxExecutionTime { get; set; }
        public bool DisallowPlaceholderDriver { get; set; }
        public bool FlexibleStartTime { get; set; }
        public bool UseTraffic { get; set; }

        public Solution CurrentBestSolution
        {
            get
            {
                Solution result = null;
                _rwLock.EnterReadLock();
                result = _currentBestSolution;
                _rwLock.ExitReadLock();

                return result;
            }
            set
            {
                _rwLock.EnterWriteLock();
                _currentBestSolution = value;

                if (SolutionUpdated != null)
                {
                    SolutionUpdated.Invoke(this, new SolutionEventArgs {Solution = _currentBestSolution});
                }

                _rwLock.ExitWriteLock();
            }
        }

        public DrayageOptimizer(IProbabilityMatrix probabilityMatrix,
            IRouteService routeService,
            IRouteExitFunction routeExitFunction, 
            ILogger logger, 
            IPheromoneMatrix pheromoneMatrix, 
            IRandomNumberGenerator randomNumberGenerator, 
            IRouteStatisticsService routeStatisticsService, 
            IJobNodeService jobNodeService, 
            IRouteStopService routeStopService,
            ISolutionComparer solutionComparer,
            IDistanceService distanceService,
            IObjectiveFunction objectiveFunction)
        {
            _probabilityMatrix = probabilityMatrix;
            _routeExitFunction = routeExitFunction;
            _logger = logger;
            _pheromoneMatrix = pheromoneMatrix;
            _randomNumberGenerator = randomNumberGenerator;
            _routeStatisticsService = routeStatisticsService;
            _jobNodeService = jobNodeService;
            _routeStopService = routeStopService;
            _solutionComparer = solutionComparer;
            _objectiveFunction = objectiveFunction;
            _routeService = routeService;
            _distanceService = distanceService;
            _noCaseComparer = new CompareNoCaseComparer();
        }

        public virtual void Cancel()
        {
            _rwLock.EnterWriteLock();
            if (_isExecuting)
            {
                _isCancelling = true;
            }
            _rwLock.ExitWriteLock();
        }

        public event EventHandler<SolutionEventArgs> SolutionUpdated;

        #region Progress Event
        public event EventHandler<ProgressEventArgs> ProgressChanged;

        private void OnProgressEvent(ProgressEventArgs eventArgs)
        {
            if (ProgressChanged != null)
            {
                ProgressChanged.Invoke(this, eventArgs);
            }
        }
        #endregion

        /// <summary>
        /// Creates route assignments from the given trucks and jobs
        /// </summary>
        /// <param name="drivers"></param>
        /// <param name="defaultDriver"> </param>
        /// <param name="jobs"></param>
        /// <returns></returns>
        public virtual Solution BuildSolution(IList<Driver> drivers, Driver defaultDriver, IList<Job> jobs)
        {
            if (drivers == null) throw new ArgumentNullException("drivers");
            if (jobs == null) throw new ArgumentNullException("jobs");
            if (defaultDriver == null) throw new ArgumentNullException("defaultDriver");
            //if (jobs.Count == 0) throw new OptimizationException("Need at least one job to build solution");

            if (_isExecuting)
            {
                //throw new OptimizationException("Cannot BuildSolution while another BuildSolution is executing.");
            }

            // begin execution
            _isExecuting = true;
            _isCancelling = false;
            CurrentBestSolution = null;

            // clear pheromone matrix
            _pheromoneMatrix.Clear();

            //moved FlexibleStartTime property into driver object 
            //because DrivingStartingTimeProbabilityMatrix has to be initialized 
            //and in case with dps with started jobs we fix earliest start time to dp departure time
            //if (FlexibleStartTime)
                InitializeDrivingStartingTimeProbabilityMatrix(drivers);
            
            // Create job nodes
            var jobNodes = jobs.Select((job, i) => _jobNodeService.CreateJobNode(job, UseTraffic)).ToList();

            
            // build solution
            var bestSolution = BuildSolution(defaultDriver, jobNodes.Cast<INode>().ToList(), drivers);
            
            // done executing
            _isExecuting = false;
            _isCancelling = false;

            CurrentBestSolution = bestSolution;

            return bestSolution;
        }

        private void InitializeDrivingStartingTimeProbabilityMatrix(IEnumerable<Driver> drivers)
        {
            _driverStartingTimeProbabilityMatrix = new DriverStartingTimeProbabilityMatrix(drivers, _randomNumberGenerator, _objectiveFunction);
            _driverStartingTimeProbabilityMatrix.Rho = _pheromoneMatrix.Rho;
            _driverStartingTimeProbabilityMatrix.Q = _pheromoneMatrix.Q;
        }

        private bool IsSolutionPresent(Solution solution)
        {
            return solution.RouteSolutions.Any(x => x.JobCount > 0);
        }

        public virtual Solution BuildSolution(Driver placeholderDriver, IList<INode> jobNodes, IList<Driver> drivers)
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            int iterationsSinceBestResult = 0;
            int totalIterations = 0;
            bool stopping = false;

            Solution bestSolution = null;
            var subSolutions = new List<Solution>();
            Solution bestSolutionPerLoop = null;

            jobNodes = jobNodes.OrderByDescending(a => a.WindowEnd).Reverse().ToList();

            // Define iteration
            Action<int, ParallelLoopState> iterationAction = (i, loopState) =>
                {
                    // Nominate driver
                    var driverNodes =
                        drivers.Select(x => _driverStartingTimeProbabilityMatrix.GetNominatedElement(x)).ToList();

                    //We'll only do the greedy algorithm the first iteration and assume it's the best
                    if (i == 0)
                    {
                        //bestSolution = ProcessDriversGreedilyTwo(driverNodes, placeholderDriver, jobNodes);
                        //bestSolution = ProcessDriversGreedily(driverNodes, placeholderDriver, jobNodes);
                        //var secondGreedySolution = ProcessDriversGreedilyTwo(driverNodes, placeholderDriver, jobNodes);

                        // bestSolution = _routeService.GetBestSolution(bestSolution, secondGreedySolution);
                    }

                    var solution = ProcessDrivers(driverNodes, placeholderDriver, jobNodes, bestSolutionPerLoop);
                    
                    _rwLock.EnterWriteLock();

                    try
                    {
                        totalIterations++;
                        iterationsSinceBestResult++;
                        subSolutions.Add(solution);

                        // Update progress
                        OnProgressEvent(
                            new ProgressEventArgs
                            {
                                PrimaryTotal = MaxIterations,
                                PrimaryValue = totalIterations
                            });

                        var oldBest = bestSolution;

                        bestSolution = bestSolution == null ? solution : _routeService.GetBestSolution(bestSolution, solution);
                        
                        if (!IsSolutionPresent(solution) || bestSolution != oldBest)
                        {
                            _currentBestSolution = bestSolution;
                            iterationsSinceBestResult = 0;
                        }


                        // Check exit criteria
                        if ((loopState == null || !loopState.IsStopped) && iterationsSinceBestResult > MaxIterationSinceBestResult || i >= MaxIterations || stopWatch.ElapsedMilliseconds > MaxExecutionTime)
                        {
                            _logger.Info("Max iterations since best result reached ({0})", MaxIterationSinceBestResult);
                            stopping = true;
                        }

                        if (_isCancelling)
                        {
                            stopping = true;
                        }

                        if (stopping)
                        {
                            if (loopState != null) loopState.Stop();
                        }

                    }
                    finally
                    {
                        _rwLock.ExitWriteLock();
                    }

                    // Update Pheromone Matrix 
                    if (!stopping && PheromoneUpdateFrequency > 0 && i > 0 && i % PheromoneUpdateFrequency == 0)
                    {
                        try
                        {
                            _rwLock.EnterWriteLock();

                            List<Solution> subResultCopy = subSolutions.ToList();
                            subSolutions.Clear();

                            // Sort from best to worse of the subsolution, pick top half
                            var sortedSubSolution = subResultCopy.OrderBy(x => x, _solutionComparer).ToList();
                            var topHalfSolutions = sortedSubSolution.GetRange(0, sortedSubSolution.Count/2);
                            _pheromoneMatrix.UpdatePheromoneMatrix(topHalfSolutions);
                            _driverStartingTimeProbabilityMatrix.UpdateData(driverNodes, topHalfSolutions);
                        }
                        finally
                        {
                            _rwLock.ExitWriteLock();
                        }
                    }
                };

            // Run iterations
            if (EnableParallelism)
            {
                Parallel.For(0, Int32.MaxValue, iterationAction);
            }
            else
            {
                List<int> processedJobIds = jobNodes.Select(x => x.Id).ToList();
                int loopsCompleted = 0;

                while (loopsCompleted < 2 || processedJobIds.Count > 0)
                {
                    for (var i = 0; i < Int32.MaxValue; i++)
                    {
                        iterationAction(i, null);

                        if (stopping)
                            break;
                    }
                    stopping = false;
                    iterationsSinceBestResult = 0;
                    bestSolutionPerLoop = bestSolution;
                    if (bestSolution.RouteSolutions.Where(z => !z.DriverNode.Driver.IsPlaceHolderDriver).SelectMany(x => x.Nodes).Select(y => y.Id).ToList().Count == processedJobIds.Count)
                        break;
                    processedJobIds = bestSolution.RouteSolutions.Where(z => !z.DriverNode.Driver.IsPlaceHolderDriver).SelectMany(x => x.Nodes).Select(y => y.Id).ToList();
                    loopsCompleted++;
                }
            }

            for(int i=0; i< bestSolution.RouteSolutions.Count;i++)
            {
                NodeRouteSolution nodeSolution = bestSolution.RouteSolutions[i];

                if(!nodeSolution.DriverNode.Driver.IsPlaceHolderDriver)
                    bestSolution.RouteSolutions[i] = RecalculateRouteSolution(nodeSolution.DriverNode, nodeSolution.Nodes,nodeSolution.StartTime);
            }

            stopWatch.Stop();

            return bestSolution;
        }

        /// <summary>
        /// Creates our route assignments by processing all the drivers and getting their routes
        /// </summary>
        /// <returns></returns>
        public virtual Solution ProcessDrivers(IList<DriverNode> driverNodes, Driver placeholderDriver, IList<INode> jobNodes, Solution solutionToOptimize)
        {
            int lastAvailableNodesCount;
            Solution solution = new Solution();

            if (solutionToOptimize != null)
            {
                var newRouteSolutions = solutionToOptimize.RouteSolutions.Where(x => !x.DriverNode.Driver.IsPlaceHolderDriver).Select(x => new NodeRouteSolution(x)).ToList();
                solution.RouteSolutions = new System.Collections.ObjectModel.ObservableCollection<NodeRouteSolution>(newRouteSolutions);
                solution.RouteStatistics = solutionToOptimize.RouteStatistics;
                solution.UnassignedJobNodes = solutionToOptimize.UnassignedJobNodes;
            }

            if (jobNodes.Count == 0) return solution;
            
            var availableNodes = jobNodes;

            _randomNumberGenerator.Reseed(Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value));
            var realDriverNodes = driverNodes.Where(f => f.Driver != placeholderDriver)
                .OrderBy(f => _randomNumberGenerator.Next()).ToArray(); // random sort order

            if (solutionToOptimize == null)
            {
                // going through all the real drivers
                foreach (var driverNode in realDriverNodes)
                {
                    // get the route solution for this particular driver
                    var nodeRouteSolution = new NodeRouteSolution();

                    availableNodes = FilterJobsByEmptyReturnAndTime(availableNodes, 10);

                    nodeRouteSolution = GenerateRouteSolution(availableNodes, driverNode, (int)Math.Ceiling((double)jobNodes.Count / (double)realDriverNodes.Count()));

                    // insert solution only if the solution isn't just the driver going to and from home
                    if (nodeRouteSolution.AllNodes.Count > 2)
                    {
                        solution.RouteSolutions.Add(nodeRouteSolution);

                        // update available nodes based on new solution
                        var selectedIds = nodeRouteSolution.Nodes.Select(p => p.Id).ToList();
                        availableNodes = availableNodes.Where(p => !selectedIds.Contains(p.Id)).ToList();
                    }

                    if (availableNodes.Count == 0) break;
                }
            }
            else
            {
                var previousIds = solution.RouteSolutions.SelectMany(x=>x.Nodes).Select(p => p.Id).ToList();
                availableNodes = availableNodes.Where(p => !previousIds.Contains(p.Id)).ToList();

                lastAvailableNodesCount = availableNodes.Count;
                while (availableNodes.Count > 0)
                {
                    foreach (var driverNode in realDriverNodes)
                    {
                        // get the route solution for this particular driver
                        var nodeRouteSolution = solution.RouteSolutions.FirstOrDefault(x => x.DriverNode.Driver.Id == driverNode.Driver.Id);
                        int indexPosition = solution.RouteSolutions.IndexOf(nodeRouteSolution);

                        if (nodeRouteSolution == null)
                            nodeRouteSolution = new NodeRouteSolution();

                        nodeRouteSolution = AddOrdersToRouteSolution(availableNodes, driverNode, nodeRouteSolution, 2);

                        // insert solution only if the solution isn't just the driver going to and from home
                        if (nodeRouteSolution.AllNodes.Count > 2)
                        {
                            if (indexPosition == -1)
                                solution.RouteSolutions.Add(nodeRouteSolution);
                            else
                                solution.RouteSolutions[indexPosition] = nodeRouteSolution;

                            // update available nodes based on new solution
                            var selectedIds = nodeRouteSolution.Nodes.Select(p => p.Id).ToList();
                            availableNodes = availableNodes.Where(p => !selectedIds.Contains(p.Id)).ToList();
                        }

                        if (availableNodes.Count == 0)
                            break;
                    }

                    if (availableNodes.Count >= lastAvailableNodesCount)
                        break;
                    lastAvailableNodesCount = availableNodes.Count;
                }
            }

            availableNodes = jobNodes.Where(p => !solution.RouteSolutions.SelectMany(x => x.Nodes).Select(y=>y.Id).Contains(p.Id)).ToList();

            // use dummy drivers to generate route solution
            lastAvailableNodesCount = availableNodes.Count;
            while (availableNodes.Count > 0 && !DisallowPlaceholderDriver)
            {
                // Generate a new dummy driver using placeholder driver template
                var dummyDriverNode = new DriverNode(placeholderDriver);

                // get the route solution for this particular driver
                var nodeRouteSolution = GenerateRouteSolution(availableNodes, dummyDriverNode);

                // don't bother if we didn't generate a solution
                if (nodeRouteSolution.Nodes.Count == 0)
                    break;

                // insert solution
                solution.RouteSolutions.Add(nodeRouteSolution);

                // update available nodes based on new solution
                lastAvailableNodesCount = availableNodes.Count;
                availableNodes = availableNodes.Where(n => !nodeRouteSolution.Nodes.Contains(n)).ToList();

                // Exit criteria is when all node are taken or somehow we fail to assign order to placeholder driver
                if (availableNodes.Count == 0 || lastAvailableNodesCount == availableNodes.Count)
                    break;
            }

            // Add unassigned job nodes
            solution.UnassignedJobNodes.Clear();
            solution.UnassignedJobNodes.AddRange(availableNodes);

            // Compute the total plan route statistics
            solution.RouteStatistics = solution.RouteSolutions.Select(x => x.RouteStatistics).Sum();
            
            return solution;
        }

        private IList<INode> FilterJobsByEmptyReturnAndTime(IList<INode> availableNodes, int windowEndTime)
        {
            List<INode> lateEmptyJobs = availableNodes.Where(x => ((JobNode)x).Job.JobTemplateType == JobTemplateType.EmptyReturn && x.WindowEnd.Hours > windowEndTime).ToList();
            availableNodes = availableNodes.Where(a => a.WindowEnd.Hours <= windowEndTime).OrderBy(x=>((JobNode)x).Job.Container).ToList();

            int availableNodesCount = availableNodes.Count;
            for (int i = 0; i < availableNodesCount; i++)
            {
                var earlyNode = availableNodes[i];
                bool foundEquipSize = false;

                if (!string.IsNullOrWhiteSpace(((JobNode)earlyNode).Job.Container))
                {
                    foreach (var emptyJob in lateEmptyJobs)
                    {
                        if (emptyJob.RouteStops[emptyJob.RouteStops.Count - 1].Location.Equals(earlyNode.RouteStops[0].Location) && ((JobNode)earlyNode).Job.Container == ((JobNode)emptyJob).Job.Container)
                        {
                            availableNodes.Add(emptyJob);
                            lateEmptyJobs.Remove(emptyJob);
                            foundEquipSize = true;
                            break;
                        }
                    }
                }

                if (foundEquipSize == false)
                {
                    foreach (var emptyJob in lateEmptyJobs)
                    {
                        if (emptyJob.RouteStops[emptyJob.RouteStops.Count - 1].Location.Equals(earlyNode.RouteStops[0].Location))
                        {
                            availableNodes.Add(emptyJob);
                            lateEmptyJobs.Remove(emptyJob);
                            break;
                        }
                    }
                }
            }

            int randomOrdersToAdd = availableNodesCount * 2 - availableNodes.Count;
            for (int i = 0; i < randomOrdersToAdd; i++)
            {
                if (lateEmptyJobs.Count > 0)
                {
                    int rand = _randomNumberGenerator.Next(lateEmptyJobs.Count - 1);
                    availableNodes.Add(lateEmptyJobs.ElementAt(rand));
                    lateEmptyJobs.RemoveAt(rand);
                }
                else
                    break;
            }

            return availableNodes;
        }

        /// <summary>
        /// Picks a random driver
        /// Then selects an order closest to driver start location
        /// the next order is chosen from the last routestop of the current order
        /// so on and so forth
        /// </summary>
        public virtual Solution ProcessDriversGreedily(IList<DriverNode> driverNodes, Driver placeholderDriver, IList<INode> jobNodes)
        {
            var solution = new Solution();

            if (jobNodes.Count == 0) return solution;

            var availableNodes = jobNodes.ToList();

            _randomNumberGenerator.Reseed(Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value));
            var realDriverNodes = driverNodes.Where(f => f.Driver != placeholderDriver)
                .OrderBy(f => _randomNumberGenerator.Next()); // random sort order

            // going through all the real drivers
            foreach (var driverNode in realDriverNodes)
            {
                List<INode> jobsSortedByDistance = new List<INode>();

                INode closestJob = null;
                TimeSpan fastestTime = TimeSpan.MaxValue;
                var currentAddress = driverNode.Driver.StartingLocation;
                int availableNodesCount = availableNodes.Count + 1;
                for (int i=0; i< availableNodesCount; i++)
                {
                    closestJob = FindClosestJob(currentAddress, availableNodes);

                    //set current address to location of the last route stop
                    currentAddress = closestJob.RouteStops[closestJob.RouteStops.Count - 1].Location;

                    //remove selected closest job from available nodes 
                    availableNodes.Remove(closestJob);
                    jobsSortedByDistance.Add(closestJob);

                    if (availableNodes.Count == 0)
                        break;
                }

                // get the route solution for this particular driver
                var nodeRouteSolution = new NodeRouteSolution();
                nodeRouteSolution = GenerateRouteSolution(jobsSortedByDistance, driverNode);

                // insert solution only if the solution isn't just the driver going to and from home
                if (nodeRouteSolution.AllNodes.Count > 2)
                {
                    solution.RouteSolutions.Add(nodeRouteSolution);
                }

                // update available nodes based on new solution
                var selectedIds = new HashSet<int>(nodeRouteSolution.Nodes.Select(p => p.Id));
                availableNodes = jobsSortedByDistance.Where(p => !selectedIds.Contains(p.Id)).ToList();

                if (availableNodes.Count == 0) break;
            }

            // use dummy drivers to generate route solution
            int lastAvailableNodesCount = availableNodes.Count;
            while (availableNodes.Count > 0 && !DisallowPlaceholderDriver)
            {
                // Generate a new dummy driver using placeholder driver template
                var dummyDriverNode = new DriverNode(placeholderDriver);

                // get the route solution for this particular driver
                var nodeRouteSolution = GenerateRouteSolution(availableNodes, dummyDriverNode);

                // don't bother if we didn't generate a solution
                if (nodeRouteSolution.Nodes.Count == 0)
                    break;

                // insert solution
                solution.RouteSolutions.Add(nodeRouteSolution);

                // update available nodes based on new solution
                lastAvailableNodesCount = availableNodes.Count;
                availableNodes = availableNodes.Where(n => !nodeRouteSolution.Nodes.Contains(n)).ToList();

                // Exit criteria is when all node are taken or somehow we fail to assign order to placeholder driver
                if (availableNodes.Count == 0 || lastAvailableNodesCount == availableNodes.Count)
                    break;
            }

            // Add unassigned job nodes
            solution.UnassignedJobNodes.AddRange(availableNodes);

            // Compute the total plan route statistics
            solution.RouteStatistics = solution.RouteSolutions.Select(x => x.RouteStatistics).Sum();

            return solution;
        }

        /// <summary>
        /// Picks a random driver
        /// picks an order closest to the driver
        /// then selects all of the order with the same location
        /// if there are more feasible orders to add AFTER all the order, then add it based on order distance
        /// </summary>
        public virtual Solution ProcessDriversGreedilyTwo(IList<DriverNode> driverNodes, Driver placeholderDriver, IList<INode> jobNodes)
        {
            Dictionary<int, List<INode>> driversJobs = new Dictionary<int, List<INode>>();

            var solution = new Solution();

            if (jobNodes.Count == 0) return solution;

            var availableNodes = jobNodes.ToList();

            _randomNumberGenerator.Reseed(Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value));
            var realDriverNodes = driverNodes.Where(f => f.Driver != placeholderDriver)
                .OrderBy(f => _randomNumberGenerator.Next()); // random sort order

            while (availableNodes.Count > 0)
            {
                // going through all the real drivers
                foreach (var driverNode in realDriverNodes)
                {
                    List<INode> jobsForDriver = null;
                    Model.Location currentAddress = null;

                    if (driversJobs.ContainsKey(driverNode.Id))
                    {
                        jobsForDriver = driversJobs[driverNode.Id];
                        var tempLastJob = jobsForDriver.Last();
                        currentAddress = tempLastJob.RouteStops[tempLastJob.RouteStops.Count-1].Location;
                    }
                    else
                    {
                        jobsForDriver = new List<INode>();
                        currentAddress = driverNode.Driver.StartingLocation;
                    }

                    INode closestJob = FindClosestJob(currentAddress, availableNodes);

                    //set current address to location of the last route stop
                    currentAddress = closestJob.RouteStops[closestJob.RouteStops.Count - 1].Location;

                    //remove selected closest job from available nodes 
                    availableNodes.Remove(closestJob);
                    jobsForDriver.Add(closestJob);

                    for (int i = availableNodes.Count - 1; i >= 0; i--)
                    {
                        var job = availableNodes[i];

                        //no need for a real date since all we care about is distance.
                        var distance = _distanceService.CalculateDistance(currentAddress, job.RouteStops[0].Location, DateTime.Now, false);
                        if (distance.Distance < 0.001)
                        {
                            jobsForDriver.Add(job);
                            availableNodes.RemoveAt(i);
                        }
                    }

                    driversJobs[driverNode.Id] = jobsForDriver;

                    if (availableNodes.Count == 0)
                        break;
                }
            }

            bool feasibleNodesExist = true;

            while (feasibleNodesExist)
            {
                List<int> availableNodeIds = availableNodes.Select(x=>x.Id).ToList();
                foreach (var driverNode in realDriverNodes)
                {
                    List<INode> jobsForDriver = null;

                    if (driversJobs.ContainsKey(driverNode.Id))
                        jobsForDriver = driversJobs[driverNode.Id];
                    else
                        jobsForDriver = new List<INode>();

                    if (availableNodes.Count > 0)
                    {
                        Model.Location currentAddress = null;
                        if (jobsForDriver.Count > 0)
                        {
                            var tempLastJob = jobsForDriver.Last();
                            currentAddress = tempLastJob.RouteStops[tempLastJob.RouteStops.Count - 1].Location;
                        }
                        else
                        {
                            currentAddress = driverNode.Driver.StartingLocation;
                        }

                        INode closestJob = FindClosestJob(currentAddress, availableNodes);

                        //set current address to location of the last route stop
                        currentAddress = closestJob.RouteStops[closestJob.RouteStops.Count - 1].Location;

                        availableNodes.Remove(closestJob);
                        jobsForDriver.Add(closestJob);

                        //now find any jobs in the same location and add to the driversJob
                        for (int i = availableNodes.Count - 1; i >= 0; i--)
                        {
                            var job = availableNodes[i];

                            //no need for a real date since all we care about is distance.
                            var distance = _distanceService.CalculateDistance(currentAddress, job.RouteStops[0].Location, DateTime.Now, false);
                            if (distance.Distance < 0.001)
                            {
                                jobsForDriver.Add(job);
                                availableNodes.RemoveAt(i);
                            }
                        }
                    }

                    // get the route solution for this particular driver
                    var nodeRouteSolution = new NodeRouteSolution();
                    nodeRouteSolution = GenerateRouteSolution(jobsForDriver, driverNode);

                    //cant have duplicates from previous iterations
                    var removeSolution = solution.RouteSolutions.FirstOrDefault(x => x.DriverNode.Id == driverNode.Id);
                    if(removeSolution != null)
                        solution.RouteSolutions.Remove(removeSolution);

                    // insert solution only if the solution isn't just the driver going to and from home
                    if (nodeRouteSolution.AllNodes.Count > 2)
                    {
                        solution.RouteSolutions.Add(nodeRouteSolution);
                    }

                    // update available nodes based on new solution
                    var selectedIds = new HashSet<int>(nodeRouteSolution.Nodes.Select(p => p.Id));
                    availableNodes.AddRange(jobsForDriver.Where(p => !selectedIds.Contains(p.Id)).ToList());

                    driversJobs[driverNode.Id] = jobsForDriver.Where(p => selectedIds.Contains(p.Id)).ToList();
                }

                //only loop again if we see that nodes are being taken, meaning feasible nodes
                if (availableNodes.Select(x=> x.Id).Except(availableNodeIds).Count() == 0 || availableNodes.Count == 0)
                    feasibleNodesExist = false;
            }

            // use dummy drivers to generate route solution
            int lastAvailableNodesCount = availableNodes.Count;
            while (availableNodes.Count > 0 && !DisallowPlaceholderDriver)
            {
                // Generate a new dummy driver using placeholder driver template
                var dummyDriverNode = new DriverNode(placeholderDriver);

                // get the route solution for this particular driver
                var nodeRouteSolution = GenerateRouteSolution(availableNodes, dummyDriverNode);

                // don't bother if we didn't generate a solution
                if (nodeRouteSolution.Nodes.Count == 0)
                    break;

                // insert solution
                solution.RouteSolutions.Add(nodeRouteSolution);

                // update available nodes based on new solution
                lastAvailableNodesCount = availableNodes.Count;
                availableNodes = availableNodes.Where(n => !nodeRouteSolution.Nodes.Contains(n)).ToList();

                // Exit criteria is when all node are taken or somehow we fail to assign order to placeholder driver
                if (availableNodes.Count == 0 || lastAvailableNodesCount == availableNodes.Count)
                    break;
            }

            // Add unassigned job nodes
            solution.UnassignedJobNodes.AddRange(availableNodes);

            // Compute the total plan route statistics
            solution.RouteStatistics = solution.RouteSolutions.Select(x => x.RouteStatistics).Sum();

            return solution;
        }

        /// <summary>
        /// Finds the closest job in the availableNodes from the currentAddress
        /// </summary>
        private INode FindClosestJob(Model.Location currentAddress, List<INode> availableNodes)
        {
            TimeSpan fastestTime = TimeSpan.MaxValue;
            INode closestJob = null;

            if (availableNodes != null)
            {
                foreach (var job in availableNodes)
                {
                    if (currentAddress != job.RouteStops[0].Location)
                    {
                        //no need for a real date since all we care about is distance.
                        var distance = _distanceService.CalculateDistance(currentAddress, job.RouteStops[0].Location, DateTime.Now, false);
                        if (distance.Time < fastestTime)
                        {
                            closestJob = job;
                            fastestTime = distance.Time;
                        }
                    }
                }
            }

            return closestJob;
        }

        private INode SelectColocatedNode(INode currentNode, IList<NodeTiming> feasibleNodes)
        {
            return feasibleNodes.Where(timing =>
            {
                var node = (NodeBase)timing.Node;
                var nodeStop = node.RouteStops.FirstOrDefault();
                var currentNodeStop = ((NodeBase)currentNode).RouteStops.LastOrDefault();
                if (nodeStop != null && currentNodeStop != null)
                {
                    return nodeStop.Location.Equals(currentNodeStop.Location); //&& timing.CumulativeRouteStatistics.TotalIdleTime == TimeSpan.Zero;
                }
                return false;
            }).Select(x => x.Node).FirstOrDefault();
        }

        private INode SelectColocatedAndSameContainerNode(INode currentNode, IList<NodeTiming> feasibleNodes)
        {
            return feasibleNodes.Where(timing =>
            {
            var node = (NodeBase)timing.Node;
            var nodeStop = node.RouteStops.FirstOrDefault();
            var currentNodeStop = ((NodeBase)currentNode).RouteStops.LastOrDefault();
            if (nodeStop != null && currentNodeStop != null)
            {
                if (currentNode is DriverNode)
                    return nodeStop.Location.Equals(currentNodeStop.Location);
                else
                    return nodeStop.Location.Equals(currentNodeStop.Location) && ((JobNode)currentNode).Job.Container == ((JobNode)node).Job.Container;
                }
                return false;
            }).Select(x => x.Node).FirstOrDefault();
        }

        /// <summary>
        /// Generates node sequence iteration
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="driverNode"> </param>
        /// <returns></returns>
        public virtual NodeRouteSolution GenerateRouteSolution(IList<INode> nodes, DriverNode driverNode, int? maxJobsToAccept = null)
        {
            IList<INode> processedNodes = new List<INode>();
            INode currentNode = driverNode;
            var startTime = driverNode.WindowStart;
            var currentNodeEndTime = startTime;
            var currentStatistics = new RouteStatistics();
            IList<RouteSegmentStatistics> finalRouteSegmentStatistics = null;

            int exitCounter = 0;
            while (exitCounter++ < 1000)
            {
                // Pick nodes that is not being processed yet
                nodes = nodes.Where(x => !processedNodes.Select(y => y.Id).ToList().Contains(x.Id)).ToList();

                // getting avaiable nodes that have not been processed
                if (!nodes.Any())
                {
                    break;
                }

                // getting avaiable nodes that have not been processed
                var feasibleNodeTimings = GetFeasibleNodes(nodes, driverNode, processedNodes, currentNodeEndTime, currentStatistics);
                if (!feasibleNodeTimings.Any())
                {
                    break;
                }

                var feasibleNodeTimingsByNode = feasibleNodeTimings.ToDictionary(f => f.Node);

                // build probability matrix for the available nodes
                var probabilityData = _probabilityMatrix.BuildProbabilityDataMatrix(currentNode, feasibleNodeTimings, UseTraffic);

                // find a suitable node based on the cumulative probability
                var selectedNode = SelectColocatedAndSameContainerNode(currentNode, feasibleNodeTimings) ?? SelectColocatedNode(currentNode, feasibleNodeTimings) ??
                    FindClosestJob(currentNode.RouteStops[currentNode.RouteStops.Count - 1].Location, feasibleNodeTimings.Select(x => x.Node).ToList()) ??
                    (INode)_probabilityMatrix.GetNominatedElement(probabilityData);

                //var selectedNode = feasibleNodeTimings[0].Node;
                selectedNode.DepartureTime = feasibleNodeTimingsByNode[selectedNode].DepartureTime; // set the Departure Time
                
                // break if we nominated the driver node
                if (selectedNode == driverNode)
                {
                    break;
                }

                currentNode = selectedNode;

                // now we update the current node's end time
                var selectedNodeTiming = feasibleNodeTimingsByNode[selectedNode];

                currentNodeEndTime = selectedNodeTiming.EndExecutionTime;
                //cumulativeRouteStatistics = selectedNodeTiming.CumulativeRouteStatistics;


                // Phase 2:
                // We take all the node solution so far and we build ONE job with all the nodes
                var processedRouteStops = processedNodes.SelectMany(x => x.RouteStops);
                var provisionalRouteStops = new Queue<RouteStop>();
                var driverStartAndEndNode = driverNode.RouteStops.FirstOrDefault();
                provisionalRouteStops.Enqueue(driverStartAndEndNode);  // Add the head (driver start)

                // Add everything flatten from previous selected
                foreach (var processedRouteStop in processedRouteStops)
                {
                    provisionalRouteStops.Enqueue(processedRouteStop);
                }

                // Add everything from the current selected
                foreach (var routeStop in selectedNode.RouteStops)
                {
                    provisionalRouteStops.Enqueue(routeStop);
                }

                //TODO remove this later
                //provisionalRouteStops.Enqueue(driverStartAndEndNode); // Add the tail (driver end)

                var segmentStatistics = _routeStopService.CalculateRouteSegmentStatistics(startTime, provisionalRouteStops.ToList(), UseTraffic);
                if (segmentStatistics.All(x => x.IsFeasible && x.Violations == Violations.None))
                {
                    var totalStatistics = _routeStopService.CalculateTotalStatistics(segmentStatistics);
                    if (!_routeExitFunction.ExceedsExitCriteria(totalStatistics, driverNode.Driver))
                    {
                        processedNodes.Add(selectedNode);
                        finalRouteSegmentStatistics = segmentStatistics;
                        currentStatistics = totalStatistics;
                    }
                }

                if (driverNode.Driver.IsPlaceHolderDriver && !processedNodes.Contains(selectedNode))
                {
                    processedNodes.Add(selectedNode);
                }

                if (processedNodes.Count == 2)
                    break;
            }
            
            var result = new NodeRouteSolution
            {
                DriverNode = driverNode,
                Nodes = processedNodes.ToList(),
                StartTime = startTime,
                RouteStatistics = currentStatistics,
                RouteSegmentStatistics = finalRouteSegmentStatistics
            };

            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="driverNode"></param>
        /// <param name="solutionToUpdate"></param>
        /// <returns></returns>
        public virtual NodeRouteSolution AddOrdersToRouteSolution(IList<INode> nodes, DriverNode driverNode, NodeRouteSolution solutionToUpdate, int amountToAdd)
        {
            IList<INode> processedNodes = solutionToUpdate.Nodes;
            INode currentNode = null;
            var startTime = driverNode.WindowStart;
            TimeSpan currentNodeEndTime;
            var currentStatistics = solutionToUpdate.RouteStatistics;
            IList<RouteSegmentStatistics> finalRouteSegmentStatistics = solutionToUpdate.RouteSegmentStatistics;

            if(solutionToUpdate.Nodes.Count == 0)
            {
                currentNode = driverNode;
                currentNodeEndTime = driverNode.WindowStart;
            }
            else
            {
                currentNode = solutionToUpdate.Nodes[solutionToUpdate.Nodes.Count - 1];
                currentNodeEndTime = solutionToUpdate.RouteSegmentStatistics[solutionToUpdate.RouteSegmentStatistics.Count - 1].EndTime;
            }

            int previousJobCount = solutionToUpdate.Nodes.Count;

            int exitCounter = 0;
            while (exitCounter++ < 1000)
            {
                // Pick nodes that is not being processed yet
                nodes = nodes.Where(x => !processedNodes.Select(y => y.Id).ToList().Contains(x.Id)).ToList();

                // getting avaiable nodes that have not been processed
                if (!nodes.Any())
                {
                    break;
                }

                // getting avaiable nodes that have not been processed
                var feasibleNodeTimings = GetFeasibleNodes(nodes, driverNode, processedNodes, currentNodeEndTime, currentStatistics);
                if (!feasibleNodeTimings.Any())
                {
                    break;
                }

                var feasibleNodeTimingsByNode = feasibleNodeTimings.ToDictionary(f => f.Node);

                // build probability matrix for the available nodes
                var probabilityData = _probabilityMatrix.BuildProbabilityDataMatrix(currentNode, feasibleNodeTimings, UseTraffic);

                // find a suitable node based on the cumulative probability
                var selectedNode = SelectColocatedAndSameContainerNode(currentNode, feasibleNodeTimings) ?? SelectColocatedNode(currentNode, feasibleNodeTimings) ??
                    FindClosestJob(currentNode.RouteStops[currentNode.RouteStops.Count - 1].Location, feasibleNodeTimings.Select(x => x.Node).ToList()) ??
                    (INode)_probabilityMatrix.GetNominatedElement(probabilityData);
                //var selectedNode = feasibleNodeTimings[0].Node;

                selectedNode.DepartureTime = feasibleNodeTimingsByNode[selectedNode].DepartureTime; // set the Departure Time

                // break if we nominated the driver node
                if (selectedNode == driverNode)
                {
                    break;
                }

                currentNode = selectedNode;

                // now we update the current node's end time
                var selectedNodeTiming = feasibleNodeTimingsByNode[selectedNode];

                currentNodeEndTime = selectedNodeTiming.EndExecutionTime;
                //cumulativeRouteStatistics = selectedNodeTiming.CumulativeRouteStatistics;


                // Phase 2:
                // We take all the node solution so far and we build ONE job with all the nodes
                var processedRouteStops = processedNodes.SelectMany(x => x.RouteStops);
                var provisionalRouteStops = new Queue<RouteStop>();
                var driverStartAndEndNode = driverNode.RouteStops.FirstOrDefault();
                provisionalRouteStops.Enqueue(driverStartAndEndNode);  // Add the head (driver start)

                // Add everything flatten from previous selected
                foreach (var processedRouteStop in processedRouteStops)
                {
                    provisionalRouteStops.Enqueue(processedRouteStop);
                }

                // Add everything from the current selected
                foreach (var routeStop in selectedNode.RouteStops)
                {
                    provisionalRouteStops.Enqueue(routeStop);
                }

                //TODO remove this later
                //provisionalRouteStops.Enqueue(driverStartAndEndNode); // Add the tail (driver end)

                var segmentStatistics = _routeStopService.CalculateRouteSegmentStatistics(startTime, provisionalRouteStops.ToList(), UseTraffic);
                if (segmentStatistics.All(x => x.IsFeasible && x.Violations == Violations.None))
                {
                    var totalStatistics = _routeStopService.CalculateTotalStatistics(segmentStatistics);
                    if (!_routeExitFunction.ExceedsExitCriteria(totalStatistics, driverNode.Driver))
                    {
                        processedNodes.Add(selectedNode);
                        finalRouteSegmentStatistics = segmentStatistics;
                        currentStatistics = totalStatistics;
                    }
                }

                if (driverNode.Driver.IsPlaceHolderDriver)
                {
                    processedNodes.Add(selectedNode);
                }

                //TODO Remove this
                if (processedNodes.Count == previousJobCount + amountToAdd)
                    break;
            }

            solutionToUpdate.DriverNode = driverNode;
            solutionToUpdate.Nodes = processedNodes.ToList();
            solutionToUpdate.StartTime = startTime;
            solutionToUpdate.RouteStatistics = currentStatistics;
            solutionToUpdate.RouteSegmentStatistics = finalRouteSegmentStatistics;

            return solutionToUpdate;
        }


        /// <summary>
        /// Reevaluation of CumulativeStatistic for solution nodes so far.  This include the driver nodes as well
        /// </summary>
        /// <param name="driverNode"></param>
        /// <param name="jobNodes"></param>
        /// <param name="startTime"></param>
        /// <returns></returns>
        public NodeRouteSolution RecalculateRouteSolution(DriverNode driverNode, IList<INode> jobNodes, TimeSpan startTime)
        {
            var allRouteStops = new Queue<RouteStop>();
            var driverStartAndEndNode = driverNode.RouteStops.FirstOrDefault();
            allRouteStops.Enqueue(driverStartAndEndNode);  // Add the head (driver start)

            // Flatten all the route stops
            var flattenStops = jobNodes.SelectMany(x => x.RouteStops);
            foreach (var flattenStop in flattenStops)
            {
                allRouteStops.Enqueue(flattenStop); // Add all the flatten job nodes
            }
            
            allRouteStops.Enqueue(driverStartAndEndNode); // Add the tail (driver end)

            var tempJob = new Job
            {
                RouteStops = allRouteStops.Select(x => x).ToList()
            };

            // Compute all the timing and statistics using the route matrix
            var allRouteSegmentStatistics = _routeStopService.CalculateRouteSegmentStatistics(startTime,
                allRouteStops.ToList(), UseTraffic);
            
            // Our current matrix doesn't support constraint check against duty hour so for now we have
            // to check against this separately.
            var routeStatSoFar = new RouteStatistics();
            foreach (var routeSegmentStatistics in allRouteSegmentStatistics)
            {
                // Set the feasibility of the node based on the driving & duty time limit
                // In here we need to tally each route stat for total driving and duty time
                routeStatSoFar += routeSegmentStatistics.Statistics;
                routeSegmentStatistics.IsFeasible &= !_routeExitFunction.ExceedsExitCriteria(routeStatSoFar, driverNode.Driver);
                if (_routeExitFunction.ExceedsExitCriteria(routeStatSoFar, driverNode.Driver))
                    routeSegmentStatistics.Violations |= Violations.ExceedsExitCriteria;

            }

            var routeSegmentIndex = 0;
            foreach (var jobNode in jobNodes)
            {
                foreach (var routeStop in jobNode.RouteStops)
                {
                    var routeStatistic = allRouteSegmentStatistics[routeSegmentIndex];
                    routeStatistic.IsFeasible &= PassesFilterCriteria(driverNode, (JobNode)jobNode);
                    routeStatistic.Violations |= PassesFilterCriteriaForViolations(driverNode, (JobNode)jobNode);
                    routeSegmentIndex++;
                }
            }

            return new NodeRouteSolution
            {
                DriverNode = driverNode,
                Nodes = jobNodes,
                StartTime = startTime,
                RouteStatistics = _routeStopService.CalculateTotalStatistics(allRouteSegmentStatistics),
                RouteSegmentStatistics = allRouteSegmentStatistics
            };

        }

        public IList<int> GetInfeasibleJobIds(IList<Job> jobs, Driver driver)
        {

            // Create and calculate node timing from all the node starting with the driver
            List<NodeTiming> nodeTimings;
            IList<int> resultId = new List<int>();
            ComputeJobNodeTimings(jobs, driver, out nodeTimings, out resultId);


            return resultId;
        }

        public bool ComputeJobNodeTimings(IList<Job> jobs, Driver driver, out List<NodeTiming> nodeTimings, out IList<int> inFeasibleJobIds)
        {
            nodeTimings = new List<NodeTiming>();
            inFeasibleJobIds = new List<int>();
            if (driver == null || jobs == null || !jobs.Any())
            {
                {
                    return false;
                }
            }

            var jobNodes = jobs.Select((job, i) => _jobNodeService.CreateJobNode(job, false, i != 0)).Cast<INode>().ToList();
            var driverNode = new DriverNode(driver);
            var processedNodes = new List<INode>();
            var cumulativeRouteStatistics = new RouteStatistics();

            //var routeSolution = GenerateRouteSolution(jobNodes, driverNode);

            //GetFeasibleNodes(jobNodes, driverNode, processedNodes, )
            //var isFirstStop = processedNodes.Count == 0;
            //var currentNode = isFirstStop ? driverNode : processedNodes.Last();

            // first check feasibility for driver to first node
            var nodeTimingResult = _routeStatisticsService.GetNodeTiming(
                driverNode, jobNodes.FirstOrDefault(), driverNode.WindowStart, UseTraffic, cumulativeRouteStatistics);


            nodeTimings = new List<NodeTiming> {nodeTimingResult};

            for (int i = 1; i < jobNodes.Count; i++)
            {
                var currentNode = (JobNode) jobNodes[i];
                var lastNode = jobNodes[i - 1];
                var iterationStartTime = nodeTimingResult.EndExecutionTime;

                nodeTimingResult = _routeStatisticsService.GetNodeTiming(
                    lastNode, currentNode, iterationStartTime, UseTraffic, cumulativeRouteStatistics);

                nodeTimingResult.CumulativeRouteStatistics = cumulativeRouteStatistics + nodeTimingResult.CumulativeRouteStatistics;

                if (_routeExitFunction.ExceedsExitCriteria(nodeTimingResult.CumulativeRouteStatistics, driverNode.Driver))
                {
                    nodeTimingResult.IsFeasableTimeWindow = false;
                    inFeasibleJobIds.Add(currentNode.Job.Id);
                }

                nodeTimings.Add(nodeTimingResult);
            }

            var lastLeg = _routeStatisticsService.GetRouteStatistics(nodeTimingResult.Node, driverNode, nodeTimingResult.EndExecutionTime, UseTraffic);
            var finalRouteStatistics = nodeTimingResult.CumulativeRouteStatistics + lastLeg;
            if (_routeExitFunction.ExceedsExitCriteria(finalRouteStatistics, driverNode.Driver))
            {
                nodeTimingResult.IsFeasableTimeWindow = false;
            }

            nodeTimings.Add(nodeTimingResult);

            return true;
        }

        private bool IsExecutionTimeIgnored(INode currentStop, INode nextStop)
        {
            try
            {
                var start = currentStop.RouteStops.LastOrDefault();
                var end = nextStop.RouteStops.FirstOrDefault();

                if (start != null && end != null)
                {
                    if ((start.Location.DisplayName == end.Location.DisplayName) ||
                        (start.Location.Latitude == end.Location.Latitude &&
                         start.Location.Longitude == end.Location.Longitude))
                    {
                        return true;
                    }
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }

            return false;
        }

        private bool PassTagCriteria(JobNode jobNode, DriverNode driverNode)
        {
            var jobNodeTag = string.IsNullOrEmpty(jobNode.Job.Tags)
                ? new string[0]
                : jobNode.Job.Tags.Split(',');

            var driverTags = string.IsNullOrEmpty(driverNode.Driver.Tags) ? new string[0] : driverNode.Driver.Tags.Split(',');

            // If job doesn't have any tag whatsoever, then it's always successful.
            if (jobNodeTag.Any())
            {
                
                var tagMatched = jobNodeTag.All(jobTag => driverTags.Contains(jobTag, _noCaseComparer));
                return tagMatched;
            }
            //retrun true if jobNodeTag has no tags
            return true;
        }
        private Violations PassTagCriteriaForViolations(JobNode jobNode, DriverNode driverNode)
        {
            if (PassTagCriteria(jobNode, driverNode))
                return Violations.None;
            return Violations.Tag;
        }

        private bool PassesFilterCriteria(DriverNode driverNode, JobNode jobNode)
        {
            if (!driverNode.Driver.IsHazmat && jobNode.Job.IsHazmat)
            {
                return false;
            }

            if (!driverNode.Driver.IsFlatbed && jobNode.Job.IsFlatbed)
            {
                return false;
            }

            if (driverNode.Driver.Priority < jobNode.Job.Priority)
            {
                return false;
            }
            if (jobNode.Job.AssignedDriverId.HasValue && jobNode.Job.AssignedDriverId != driverNode.Id && !driverNode.Driver.IsPlaceHolderDriver)
            {
                return false;
            }

            return PassTagCriteria(jobNode, driverNode);

        }

        private Violations PassesFilterCriteriaForViolations(DriverNode driverNode, JobNode jobNode)
        {
            Violations violations = Violations.None;
            if (!driverNode.Driver.IsHazmat && jobNode.Job.IsHazmat)
            {
                violations |= Violations.Hazmat;
            }

            if (!driverNode.Driver.IsFlatbed && jobNode.Job.IsFlatbed)
            {
                violations |= Violations.Flatbed;
            }

            if (driverNode.Driver.Priority < jobNode.Job.Priority)
            {
                violations |= Violations.Priority;
            }
            if (jobNode.Job.AssignedDriverId.HasValue && jobNode.Job.AssignedDriverId != driverNode.Id)
            {
                violations |= Violations.AssignedDriver;
            }

            violations |= PassTagCriteriaForViolations(jobNode, driverNode);

            return violations;

        }

        public virtual List<NodeTiming> GetFeasibleNodes(IList<INode> availableNodes, DriverNode driverNode, IList<INode> processedNodes,
            TimeSpan currentNodeEndTime, RouteStatistics cumulativeRouteStatistics)
        {
            var isFirstStop = (processedNodes.Count == 0);
            var currentNode = isFirstStop ? driverNode : processedNodes.Last();

            var filteredAvailableNodes = new List<INode>();

            var updatedNodes = new List<INode>();
            if (currentNode is JobNode)
            {
                // update nodes to adjust for potentially shortened execution time
                foreach (var n in availableNodes)
                {
                    if (n is JobNode)
                    {
                        var node = _jobNodeService.CreateJobNode(((JobNode) n).Job, false, IsExecutionTimeIgnored(currentNode, n));
                        updatedNodes.Add(node);
                    }
                    else
                    {
                        updatedNodes.Add(n);
                    }
                }

                availableNodes = updatedNodes.ToList();
            }

            // filter available nodes based on predefined criteria
            foreach (var availableNode in availableNodes)
            {
                if (availableNode is JobNode)
                {
                    if (PassesFilterCriteria(driverNode, (JobNode) availableNode))
                    {
                        filteredAvailableNodes.Add(availableNode);
                    }
                    else
                    {
                        ;
                    }
                }
                else
                {
                    filteredAvailableNodes.Add(availableNode);  // we are only filtering JobNodes
                }
            }

            availableNodes = filteredAvailableNodes.ToList();

            // get the node timings for all of the available nodes
            var unprocessedNodes = availableNodes.Where(x => !processedNodes.Select(y => y.Id).ToList().Contains(x.Id));

            unprocessedNodes = new List<INode>();
            foreach (var availableNode in availableNodes)
            {
                var processedNodesIds = processedNodes.Select(x => x.Id);
                if (!processedNodesIds.Contains(availableNode.Id))
                {
                    unprocessedNodes = unprocessedNodes.Concat(new List<INode> {availableNode});
                }
            }

            var nodeTimings = unprocessedNodes.Select(nextNode => 
                _routeStatisticsService.GetNodeTiming(currentNode, nextNode, currentNodeEndTime, UseTraffic, cumulativeRouteStatistics));
                
            var feasibleNodes = new List<NodeTiming>();
            
            foreach (var nodeTiming in nodeTimings.Where(f => f.IsFeasableTimeWindow))
            {
                // calculate for return home to driver node
                var lastLeg = _routeStatisticsService.GetRouteStatistics(nodeTiming.Node, driverNode, nodeTiming.EndExecutionTime, UseTraffic);
                var finalRouteStatistics = nodeTiming.CumulativeRouteStatistics + lastLeg;

                if (!_routeExitFunction.ExceedsExitCriteria(finalRouteStatistics, driverNode.Driver))
                {
                    feasibleNodes.Add(nodeTiming);
                }
            }

            return feasibleNodes;
        }
    }


    public class CompareNoCaseComparer : IEqualityComparer<string>
    {
        public bool Equals(string x, string y)
        {
            return string.Compare(x, y, StringComparison.CurrentCultureIgnoreCase) == 0;
        }

        public int GetHashCode(string obj)
        {
            return obj.GetHashCode();
        }
    }
}