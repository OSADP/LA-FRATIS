using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public interface IRouteStopDelayService
    {
        /// <summary>
        /// Gets the execution time considering the previous routestop
        /// </summary>
        /// <param name="previousRouteStop"></param>
        /// <param name="routeStop"></param>
        /// <param name="timeOfDay"></param>
        /// <returns></returns>
        TimeSpan GetExecutionTime(RouteStop routeStop, TimeSpan timeOfDay);

        TimeSpan GetExecutionTime(RouteStop previousRouteStop, RouteStop routeStop, TimeSpan timeOfDay);

        /// <summary>Gets the queue time for  the given <see cref="RouteStop"/></summary>
        /// <param name="startStop">Comment</param>
        /// <param name="endStop">The end Stop.</param>
        /// <param name="timeOfDay"></param>
        /// <returns></returns>
        TimeSpan GetQueueTime(RouteStop startStop, RouteStop endStop, TimeSpan timeOfDay);

        void SetLocationQueueDelays(List<LocationQueueDelay> delays);
    }
}