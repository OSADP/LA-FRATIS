using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>The DrayageOptimizer interface.</summary>
    public interface IDrayageOptimizer
    {
        /// <summary>The progress changed event handler for the Drayage / Route Optimization iterations</summary>
        event EventHandler<ProgressEventArgs> ProgressChanged;

        /// <summary>Gets or sets a value indicating whether parallelism is enabled.</summary>
        bool EnableParallelism { get; set; }

        /// <summary>Gets or sets the pheromone update frequency.</summary>
        int PheromoneUpdateFrequency { get; set; }

        /// <summary>Gets or sets the max iterations.</summary>
        int MaxIterations { get; set; }

        /// <summary>Gets or sets the max iteration since best result.</summary>
        int MaxIterationSinceBestResult { get; set; }

        /// <summary>Gets or sets the max execution time.</summary>
        int MaxExecutionTime { get; set; }

        Solution CurrentBestSolution { get; set; }

        bool DisallowPlaceholderDriver { get; set; }
        bool FlexibleStartTime { get; set; }
        bool UseTraffic { get; set; }

        /// <summary>
        /// Builds a solution using the Optimization Algorithm for 
        /// the provided drivers and jobs.
        /// </summary>
        /// <param name="drivers">The drivers.</param>
        /// <param name="defaultDriver">The default driver.</param>
        /// <param name="jobs">The jobs.</param>
        /// <returns>The <see cref="Solution"/>.</returns>
        Solution BuildSolution(IList<Driver> drivers, Driver defaultDriver, IList<Job> jobs);

        /// <summary>
        /// Solution Updated Event
        /// </summary>
        event EventHandler<SolutionEventArgs> SolutionUpdated;

        /// <summary>
        /// Gets a list of Infeasible Jobs Ids considering travel time / window feasibility
        /// </summary>
        /// <param name="jobs"></param>
        /// <param name="driver"></param>
        /// <returns></returns>
        IList<int> GetInfeasibleJobIds(IList<Job> jobs, Driver driver);

        bool ComputeJobNodeTimings(IList<Job> jobs, Driver driver, out List<NodeTiming> nodeTimings, out IList<int> inFeasibleJobIds);

        NodeRouteSolution RecalculateRouteSolution(DriverNode driverNode, IList<INode> jobNodes, TimeSpan startTime);

    }
}