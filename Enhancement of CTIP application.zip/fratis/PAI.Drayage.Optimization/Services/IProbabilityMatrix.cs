﻿using System.Collections.Generic;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Services
{
    public interface IProbabilityMatrix
    {
        /// <summary>
        /// Returns list of probability data
        /// </summary>
        /// <param name="currentNode"></param>
        /// <param name="availableNodeTimings"> </param>
        /// <returns></returns>
        IList<ProbabilityItem> BuildProbabilityDataMatrix(INode currentNode, IEnumerable<NodeTiming> availableNodeTimings, bool useTraffic);

        /// <summary>
        /// Calculates the probabilities for a list of <see cref="ProbabilityItem"/>
        /// </summary>
        /// <param name="probabilityDataList"></param>
        void CalculateProbabilities(IList<ProbabilityItem> probabilityDataList);

        /// <summary>
        /// Nomiate node from probability data
        /// </summary>
        /// <param name="probabilityData"></param>
        /// <returns></returns>
        object GetNominatedElement(IList<ProbabilityItem> probabilityData);
    }
}