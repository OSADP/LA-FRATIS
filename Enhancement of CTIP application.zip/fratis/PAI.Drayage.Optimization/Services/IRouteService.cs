using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public interface IRouteService
    {
        ///// <summary>
        ///// Creates a route solution from a list of nodes
        ///// </summary>
        ///// <param name="nodes"></param>
        ///// <returns></returns>
        NodeRouteSolution CreateRouteSolution(DriverNode driverNode, IEnumerable<INode> nodes, bool useTraffic);

        ///// <summary>
        ///// Gets the best solution between a new list of <see cref="INode"/> and a current best <see cref="NodeRouteSolution"/>
        ///// </summary>
        ///// <param name="nodes"></param>
        ///// <param name="driverNode"> </param>
        ///// <param name="bestSolution"></param>
        ///// <returns>the best solution</returns>
        NodeRouteSolution GetBestFeasableSolution(IEnumerable<INode> nodes, DriverNode driverNode, bool useTraffic, NodeRouteSolution bestSolution);
        
        /// <summary>
        /// Gets a list of <see cref="RouteStop"/> for the given <see cref="NodeRouteSolution"/>
        /// </summary>
        /// <param name="routeSolution"></param>
        /// <returns></returns>
        IList<RouteStop> GetRouteStopsForRouteSolution(NodeRouteSolution routeSolution);        
        [Obsolete("Use IRouteStatisticsComparer")]
        NodeRouteSolution GetBestSolution(NodeRouteSolution left, NodeRouteSolution right);

        [Obsolete("Use IRouteStatisticsComparer")]
        Solution GetBestSolution(Solution left, Solution right);
    }
}