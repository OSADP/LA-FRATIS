using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Services
{
    public interface IPheromoneMatrix
    {
        /// <summary>
        /// Gets or sets the initial pheromone value
        /// </summary>
        double InitialPheromoneValue { get; set; }

        /// <summary>
        /// Gets or sets the pheromone evaporation rate
        /// </summary>
        double Rho { get; set; }

        /// <summary>
        /// Gets or sets the performance measure coeficient
        /// </summary>
        double Q { get; set; }

        /// <summary>
        /// Clears the pheromone matrix
        /// </summary>
        void Clear();

        /// <summary>
        /// Gets the value
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <returns></returns>
        double GetValue(INode origin, INode destination);

        /// <summary>
        /// Sets the value
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="value"></param>
        void SetValue(INode origin, INode destination, double value);

        /// <summary>
        /// Update pheromone
        /// </summary>
        /// <param name="solutions"></param>
        void UpdatePheromoneMatrix(IEnumerable<Solution> solutions);

    }
}