﻿using System;
using System.Linq;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public interface IJobNodeService
    {
        JobNode CreateJobNode(Job job, bool useTraffic, bool allowStartTimeAdjustment = false, bool ignoreFirstStopExecutionTime = false);
    }

    public class JobNodeService : IJobNodeService
    {
        private readonly IRouteStopService _routeStopService;
        private double[] _distances;

        public JobNodeService(IRouteStopService routeStopService)
        {
            _routeStopService = routeStopService;
        }

        public double[,] Array { get; private set; }

        public JobNode CreateJobNode(Job job, bool useTraffic, bool allowStartTimeAdjustment = false,
            bool ignoreFirstStopExecutionTime = false)
        {
            var routeStops = job.RouteStops.ToList();
            if (!routeStops.Any())
                throw new ArgumentException("Input job has no route stop");

            if (routeStops.Count == 1)
            {
                // Non drayage
                return new JobNode(job)
                {
                    Priority = job.Priority > 0 && job.Priority < 4 ? job.Priority : 1,
                    WindowStart = job.RouteStops.First().WindowStart,
                    WindowEnd = job.RouteStops.First().WindowEnd
                };
            }
            
            // Drayage case
            var routeSegmentStatistics =
                _routeStopService.CalculateRouteSegmentStatistics(routeStops.First().WindowStart, routeStops, useTraffic);

            var lowerBound = routeStops.Min(x => x.WindowStart);
            var upperBound = routeStops.Min(x => x.WindowEnd);

            return new JobNode(job)
            {
                WindowStart = lowerBound,
                WindowEnd = upperBound,
                DepartureTime = upperBound.Ticks,
                IsInvalid = routeSegmentStatistics.Any(x => !x.IsFeasible) || routeSegmentStatistics.Any(x => x.Violations != Violations.None),
                //IsInvalid = routeSegmentStatistics.Any(x => x.Violations != Violations.None),
                Priority = job.Priority > 0 && job.Priority < 4 ? job.Priority : 1,
            };
        }
    }
}