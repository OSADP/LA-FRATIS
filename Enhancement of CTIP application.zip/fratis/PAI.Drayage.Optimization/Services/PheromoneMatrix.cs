using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Represents a pheromone matrix
    /// </summary>
    public class PheromoneMatrix : IPheromoneMatrix
    {
        
        private readonly IObjectiveFunction _objectiveFunction;

        /// <summary>
        /// Gets or sets the initial pheromone value
        /// </summary>
        public double InitialPheromoneValue { get; set; }

        /// <summary>
        /// Gets or sets the pheromone evaporation rate
        /// </summary>
        public double Rho { get; set; }

        /// <summary>
        /// Gets or sets the performance measure coeficient
        /// </summary>
        public double Q { get; set; }

        public ConcurrentDictionary<Tuple<Location, Location>, double> PheromoneMatrixMap { get; private set; }
        
        public PheromoneMatrix(IObjectiveFunction objectiveFunction)
        {
            _objectiveFunction = objectiveFunction;
            
            PheromoneMatrixMap = new ConcurrentDictionary<Tuple<Location, Location>, double>();
        }

        /// <summary>
        /// Clears the pheromone matrix
        /// </summary>
        public virtual void Clear()
        {
            PheromoneMatrixMap.Clear();
        }

        private static Tuple<Location, Location> GetKey(INode node1, INode node2)
        {
            var originLocation = node1.RouteStops.First().Location;
            var destinationLocation = node2.RouteStops.First().Location;
            var key = new Tuple<Location, Location>(originLocation, destinationLocation);
            return key;
        }

        /// <summary>
        /// Gets the value
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <returns></returns>
        public virtual double GetValue(INode origin, INode destination)
        {
            if (origin == null) throw new ArgumentNullException("origin");
            if (destination == null) throw new ArgumentNullException("destination");

            double value = PheromoneMatrixMap.GetOrAdd(GetKey(origin, destination), InitialPheromoneValue);
            
            return value;
        }

        /// <summary>
        /// Sets the value
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="value"></param>
        public virtual void SetValue(INode origin, INode destination, double value)
        {
            if (origin == null) throw new ArgumentNullException("origin");
            if (destination == null) throw new ArgumentNullException("destination");
            
            PheromoneMatrixMap[GetKey(origin, destination)] = value;
        }

        /// <summary>
        /// Update pheromone
        /// </summary>
        /// <param name="solutions"></param>
        public virtual void UpdatePheromoneMatrix(IEnumerable<Solution> solutions)
        {
            var allSolutions = solutions.ToList();
            if (!allSolutions.Any())
                throw new ArgumentNullException(nameof(solutions));

            var objectiveMeasureSum = new Dictionary<Tuple<Location, Location>, double>();
            foreach (var solution in allSolutions)
            {
                var statistics = solution.RouteStatistics;
                statistics.DriversWithAssignments = solution.RouteSolutions.Count(p => p.JobCount > 0);
                var unassignedJobCount = solution.UnassignedJobNodes.Count();
                statistics.UnassignedJobs = unassignedJobCount;
                solution.RouteStatistics = statistics;

                double performanceMeasure = _objectiveFunction.GetObjectiveMeasure(solution.RouteStatistics);
                foreach (var nodeRouteSolution in solution.RouteSolutions)
                {
                    // Add to temporary matrix summation of objective measure value
                    for (var i = 0; i < nodeRouteSolution.AllNodes.Count - 1; i++)
                    {
                        var key = GetKey(nodeRouteSolution.AllNodes[i], nodeRouteSolution.AllNodes[i + 1]);
                        double value;
                        objectiveMeasureSum[key] = objectiveMeasureSum.TryGetValue(key, out value)
                            ? value + performanceMeasure
                            : performanceMeasure;
                    }
                }
                
            }

            foreach (var key in PheromoneMatrixMap.Keys)
            {
                // For each keys in the main pheromone map, see if we have the sum alread
                double value;
                PheromoneMatrixMap[key] = objectiveMeasureSum.TryGetValue(key, out value)
                    ? PheromoneMatrixMap[key]*Rho + value
                    : 0.0;
            }
        }

    }
}