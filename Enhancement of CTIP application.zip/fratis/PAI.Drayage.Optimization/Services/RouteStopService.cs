using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public class RouteStopService : IRouteStopService
    {
        private readonly IDistanceService _distanceService;
        private readonly OptimizerConfiguration _configuration;
        private readonly IRouteStopDelayService _routeStopDelayService;

        public RouteStopService(IDistanceService distanceService, OptimizerConfiguration configuration, IRouteStopDelayService routeStopDelayService)
        {
            _distanceService = distanceService;
            _configuration = configuration;
            _routeStopDelayService = routeStopDelayService;
        }

        /// <summary>
        /// Calculates the trip length between two stops
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="startTime"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        private TripLength CalculateTripLength(RouteStop start, RouteStop end, DateTime startTime, bool useTraffic)
        {
            return _distanceService.CalculateDistance(start.Location, end.Location, startTime, useTraffic);
        }
        
        /// <summary>
        /// Calculates the route statistics for a list of stops
        /// </summary>
        /// <param name="stops"></param>
        /// <param name="startTime"></param>
        /// <param name="ignoreFirstStopDelays"> </param>
        /// <returns></returns>
        public RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, TimeSpan startTime, bool useTraffic, bool ignoreFirstStopDelays, RouteStop lastNodeEndStop = null)
        {
            var result = new RouteStatistics();

            var currentTime = startTime;

            for (int i = 0; i < stops.Count; i++)
            {
                var currentStop = stops[i];
                var previousStop = i > 0 ? stops[i - 1] : lastNodeEndStop;
                var waitTime = TimeSpan.Zero;
                if (currentTime < currentStop.WindowStart)
                {
                    // early
                    waitTime = currentStop.WindowStart.Subtract(currentTime);
                }
                else if (currentTime > currentStop.WindowEnd)
                {
                    ;
                    // late
                    //var lateTime = currentTime.Subtract(currentStop.WindowEnd);
                }

                if (ignoreFirstStopDelays)
                {
                    if (i != 0)
                    {
                        var executionTime = _routeStopDelayService.GetExecutionTime(previousStop, currentStop,
                            currentTime);
                        var staticStats = new RouteStatistics
                        {
                            TotalExecutionTime = executionTime,
                            TotalIdleTime = waitTime
                        };

                        result += staticStats;
                    }
                }
                else
                {
                    // todo refactor
                    var executionTime = _routeStopDelayService.GetExecutionTime(previousStop, currentStop, currentTime);
                    var staticStats = new RouteStatistics
                    {
                        TotalExecutionTime = executionTime,
                        TotalIdleTime = waitTime
                    };

                    result += staticStats;
                }

                // update current time with accumulated total time
                currentTime = startTime + result.TotalTime;

                // add travel cost
                if (i < stops.Count - 1)
                {
                    var nextStop = stops[i + 1];
                    if (currentStop.Location != null && nextStop.Location != null)
                    {
                        // calculate the trip between the current and next stop
                        var tripLength = CalculateTripLength(currentStop, nextStop, new DateTime(currentTime.Ticks), useTraffic);
                        var queueTime = _routeStopDelayService.GetQueueTime(currentStop, nextStop, currentTime);
                        var travelStats = new RouteStatistics
                        {
                            TotalTravelTime = tripLength.Time,
                            TotalTravelDistance = tripLength.Distance,
                            TotalQueueTime = queueTime
                        };

                        result += travelStats;                        
                    }
                }

                // update current time once again with accumulated total time
                currentTime = startTime + result.TotalTime;
            }

            return result;
        }
        

        /// <summary>
        /// Calculates the route segment statistics for a list of stops
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="stops"></param>
        /// <returns></returns>
        public IList<RouteSegmentStatistics> CalculateRouteSegmentStatistics(TimeSpan startTime, IList<RouteStop> stops, bool useTraffic)
        {
            if(stops.Count < 2)
                throw new ArgumentException("Route stop has to be minimum of two.", nameof(stops));

            var result = new List<RouteSegmentStatistics>();
            
            // Compute first to second
            var currentSegmentStatistic = CreateRouteSegmentStatistics(new DateTime(startTime.Ticks), useTraffic, stops[0], stops[1], false);
            result.Add(currentSegmentStatistic);

            // Compute the rest to the tail
            for (var i = 1; i < stops.Count - 1; i++)
            {
                if (stops[i].RouteStopStatus == RouteStopStatus.Completed
                    && stops[i].RouteStopStatusTimes.Any(x => x.Status == RouteStopStatus.Completed))
                {
                    var timestamp = stops[i].RouteStopStatusTimes.
                                    Where(x => x.Status == RouteStopStatus.Completed).OrderBy(x => x.TimeStamp).LastOrDefault().TimeStamp;
                    currentSegmentStatistic.EndTime = TimeSpan.FromTicks(timestamp.Ticks);
                }
                else if (stops[i].RouteStopStatus == RouteStopStatus.InProgress
                         && stops[i].RouteStopStatusTimes.Any(x => x.Status == RouteStopStatus.InProgress))
                {
                    var timestamp = stops[i].RouteStopStatusTimes.
                                Where(x => x.Status == RouteStopStatus.InProgress).OrderBy(x => x.TimeStamp).LastOrDefault().TimeStamp;
                    currentSegmentStatistic.EndTime = TimeSpan.FromTicks(timestamp.Ticks) + stops[i].ExecutionTime.Value;
                }
                else if (stops[i].RouteStopStatus == RouteStopStatus.EnRoute
                         && stops[i].RouteStopStatusTimes.Any(x => x.Status == RouteStopStatus.EnRoute))
                {
                    var timestamp = stops[i].RouteStopStatusTimes.
                                Where(x => x.Status == RouteStopStatus.EnRoute).OrderBy(x => x.TimeStamp).LastOrDefault().TimeStamp;
                    currentSegmentStatistic.EndTime = TimeSpan.FromTicks(timestamp.Ticks) + result.ElementAt(i - 1).Statistics.TotalTravelTime
                                                        + stops[i].ExecutionTime.Value;
                }
                currentSegmentStatistic = CreateRouteSegmentStatistics(new DateTime(currentSegmentStatistic.EndTime.Ticks), useTraffic, stops[i], stops[i + 1], true);
                result.Add(currentSegmentStatistic);
            }
            return result;
        }

        public RouteStatistics CalculateTotalStatistics(IEnumerable<RouteSegmentStatistics> routeSegmentStatistics)
        {
            return routeSegmentStatistics.Select(x => x.Statistics).Sum();
        }

        private RouteSegmentStatistics CreateRouteSegmentStatistics(DateTime departureTime, bool useTraffic, RouteStop currentStop, RouteStop nextStop, bool allowWaitIfEarly = true)
        {
            // calculate the trip between the current and next stop
            var tripLength = CalculateTripLength(currentStop, nextStop, departureTime, useTraffic);

            var arrivalTimeAtNextNode = departureTime + tripLength.Time;

            // lower and upper bounds are calculated from start/end time window of the next stop
            var deltaTimeWindow = nextStop.WindowEnd - nextStop.WindowStart;
            
            var lowerBound = new DateTime(new DateTime(nextStop.WindowStart.Ticks).Year,
                new DateTime(nextStop.WindowStart.Ticks).Month, new DateTime(nextStop.WindowStart.Ticks).Day,
                nextStop.WindowStart.Hours, nextStop.WindowStart.Minutes, nextStop.WindowStart.Seconds);

            var upperBound = lowerBound + deltaTimeWindow;

            bool early = arrivalTimeAtNextNode < lowerBound;
            bool late = arrivalTimeAtNextNode > upperBound;
            var timeWindowIsViolated = false;

            TimeSpan idleTime = TimeSpan.Zero;

            if (early)
            {
                //idleTime = lowerBound - arrivalTimeAtNextNode;

                if (allowWaitIfEarly)
                {
                    idleTime = lowerBound - arrivalTimeAtNextNode;
                }
                else
                {
                    idleTime = TimeSpan.FromTicks((lowerBound - arrivalTimeAtNextNode).Ticks % (new TimeSpan(0, 30, 0)).Ticks);

                    departureTime += (lowerBound - arrivalTimeAtNextNode) - idleTime;
                    arrivalTimeAtNextNode = departureTime + tripLength.Time;
                }
            }
            else if (late)
            {
                // we started past the time window
                timeWindowIsViolated = true;
            }

            // Retrieve queue time from service
            var queueTime = _routeStopDelayService.GetQueueTime(currentStop, nextStop, new TimeSpan(arrivalTimeAtNextNode.Ticks));

            //Generate route statistics
            var routeStatistics = new RouteStatistics
            {
                TotalExecutionTime = nextStop.ExecutionTime ?? TimeSpan.Zero,
                TotalIdleTime = idleTime,
                TotalTravelTime = tripLength.Time,
                TotalTravelDistance = tripLength.Distance,
                TotalQueueTime = queueTime
            };
            Violations timeWindowViolations = Violations.None;
            if (timeWindowIsViolated && !nextStop.IgnoreTimeWindow)
                timeWindowViolations = Violations.TimeWindow;

            var result = new RouteSegmentStatistics
                {
                    StartStop = currentStop,
                    EndStop = nextStop,
                    StartTime = new TimeSpan(departureTime.Ticks),
                    EndTime = new TimeSpan((departureTime + routeStatistics.TotalTime).Ticks),
                    Statistics = routeStatistics,
                    IsFeasible = !timeWindowIsViolated || nextStop.IgnoreTimeWindow,
                    Violations = timeWindowViolations
            };
            
            return result;
        }
    }
}