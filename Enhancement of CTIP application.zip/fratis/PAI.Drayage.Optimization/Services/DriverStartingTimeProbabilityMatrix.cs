﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using System.Text.RegularExpressions;

namespace PAI.Drayage.Optimization.Services
{
    public class DriverStartingTimeProbabilityMatrix
    {
        private readonly Dictionary<Driver, IEnumerable<DriverNodeMatrixItem>> _driverNodeProbabilityMatrixData =
            new Dictionary<Driver, IEnumerable<DriverNodeMatrixItem>>();

        private readonly IRandomNumberGenerator _randomNumberGenerator;
        private readonly IObjectiveFunction _objectiveFunction;

        public DriverStartingTimeProbabilityMatrix(IEnumerable<Driver> drivers,
            IRandomNumberGenerator randomNumberGenerator, IObjectiveFunction objectiveFunction)
        {
            _randomNumberGenerator = randomNumberGenerator;
            _objectiveFunction = objectiveFunction;
            InitializeDriverNodeData(drivers);
        }

        public double Rho { get; set; }

        public double Q { get; set; }

        private void InitializeDriverNodeData(IEnumerable<Driver> drivers)
        {
            var timeIncrementInMinutes = 30.0;
            // Create DriverNode data
            foreach (var driver in drivers.ToList())
            {
                var driverNodeList = new List<DriverNodeMatrixItem>();
                var currentTimeBucket = driver.EarliestStartTimeSpan;

                if (driver.IsFlexibleStartTime)
                {
                    while (currentTimeBucket <= driver.LatestDepatureTimeSpan)
                    {
                        driverNodeList.Add(new DriverNodeMatrixItem
                        {
                            Driver = new DriverNode(driver) { WindowStart = currentTimeBucket },
                            Value = 1.0
                        });
                        currentTimeBucket = currentTimeBucket.Add(TimeSpan.FromMinutes(timeIncrementInMinutes));
                    }
                }
                else
                {
                    driverNodeList.Add(new DriverNodeMatrixItem
                    {
                        Driver = new DriverNode(driver)
                        {
                            WindowStart = driver.EarliestStartTimeSpan
                        },
                        Value = 1.0
                    });
                }
                
                _driverNodeProbabilityMatrixData.Add(driver, driverNodeList);
            }
        }

        public void UpdateData(IEnumerable<DriverNode> driverNodeToUpdate, IEnumerable<Solution> allSolutions)
        {
            // Compute the sum of the objective function
            IList<double> performanceMeasure = new List<double>();
            foreach (var solution in allSolutions)
            {
                var statistics = solution.RouteStatistics;
                statistics.DriversWithAssignments = solution.RouteSolutions.Count(p => p.JobCount > 0);
                var unassignedJobCount = solution.UnassignedJobNodes.Count();
                statistics.UnassignedJobs = unassignedJobCount;
                solution.RouteStatistics = statistics;

                performanceMeasure.Add(_objectiveFunction.GetObjectiveMeasure(solution.RouteStatistics));
            }
            // Seach the node in question
            foreach (var driverNode in driverNodeToUpdate)
            {
                var data = _driverNodeProbabilityMatrixData[driverNode.Driver].SingleOrDefault(x => x.Driver == driverNode);

                if (data != null)
                    data.Value = Rho * data.Value + performanceMeasure.Sum(value => Q / value);
            }
            
        }

        public DriverNode GetNominatedElement(Driver driver)
        {
            _randomNumberGenerator.Reseed(Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value));
            var rand = _randomNumberGenerator.NextDouble();

            var driverDataRow = _driverNodeProbabilityMatrixData[driver].Select(x => x).ToList();
            var sum = driverDataRow.Sum(x => x.Value);
            var cummulativeData = new Dictionary<DriverNodeMatrixItem, double>();
            var sumSoFar = 0.0;
            foreach (var driverNodeMatrixItem in driverDataRow)
            {
                sumSoFar += driverNodeMatrixItem.Value;
                cummulativeData.Add(driverNodeMatrixItem, sumSoFar / sum);
            }

            var selectedItem = cummulativeData.FirstOrDefault(x => x.Value > rand).Key;
            
            return selectedItem != null ? selectedItem.Driver : _driverNodeProbabilityMatrixData[driver].First().Driver;
        }

        private class DriverNodeMatrixItem
        {
            public DriverNode Driver { get; set; }
            public double Value { get; set; }
        }
    }
}