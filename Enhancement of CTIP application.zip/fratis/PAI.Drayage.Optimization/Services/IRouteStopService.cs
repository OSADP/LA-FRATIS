using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Delay Service Interface
    /// </summary>
    public interface IRouteStopService
    {
        /// <summary>
        /// Calculates the route statistics for a list of stops
        /// </summary>
        /// <param name="stops"></param>
        /// <param name="startTime"></param>
        /// <param name="ignoreFirstStopDelays"> </param>
        /// <returns></returns>
        RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, TimeSpan startTime, bool useTraffic, bool ignoreFirstStopDelays, RouteStop lastNodeEndStop = null);

        /// <summary>
        /// Calculates the route segment statistics for a list of stops
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="stops"></param>
        /// <returns></returns>
        IList<RouteSegmentStatistics> CalculateRouteSegmentStatistics(TimeSpan startTime, IList<RouteStop> stops, bool useTraffic);


        /// <summary>
        /// Calculates total statistics from individual route segment statistics
        /// </summary>
        /// <param name="routeSegmentStatistics">List of RSS to be summed</param>
        /// <returns></returns>
        RouteStatistics CalculateTotalStatistics(IEnumerable<RouteSegmentStatistics> routeSegmentStatistics);
    }
}