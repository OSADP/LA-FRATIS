using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Infrastructure;


namespace PAI.Drayage.Optimization.Services
{
    public class RouteService : IRouteService
    {
        private readonly IRouteExitFunction _routeExitFunction;
        private readonly INodeService _nodeService;
        private readonly IRouteStatisticsComparer _routeStatisticsComparer;
        private readonly IRouteStatisticsService _routeStatisticsService;
        private readonly ISolutionComparer _solutionComparer;

        public RouteService(IRouteExitFunction routeExitFunction,
            INodeService nodeService,
            IRouteStatisticsComparer routeStatisticsComparer,
            IRouteStatisticsService routeStatisticsService,
            INodeConnectionFactory nodeConnectionFactory,
            ISolutionComparer solutionComparer)
        {
            _routeExitFunction = routeExitFunction;
            _nodeService = nodeService;
            _routeStatisticsComparer = routeStatisticsComparer;
            _routeStatisticsService = routeStatisticsService;
            _solutionComparer = solutionComparer;
        }


        /// <summary>
        /// Returns true if the given route solution is feasable within time windows and exit criteria
        /// </summary>
        /// <param name="nodeRouteSolution"></param>
        /// <param name="useTraffic"></param>
        /// <returns></returns>
        public bool IsFeasableRouteSolution(NodeRouteSolution nodeRouteSolution, bool useTraffic)
        {
            var driverNode = nodeRouteSolution.DriverNode;
            var currentNodeEndTime = driverNode.Driver.EarliestStartTimeSpan;
            var cumulativeRouteStatistics = new RouteStatistics();
            var allNodes = nodeRouteSolution.AllNodes;

            for (int i = 0; i < allNodes.Count - 1; i++)
            {
                var nodeTiming = _routeStatisticsService.GetNodeTiming(allNodes[i], allNodes[i + 1], currentNodeEndTime, useTraffic, cumulativeRouteStatistics);
                var previousNode = i > 0 ? allNodes[i - 1] : null;

                if (nodeTiming.IsFeasableTimeWindow)
                {
                    // is it a feasable route

                    var lastConnection = _nodeService.GetNodeConnection(nodeTiming.Node, driverNode);
                    var lastLeg = _routeStatisticsService.GetRouteStatistics(lastConnection, previousNode, nodeTiming.EndExecutionTime, useTraffic);
                    var finalRouteStatistics = nodeTiming.CumulativeRouteStatistics + lastLeg;

                    if (_routeExitFunction.ExceedsExitCriteria(finalRouteStatistics, driverNode.Driver))
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                currentNodeEndTime = nodeTiming.EndExecutionTime;
                cumulativeRouteStatistics = nodeTiming.CumulativeRouteStatistics;
            }

            return true;
        }

        ///// <summary>
        ///// Creates a route solution from a list of nodes
        ///// </summary>
        ///// <param name="nodes"></param>
        ///// <returns></returns>
        public NodeRouteSolution CreateRouteSolution(DriverNode driverNode, IEnumerable<INode> nodes, bool useTraffic)
        {
            var startTime = TimeSpan.FromTicks(driverNode.DepartureTime);
            var firstJobNode = nodes.FirstOrDefault();

            // adjust the start time
            //if (firstJobNode != null)
            //{
            //    // there may have been waiting for the driver to leave, do not count that as idle time
            //    // update the currentTime to the JobNode WindowEnd, less travel time
            //    var connection = _nodeService.GetNodeConnection(driverNode, nodes.First());
            //    if (firstJobNode.WindowEnd.Subtract(connection.RouteStatistics.TotalTravelTime) > startTime)
            //    {
            //        startTime = firstJobNode.WindowEnd.Subtract(connection.RouteStatistics.TotalTravelTime);
            //    }
            //}


            var routeSolution = new NodeRouteSolution
            {
                DriverNode = driverNode,
                StartTime = startTime,
                Nodes = nodes.ToList()
            };

            var allNodes = routeSolution.AllNodes;


            var currentTime = startTime;

            // calculate route statistics
            for (int i = 0; i < allNodes.Count; i++)
            {
                // create node plan
                var node = allNodes[i];
                var previousNode = i > 0 ? allNodes[i - 1] : null;

                // insert waiting time as per JobNode windows
                if (i >= 1 && node is JobNode && previousNode is JobNode)
                {
                    // there may have been waiting for the driver to leave, do not count that as idle time
                    // update the currentTime to the JobNode WindowEnd, less travel time
                    var connection = _nodeService.GetNodeConnection(previousNode, node);
                    if (node.WindowEnd.Subtract(connection.RouteStatistics.TotalTravelTime) > currentTime)
                    {
                        // waiting found
                        var waitingTime = node.WindowEnd.Subtract(currentTime);
                        var currentStatistics = routeSolution.RouteStatistics;
                        currentStatistics.TotalIdleTime = currentStatistics.TotalIdleTime.Add(waitingTime);
                        routeSolution.RouteStatistics = currentStatistics;
                        currentTime = currentTime.Add(waitingTime);
                    }
                }

                // add node trip length
                var stats = _routeStatisticsService.GetRouteStatistics(node, previousNode:previousNode, startTime:currentTime, useTraffic:useTraffic);
                routeSolution.RouteStatistics += stats;

                // currentTime = startTime + routeSolution.RouteStatistics.TotalTime;

                if (previousNode != null)
                {
                    var statistics = _routeStatisticsService.GetRouteStatistics(previousNode, node, currentTime, useTraffic);
                    routeSolution.RouteStatistics += statistics;
                }

                currentTime = startTime + routeSolution.RouteStatistics.TotalTime;
            }

            return routeSolution;
        }

        public IList<RouteStop> GetRouteStopsForRouteSolution(NodeRouteSolution routeSolution)
        {
            var allNodes = routeSolution.AllNodes;

            var routeStops = new List<RouteStop>();

            foreach (var rs in allNodes[0].RouteStops)
            {
                routeStops.Add(rs);
            }


            // calculate route statistics
            for (int i = 1; i < allNodes.Count; i++)
            {
                // create node plan
                var node = allNodes[i];
                routeStops.AddRange(node.RouteStops);
            }

            return routeStops;
        }

        /// <summary>
        /// Gets the best solution between a new list of <see cref="INode"/> and a current best <see cref="NodeRouteSolution"/>
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="driverNode"> </param>
        /// <param name="bestSolution"></param>
        /// <returns>the best solution</returns>
        public NodeRouteSolution GetBestFeasableSolution(IEnumerable<INode> nodes, DriverNode driverNode, bool useTraffic, NodeRouteSolution bestSolution)
        {
            // create solution
            var routeSolution = CreateRouteSolution(driverNode, nodes, useTraffic);

            // check feasibility
            if (IsFeasableRouteSolution(routeSolution, useTraffic))
            {
                if (bestSolution != null)
                {
                    routeSolution = GetBestSolution(bestSolution, routeSolution);
                }
            }
            else
            {
                routeSolution = bestSolution;
            }

            return routeSolution;
        }

        public NodeRouteSolution GetBestSolution(NodeRouteSolution left, NodeRouteSolution right)
        {
            double prioritySumLeft = left.AllNodes.Sum(f => f.Priority);
            double prioritySumRight = right.AllNodes.Sum(f => f.Priority);

            // set driver count
            var leftRs = left.RouteStatistics;
            leftRs.DriversWithAssignments = left.Nodes.Count > 0 ? 1 : 0;
            left.RouteStatistics = leftRs;

            var rightRs = right.RouteStatistics;
            rightRs.DriversWithAssignments = right.Nodes.Count > 0 ? 1 : 0;
            right.RouteStatistics = rightRs;

            //if (leftRs.DriversWithAssignments > 0 || rightRs.DriversWithAssignments > 0)
            //{
            //    ;
            //}
            int priorityCompareResult = prioritySumLeft.CompareTo(prioritySumRight);
            if (priorityCompareResult == 0)
            {
                return _routeStatisticsComparer.Compare(left.RouteStatistics, right.RouteStatistics) > 0 ? right : left;
            }

            return _routeStatisticsComparer.Compare(left.RouteStatistics, right.RouteStatistics) > 0 ? right : left;

            // return the solution with the highest priority sum
            //return priorityCompareResult > 0 ? left : right;
            var result = _routeStatisticsComparer.Min(left, right);
            return result;
            //return _routeStatisticsComparer.Compare(left.RouteStatistics, right.RouteStatistics) > 0 ? right : left;
        }

        public Solution GetBestSolution(Solution left, Solution right)
        {
            return _solutionComparer.Compare(left, right) > 0 ? right : left;
        }
    }
}