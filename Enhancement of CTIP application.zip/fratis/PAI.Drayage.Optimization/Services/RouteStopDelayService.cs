using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public class RouteStopDelayService : IRouteStopDelayService
    {
        private readonly OptimizerConfiguration _optimizerConfiguration;

        public List<LocationQueueDelay> LocationQueueDelays { get; set; }

        public RouteStopDelayService(OptimizerConfiguration optimizerConfiguration)
        {
            _optimizerConfiguration = optimizerConfiguration;
        }

        /// <summary>
        /// Gets the approximate delay (minutes) for the given stop and location
        /// </summary>
        /// <param name="stopAction"> </param>
        /// <param name="location"></param>
        /// <param name="timeOfDay"></param>
        /// <returns></returns>
        public TimeSpan GetExecutionTime(StopAction stopAction, Location location, TimeSpan timeOfDay)
        {
            if (stopAction == StopActions.NoAction)
                return TimeSpan.Zero;

            return _optimizerConfiguration.DefaultStopDelay;
        }

        /// <summary>
        /// Gets the approximate delay (minutes) for the given <see cref="RouteStop"/>
        /// </summary>
        /// <param name="routeStop"></param>
        /// <param name="timeOfDay"></param>
        /// <returns></returns>
        public TimeSpan GetExecutionTime(RouteStop routeStop, TimeSpan timeOfDay)
        {
            if (routeStop.ExecutionTime.HasValue)
                return routeStop.ExecutionTime.Value;

            return GetExecutionTime(routeStop.StopAction, routeStop.Location, timeOfDay);
        }
        public TimeSpan GetExecutionTime(RouteStop previousRouteStop, RouteStop routeStop, TimeSpan timeOfDay)
        {
            var result = GetExecutionTime(routeStop, timeOfDay);
            return result;
        }
        /// <summary>
        /// Gets the queue time for  the given <see cref="RouteStop"/>
        /// </summary>
        /// <param name="routeStop"></param>
        /// <param name="timeOfDay"></param>
        /// <returns></returns>
        public TimeSpan GetQueueTime(RouteStop startStop, RouteStop endStop, TimeSpan timeOfDay)
        {
            if (endStop == null)
            {
                throw new ArgumentNullException("endStop");
            }

            if (LocationQueueDelays != null)
            {
                bool shouldGetQueueTime = !(startStop != null && startStop.Location.Id == endStop.Location.Id);

                if (shouldGetQueueTime)
                {
                    var queueDelays = LocationQueueDelays.Where(p => p.LocationId == endStop.Location.Id);
                    var match = queueDelays.FirstOrDefault(
                        p => p.DelayStartTime <= timeOfDay.Ticks && p.DelayEndTime >= timeOfDay.Ticks);
                    if (match != null)
                    {
                        endStop.QueueTime = new TimeSpan(0, match.QueueDelay, 0);
                        return endStop.QueueTime.Value;
                    }
                }
            }
            
            return TimeSpan.Zero;
        }

        public void SetLocationQueueDelays(List<LocationQueueDelay> delays)
        {
            LocationQueueDelays = delays;
        }
    }
}