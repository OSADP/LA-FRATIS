﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Services
{
    public interface ISolutionComparer : IComparer<Solution>
    {
    }

    public class SolutionComparer : ISolutionComparer
    {
        public int Compare(Solution x, Solution y)
        {
            var leftScore = x.RouteStatistics.TotalTime.TotalHours + 1000000 * x.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            var rightScore = y.RouteStatistics.TotalTime.TotalHours + 1000000 * y.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            if (leftScore < rightScore)
                return -1;
            if (leftScore > rightScore)
            {
                return 1;
            }
            return 0;
        }
    }
    public class DistanceSolutionComparer : ISolutionComparer
    {
        public int Compare(Solution x, Solution y)
        {
            var leftScore = x.RouteStatistics.TotalTravelDistance + 1000000 * x.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            var rightScore = y.RouteStatistics.TotalTravelDistance + 1000000 * y.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            //var leftScore = x.RouteStatistics.TotalTime.TotalHours + 1000000 * x.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            //var rightScore = y.RouteStatistics.TotalTime.TotalHours + 1000000 * y.RouteSolutions.Count(rs => rs.DriverNode.Driver.IsPlaceHolderDriver);
            if (leftScore < rightScore)
                return -1;
            if (leftScore > rightScore)
            {
                return 1;
            }
            return 0;
        }
    }
}