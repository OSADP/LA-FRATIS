using System;

namespace PAI.Drayage.Optimization.Common
{
    public class ProgressEventArgs : EventArgs
    {
        public int PrimaryTotal { get; set; }

        public int PrimaryValue { get; set; }
    }
}