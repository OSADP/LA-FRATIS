using System;

namespace PAI.Drayage.Optimization.Common
{
    public class RandomNumberGenerator : IRandomNumberGenerator
    {
        private Random _random;

        public RandomNumberGenerator()
        {
            _random = new Random();
        }

        public void Reseed(int seed)
        {
            _random = seed == 0 ? new Random() : new Random(seed);
        }

        public double NextDouble()
        {
            return _random.NextDouble();
        }

        public int Next()
        {
            return _random.Next();
        }

        public int Next(int maxValue)
        {
            return _random.Next(maxValue);
        }

        public int Next(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }
    }
}