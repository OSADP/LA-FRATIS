using System;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Common
{
    public class SolutionEventArgs : EventArgs
    {
        public Solution Solution { get; set; }
    }
}