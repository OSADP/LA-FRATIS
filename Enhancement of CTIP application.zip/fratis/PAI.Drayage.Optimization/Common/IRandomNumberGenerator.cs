namespace PAI.Drayage.Optimization.Common
{
    public interface IRandomNumberGenerator
    {
        void Reseed(int seed);
        double NextDouble();
        int Next();
        int Next(int maxValue);
        int Next(int minValue, int maxValue);
    }
}