﻿using System;

namespace PAI.Drayage.Optimization.Model
{
    public class OptimizerConfiguration
    {
        /// <summary>
        /// Gets or sets the maximum wait time at stop
        /// </summary>
        public TimeSpan MaximumIdleTimeAtStop { get; set; }

        /// <summary>
        /// Gets or sets the maximum wait time before start
        /// </summary>
        public TimeSpan MaximumIdleTimeBeforeStart { get; set; }

        /// <summary>
        /// Gets or sets the default stop delay
        /// </summary>
        public TimeSpan DefaultStopDelay { get; set; }

        public OptimizerConfiguration()
        {
            MaximumIdleTimeAtStop = new TimeSpan(24, 30, 0);
            MaximumIdleTimeBeforeStart = TimeSpan.FromHours(17);
            DefaultStopDelay = new TimeSpan(0, 30, 0);  
        }
    }
}
