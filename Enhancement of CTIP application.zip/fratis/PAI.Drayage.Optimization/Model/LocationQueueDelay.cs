﻿namespace PAI.Drayage.Optimization.Model
{
    public class LocationQueueDelay
    {
        public int? LocationId { get; set; }

        public long DelayStartTime { get; set; }

        public long DelayEndTime { get; set; }

        public int QueueDelay { get; set; }
    }
}
