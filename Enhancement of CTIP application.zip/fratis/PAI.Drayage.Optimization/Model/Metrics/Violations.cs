﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAI.Drayage.Optimization.Model.Metrics
{
    [Flags]
    public enum Violations
    {
        None = 0,
        Hazmat = 1,
        Flatbed = 2,
        Priority = 4,
        AssignedDriver = 8,
        Tag = 16,
        TimeWindow = 32,
        ExceedsExitCriteria = 64

    }
}
