using System;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Metrics
{
    public class RouteSegmentStatistics
    {
        /// <summary>
        /// Gets or sets the start stop
        /// </summary>
        public RouteStop StartStop { get; set; }

        /// <summary>
        /// Gets or sets the end stop
        /// </summary>
        public RouteStop EndStop { get; set; }

        /// <summary>
        /// Gets or sets the start time of this segment
        /// </summary>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        /// Gets the end time of this segment
        /// </summary>
        //public TimeSpan EndTime { get { return StartTime.Add(Statistics.TotalTime); } }
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// Gets or sets the statistics of this segment
        /// </summary>
        public RouteStatistics Statistics { get; set; }

        /// <summary>
        /// Gets or sets whether or not the time window got whiffed
        /// </summary>
        public bool IsFeasible { get; set; }
        public Violations Violations { get; set; }

        /// <summary>
        /// Gets the truck state for this segment
        /// </summary>
        public TruckState TruckState
        {
            get
            {
                return StartStop.PostTruckConfig.TruckState;
            }
        }
    }
}