using System;
using System.Collections.Generic;
using System.Linq;

namespace PAI.Drayage.Optimization.Model.Metrics
{
    /// <summary>
    /// Represents the statistics for a set of route stops
    /// </summary>
    public struct RouteStatistics
    {
        /// <summary>
        /// Gets the number of drivers with job assignments - manually set
        /// </summary>
        public int DriversWithAssignments;

        /// <summary>
        /// Gets or sets the idle time
        /// </summary>
        public TimeSpan TotalIdleTime;

        /// <summary>
        /// Gets or sets the queue time
        /// </summary>
        public TimeSpan TotalQueueTime;

        /// <summary>
        /// Gets or sets the execution time
        /// </summary>
        public TimeSpan TotalExecutionTime;

        /// <summary>
        /// Gets or sets the total time
        /// </summary>
        public TimeSpan TotalTravelTime;

        /// <summary>
        /// Gets or sets the distance (mi)
        /// </summary>
        public double TotalTravelDistance;

        /// <summary>
        /// Gets or sets the total time
        /// </summary>
        public TimeSpan TotalTime
        {
            get
            {
                return TotalIdleTime + TotalQueueTime + TotalExecutionTime + TotalTravelTime;
            }
        }

        public TimeSpan TotalNonIdleTime
        {
            get
            {
                return TotalQueueTime + TotalExecutionTime + TotalTravelTime;
            }
        }

        public double PriorityValue;

        /// <summary>
        /// Gets or sets total capacity
        /// </summary>
        public double TotalCapacity;

        public static RouteStatistics operator + (RouteStatistics c1, RouteStatistics c2)
        {
            var result = new RouteStatistics
            {
                    TotalIdleTime = c1.TotalIdleTime + c2.TotalIdleTime,
                    TotalQueueTime = c1.TotalQueueTime + c2.TotalQueueTime,
                    TotalExecutionTime = c1.TotalExecutionTime + c2.TotalExecutionTime,
                    TotalTravelTime = c1.TotalTravelTime + c2.TotalTravelTime,
                    TotalTravelDistance = c1.TotalTravelDistance + c2.TotalTravelDistance,
                    TotalCapacity = c1.TotalCapacity + c2.TotalCapacity
                };

            return result;
        }

        public int UnassignedJobs { get; set; }
        
        public override string ToString()
        {
            return string.Format("TotalTravelDistance = {0:F1}, TravelTime = {1}, TotalTime = {2}", 
                TotalTravelDistance, TotalTravelTime, TotalTime);
        }
    }

    public static class RouteStatisticsExtension
    {
        public static RouteStatistics Sum(this IEnumerable<RouteStatistics> source)
        {
            var routeStatisticses = source as RouteStatistics[] ?? source.ToArray();
            return routeStatisticses.Any() ? routeStatisticses.Aggregate((x, y) => x + y) : new RouteStatistics();
        }
    }
}