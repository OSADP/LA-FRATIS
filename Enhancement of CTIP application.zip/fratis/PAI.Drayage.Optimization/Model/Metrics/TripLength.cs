using System;

namespace PAI.Drayage.Optimization.Model.Metrics
{
    /// <summary>
    /// Represents a trip length
    /// </summary>
    public struct TripLength
    {
        /// <summary>
        /// Gets or sets the distance (mi)
        /// </summary>
        public double Distance;

        /// <summary>
        /// Gets or sets the time
        /// </summary>
        public TimeSpan Time;

        
        public TripLength(double distance, TimeSpan time)
        {
            Distance = distance;
            Time = time;
        }

        public override string ToString()
        {
            return String.Format("{0}mi {1}", Distance, Time);
        }

        #region Operators

        public static TripLength operator +(TripLength c1, TripLength c2)
        {
            return new TripLength(c1.Distance + c2.Distance, c1.Time + c2.Time);
        }

        public static bool operator ==(TripLength c1, TripLength c2)
        {
            return (c1.Distance == c2.Distance && c1.Time == c2.Time);
        }

        public static bool operator !=(TripLength c1, TripLength c2)
        {
            return (c1.Distance != c2.Distance || c1.Time != c2.Time);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Distance.GetHashCode()*397) ^ Time.GetHashCode();
            }
        }

        public bool Equals(TripLength other)
        {
            return Distance == other.Distance && Time.Equals(other.Time);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is TripLength && Equals((TripLength) obj);
        }

        #endregion


        public static TripLength MaxValue = new TripLength(double.MaxValue, TimeSpan.MaxValue);
        public static TripLength MinValue = new TripLength(double.MinValue, TimeSpan.MinValue);
        public static TripLength Zero = new TripLength(0.0, TimeSpan.Zero);
        
    }
}