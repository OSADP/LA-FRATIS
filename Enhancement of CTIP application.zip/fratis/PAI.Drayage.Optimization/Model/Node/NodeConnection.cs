using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Represents a connection between two nodes
    /// </summary>
    public class NodeConnection : IRouteSegment
    {
        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        public IList<RouteStop> RouteStops { get; set; }

        public RouteStatistics RouteStatistics { get; set; }
        /// <summary>
        /// Gets or sets the lower bound of the time window
        /// </summary>
        public TimeSpan WindowStart { get; set; }

        /// <summary>
        /// Gets or sets the upper bound of the time window
        /// </summary>
        public TimeSpan WindowEnd { get; set; }

        /// <summary>Gets or sets the departure time from the first stop.</summary>
        public long DepartureTime { get; set; }

        public bool IsConnection { get { return true; } }

        /// <summary>
        /// Gets or sets the start node
        /// </summary>
        public INode StartNode { get; set; }

        /// <summary>
        /// Gets or sets the end node
        /// </summary>
        public INode EndNode { get; set; }
    }
}