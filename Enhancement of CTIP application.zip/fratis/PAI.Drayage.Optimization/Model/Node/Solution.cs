﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Model.Node
{
    public class Solution : IHaveRouteStatistics
    {
        private RouteStatistics _routeStatistics;

        public ObservableCollection<NodeRouteSolution> RouteSolutions { get; set; }

        public List<INode> UnassignedJobNodes { get; set; }
        
        public Solution()
        {
            RouteSolutions = new ObservableCollection<NodeRouteSolution>();
            UnassignedJobNodes = new List<INode>();
        }

        public RouteStatistics RouteStatistics
        {
            get
            {
                return _routeStatistics;
            }
            set
            {
                _routeStatistics = value;
            }
        }

        public Solution Clone()
        {
            var clone = new Solution();
            foreach (var routeSolution in RouteSolutions)
            {
                clone.RouteSolutions.Add(routeSolution.Clone());
            }
            return clone;
        }

        public void PruneEmptySolutions()
        {
            // Prune empty solutions
            RouteSolutions = new ObservableCollection<NodeRouteSolution>(RouteSolutions.Where(f => f.Nodes.Count > 0));
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var nodeRouteSolution in RouteSolutions)
            {
                var s = string.Join("\t", nodeRouteSolution.Nodes.Select(f => "[" + f.Id + "]").ToArray());
                sb.AppendLine(s);
            }

            sb.AppendLine(RouteStatistics.ToString());

            return sb.ToString();
        }
    }
}
