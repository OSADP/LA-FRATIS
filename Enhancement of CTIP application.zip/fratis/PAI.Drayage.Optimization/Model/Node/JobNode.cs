using System.Linq;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Represents a Job Node
    /// </summary>
    public class JobNode : NodeBase
    {
        public Job Job { get; set; }

        public bool IsInvalid { get; set; }

        public RouteStatistics RouteStatistics
        {
            get { return Job.RouteSegmentStatistics.Select(x => x.Statistics).Sum(); }
        }

        public JobNode(Job job)
        {
            Job = job;
            Id = job.Id;


            RouteStops = Job.RouteStops.ToList();
            //if(RouteStops.Count > 0)
            //{
            //    // This assumes that the internal time widows of the job are feasable
            //    var firstStop = RouteStops.First();
            //    RouteStop secondStop = null;
            //    if (RouteStops.Count > 1)
            //    {
            //        secondStop = RouteStops[1];
            //    }

            //    WindowStart = firstStop.WindowStart;
            //    WindowEnd = secondStop != null 
            //        && secondStop.WindowStart < firstStop.WindowEnd ? secondStop.WindowStart : firstStop.WindowEnd;
            //}
        }

        public override string ToString()
        {
            return Job.DisplayName;
        }
    }
}