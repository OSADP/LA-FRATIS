using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Node
{
    public class DriverNode : NodeBase
    {
        public Driver Driver { get; private set; }

        public DriverNode(Driver driver)
        {
            Id = driver.Id;
            Driver = driver;
            WindowStart = new TimeSpan(driver.EarliestStartTime);
            WindowEnd = new TimeSpan(driver.EarliestStartTime).Add(TimeSpan.FromDays(1));
            RouteStops = new List<RouteStop>
                {
                    new RouteStop
                    {
                        Location = driver.StartingLocation,
                        WindowStart = WindowStart,
                        WindowEnd = WindowEnd,
                        IgnoreTimeWindow = true
                    }
                };
            
            Priority = 1.0;
        }

        public override string ToString()
        {
            return "Driver " + Driver.DisplayName;
        }

    }
}