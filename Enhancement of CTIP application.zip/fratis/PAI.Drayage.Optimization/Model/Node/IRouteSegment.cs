using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Represents a route segment
    /// </summary>
    public interface IRouteSegment
    {
        /// <summary>
        /// Gets the route stops
        /// </summary>
        IList<RouteStop> RouteStops { get; set; }

        /// <summary>
        /// Gets or sets the lower bound of the time window
        /// </summary>
        TimeSpan WindowStart { get; set; }

        /// <summary>
        /// Gets or sets the upper bound of the time window
        /// </summary>
        TimeSpan WindowEnd { get; set; }

        /// <summary>
        /// Gets or sets the departure time.
        /// </summary>
        long DepartureTime { get; set; }

        /// <summary>
        /// Gets whether this segment is a connection
        /// </summary>
        bool IsConnection { get; }
    }
}