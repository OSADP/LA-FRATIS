using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Represents a Route Solution
    /// </summary>
    public class NodeRouteSolution : IHaveRouteStatistics, IEqualityComparer<NodeRouteSolution>
    {
        /// <summary>
        /// Gets or sets the driver node 
        /// </summary>
        public DriverNode DriverNode { get; set; }

        /// <summary>
        /// Gets or sets the start time for the series of routes
        /// </summary>
        public TimeSpan StartTime { get; set; }
        
        /// <summary>
        /// Gets or sets the internal nodes
        /// </summary>
        public IList<INode> Nodes { get; set; }

        /// <summary>
        /// Gets or sets the route statistics
        /// </summary>
        public RouteStatistics RouteStatistics { get; set; }

        public IList<RouteSegmentStatistics> RouteSegmentStatistics { get; set; }
        
        /// <summary>
        /// Gets all the nodes
        /// </summary>
        public IList<INode> AllNodes
        {
            get
            {
                var allNodes = new List<INode>();

                if (DriverNode != null)
                    allNodes.Add(DriverNode);

                allNodes.AddRange(Nodes);

                if (DriverNode != null)
                    allNodes.Add(DriverNode);

                return allNodes;
            }
        }

        public NodeRouteSolution()
        {
            Nodes = new List<INode>();
        }

        public NodeRouteSolution(NodeRouteSolution solutionCopy)
        {
            Nodes = new List<INode>(solutionCopy.Nodes);
            DriverNode = solutionCopy.DriverNode;
            RouteSegmentStatistics = new List<RouteSegmentStatistics>(solutionCopy.RouteSegmentStatistics);
            RouteStatistics = solutionCopy.RouteStatistics;
            StartTime = solutionCopy.StartTime;
        }

        public static NodeRouteSolution CopyFrom(NodeRouteSolution solutionToCopy)
        {
            NodeRouteSolution newCopy = new NodeRouteSolution();
            newCopy.Nodes = solutionToCopy.Nodes;
            newCopy.DriverNode = solutionToCopy.DriverNode;
            newCopy.RouteSegmentStatistics = solutionToCopy.RouteSegmentStatistics;
            newCopy.RouteStatistics = solutionToCopy.RouteStatistics;
            newCopy.StartTime = solutionToCopy.StartTime;
            return newCopy;
        }

        public int JobCount
        {
            get
            {
                return Nodes.Count(node => node.GetType() == typeof (JobNode));
            }
        }
        
        /// <summary>
        /// Determines whether the specified objects are equal.
        /// </summary>
        public bool Equals(NodeRouteSolution x, NodeRouteSolution y)
        {
            return x.Nodes.SequenceEqual(y.Nodes);
        }

        /// <summary>
        /// Returns a hash code for the specified object.
        /// </summary>
        public int GetHashCode(NodeRouteSolution obj)
        {
            return Nodes.GetHashCode();
        }

        /// <summary>
        /// Returns a shallow copy 
        /// </summary>
        /// <returns></returns>
        public NodeRouteSolution Clone()
        {
            return MemberwiseClone() as NodeRouteSolution;
        }
    }
}