using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Base Node implementation
    /// </summary>
    public abstract class NodeBase : INode
    {
        /// <summary>
        /// Gets or sets the node identifier
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets the route stops
        /// </summary>
        public IList<RouteStop> RouteStops { get; set; }

        /// <summary>
        /// Gets or sets the lower bound of the time window
        /// </summary>
        public TimeSpan WindowStart { get; set; }

        /// <summary>
        /// Gets or sets the upper bound of the time window
        /// </summary>
        public TimeSpan WindowEnd { get; set; }

        public double Priority { get; set; }

        /// <summary>Gets or sets the departure time.</summary>
        public long DepartureTime { get; set; }

        public bool IsConnection { get { return false; } }

        protected NodeBase()
        {
            WindowStart = TimeSpan.Zero;
            WindowEnd = TimeSpan.FromHours(24);
            RouteStops = new List<RouteStop>();
        }
    }

}