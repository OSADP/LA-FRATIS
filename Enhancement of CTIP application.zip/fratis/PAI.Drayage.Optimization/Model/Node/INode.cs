namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// Represents a node
    /// </summary>
    public interface INode : IRouteSegment
    {
        /// <summary>
        /// Gets or sets the node identifier
        /// </summary>
        int Id { get; set; }
        double Priority { get; set; }
    }
}