namespace PAI.Drayage.Optimization.Model.Equipment
{
    /// <summary>
    /// Represents a chassis
    /// </summary>
    public class Chassis : ModelBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public string DisplayName { get; set; }
    } 
}