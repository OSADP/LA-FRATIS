namespace PAI.Drayage.Optimization.Model.Equipment
{
    public interface IEquipmentConfiguration
    {
        Chassis Chassis { get; set; }
        ChassisOwner ChassisOwner { get; set; }
        Container Container { get; set; }
        ContainerOwner ContainerOwner { get; set; }
    }

    public class EquipmentConfiguration : IEquipmentConfiguration
    {
        public EquipmentConfiguration()
        {
        }

        public EquipmentConfiguration(Chassis chassisType, Container containerType, ChassisOwner chassisOwner, ContainerOwner containerOwner)
        {
            Chassis = chassisType;
            Container = containerType;
            ChassisOwner = chassisOwner;
            ContainerOwner = containerOwner;
        }

        public Chassis Chassis { get; set; }

        public ChassisOwner ChassisOwner { get; set; }

        public Container Container { get; set; }

        public ContainerOwner ContainerOwner { get; set; }
    }
}