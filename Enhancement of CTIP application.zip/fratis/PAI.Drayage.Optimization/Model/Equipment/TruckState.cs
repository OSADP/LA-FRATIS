using System;

namespace PAI.Drayage.Optimization.Model.Equipment
{
    [Flags]
    public enum TruckState
    {
        Invalid = 0,
        Bobtail = 0x2,
        Chassis = 0x4,
        Empty = 0x8,
        Loaded = 0x20,
        Any = Bobtail | Chassis | Empty | Loaded
    }
}