namespace PAI.Drayage.Optimization.Model.Equipment
{
    /// <summary>
    /// Represents a EquipmentOwner
    /// </summary>
    public class EquipmentOwner : ModelBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string DisplayName { get; set; }
    }

    /// <summary>
    /// Represents a ChassisOwner
    /// </summary>
    public class ChassisOwner : EquipmentOwner
    {
    }

    /// <summary>
    /// Represents a ContainerOwner
    /// </summary>
    public class ContainerOwner : EquipmentOwner
    {
    }
    
}