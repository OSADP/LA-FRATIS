using System.Collections.Generic;

namespace PAI.Drayage.Optimization.Model.Equipment
{
    /// <summary>
    /// Represents a chassis
    /// </summary>
    public class Container : ModelBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// A list of chassis that can carry this container
        /// </summary>
        public List<Chassis> AllowedChassis { get; set; }
        
        /// <summary>
        /// Determines if the chassis is allowed for this container
        /// </summary>
        /// <param name="chassis"></param>
        /// <returns></returns>
        public bool IsAllowed(Chassis chassis)
        {
            return AllowedChassis.Contains(chassis);
        }
    } 
}