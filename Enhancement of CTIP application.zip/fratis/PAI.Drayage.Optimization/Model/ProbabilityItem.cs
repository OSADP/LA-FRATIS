﻿namespace PAI.Drayage.Optimization.Model
{
    /// <summary>
    /// Represents a probablity item
    /// </summary>
    public class ProbabilityItem
    {
        /// <summary>
        /// Gets or sets the reference element
        /// </summary>
        public object Element { get; set; }

        /// <summary>
        /// Gets or sets the top probability
        /// </summary>
        public double TopProbability { get; set; }

        /// <summary>
        /// Gets or sets the probability
        /// </summary>
        public double Probability { get; set; }

        /// <summary>
        /// Gets or sets the cumulative probability
        /// </summary>
        public double CumulativeProbability { get; set; }
    }
}