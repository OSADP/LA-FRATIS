using System;

namespace PAI.Drayage.Optimization.Model
{
    /// <summary>
    /// Represents a geographical location
    /// </summary>
    public class Location : 
        ModelBase, 
        IComparable<Location>, 
        IEquatable<Location>
    {
        private const double Epsilon = 0.000001;

        /// <summary>
        /// Gets or sets the display name
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the longitude in degrees
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        /// Gets or sets the latitude in degrees
        /// </summary>
        public double Latitude { get; set; }

        public virtual bool PortOfMiami { get; set; }

        public virtual bool PortEverglades { get; set; }

        public int CompareTo(Location other)
        {
            return GetHashCode() - other.GetHashCode();
        }
        
        public bool Equals(Location other)
        {
            return Math.Abs(Latitude - other.Latitude) < Epsilon
                   && Math.Abs(Longitude - other.Longitude) < Epsilon;
        }

        public override int GetHashCode()
        {
            return Longitude.GetHashCode() + Latitude.GetHashCode();
        }

        public bool IsValid()
        {
            return Math.Abs(Latitude) > Epsilon && Math.Abs(Longitude) > Epsilon;
        }
    }
}