namespace PAI.Drayage.Optimization.Model.Orders
{
    public enum Action
    {
        NoAction = 0,
        PickUp = 1,
        DropOff = -1
    }
}