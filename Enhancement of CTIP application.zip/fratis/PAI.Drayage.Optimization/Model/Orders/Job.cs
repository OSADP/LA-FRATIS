using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Model.Orders
{
    /// <summary>
    /// Represents a drayage job
    /// </summary>
    public class Job : ModelBase, ICloneable
    {
        /// <summary>
        /// Gets or sets the DisplayName 
        /// </summary>
        public string DisplayName { get; set; }


        public EquipmentConfiguration EquipmentConfiguration { get; set; }

        /// <summary>
        /// Gets or sets the container Size
        /// </summary>
        public string Container { get; set; }

        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        public ICollection<RouteStop> RouteStops { get; set; }

        public bool IsHazmat { get; set; }

        public bool IsFlatbed { get; set; }

        public double Priority { get; set; }

        public IList<RouteSegmentStatistics> RouteSegmentStatistics { get; set; }

        public string Tags { get; set; }

        public JobTemplateType JobTemplateType { get; set; }

        public double LoadPerOrder { get; set; }

        public int? AssignedDriverId { get; set; }

        public Job()
        {
            RouteStops = new List<RouteStop>();
            RouteSegmentStatistics = new List<RouteSegmentStatistics>();
        }

        public object Clone()
        {
            return new Job
            {
                DisplayName = DisplayName,
                EquipmentConfiguration = EquipmentConfiguration,
                JobTemplateType = JobTemplateType,
                RouteStops = RouteStops.ToList(),
                IsHazmat = IsHazmat, 
                IsFlatbed = IsFlatbed,
                AssignedDriverId = AssignedDriverId,
                LoadPerOrder = LoadPerOrder,
                Priority = Priority,
                RouteSegmentStatistics = RouteSegmentStatistics.ToList(),
                Tags = Tags,
                Id = Id
            };
        }
    }
}
