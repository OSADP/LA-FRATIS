using PAI.Drayage.Optimization.Model.Equipment;

namespace PAI.Drayage.Optimization.Model.Orders
{
    /// <summary>
    /// Represents a stop action or type
    /// </summary>
    public class StopAction : ModelBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string Name { get; set; }

        /// <summary>
        /// Gets or sets the short name
        /// </summary>
        public virtual string ShortName { get; set; }

        /// <summary>
        /// Gets or sets the state prior to executing action
        /// </summary>
        public virtual TruckState PreState { get; set; }
        
        /// <summary>
        /// Gets or sets the state upon executing action
        /// </summary>
        public virtual TruckState PostState { get; set; }

        /// <summary>
        /// Gets or sets the action
        /// </summary>
        public Action Action { get; set; }
    }
}