﻿namespace PAI.Drayage.Optimization.Model.Orders
{
    /// <summary>The job template type.</summary>
    public enum JobTemplateType
    {
        /// <summary>The unspecified.</summary>
        Custom = 0,

        /// <summary>The import.</summary>
        Import = 1,

        /// <summary>The import live unload.</summary>
        ImportLiveUnload = 2,

        /// <summary>The export.</summary>
        Export = 3,

        /// <summary>The export live load.</summary>
        ExportLiveLoad = 4,

        /// <summary> Empty Returns</summary>
        EmptyReturn = 5,

        /// <summary> Empty Pickups</summary>
        EmptyPickup = 6,

        /// <summary> Returns</summary>
        Return = 7,

        /// <summary> Live Loads</summary>
        LiveLoad = 8,

        /// <summary> Chassis</summary>
        Chassis = 9,

        /// <summary> Others</summary>
        Other = 10
    }
}
