using System;

namespace PAI.Drayage.Optimization.Model.Orders
{
    /// <summary>
    ///     Represents a driver
    /// </summary>
    public class Driver : ModelBase
    {

        public Driver()
        {
            IsFlexibleStartTime = false;
        }
        /// <summary>
        ///     Gets or sets the display name
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        ///     Gets or sets the starting location
        /// </summary>
        public virtual Location StartingLocation { get; set; }

        /// <summary>
        ///     Gets or sets the earliest start time as a TimeSpan
        /// </summary>
        public virtual TimeSpan EarliestStartTimeSpan
        {
            get { return new TimeSpan(EarliestStartTime); }
        }

        /// <summary>
        ///     Gets or sets the earliest start time
        /// </summary>
        public virtual long EarliestStartTime { get; set; }

        public virtual TimeSpan LatestDepatureTimeSpan
        {
            get { return new TimeSpan(LatestDepartureTime); }
        }

        public long LatestDepartureTime { get; set; }

        /// <summary>
        ///     Gets or sets the available duty time
        /// </summary>
        public virtual double AvailableDutyHours { get; set; }

        /// <summary>
        ///     Gets or sets the available driving time
        /// </summary>
        public virtual double AvailableDrivingHours { get; set; }

        /// <summary>
        ///     Gets or sets the available duty time
        /// </summary>
        public TimeSpan AvailableDutyTime
        {
            get { return TimeSpan.FromHours(AvailableDutyHours); }
        }

        /// <summary>
        ///     Gets or sets the available driving time
        /// </summary>
        public TimeSpan AvailableDrivingTime
        {
            get { return TimeSpan.FromHours(AvailableDrivingHours); }
        }

        public bool IsHazmat { get; set; }
        public bool IsFlatbed { get; set; }
        public bool IsPlaceHolderDriver { get; set; }
        public double Priority { get; set; }
        public string Tags { get; set; }
        public double Load { get; set; }
        public bool IsFlexibleStartTime { get; set; }
    }
}