using System;
using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Planning;

namespace PAI.Drayage.Optimization.Model.Orders
{
    /// <summary>
    /// Represents a route stop
    /// </summary>
    public class RouteStop : ModelBase
    {
        /// <summary>
        /// Gets or sets stop action
        /// </summary>
        public virtual StopAction StopAction { get; set; }
        
        /// <summary>
        /// Gets or sets the location
        /// </summary>
        public virtual Location Location { get; set; }

        /// <summary>
        /// Gets or sets the start of the date range
        /// </summary>
        public virtual TimeSpan WindowStart { get; set; }

        /// <summary>
        /// Gets or sets the end of the date range
        /// </summary>
        public virtual TimeSpan WindowEnd { get; set; }
        
        /// <summary>
        /// Gets or sets the truck configuration that must be met at this route stop
        /// </summary>
        public virtual TruckConfiguration PreTruckConfig { get; set; }

        /// <summary>
        /// Gets or sets the truck configuration after the route stop
        /// </summary>
        public virtual TruckConfiguration PostTruckConfig { get; set; }

        /// <summary>
        /// Gets or sets the ExecutionTime (optional)
        /// </summary>
        public virtual TimeSpan? ExecutionTime { get; set; }

        /// <summary>
        /// Gets or sets the QueueTime (optional)
        /// </summary>
        public virtual TimeSpan? QueueTime { get; set; }
        
        public RouteStop()
        {
            WindowStart = TimeSpan.Zero;
            WindowEnd = TimeSpan.MaxValue;
            StopAction = StopActions.NoAction;
            PreTruckConfig = new TruckConfiguration();
            PostTruckConfig = new TruckConfiguration();
        }

        /// <summary>
        /// Set this if we don't want time window math to be applied while evaluating this stop
        /// Typical use:  set it to true 
        /// </summary>
        public bool IgnoreTimeWindow { get; set; } = false;
        private IList<RouteStopStatusTime> _routeStopStatusTimes;
        public virtual IList<RouteStopStatusTime> RouteStopStatusTimes
        {
            get { return _routeStopStatusTimes ?? (_routeStopStatusTimes = new List<RouteStopStatusTime>()); }
            set { _routeStopStatusTimes = value; }
        }
        public virtual RouteStopStatus RouteStopStatus { get; set; }

    }
}