﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAI.Drayage.Optimization.Model.Orders
{
    public enum RouteStopStatus
    {
        Invalid = 0,
        Active = 1,
        EnRoute = 2,
        InProgress = 3,
        Completed = 4,
        Deferred = 5

    }
}
