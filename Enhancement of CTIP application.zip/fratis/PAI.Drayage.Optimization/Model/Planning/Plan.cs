using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Model.Planning
{
    /// <summary>
    /// represents a plan
    /// </summary>
    public class Plan : ModelBase
    {
        /// <summary>
        /// Gets or sets the driver plans
        /// </summary>
        private IList<PlanDriver> _driverPlans;
        public IList<PlanDriver> DriverPlans
        {
            get
            {
                return _driverPlans ?? (_driverPlans = new List<PlanDriver>());
            }
            set
            {
                _driverPlans = value;
            }
        }
        
        /// <summary>
        /// Gets or sets the unassigned jobs
        /// </summary>
        private IList<Job> _unassignedJobs;
        public virtual IList<Job> UnassignedJobs
        {
            get
            {
                return _unassignedJobs ?? (_unassignedJobs = new List<Job>());
            }
            set
            {
                _unassignedJobs = value;
            }
        }

        public bool UseTraffic { get; set; }

        public RouteStatistics TotalMetrics {
            get { return DriverPlans.Where(x => !x.Driver.IsPlaceHolderDriver).Select(x => x.TotalMetrics).Sum(); }
        }
    }
}
