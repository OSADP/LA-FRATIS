using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Function
{
    public interface IRouteExitFunction
    {
        /// <summary>
        /// Returns true if the route statistics exceed our exit criteria
        /// </summary>
        /// <param name="routeStatistics"></param>
        /// <param name="driver"></param>
        /// <returns></returns>
        bool ExceedsExitCriteria(RouteStatistics routeStatistics, Driver driver);
    }
}