using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Function
{
    public class TotalTimeObjectiveFunction : IObjectiveFunction
    {
        /// <summary>
        /// Returns the objective measure that we are minimizing
        /// </summary>
        public double GetObjectiveMeasure(RouteStatistics statistics)
        {
            return statistics.TotalTime.TotalSeconds;
        }
    }
}