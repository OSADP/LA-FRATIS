using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Function
{
    public class DistanceObjectiveFunction : IObjectiveFunction
    {
        /// <summary>
        /// Returns the objective measure that we are minimizing
        /// </summary>
        public double GetObjectiveMeasure(RouteStatistics statistics)
        {
            return (double)statistics.TotalTravelDistance;
        }
    }
}