using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Function
{
    public interface IObjectiveFunction
    {
        double GetObjectiveMeasure(RouteStatistics statistics);
    }
}