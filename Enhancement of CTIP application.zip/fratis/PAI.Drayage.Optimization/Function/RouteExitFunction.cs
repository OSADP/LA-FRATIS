﻿using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Infrastructure;

namespace PAI.Drayage.Optimization.Function
{
    public class RouteExitFunction : IRouteExitFunction
    {
        private readonly ILogger _logger;

        public RouteExitFunction(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        ///     Returns true if the route statistics exceed our exit criteria
        /// </summary>
        /// <param name="routeStatistics"></param>
        /// <param name="driver"></param>
        /// <returns></returns>
        public bool ExceedsExitCriteria(RouteStatistics routeStatistics, Driver driver)
        {
            var result = routeStatistics.TotalTravelTime > driver.AvailableDrivingTime ||
                         routeStatistics.TotalTime > driver.AvailableDutyTime;

            if (result && _logger.IsDebugEnabled)
            {
                if (routeStatistics.TotalTravelTime > driver.AvailableDrivingTime)
                {
                    _logger.Debug("Route AvailableDrivingTime. TotalTravelTime={0}, AvailableDrivingTime={1}",
                        routeStatistics.TotalTravelTime.TotalHours,
                        driver.AvailableDrivingTime.TotalHours);
                }

                if (routeStatistics.TotalTime > driver.AvailableDutyTime)
                {
                    _logger.Debug("Route exceeds AvailableDutyTime. TotalTime={0}, AvailableDutyTime={1}",
                        routeStatistics.TotalTime.TotalHours,
                        driver.AvailableDutyTime.TotalHours);
                }
            }

            return result;
        }
    }
}