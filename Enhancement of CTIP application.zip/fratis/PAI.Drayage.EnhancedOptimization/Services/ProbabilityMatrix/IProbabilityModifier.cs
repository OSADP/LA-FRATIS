﻿using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public interface IProbabilityModifier
    {
        /// <summary>
        /// Gets or sets the Multiplier
        /// </summary>
        double Multiplier { get; set; }

        /// <summary>
        /// Applies the modifer to the top probability
        /// </summary>
        /// <param name="currentNode"></param>
        /// <param name="nodeTiming"></param>
        /// <param name="topProbability"></param>
        /// <returns></returns>
        double ApplyModifier(INode currentNode, NodeTiming nodeTiming, double topProbability);
    }
}