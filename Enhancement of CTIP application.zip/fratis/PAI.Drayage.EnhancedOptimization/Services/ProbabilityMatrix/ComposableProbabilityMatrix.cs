﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;
using System.Text.RegularExpressions;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class ComposableProbabilityMatrix : IProbabilityMatrix
    {
        private readonly IRandomNumberGenerator _randomNumberGenerator;
        private readonly IList<IProbabilityModifier> _modifiers;

        public double? ForcedHomeProbaility { get; set; }

        public ComposableProbabilityMatrix(IRandomNumberGenerator randomNumberGenerator, IEnumerable<IProbabilityModifier> modifiers)
        {
            _randomNumberGenerator = randomNumberGenerator;
            _modifiers = modifiers.ToList();

            foreach (var modifer in modifiers)
            {
                modifer.Multiplier = 1;
            }
        }

        public IProbabilityModifier GetModifierByName(string modiferName)
        {
            var name = modiferName + "ProbabilityModifier";
            var modifier = _modifiers.FirstOrDefault(probabilityModifier => probabilityModifier.GetType().Name == name);

            if (modifier == null)
            {
                throw new Exception(string.Format("Modifer '{0}' was not found in Modifier collection", name));
            }

            return modifier;
        }
        
        /// <summary>
        /// Sets the multiplier for the given modifier
        /// </summary>
        /// <param name="modiferName"></param>
        /// <param name="multiplier"></param>
        public void SetModiferMultiplier(string modiferName, double multiplier)
        {
            var modifier = GetModifierByName(modiferName);

            if (modifier != null)
            {
                modifier.Multiplier = multiplier;
            }
        }

        /// <summary>
        /// Gets the multiplier for the given modifier
        /// </summary>
        /// <param name="modiferName"></param>
        public double GetModiferMultiplier(string modiferName)
        {
            double result = 0.0;
            var modifier = GetModifierByName(modiferName);

            if (modifier != null)
            {
                result = modifier.Multiplier;
            }

            return result;
        }

        /// <summary>
        /// Returns list of probability data
        /// </summary>
        /// <param name="currentNode"></param>
        /// <param name="availableNodeTimings"> </param>
        /// <returns></returns>
        public virtual IList<ProbabilityItem> BuildProbabilityDataMatrix(INode currentNode, IEnumerable<NodeTiming> availableNodeTimings, bool useTraffic)
        {
            var probabilityDataList = new List<ProbabilityItem>();

            // build probability data matrix for all unprocessed nodes
            foreach (var nodeTiming in availableNodeTimings)
            {
                var topProbability = CalculateProbability(currentNode, nodeTiming);    
                
                var probabilityItem = new ProbabilityItem
                {
                    Element = nodeTiming.Node,
                    TopProbability = topProbability
                };

                // store the result
                probabilityDataList.Add(probabilityItem);
            }

            CalculateProbabilities(probabilityDataList);

            return probabilityDataList;
        }

        /// <summary>
        /// Calculates the probabilities for a list of <see cref="ProbabilityItem"/>
        /// </summary>
        /// <param name="probabilityDataList"></param>
        public virtual void CalculateProbabilities(IList<ProbabilityItem> probabilityDataList)
        {
            double topProbSummation = probabilityDataList.Sum(f => f.TopProbability);
            double cumulativeProbability = 0.0;

            foreach (var probabilityData in probabilityDataList)
            {
                probabilityData.Probability = probabilityData.TopProbability / topProbSummation;
                cumulativeProbability += probabilityData.Probability;
                probabilityData.CumulativeProbability = cumulativeProbability;
            }
        }
        
        /// <summary>
        /// Nomiate node from probability data
        /// </summary>
        /// <param name="probabilityData"></param>
        /// <returns></returns>
        public virtual object GetNominatedElement(IList<ProbabilityItem> probabilityData)
        {
            if (probabilityData == null) throw new ArgumentNullException("probabilityData");

            _randomNumberGenerator.Reseed(Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value));

            var rand = _randomNumberGenerator.NextDouble();
            var data = probabilityData.FirstOrDefault(d => d.CumulativeProbability > rand);
            return data != null ? data.Element : ((probabilityData.Count == 0) ? null : (probabilityData.First().Element));
        }


        public virtual double CalculateProbability(INode currentNode, NodeTiming nodeTiming)
        {
            if (currentNode == null) throw new ArgumentNullException("currentNode");
            if (nodeTiming == null) throw new ArgumentNullException("nodeTiming");

            var topProbability = 1.0;

            foreach (var probabilityMatrixModifier in _modifiers)
            {
                topProbability = probabilityMatrixModifier.ApplyModifier(currentNode, nodeTiming, topProbability);
            }
            
            if (nodeTiming.Node is DriverNode)
            {
                topProbability = ForcedHomeProbaility.HasValue ? ForcedHomeProbaility.Value : 0;
            }

            return topProbability;
        }

    }
}