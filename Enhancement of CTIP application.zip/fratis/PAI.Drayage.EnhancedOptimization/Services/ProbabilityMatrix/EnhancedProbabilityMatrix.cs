﻿using System;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class EnhancedProbabilityMatrix : Optimization.Services.ProbabilityMatrix
    {
        public EnhancedProbabilityMatrix(IPheromoneMatrix pheromoneMatrix, IRouteService routeService, IObjectiveFunction objectiveFunction, IRandomNumberGenerator randomNumberGenerator, IRouteStatisticsService routeStatisticsService)
            : base(pheromoneMatrix, routeService, objectiveFunction, randomNumberGenerator, routeStatisticsService)
        {
            Gamma = 1.0f;
        }

        public float Gamma { get; set; }

       
        public override double CalculateProbability(INode currentNode, NodeTiming nodeTiming, bool useTraffic)
        {
            var topProbability = base.CalculateProbability(currentNode, nodeTiming, useTraffic);

            var priorityMeasure = (nodeTiming.Node.WindowEnd - nodeTiming.ArrivalTime).TotalMinutes;
            if (priorityMeasure > 0)
            {
                topProbability *= Math.Pow(1 / priorityMeasure, Gamma);
            }

            // HACK: Kids don't try this at home
            if (nodeTiming.Node is DriverNode && ForcedHomeProbaility.HasValue)
            {
                topProbability = ForcedHomeProbaility.Value;
            }

            return topProbability;
        }
    }
}