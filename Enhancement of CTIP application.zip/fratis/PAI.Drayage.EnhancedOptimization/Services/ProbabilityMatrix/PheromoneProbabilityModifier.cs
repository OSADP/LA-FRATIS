﻿using System;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class PheromoneProbabilityModifier : IProbabilityModifier
    {
        private readonly IPheromoneMatrix _pheromoneMatrix;

        public PheromoneProbabilityModifier(IPheromoneMatrix pheromoneMatrix)
        {
            _pheromoneMatrix = pheromoneMatrix;
        }

        public double Multiplier { get; set; }

        public double ApplyModifier(INode currentNode, NodeTiming nodeTiming, double topProbability)
        {
            if (Math.Abs(topProbability) < double.Epsilon) return topProbability;

            if (Multiplier > 0)
            {
                var node = nodeTiming.Node;
                var pheromone = _pheromoneMatrix.GetValue(currentNode, node);

                if (pheromone > 0)
                {
                    topProbability *= Math.Pow(pheromone, Multiplier);
                }
            }

            return topProbability;
        }
    }
}