﻿using System;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class PerformanceMeasureProbabilityModifier : IProbabilityModifier
    {
        private readonly IRouteStatisticsService _routeStatisticsService;
        private readonly IObjectiveFunction _objectiveFunction;

        public PerformanceMeasureProbabilityModifier(IObjectiveFunction objectiveFunction, IRouteStatisticsService routeStatisticsService)
        {
            _objectiveFunction = objectiveFunction;
            _routeStatisticsService = routeStatisticsService;
        }

        public double Multiplier { get; set; }

        public double ApplyModifier(INode currentNode, NodeTiming nodeTiming, double topProbability)
        {
            if (Math.Abs(topProbability) < double.Epsilon) return topProbability;

            if (Multiplier > 0)
            {
                var routeStatistics = _routeStatisticsService.GetRouteStatistics(currentNode, nodeTiming.Node, nodeTiming.EndExecutionTime,false);
                var performanceMeasure = _objectiveFunction.GetObjectiveMeasure(routeStatistics);

                if (performanceMeasure > 0)
                {
                    topProbability *= Math.Pow(1 / performanceMeasure, Multiplier);
                }
            }

            return topProbability;
        }
    }
}