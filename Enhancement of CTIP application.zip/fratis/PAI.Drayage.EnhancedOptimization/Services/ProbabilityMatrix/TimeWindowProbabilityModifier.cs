﻿using System;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class TimeWindowProbabilityModifier : IProbabilityModifier
    {
        public double Multiplier { get; set; }

        public double ApplyModifier(INode currentNode, NodeTiming nodeTiming, double topProbability)
        {
            if (Math.Abs(topProbability) < double.Epsilon) return topProbability;

            try
            {
                var priorityMeasure = (nodeTiming.Node.WindowEnd - nodeTiming.ArrivalTime).TotalMinutes;
                if (Multiplier > 0 && priorityMeasure > 0)
                {
                    topProbability *= Math.Pow(1 / priorityMeasure, Multiplier);
                }
            }
            catch (Exception e)
            {
                
                Console.WriteLine(e);
            }
            return topProbability;
        }
    }
}