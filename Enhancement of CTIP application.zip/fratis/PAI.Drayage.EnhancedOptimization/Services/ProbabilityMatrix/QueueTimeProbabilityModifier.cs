﻿using System;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix
{
    public class QueueTimeProbabilityModifier : IProbabilityModifier
    {
        public double Multiplier { get; set; }

        public double ApplyModifier(INode currentNode, NodeTiming nodeTiming, double topProbability)
        {
            if (Math.Abs(topProbability) < double.Epsilon) return topProbability;

            var queueTime = nodeTiming.QueueTime;
            
            if (Multiplier > 0 && queueTime.TotalMinutes > 0)
            {
                topProbability *= Math.Pow(1 / queueTime.TotalMinutes, Multiplier);
            }

            return topProbability;
        }
    }
}