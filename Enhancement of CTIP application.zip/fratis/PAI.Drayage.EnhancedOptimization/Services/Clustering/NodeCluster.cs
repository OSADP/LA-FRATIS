using System.Collections.Generic;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.Clustering
{
    /// <summary>
    /// Represents a node cluster
    /// </summary>
    public class NodeCluster
    {
        /// <summary>
        /// Gets or sets the centroid
        /// </summary>
        public ClusterCentriod Centriod { get; set; }

        /// <summary>
        /// Gets or sets the nodes
        /// </summary>
        public List<INode> Nodes { get; set; }

        public NodeCluster()
        {
            Nodes = new List<INode>();
            Centriod = new ClusterCentriod
            {
                    Location = new Location()
                };
        }
    }
}