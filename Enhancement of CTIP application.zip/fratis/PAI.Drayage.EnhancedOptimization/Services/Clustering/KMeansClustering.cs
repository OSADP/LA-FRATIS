using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.Clustering
{
    public class KMeansClustering : IClusteringService
    {
        private readonly IRandomNumberGenerator _randomNumberGenerator;
        private readonly IDistanceService _distanceService;
        private const double Epsilon = 0.000001;

        public KMeansClustering(IRandomNumberGenerator randomNumberGenerator, IDistanceService distanceService)
        {
            _randomNumberGenerator = randomNumberGenerator;
            _distanceService = distanceService;
        }
        
        public List<NodeCluster> CreateClusters(IList<INode> nodes, int clusters)
        {
            var randomCenters = CreateRandomCenters(nodes, clusters);

            IDictionary<ClusterCentriod, IList<INode>> centerAssignments = GetCenterAssignments(nodes, randomCenters);

            IList<ClusterCentriod> oldCenters = null;
            while (true)
            {
                //calculate average center
                var newCenters = GetNewCenters(centerAssignments);

                if (CentersEqual(newCenters, oldCenters))
                {
                    break;
                }

                centerAssignments = GetCenterAssignments(nodes, newCenters);

                oldCenters = newCenters;
            }
            
            var nodeClusters = centerAssignments.Select(centerAssignment => new NodeCluster
            {
                    Centriod = centerAssignment.Key,
                    Nodes = centerAssignment.Value.ToList()
                }).ToList();

            return nodeClusters;
        }

        /// <summary>
        /// Returns true if sets of centers are equal
        /// </summary>
        /// <param name="newCenters"></param>
        /// <param name="oldCenters"></param>
        /// <returns></returns>
        public bool CentersEqual(IList<ClusterCentriod> newCenters, IList<ClusterCentriod> oldCenters)
        {
            if (newCenters == null || oldCenters == null)
            {
                return false;
            }

            foreach (ClusterCentriod newCenter in newCenters)
            {
                bool found = false;
                foreach (ClusterCentriod oldCenter in oldCenters)
                {
                    if (Math.Abs(newCenter.Location.Latitude - oldCenter.Location.Latitude) < Epsilon
                        && Math.Abs(newCenter.Location.Longitude - oldCenter.Location.Longitude) < Epsilon)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Create random centroids
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="clusters">number of centroids to create</param>
        /// <returns></returns>
        public List<ClusterCentriod> CreateRandomCenters(IList<INode> nodes, int clusters)
        {
            var result = new List<ClusterCentriod>();

            double minLat = double.MaxValue;
            double maxLat = double.MinValue;
            double minLon = double.MaxValue;
            double maxLon = double.MinValue;

            foreach (var node in nodes)
            {
                var lat = node.RouteStops[0].Location.Latitude;
                var lon = node.RouteStops[0].Location.Longitude;

                minLat = Math.Min(minLat, lat);
                maxLat = Math.Max(maxLat, lat);
                minLon = Math.Min(minLon, lon);
                maxLon = Math.Max(maxLon, lon);
            }

            for (int i = 0; i < clusters; i++)
            {
                double randomLat = _randomNumberGenerator.NextDouble() * (maxLat - minLat) + minLat;
                double randomLon = _randomNumberGenerator.NextDouble() * (maxLon - minLon) + minLon;

                if (double.IsNaN(randomLat))
                    randomLat = _randomNumberGenerator.NextDouble();

                if (double.IsNaN(randomLon))
                    randomLon = _randomNumberGenerator.NextDouble();

                var clusterCentroid = new ClusterCentriod
                {
                        Location = new Location
                        {
                                Latitude = randomLat,
                                Longitude = randomLon
                            }
                    };

                result.Add(clusterCentroid);
            }
            
            return result;
        }


        /// <summary>
        /// Gets the center assigment for each node
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="centers"></param>
        /// <returns></returns>
        public IDictionary<ClusterCentriod, IList<INode>> GetCenterAssignments(IList<INode> nodes, IList<ClusterCentriod> centers)
        {
            var centerAssignments = new Dictionary<ClusterCentriod, IList<INode>>();
            foreach (var center in centers)
            {
                centerAssignments.Add(center, new List<INode>());
            }
            
            foreach (var node in nodes)
            {
                ClusterCentriod closestCenter = null;
                TripLength closestCenterDistance = TripLength.MaxValue;

                foreach (var center in centers)
                {
                    var distance =_distanceService.CalculateDistance(center.Location, node.RouteStops[0].Location, DateTime.Now, false);

                    if (distance.Distance < closestCenterDistance.Distance)
                    {
                        closestCenterDistance = distance;
                        closestCenter = center;
                    }
                }
                
                if (closestCenter != null)
                {
                    centerAssignments[closestCenter].Add(node);
                }
            }

            return centerAssignments;
        }
        
        /// <summary>
        /// Recalculates centers from assigments
        /// </summary>
        /// <param name="centerAssignments"></param>
        /// <returns></returns>
        public IList<ClusterCentriod> GetNewCenters(IDictionary<ClusterCentriod, IList<INode>> centerAssignments)
        {
            var newCenters = new List<ClusterCentriod>();

            foreach (var center in centerAssignments.Keys)
            {
                double totalLat = 0;
                double totalLon = 0;

                foreach (INode node in centerAssignments[center])
                {
                    totalLat += node.RouteStops[0].Location.Latitude;
                    totalLon += node.RouteStops[0].Location.Longitude;
                }

                var assignmentCount = centerAssignments[center].Count;

                if (assignmentCount > 0)
                {
                    double avgLat = totalLat/assignmentCount;
                    double avgLon = totalLon/assignmentCount;

                    var newCenter = new ClusterCentriod
                    {
                            Location = new Location
                            {
                                    Latitude = avgLat,
                                    Longitude = avgLon
                                }
                        };

                    newCenters.Add(newCenter);
                }
            }
            
            return newCenters;
        }

        public double CalculateDistortion(List<NodeCluster> clusters)
        {
            double distortion = 0;
            foreach (var nodeCluster in clusters)
            {
                var center = nodeCluster.Centriod;
                foreach (var node in nodeCluster.Nodes)
                {
                    var distance = _distanceService.CalculateDistance(center.Location, node.RouteStops[0].Location, DateTime.Now, false);
                    distortion += Math.Pow((double)distance.Distance,2);
                }
            }

            return distortion;
        }
    }
}