using PAI.Drayage.Optimization.Model;

namespace PAI.Drayage.EnhancedOptimization.Services.Clustering
{
    /// <summary>
    /// Represents a center of a cluster
    /// </summary>
    public class ClusterCentriod
    {
        /// <summary>
        /// Gets or sets the location
        /// </summary>
        public Location Location { get; set; }
    }
}
