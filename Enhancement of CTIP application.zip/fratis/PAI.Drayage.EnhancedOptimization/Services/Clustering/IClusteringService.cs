using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.Clustering
{
    public interface IClusteringService
    {
        List<NodeCluster> CreateClusters(IList<INode> nodes, int clusters);
        double CalculateDistortion(List<NodeCluster> clusters);
    }
}