﻿using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public interface IRouteSanitizer
    {
        /// <summary>
        /// Returns true if route stop is valid
        /// </summary>
        /// <param name="stop"></param>
        /// <returns></returns>
        bool IsValidRouteStop(RouteStop stop);

        /// <summary>
        /// function that check if the truck configuration is valid.
        /// returns true if valid and false if not
        /// </summary>
        /// <returns></returns>
        bool IsValidTruckConfig(TruckConfiguration truckConfiguration);
        
        /// <summary>
        /// Prepares a job for optimization
        /// </summary>
        /// <param name="job"></param>
        void PrepareJob(Job job);
    }
}