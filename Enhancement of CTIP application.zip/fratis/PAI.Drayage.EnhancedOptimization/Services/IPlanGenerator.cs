﻿using PAI.Drayage.EnhancedOptimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Model.Planning;
using PAI.Drayage.Optimization.Reporting.Model;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public interface IPlanGenerator
    {
        /// <summary>
        /// Generates a plan
        /// </summary>
        /// <param name="planConfigModel"></param>
        /// <param name="placeholderDriver"></param>
        /// <param name="optimizerSettings"></param>
        /// <returns></returns>
        Plan GeneratePlan(PlanConfig planConfigModel, Driver placeholderDriver, OptimizerSettings optimizerSettings);

        /// <summary>
        /// Recalculates Plan Statistics
        /// </summary>
        /// <param name="planModel"></param>
        void RecalculatePlanStatistics(Plan planModel);

        /// <summary>
        /// Gets a solution from a persisted Plan
        /// </summary>
        /// <param name="plan"></param>
        /// <returns></returns>
        Solution GetSolutionFromPlan(Plan plan);

        /// <summary>
        /// Gets Solution Performance statistics
        /// </summary>
        /// <param name="plan"></param>
        /// <returns></returns>
        SolutionPerformanceStatistics GetSolutionPerformanceStatistics(Plan plan);
    }
}