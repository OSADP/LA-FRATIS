using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.EnhancedOptimization.Services.DynamicStops
{
    public interface IDepotLocatorService
    {
        IEnumerable<Depot> GetDepotsByAction(StopAction stopAction, TruckConfiguration currentConfig, TruckConfiguration targetConfig);
    }
}