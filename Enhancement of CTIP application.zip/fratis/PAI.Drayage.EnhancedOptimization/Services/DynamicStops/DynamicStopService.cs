using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.Infrastructure;
using PAI.Infrastructure.Threading;


namespace PAI.Drayage.EnhancedOptimization.Services.DynamicStops
{
    public class DynamicStopService : IDynamicStopService
    {
        private readonly ILogger _logger;
        private readonly IRouteStopService _routeStopService;
        private readonly IRouteSanitizer _routeSanitizer;
        private readonly IDepotLocatorService _depotLocatorService;
        private readonly IRouteStatisticsComparer _routeStatisticsComparer;
        private readonly IDictionary<Tuple<TruckState, TruckState>, List<List<StopAction>>> _stopTreeCache;
        private readonly ReaderWriterLockSlim _rwLock;

        public DynamicStopService(IDepotLocatorService depotLocatorService, ILogger logger, 
            IRouteStopService routeStopService, 
            IRouteStatisticsComparer routeStatisticsComparer, IRouteSanitizer routeSanitizer)
        {
            _depotLocatorService = depotLocatorService;
            _logger = logger;
            _routeStopService = routeStopService;
            _routeStatisticsComparer = routeStatisticsComparer;
            _routeSanitizer = routeSanitizer;

            _stopTreeCache = new Dictionary<Tuple<TruckState, TruckState>, List<List<StopAction>>>();
            _rwLock = new ReaderWriterLockSlim();
        }

        /// <summary>
        /// Gets the dynamic stops required between the startStop and endStop
        /// </summary>
        /// <param name="startStop"></param>
        /// <param name="endStop"></param>
        /// <returns></returns>
        public List<RouteStop> GetDynamicStops(RouteStop startStop, RouteStop endStop)
        {
            // Validate input parameters
            if (startStop == null) 
                throw new ArgumentNullException("startStop");

            if (endStop == null) 
                throw new ArgumentNullException("endStop");

            if (!_routeSanitizer.IsValidRouteStop(startStop))
            {
                throw new OptimizationException("Invalid route stop configuration! PreTruckConfig.TruckState ({0}) != StopAction.PreState ({1}).",
                    startStop.PreTruckConfig.TruckState, startStop.StopAction.PreState);
            }

            if (!_routeSanitizer.IsValidRouteStop(endStop))
            {
                throw new OptimizationException("Invalid route stop configuration! PreTruckConfig.TruckState ({0}) != StopAction.PreState ({1}).",
                    endStop.PreTruckConfig.TruckState, endStop.StopAction.PreState);
            }
            
            if ((startStop.PreTruckConfig.TruckState != startStop.StopAction.PreState) && startStop.StopAction.PreState != TruckState.Any)
            {
                throw new OptimizationException("Invalid route stop configuration! RouteStop.PreTruckConfig.TruckState ({0}) != RouteStop.StopAction.PreState ({1}).",
                    startStop.PreTruckConfig.TruckState, startStop.StopAction.PreState);
            }

            if ((startStop.PostTruckConfig.TruckState != startStop.StopAction.PostState) && startStop.StopAction.PostState != TruckState.Any)
            {
                throw new OptimizationException("Invalid route stop configuration! RouteStop.PostTruckConfig.TruckState ({0}) != RouteStop.StopAction.PostState ({1}).",
                    startStop.PostTruckConfig.TruckState, startStop.StopAction.PostState);
            }

            if ((endStop.PreTruckConfig.TruckState != endStop.StopAction.PreState) && endStop.StopAction.PreState != TruckState.Any)
            {
                throw new OptimizationException("Invalid route stop configuration! RouteStop.PreTruckConfig.TruckState ({0}) != RouteStop.StopAction.PreState ({1}).",
                    endStop.PreTruckConfig.TruckState, endStop.StopAction.PreState);
            }

            if ((endStop.PostTruckConfig.TruckState != endStop.StopAction.PostState) && endStop.StopAction.PostState != TruckState.Any)
            {
                throw new OptimizationException("Invalid route stop configuration! RouteStop.PostTruckConfig.TruckState ({0}) != RouteStop.StopAction.PostState ({1}).",
                    endStop.PostTruckConfig.TruckState, endStop.StopAction.PostState);
            }
            

            List<RouteStop> route = null;
            // get base stop action tree
            var tree = GetStopActionTree(startStop, endStop);

            if (tree != null && tree.Count > 0)
            {
                if (_logger.IsDebugEnabled)
                {
                    _logger.Debug("Generated stop action tree\n" + DebugTree(tree));
                }

                // prune tree to allow only sensible routes
                tree = PruneStopActionTreeSecondPass(tree, startStop, endStop);

                if (_logger.IsDebugEnabled)
                {
                    _logger.Debug("Pruned stop action tree\n" + DebugTree(tree));
                }

                // then get the best route, given the tree
                route = GetRouteForTree(tree, startStop, endStop);
            }

            return route;
        }
        
        /// <summary>
        /// Gets the best route for the given stop action tree
        /// </summary>
        public List<RouteStop> GetRouteForTree(List<List<StopAction>> tree, RouteStop startStop, RouteStop endStop)
        {
            List<RouteStop> bestRoute = null;
            var bestStatistics = new RouteStatistics();

            foreach (var branch in tree)
            {
                var branchStops = GetRouteForBranch(branch, startStop, endStop);
                var branchStatisticts = _routeStopService.CalculateRouteStatistics(branchStops,TimeSpan.Zero, false, true);
                
                if (bestRoute == null)
                {
                    bestRoute = branchStops;
                    bestStatistics = branchStatisticts;
                }
                else
                {
                    if (_routeStatisticsComparer.Compare(bestStatistics, branchStatisticts) < 0)
                    {
                        bestRoute = branchStops;
                        bestStatistics = branchStatisticts;
                    }
                }
            }

            return bestRoute;
        }
        
        /// <summary>
        /// Gets the best route for the given stop action tree branch
        /// </summary>
        public List<RouteStop> GetRouteForBranch(List<StopAction> branch, RouteStop startStop, RouteStop endStop)
        {
            var routeStops = new List<RouteStop>();
            foreach (var stopAction in branch)
            {
                var nextRouteStop = GetRouteStopForBranch(routeStops, startStop, endStop, stopAction);
                routeStops.Add(nextRouteStop);
            }

            return routeStops;
        }

        /// <summary>
        /// Gets the best depot for the stop action you passed in
        /// </summary>
        /// <param name="routeStops"></param>
        /// <param name="startStop"></param>
        /// <param name="endStop"></param>
        /// <param name="stopAction"></param>
        /// <returns></returns>
        public RouteStop GetRouteStopForBranch(List<RouteStop> routeStops, RouteStop startStop, RouteStop endStop, StopAction stopAction)
        {
            var finalTruckConfig = endStop.PreTruckConfig;

            RouteStop previousStop = routeStops.Count == 0 ? startStop : routeStops.Last();

            TruckConfiguration currentConfig = previousStop.PostTruckConfig;
            TruckConfiguration targetConfig = ComputeNextTruckConfiguration(stopAction, currentConfig, finalTruckConfig);

            if (!_routeSanitizer.IsValidTruckConfig(currentConfig) || !_routeSanitizer.IsValidTruckConfig(targetConfig))
            {
                throw new OptimizationException("Invalid truck configuration!");
            }

            RouteStop bestDepotStop = null;
            List<RouteStop> bestRoute = null;
            var bestStatistics = new RouteStatistics();

            // get available depots for the given configuration requirements
            var depotStops = GetAvailableDepotStops(stopAction, currentConfig, targetConfig);

            // choose the best depot stop based on the route statistics
            foreach (var depotStop in depotStops)
            {
                if (bestDepotStop == null)
                    bestDepotStop = depotStop;

                var dynamicRoute = new List<RouteStop>();
                dynamicRoute.Add(startStop);
                dynamicRoute.AddRange(routeStops);
                dynamicRoute.Add(bestDepotStop);
                dynamicRoute.Add(endStop);

                var dynamicRouteStats = _routeStopService.CalculateRouteStatistics(dynamicRoute,TimeSpan.Zero, false, true);

                if (bestRoute == null)
                {
                    bestDepotStop = depotStop;
                    bestRoute = dynamicRoute;
                    bestStatistics = dynamicRouteStats;
                }
                else
                {
                    if (_routeStatisticsComparer.Compare(bestStatistics, dynamicRouteStats) > 0)
                    {
                        bestDepotStop = depotStop;
                        bestRoute = dynamicRoute;
                        bestStatistics = dynamicRouteStats;
                    }
                }
            }
            
            return bestDepotStop;
        }

        /// <summary>
        /// Gets the next truck configuration given the stop action we have to fulfill
        /// </summary>
        /// <param name="stopAction"></param>
        /// <param name="currentConfig"></param>
        /// <param name="finalTruckConfig"></param>
        /// <returns></returns>
        public TruckConfiguration ComputeNextTruckConfiguration(StopAction stopAction, TruckConfiguration currentConfig, TruckConfiguration finalTruckConfig)
        {
            TruckConfiguration result = null;

            if (stopAction == StopActions.PickupChassis)
            {
                result = new TruckConfiguration
                {
                    EquipmentConfiguration = new EquipmentConfiguration
                    {
                        Chassis = finalTruckConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = finalTruckConfig.EquipmentConfiguration.ChassisOwner
                    },
                    IsLoaded = false
                };
            }

            else if (stopAction == StopActions.DropOffChassis)
            {
                result = new TruckConfiguration
                {
                    IsLoaded = false
                };
            }

            else if (stopAction == StopActions.PickupEmpty)
            {
                result = new TruckConfiguration
                {
                    EquipmentConfiguration = new EquipmentConfiguration
                    {
                        Chassis = currentConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = currentConfig.EquipmentConfiguration.ChassisOwner,
                        Container = finalTruckConfig.EquipmentConfiguration.Container,
                        ContainerOwner = finalTruckConfig.EquipmentConfiguration.ContainerOwner
                    },
                    IsLoaded = false
                };
            }

            else if (stopAction == StopActions.DropOffEmpty)
            {
                result = new TruckConfiguration
                {
                    EquipmentConfiguration = new EquipmentConfiguration
                    {
                        Chassis = currentConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = currentConfig.EquipmentConfiguration.ChassisOwner
                    },
                    IsLoaded = false
                };
            }

            else if (stopAction == StopActions.PickupEmptyWithChassis)
            {
                result = new TruckConfiguration
                {
                    EquipmentConfiguration = new EquipmentConfiguration
                    {
                        Chassis = finalTruckConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = finalTruckConfig.EquipmentConfiguration.ChassisOwner,
                        Container = finalTruckConfig.EquipmentConfiguration.Container,
                        ContainerOwner = finalTruckConfig.EquipmentConfiguration.ContainerOwner
                    },
                    IsLoaded = false
                };
            }

            else if (stopAction == StopActions.DropOffEmptyWithChassis)
            {
                result = new TruckConfiguration
                {
                    IsLoaded = false
                };
            }

            else
            {
                var errorMsg = string.Format("StopAction '{0}' is invalid", stopAction.Name);
                throw new PaiException(errorMsg);
            }
                
            return result;
        }


        /// <summary>
        /// Retuns a list of available depot stops for the given stop action and configurations
        /// </summary>
        /// <param name="stopAction"></param>
        /// <param name="currentConfig"></param>
        /// <param name="targetConfig"></param>
        /// <returns></returns>
        public IEnumerable<RouteStop> GetAvailableDepotStops(StopAction stopAction, TruckConfiguration currentConfig, TruckConfiguration targetConfig)
        {
            var depots = _depotLocatorService.GetDepotsByAction(stopAction, currentConfig, targetConfig);

            var routeStops = new List<RouteStop>();
            
            foreach (var depot in depots)
            {
                var depotStop = new RouteStop
                {
                        StopAction = stopAction,
                        Location = depot.Location,
                        PreTruckConfig = currentConfig,
                        PostTruckConfig = targetConfig
                    };

                routeStops.Add(depotStop);
            }

            return routeStops;
        }

        /// <summary>
        /// Gets the stop action tree from the cache if it's there and if not put it into the cache
        /// </summary>
        /// <param name="startStop"></param>
        /// <param name="endStop"></param>
        /// <returns></returns>
        public List<List<StopAction>> GetStopActionTree(RouteStop startStop, RouteStop endStop)
        {
            TruckState currentTruckState = startStop.PostTruckConfig.TruckState;
            TruckState goalTruckState = endStop.StopAction.PreState;
            
            // attempt to retrieve from cache
            List<List<StopAction>> tree = null;
            var key = new Tuple<TruckState, TruckState>(currentTruckState, goalTruckState);
            using (_rwLock.Read())
            {
                if (_stopTreeCache.TryGetValue(key, out tree))
                {
                    return tree;
                }
            }

            // create the stop action tree
            tree = CreateStopActionTree(currentTruckState, goalTruckState);
            
            // cache
            using (_rwLock.Write())
            {
                _stopTreeCache[key] = tree;
            }
            
            return tree;
        }
        
        /// <summary>
        /// Builds a Stop Action Tree recursively
        /// </summary>
        public void BuildTreeRecursively(StopActionTreeNode parentNode, TruckState currentState, TruckState endState, 
            Stack<TruckState> truckStateStack, Stack<StopAction> stopActionStack, List<List<StopAction>> treePaths, int level)
        {
            if (level > 4) 
                return;
            
            truckStateStack.Push(currentState);

            bool invalidNode = ValidNodeCheck(truckStateStack, stopActionStack);

            if (!invalidNode)
            {
                var actions = GetAllowedStopActions(currentState);

                foreach (var stopAction in actions)
                {
                    parentNode.Children.Add(new StopActionTreeNode(parentNode, stopAction));
                }

                foreach (var child in parentNode.Children)
                {
                    var childState = child.StopAction.PostState;

                    if (childState != endState)
                    {
                        stopActionStack.Push(child.StopAction);
                        BuildTreeRecursively(child, childState, endState, truckStateStack, stopActionStack, treePaths, level + 1);
                        stopActionStack.Pop();
                    }
                    else
                    {
                        // add the last element and dump the stack into a path
                        stopActionStack.Push(child.StopAction);
                        var stopActions = stopActionStack.Reverse().ToList();
                        treePaths.Add(stopActions);
                        stopActionStack.Pop();
                    }
                }
            }

            truckStateStack.Pop();
        }

        public static IEnumerable<StopAction> DynamicStopActions
        {
            get
            {
                var actions = new List<StopAction>
                {
                        StopActions.PickupChassis,
                        StopActions.DropOffChassis,
                        StopActions.PickupEmpty,
                        StopActions.DropOffEmpty,
                        StopActions.PickupEmptyWithChassis,
                        StopActions.DropOffEmptyWithChassis
                    };

                return actions;
            }
        }

        private IEnumerable<StopAction> GetAllowedStopActions(TruckState currentState)
        {
            return DynamicStopActions.Where(f => f.PreState == currentState);
        }

        /// <summary>
        /// returns true if node is invalid, false otherwise
        /// </summary>
        /// <param name="truckStateStack"></param>
        /// <param name="stopActionStack"></param>
        /// <returns></returns>
        private bool ValidNodeCheck(IEnumerable<TruckState> truckStateStack, IEnumerable<StopAction> stopActionStack)
        {
            //first checking the truck state stack
            int numBobtails = 0;
            int numChassis = 0;

            foreach (var truckState in truckStateStack)
            {
                if(truckState == TruckState.Bobtail)
                {
                    if(++numBobtails > 1)
                    {
                        return true;
                    }
                }

                if (truckState == TruckState.Chassis)
                {
                    if (++numChassis > 1)
                    {
                        return true;
                    }
                }
            }

            bool pickedUp = false;

            //next check the stop action stack
            foreach (var stopAction in stopActionStack)
            {
                if ((stopAction == StopActions.PickupEmpty) || 
                    (stopAction == StopActions.PickupChassis) || 
                    (stopAction == StopActions.PickupEmptyWithChassis))
                {
                    pickedUp = true;
                }
                
                if (pickedUp && ( 
                    (stopAction == StopActions.DropOffEmpty) || 
                    (stopAction == StopActions.DropOffChassis) || 
                    (stopAction == StopActions.DropOffEmptyWithChassis) 
                    ))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Returns true if beginAction is not followed by followedAction
        /// </summary>
        public bool IsValidBranch(IEnumerable<StopAction> branch, StopAction beginAction, StopAction followedAction)
        {
            bool foundFirst = false;

            foreach (var stopAction in branch)
            {
                if (!foundFirst)
                {
                    if (stopAction == beginAction)
                        foundFirst = true;
                }
                else
                {
                    if (stopAction == followedAction)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
        
        /// <summary>
        /// Creates the stop action tree
        /// </summary>
        /// <param name="startState"></param>
        /// <param name="endState"></param>
        /// <returns></returns>
        public List<List<StopAction>> CreateStopActionTree(TruckState startState, TruckState endState)
        {
            if (startState == endState && startState == TruckState.Bobtail)
            {
                // nothing to do
                return null;
            }

            var root = new StopActionTreeNode();
            var truckStateStack = new Stack<TruckState>();
            var stopActionStack = new Stack<StopAction>();
            var treePaths = new List<List<StopAction>>();

            BuildTreeRecursively(root, startState, endState, truckStateStack, stopActionStack, treePaths, 0);
            
            // Sort paths by depth
            treePaths = treePaths.OrderBy(f => f.Count).ToList();

            return treePaths;
        }

        public List<List<StopAction>> PruneStopActionTreeFirstPass(List<List<StopAction>> tree, RouteStop startStop, RouteStop endStop)
        {
            var newTreePass1 = new List<List<StopAction>>();
            var newTreePass2 = new List<List<StopAction>>();
            var startConfig = startStop.PostTruckConfig;
         
            // now do all the checks for valid branches
            foreach (var branch in tree)
            {
                // if false for any of the checks, don't add it
                if(!IsValidBranch(branch, StopActions.PickupEmpty, StopActions.DropOffEmpty)
                    || !IsValidBranch(branch, StopActions.PickupChassis, StopActions.DropOffChassis)
                    || !IsValidBranch(branch, StopActions.PickupEmptyWithChassis, StopActions.DropOffEmpty)
                    || !IsValidBranch(branch, StopActions.PickupEmptyWithChassis, StopActions.DropOffEmptyWithChassis))
                {
                    continue;
                }

                newTreePass1.Add(branch);
            }
            
            switch (startConfig.TruckState)
            {
                case TruckState.Bobtail:
                    newTreePass2.AddRange(newTreePass1.Where(branch => branch.All(action => action.PostState != TruckState.Bobtail)));
                    break;
                case TruckState.Chassis:
                    newTreePass2.AddRange(newTreePass1.Where(branch => branch.All(action => action.PostState != TruckState.Chassis)));
                    break;
                default:
                    newTreePass2.AddRange(newTreePass1);
                    break;
            }
            
            return newTreePass2;
        }



        /// <summary>
        /// Creates a new stop action tree of sensible routes
        /// </summary>
        public List<List<StopAction>> PruneStopActionTreeSecondPass(List<List<StopAction>> tree, RouteStop startStop, RouteStop endStop)
        {
            var newTree = new List<List<StopAction>>();
            var startConfig = startStop.PostTruckConfig;
            var endConfig = endStop.PreTruckConfig;

            if (startConfig.TruckState != TruckState.Bobtail && !startConfig.IsMatchChassis(endConfig))
            {
                // chassis change is needed
                newTree.AddRange(tree.Where(branch => IsValidBranch(branch, TruckState.Bobtail)));
            }
            else if (startConfig.TruckState != TruckState.Chassis && (!startConfig.IsMatchContainer(endConfig)))
            {
                // container change is needed
                newTree.AddRange(tree.Where(branch => IsValidBranch(branch, TruckState.Chassis)));
            }
            else
            {
                newTree.AddRange(tree);
            }
            
            return newTree;
        }

        /// <summary>
        /// Returns true if the branch contains the minimum needed truck state
        /// </summary>
        public bool IsValidBranch(List<StopAction> branch, TruckState needed)
        {
            return branch.Any(action => action.PostState <= needed);
        }

        public string DebugTree(List<List<StopAction>> tree)
        {
            var sb = new StringBuilder();
            foreach (var branch in tree)
            {
                foreach (var stopAction in branch)
                {
                    sb.AppendFormat("> [{0}] > {1}", stopAction.ShortName, stopAction.PostState);
                }
                sb.AppendLine();
            }

            return sb.ToString();
        }

    }
}
