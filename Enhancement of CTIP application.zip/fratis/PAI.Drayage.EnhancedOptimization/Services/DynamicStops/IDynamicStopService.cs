using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.EnhancedOptimization.Services.DynamicStops
{
    public interface IDynamicStopService
    {
        /// <summary>
        /// Gets the required dynamic between the startStop and endStop
        /// </summary>
        /// <param name="startStop"></param>
        /// <param name="endStop"></param>
        /// <returns></returns>
        List<RouteStop> GetDynamicStops(RouteStop startStop, RouteStop endStop);
    }
}