using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.EnhancedOptimization.Services.DynamicStops
{
    public class DynamicStopNodeConnectionFactory : INodeConnectionFactory
    {
        private readonly IDynamicStopService _dynamicStopService;

        public DynamicStopNodeConnectionFactory(IDynamicStopService dynamicStopService)
        {
            _dynamicStopService = dynamicStopService;
        }

        /// <summary>
        /// Creates a <see cref="NodeConnection"/> between two nodes
        /// </summary>
        /// <param name="startNode"></param>
        /// <param name="endNode"></param>
        /// <returns></returns>
        public virtual NodeConnection CreateNodeConnection(INode startNode, INode endNode)
        {
            Debug.Assert(startNode.RouteStops.Count > 0);
            Debug.Assert(endNode.RouteStops.Count > 0);

            var nodeConnection = new NodeConnection
            {
                StartNode = startNode,
                EndNode = endNode
            };

            if (startNode.Priority > 1)
            {
                nodeConnection.RouteStatistics += new RouteStatistics
                {
                    PriorityValue = startNode.Priority
                };
            }
            
            // start of connection is last stop of start node
            var startStop = startNode.RouteStops.Last();

            // end of connection is first stop of end node
            var endStop = endNode.RouteStops.First();

            // get dynamic stops
            var dynamicStops = _dynamicStopService.GetDynamicStops(startStop, endStop);
            nodeConnection.RouteStops = dynamicStops;

            // these stops are just used to calcuate route statistics
            var stops = new List<RouteStop>();
            stops.Add(startStop);

            if (dynamicStops != null)
            {
                stops.AddRange(dynamicStops);
            }

            stops.Add(endStop);

            return nodeConnection;
        }
    }

}