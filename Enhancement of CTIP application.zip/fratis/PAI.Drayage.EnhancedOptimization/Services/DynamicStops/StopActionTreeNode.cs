using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.EnhancedOptimization.Services.DynamicStops
{
    public class StopActionTreeNode
    {
        public StopActionTreeNode Parent { get; set; }

        public List<StopActionTreeNode> Children { get; set; }

        public StopAction StopAction { get; set; }

        public StopActionTreeNode()
        {
            Children = new List<StopActionTreeNode>();
        }

        public StopActionTreeNode(StopActionTreeNode parent, StopAction stopAction)
        {
            Parent = parent;
            StopAction = stopAction;
            Children = new List<StopActionTreeNode>();
        }

    }
}