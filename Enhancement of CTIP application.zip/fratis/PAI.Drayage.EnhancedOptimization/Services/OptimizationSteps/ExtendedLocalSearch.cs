using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;
using PAI.Infrastructure.Threading;
using PAI.Infrastructure;

namespace PAI.Drayage.EnhancedOptimization.Services.OptimizationSteps
{
    public class ExtendedLocalSearch: IOptimizationStep
    {
        private readonly IProbabilityMatrix _probabilityMatrix;
        private readonly IRouteService _nodeRouteService;

        private readonly IRouteStatisticsService _routeStatisticsService;
        private readonly INodeService _nodeService;
        private readonly IObjectiveFunction _objectiveFunction;
        private readonly ILogger _logger;

        public bool EnableParallelism { get; set; }
        public int MaxIterations { get; set; }
        public int MaxIterationSinceBestResult { get; set; }
        public int MaxExecutionTime { get; set; }
        public int MaxMovesPerRoute { get; set; }
        public bool AggressiveMode { get; set; }

        private readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim();


        private readonly ReaderWriterLockSlim _routeLockDictionaryLockSlim = new ReaderWriterLockSlim();
        private readonly IDictionary<int, bool> _routeLockDictionary;

        public ExtendedLocalSearch(IProbabilityMatrix probabilityMatrix, IRouteService nodeRouteService, 
            IObjectiveFunction objectiveFunction, ILogger logger, INodeService nodeService, IRouteStatisticsService routeStatisticsService)
        {
            _probabilityMatrix = probabilityMatrix;
            _nodeRouteService = nodeRouteService;
            _objectiveFunction = objectiveFunction;
            _logger = logger;
            _nodeService = nodeService;
            _routeStatisticsService = routeStatisticsService;

            _routeLockDictionary = new Dictionary<int, bool>();

            EnableParallelism = true;
            MaxMovesPerRoute = 100;
            MaxIterations = 40;
            MaxIterationSinceBestResult = 20;
            AggressiveMode = true;
        }

        #region Thread Safety

        private bool TryLockPair(Tuple<int, int> pair)
        {
            var success = false;
            _routeLockDictionaryLockSlim.EnterUpgradeableReadLock();
            {

                bool item1;
                _routeLockDictionary.TryGetValue(pair.Item1, out item1);

                bool item2;
                _routeLockDictionary.TryGetValue(pair.Item2, out item2);

                if (!item1 && !item2)
                {
                    using (_routeLockDictionaryLockSlim.Write())
                    {
                        _routeLockDictionary[pair.Item1] = true;
                        _routeLockDictionary[pair.Item2] = true;
                        success = true;
                    }
                }
            }
            _routeLockDictionaryLockSlim.ExitUpgradeableReadLock();

            return success;
        }

        private void UnlockPair(Tuple<int, int> pair)
        {
            using (_routeLockDictionaryLockSlim.Write())
            {
                _routeLockDictionary[pair.Item1] = false;
                _routeLockDictionary[pair.Item2] = false;
            }
        }

        private bool LockPairWait(Tuple<int, int> pair)
        {
            const int maxWait = 10;
            int waitCounter = 0;
            while (IsPairLocked(pair) && waitCounter < maxWait)
            {
                Thread.Sleep(10);
                waitCounter++;
            }
            return TryLockPair(pair);
        }

        private bool IsPairLocked(Tuple<int, int> pair)
        {
            bool result = false;
            using (_routeLockDictionaryLockSlim.Read())
            {
                bool item1;
                _routeLockDictionary.TryGetValue(pair.Item1, out item1);

                bool item2;
                _routeLockDictionary.TryGetValue(pair.Item2, out item2);

                result = item1 || item2;
            }
            return result;
        }

        #endregion

        public string Name { get { return "Extended Local Search"; } }
        public int SortOrder { get { return 30; } }

        /// <summary>
        /// Do local search
        /// </summary>
        /// <param name="solution"></param>
        /// <returns></returns>
        public Solution Execute(Solution solution)
        {
            _routeLockDictionary.Clear();
            
            var routeSolutionsCount = solution.RouteSolutions.Count;
            var workingSolution = solution.Clone();

            var improvedSolution = false;
            var iterationsSinceBestResult = 0;

            Action<Tuple<int, int>, ParallelLoopState> iterationAction = (pair, loopState) =>
                {
                    if (LockPairWait(pair))
                    {
                        var result = PerformExtendedLocalSearch(workingSolution, pair.Item1, pair.Item2);

                        using (_rwLock.Write())
                        {
                            improvedSolution = result || improvedSolution;
                        }

                        UnlockPair(pair);
                    }
                };

            for (int iterations = 0; iterations < MaxIterations; iterations++)
            {
                improvedSolution = false;

                var pairs = GetNextPairs(new Tuple<int, int>(0, 0), routeSolutionsCount);

                if (EnableParallelism)
                {
                    Parallel.ForEach(pairs, iterationAction);
                }
                else
                {
                    foreach (var pair in pairs)
                    {
                        iterationAction(pair, null);
                    }
                }

                if (improvedSolution)
                {
                    if (SolutionUpdated != null)
                    {
                        SolutionUpdated.Invoke(this, new SolutionEventArgs {Solution = workingSolution});
                    }

                    iterationsSinceBestResult = 0;
                }
                else
                {
                    iterationsSinceBestResult++;
                }

                if (iterationsSinceBestResult > MaxIterationSinceBestResult)
                {
                    break;
                }
            }

            return workingSolution;
        }

        public void Cancel()
        {
            throw new NotImplementedException();
        }

        public event EventHandler<SolutionEventArgs> SolutionUpdated;

        /// <summary>
        /// Generates a sequence of pairs
        /// </summary>
        /// <param name="value"></param>
        /// <param name="maxCount"></param>
        /// <returns></returns>
        public static IEnumerable<Tuple<int, int>> GetNextPairs(Tuple<int, int> value, int maxCount)
        {
            for (int i = value.Item1; i < maxCount; i++)
            {
                for (int j = 0; j < maxCount; j++)
                {
                    if (i==j) continue;
                    yield return new Tuple<int, int>(i, j);
                }
            }
        }

        private bool PerformExtendedLocalSearch(Solution workingSolution, int i, int j)
        {
            bool movedNode = true;
            int moveCount = 0;

            while (movedNode && moveCount < MaxMovesPerRoute)
            {
                movedNode = false;

                var leftSolution = workingSolution.RouteSolutions[i];
                var rightSolution = workingSolution.RouteSolutions[j];
                
                IList<INode> leftNominatedNodes = new List<INode>();
                if (AggressiveMode)
                {
                    leftNominatedNodes = leftSolution.Nodes;
                } 
                else
                {
                    leftNominatedNodes.Add(NominateStop(leftSolution));
                }
                
                foreach (var leftNominatedNode in leftNominatedNodes)
                {

                    foreach (var rightNominatedNode in rightSolution.Nodes)
                    {
                        //var rightNominatedNode = NominateStop(rightSolution);
                        movedNode = DoTheShuffle(workingSolution, i, j, 
                            leftSolution.Clone(), leftNominatedNode,
                            rightSolution.Clone(), rightNominatedNode);

                        if (movedNode)
                            moveCount++;
                    }
                }

            }

            return movedNode;
        }

        private bool DoTheShuffle(Solution workingSolution, int i, int j, 
            NodeRouteSolution leftSolution, INode leftNominatedNode,
            NodeRouteSolution rightSolution, INode rightNominatedNode)
        {
            bool movedNode = false;
            string actionPerformed = string.Empty;

            int workingCount = 0;
            using (_rwLock.Read())
            {
                workingCount = workingSolution.RouteSolutions.Sum(f => f.AllNodes.Count);
            }

            NodeRouteSolution leftNewSolution = null;
            NodeRouteSolution rightNewSolution = null;

            if (leftNominatedNode != null)
            {
                // try moving the left node to the right
                leftNewSolution = _nodeRouteService.CreateRouteSolution(leftSolution.DriverNode, leftSolution.Nodes.Where(n => n != leftNominatedNode).ToList(), false);

                rightNewSolution = TryInsertNode(rightSolution, leftNominatedNode);

                // Try new route solutions for improvement 
                movedNode = TryNewSolutions(leftNewSolution, rightNewSolution, workingSolution, i, j);

                if (movedNode)
                {
                    actionPerformed = string.Format("Moved node right ({0},{1}) {2} ",
                                                    i, j, leftNominatedNode);
                    _logger.Debug(actionPerformed);
                }
            }

            if (rightNominatedNode != null && !movedNode)
            {
                // try moving the right node to the left
                rightNewSolution = _nodeRouteService.CreateRouteSolution(rightSolution.DriverNode, rightSolution.Nodes.Where(n => n != rightNominatedNode).ToList(),false);

                leftNewSolution = TryInsertNode(leftSolution, rightNominatedNode);

                // Try new route solutions for improvement 
                movedNode = TryNewSolutions(leftNewSolution, rightNewSolution, workingSolution, i, j);

                if (movedNode)
                {
                    actionPerformed = string.Format("Moved node left  ({0},{1}) {2}",
                        i, j, rightNominatedNode);
                    _logger.Debug(actionPerformed);
                }
            }

            if (leftNominatedNode != null && rightNominatedNode != null && !movedNode)
            {
                // try swaping the nodes
                leftNewSolution = _nodeRouteService.CreateRouteSolution(leftSolution.DriverNode, leftSolution.Nodes.Where(n => n != leftNominatedNode).ToList(),false);

                rightNewSolution = _nodeRouteService.CreateRouteSolution(rightSolution.DriverNode, rightSolution.Nodes.Where(n => n != rightNominatedNode).ToList(),false);

                leftNewSolution = TryInsertNode(leftNewSolution, rightNominatedNode);
                rightNewSolution = TryInsertNode(rightNewSolution, leftNominatedNode);

                // Try new route solutions for improvement 
                movedNode = TryNewSolutions(leftNewSolution, rightNewSolution, workingSolution, i, j);

                if (movedNode)
                {
                    actionPerformed = string.Format("Swaped nodes ({0},{1}) {2} <> {3}",
                        i, j, leftNominatedNode, rightNominatedNode);
                    _logger.Debug(actionPerformed);
                }
            }

            int newWorkingCount = 0; 
            using (_rwLock.Read())
            {
                newWorkingCount = workingSolution.RouteSolutions.Sum(f => f.AllNodes.Count);
            }

            if (workingCount != newWorkingCount)
            {
                var errorMessage = string.Format("Node count is different was {0} is {1}.  Action Performed {2}",
                    workingCount,
                    newWorkingCount,
                    actionPerformed);

                _logger.Error(errorMessage);
                throw new Exception(errorMessage);
            }

            return movedNode;
        }

        private bool TryNewSolutions(NodeRouteSolution leftSolution, NodeRouteSolution rightSolution,
                                     Solution workingSolution, int i, int j)
        {
            // calculate cost performance prior to search
            var originalCost = workingSolution.RouteSolutions[i].RouteStatistics + workingSolution.RouteSolutions[j].RouteStatistics;
            var originalCostPm = _objectiveFunction.GetObjectiveMeasure(originalCost);

            bool movedNode = false;
            if (leftSolution != null && rightSolution != null)
            {
                var newCost = leftSolution.RouteStatistics + rightSolution.RouteStatistics;
                var newCostPm = _objectiveFunction.GetObjectiveMeasure(newCost);
                
                if (originalCostPm > newCostPm)
                {
                    using (_rwLock.Write())
                    {
                        workingSolution.RouteSolutions[i] = leftSolution.Clone();
                        workingSolution.RouteSolutions[j] = rightSolution.Clone();
                    }
                    movedNode = true;
                }
            }
            return movedNode;
        }

        private NodeRouteSolution TryInsertNode(NodeRouteSolution solution, INode node)
        {
            var nodesCopy = solution.Nodes.ToList();
            var driverNode = solution.DriverNode;

            NodeRouteSolution bestSolution = null;

            for (int i = 0; i < nodesCopy.Count; i++)
            {
                nodesCopy.Insert(i, node);

                // determine best solution
                bestSolution = _nodeRouteService.GetBestFeasableSolution(nodesCopy, driverNode, false, bestSolution);

                nodesCopy.RemoveAt(i);
            }

            // Try add at end
            nodesCopy.Add(node);
            bestSolution = _nodeRouteService.GetBestFeasableSolution(nodesCopy, driverNode, false, bestSolution);
            
            return bestSolution;
        }

        /// <summary>
        /// Nominates stop for removal
        /// </summary>
        /// <returns></returns>
        private INode NominateStop(NodeRouteSolution nodeRouteSolution)
        {
            INode selectedNode = null;
            if (nodeRouteSolution.Nodes.Count > 1)
            {
                var probabilityData = GetProbabilityDataForConnections(nodeRouteSolution);
                selectedNode = (INode) _probabilityMatrix.GetNominatedElement(probabilityData);
            }
            else if (nodeRouteSolution.Nodes.Count == 1)
            {
                selectedNode = nodeRouteSolution.Nodes[0];
            }

            return selectedNode;
        }

        public IList<ProbabilityItem> GetProbabilityDataForConnections(NodeRouteSolution nodeRouteSolution)
        {
            var probabilityDataList = new List<ProbabilityItem>();

            var nodes = nodeRouteSolution.AllNodes;

            for (int i = 0; i < nodes.Count - 2; i++)
            {
                var connectionleft = _nodeService.GetNodeConnection(nodes[i], nodes[i + 1]);
                var connectionleftStatistics = _routeStatisticsService.GetRouteStatistics(connectionleft, null, TimeSpan.Zero, false);  // todo verify
                var pmLeft = _objectiveFunction.GetObjectiveMeasure(connectionleftStatistics);

                var connectionright = _nodeService.GetNodeConnection(nodes[i + 1], nodes[i + 2]);
                var connectionrightStatistics = _routeStatisticsService.GetRouteStatistics(connectionright, null, TimeSpan.Zero, false);
                var pmRight = _objectiveFunction.GetObjectiveMeasure(connectionrightStatistics);

                var connectionWithout = _nodeService.GetNodeConnection(nodes[i], nodes[i + 2]);
                var connectionWithoutStatistics = _routeStatisticsService.GetRouteStatistics(connectionWithout, null, TimeSpan.Zero, false);
                var pmWithout = _objectiveFunction.GetObjectiveMeasure(connectionWithoutStatistics);

                var pmDifference = (pmLeft + pmRight) - pmWithout;

                var pData = new ProbabilityItem
                {
                    Element = nodes[i + 1],
                    TopProbability = pmDifference
                };

                // store the result
                probabilityDataList.Add(pData);
            }

            _probabilityMatrix.CalculateProbabilities(probabilityDataList);

            return probabilityDataList;
        }
    }
}