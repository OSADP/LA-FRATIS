using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;
using PAI.Infrastructure.Threading;

namespace PAI.Drayage.EnhancedOptimization.Services.OptimizationSteps
{
    /// <summary>
    /// 2-Opt Optimization implementation
    /// </summary>
    public class TwoOptOptimizer : IOptimizationStep
    {
        private readonly IRouteService _nodeRouteService;
        private readonly ReaderWriterLockSlim _rwLock;

        protected bool _isCancelling;

        public bool EnableParallelism { get; set; }
        public int MaxIterations { get; set; }
        public int MaxIterationSinceBestResult { get; set; }
        public int MaxExecutionTime { get; set; }

        public TwoOptOptimizer(IRouteService nodeRouteService)
        {
            _nodeRouteService = nodeRouteService;
            EnableParallelism = true;

            MaxIterations = 30;
            MaxIterationSinceBestResult = 15;
            _rwLock = new ReaderWriterLockSlim();
        }

        public string Name { get { return "Two-Opt"; } }
        public int SortOrder { get { return 10; } }
        
        public Solution Execute(Solution solution)
        {
            var newSolution = new Solution();
            foreach (var routeSolution in solution.RouteSolutions)
            {
                var bestNodeRouteSolution = TwoOpt(routeSolution);
                newSolution.RouteSolutions.Add(bestNodeRouteSolution);
            }
            return newSolution;
        }

        public void Cancel()
        {
            _rwLock.EnterWriteLock();

            _isCancelling = true;

            _rwLock.ExitWriteLock();
        }

        public event EventHandler<SolutionEventArgs> SolutionUpdated;

        public NodeRouteSolution TwoOpt(NodeRouteSolution nodeRouteSolution)
        {
            //initialize matrices needed for optimization
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            int iterationsSinceBestResult = 0;
            bool stopping = false;

            var bestResult = nodeRouteSolution;
            var driverNode = nodeRouteSolution.DriverNode;

            // Define iteration
            // Here we take in the position of the element that we are looking to switch out
            Action<int, ParallelLoopState> iterationAction = (i, loopState) =>
            {
                for (var pos = 0; pos < nodeRouteSolution.Nodes.Count; pos++)
                {
                    if (_isCancelling) break;

                    var result = SwitchPlacesOfRouteStops(pos, bestResult.Nodes, driverNode);

                    using (_rwLock.Write())
                    {
                        bestResult = _nodeRouteService.GetBestSolution(bestResult, result);
                    }
                }

                if (_isCancelling)
                {

                    if (loopState != null)
                        loopState.Stop();
                }

                using (_rwLock.Write())
                {
                    iterationsSinceBestResult++;

                    // Check exit criteria
                    if ((loopState == null || !loopState.IsStopped) && iterationsSinceBestResult > MaxIterationSinceBestResult)
                    {
                        stopping = true;
                    }

                    if ((loopState == null || !loopState.IsStopped) && stopWatch.ElapsedMilliseconds > MaxExecutionTime)
                    {
                        stopping = true;
                    }

                    if (stopping)
                    {
                        if (loopState != null)
                            loopState.Stop();
                    }
                }

            };

            // Run iterations
            if (EnableParallelism)
            {
                Parallel.For(0, MaxIterations, iterationAction);
            }
            else
            {
                for (var i = 0; i < MaxIterations; i++)
                {
                    iterationAction(i, null);
                }
            }

            stopWatch.Stop();

            return bestResult;
        }

        /// <summary>
        /// Switches the places of routes and returns the route with the smallest total distance
        /// This is only looking at switching around ONE position
        /// </summary>
        public NodeRouteSolution SwitchPlacesOfRouteStops(int pos, IList<INode> nodes, DriverNode driverNode)
        {
            var ordersCopy = nodes.ToList();

            var bestSolution = _nodeRouteService.CreateRouteSolution(driverNode, ordersCopy, false);

            for(int i = pos; i < nodes.Count; i++)
            {
                for (var j = i; j >= pos; j--)
                {
                    ordersCopy[i-j+pos] = nodes[j];
                }

                // determine best solution
                bestSolution = _nodeRouteService.GetBestFeasableSolution(ordersCopy, driverNode, false, bestSolution);
            }

            return bestSolution;
        }


    }
}
