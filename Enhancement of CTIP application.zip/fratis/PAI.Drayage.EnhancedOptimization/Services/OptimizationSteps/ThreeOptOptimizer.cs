using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;
using PAI.Infrastructure.Threading;


namespace PAI.Drayage.EnhancedOptimization.Services.OptimizationSteps
{
    /// <summary>
    /// 3-Opt Optimization implementation
    /// </summary>
    public class ThreeOptOptimizer : IOptimizationStep
    {
        private readonly IRouteService _nodeRouteService;

        protected readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim();
        protected bool _isCancelling;
        
        public bool EnableParallelism { get; set; }

        public ThreeOptOptimizer(IRouteService nodeRouteService)
        {
            _nodeRouteService = nodeRouteService;
            EnableParallelism = true;
        }

        public string Name { get { return "Three-Opt"; } }
        public int SortOrder { get { return 20; } }

        public Solution Execute(Solution solution)
        {
            var newSolution = new Solution();
            foreach (var routeSolution in solution.RouteSolutions)
            {
                var bestNodeRouteSolution = ThreeOpt(routeSolution);
                newSolution.RouteSolutions.Add(bestNodeRouteSolution);
            }
            return newSolution;
        }

        public void Cancel()
        {
            _rwLock.EnterWriteLock();

            _isCancelling = true;

            _rwLock.ExitWriteLock();
        }

        public event EventHandler<SolutionEventArgs> SolutionUpdated;

        public NodeRouteSolution ThreeOpt(NodeRouteSolution nodeRouteSolution)
        {
            _isCancelling = false;

            var stopWatch = new Stopwatch();
            stopWatch.Start();

            var bestResult = nodeRouteSolution;

            // if we have less than 4 items then we can't do three splits
            if (bestResult.Nodes.Count() < 4)
                return bestResult;
            
            var rwLock = new ReaderWriterLockSlim();
            var items = bestResult.Nodes;
            var driverNode = nodeRouteSolution.DriverNode;
            
            Action<int, ParallelLoopState> iterationAction = (lvl1, loopState) =>
            {

                for (var lvl2 = lvl1 + 1; lvl2 < items.Count() - 1; lvl2++)
                {
                    if (_isCancelling) break;

                    for (var lvl3 = lvl2 + 1; lvl3 < items.Count(); lvl3++)
                    {
                        if (_isCancelling) break;

                        var cuts = new[] { lvl1, lvl2, lvl3 };

                        var groups = GetGroupsFromCuts(items, cuts);
                        var result = ShuffleGroups(groups, driverNode, bestResult);

                        using (_rwLock.Write())
                        {
                            bestResult = _nodeRouteService.GetBestSolution(bestResult, result);
                        }
                    }

                    if (_isCancelling) break;
                }

                if (_isCancelling)
                {

                    if (loopState != null)
                        loopState.Stop();
                }
            };

            // Run iterations
            if (EnableParallelism)
            {
                Parallel.For(0, items.Count, iterationAction);
            }
            else
            {
                for (var i = 0; i < items.Count; i++)
                {
                    iterationAction(i, null);
                }
            }
            
            stopWatch.Stop();

            return bestResult;
        }
        
        /// <summary>
        /// Create groups from cut indices
        /// </summary>
        /// <param name="items"></param>
        /// <param name="cuts"></param>
        /// <returns></returns>
        public List<List<INode>> GetGroupsFromCuts(IList<INode> items, IEnumerable<int> cuts)
        {
            var groups = new List<List<INode>>();

            var cutIterator = cuts.GetEnumerator();
            var hasCut = false;

            List<INode> group = null;
            for (int i = 0; i < items.Count; i++)
            {
                // Create new group
                if (hasCut && cutIterator.Current == i || group == null)
                {
                    group = new List<INode>();
                    groups.Add(group);
                    hasCut = cutIterator.MoveNext();
                }

                // add item to group
                group.Add(items[i]);
            }

            return groups;
        }

        //this method shuffles the two middle groups and does the rest of the 3-opt optimization
        public NodeRouteSolution ShuffleGroups(List<List<INode>> groups, DriverNode driverNode, NodeRouteSolution bestSolution)
        {

            //if the middle two groups only have one item then we don't worry about this because 2-opt takes care of this
            if (groups.Count > 0 || groups[1].Count() == 1 || groups[2].Count() == 1)
            {
                return bestSolution;
            }
            
            // switch the order of the middle two groups...
            var temp = groups[1];
            groups[1] = groups[2];
            groups[2] = temp;

            var firstResult = new List<INode>();
            foreach (var g in groups)
            {
                firstResult.AddRange(g);
            }
                
            // create a route solution
            bestSolution = _nodeRouteService.GetBestFeasableSolution(firstResult, driverNode, false, bestSolution);

            // now try reversing the elements of the two middle groups
            groups[1].Reverse();
            groups[2].Reverse();

            var secondResult = new List<INode>();
            foreach (var g in groups)
            {
                secondResult.AddRange(g);
            }

            bestSolution = _nodeRouteService.GetBestFeasableSolution(secondResult, driverNode, false, bestSolution);

            return bestSolution;
        }

    }
}
