using System;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.EnhancedOptimization.Services.OptimizationSteps
{
    public interface IOptimizationStep
    {
        /// <summary>
        /// Gets the name
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Gets the sort order for this optimization step
        /// </summary>
        int SortOrder { get; }

        /// <summary>
        /// Executes the optimization step
        /// </summary>
        Solution Execute(Solution solution);

        /// <summary>
        /// Cancels the execution
        /// </summary>
        void Cancel();
        
        /// <summary>
        /// Solution Updated Event
        /// </summary>
        event EventHandler<SolutionEventArgs> SolutionUpdated;
    }
}