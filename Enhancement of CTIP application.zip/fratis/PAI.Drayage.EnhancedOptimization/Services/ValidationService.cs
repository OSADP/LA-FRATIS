﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.EnhancedOptimization.Model;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;

using Job = PAI.Drayage.Optimization.Model.Orders.Job;
using StopAction = PAI.Drayage.Optimization.Model.Orders.StopAction;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public class ValidationService : IValidationService
    {
        private readonly IList<TimeSpan> _invalidTimes;

        public IList<TimeSpan> InvalidTimes { get { return _invalidTimes; } }

        public ValidationService(IList<TimeSpan> invalidTimes)
        {
            _invalidTimes = invalidTimes;
        }

        public IEnumerable<StopAction> GetAllowedStopActions(TruckState currentState)
        {
            var allowedActions = new List<StopAction>();
            allowedActions.AddRange(StopActions.Actions.Where(f => (f.PreState & currentState) == f.PreState));
            if (currentState == TruckState.Loaded || currentState == TruckState.Empty)
            {
                allowedActions.Add(StopActions.LiveLoading);
                allowedActions.Add(StopActions.LiveUnloading);
            }

            return allowedActions;
        }

        public bool IsStopActionValid(TruckState currentState, StopAction stopAction)
        {
            return GetAllowedStopActions(currentState).Contains(stopAction);
        }

        public ValidationResult ValidateJob(Job optimizationJob, bool validateLocations, IDistanceService distanceService)
        {
            var result = new ValidationResult { Successful = true, Errors = new List<string>() };
            if (optimizationJob.RouteStops.Count == 0)
            {
                result.Successful = false;
                result.Errors.Add("There is no route stop associated with this order.");
                return result;
            }

            var routeCount = 0;
            var processedCount = 0;
            var lastWindowStart = 0.0;
            var lastWindowEnd = 0.0;
            var lastExecutionTime = 0.0;

            foreach (var optimizationRouteStop in optimizationJob.RouteStops)
            {
                routeCount++;

                if (optimizationRouteStop.Location == null)
                {
                    result.Successful = false;
                    result.Errors.Add("Location not specified for Route Stop");
                }
                else
                {
                    // Location must be geocoded successfully
                    if (Math.Abs(optimizationRouteStop.Location.Longitude) < double.Epsilon &&
                        Math.Abs(optimizationRouteStop.Location.Latitude) < double.Epsilon)
                    {
                        result.Successful = false;
                        result.Errors.Add("The location is not a valid address.");
                        continue;
                    }
                }

                if (optimizationRouteStop.StopAction == null || optimizationRouteStop.StopAction.Id == 0)
                {
                    result.Successful = false;
                    result.Errors.Add(string.Format("A valid Stop Action must be provided route stop {0}", routeCount));
                    continue;
                }
                 
                if (validateLocations && optimizationRouteStop.Location == null)
                {
                    result.Successful = false;
                    result.Errors.Add(string.Format("A location must be provided for route stop {0}", routeCount));
                    continue;
                }

                if (processedCount > 0 && (lastWindowStart > optimizationRouteStop.WindowEnd.Ticks))
                {
                    result.Errors.Add("RouteStop windows error");
                    result.Successful = false;
                    continue;
                }

                processedCount++;
                lastWindowStart = optimizationRouteStop.WindowStart.Ticks;
                lastWindowEnd = optimizationRouteStop.WindowEnd.Ticks;
                lastExecutionTime = optimizationRouteStop.ExecutionTime.HasValue
                    ? optimizationRouteStop.ExecutionTime.Value.TotalMinutes
                    : 0;
            }

            var truckState = TruckState.Bobtail;

            long ticksLastEndWindow = 0;

            if (optimizationJob.RouteStops.Any(x => _invalidTimes.Contains(x.WindowStart) || _invalidTimes.Contains(x.WindowEnd)))
            {
                optimizationJob.RouteStops.First().StopAction = StopActions.DropOffLoadedWithChassis;
            }

            foreach (var routeStop in optimizationJob.RouteStops)
            {
                if (routeStop.WindowEnd.Ticks != TimeSpan.MaxValue.Ticks)
                    ticksLastEndWindow = routeStop.WindowEnd.Ticks;

                truckState = routeStop.StopAction.PostState;
            }

            return result;
        }
    }
}