﻿using System;
using System.Collections.Generic;
using PAI.Drayage.EnhancedOptimization.Model;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model.Equipment;

using Job = PAI.Drayage.Optimization.Model.Orders.Job;
using StopAction = PAI.Drayage.Optimization.Model.Orders.StopAction;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public interface IValidationService
    {
        bool IsStopActionValid(TruckState currentState, StopAction stopAction);

        ValidationResult ValidateJob(Job optimizationJob, bool validateLocations, IDistanceService distanceService);

        IList<TimeSpan> InvalidTimes { get; }
    }
}