﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using PAI.Drayage.EnhancedOptimization.Services.OptimizationSteps;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.Infrastructure;
using PAI.Drayage.Optimization.Geography;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public class EnhancedDrayageOptimizer : DrayageOptimizer
    {
        public EnhancedDrayageOptimizer(IProbabilityMatrix probabilityMatrix, IRouteService routeService, 
            IRouteExitFunction routeExitFunction, ILogger logger, IPheromoneMatrix pheromoneMatrix, 
            IRandomNumberGenerator randomNumberGenerator, IRouteStatisticsService routeStatisticsService,
            IJobNodeService jobNodeService, IEnumerable<IOptimizationStep> optimizationSteps, IRouteStopService routeStopService, ISolutionComparer solutionComparer,
            IDistanceService distanceService, IObjectiveFunction objectiveFunction) 
            : base(probabilityMatrix, routeService, routeExitFunction, logger, pheromoneMatrix,
            randomNumberGenerator, routeStatisticsService, jobNodeService, routeStopService, solutionComparer, distanceService, objectiveFunction)
        {
            OptimizationSteps = optimizationSteps;
        }

        public int MajorIterations { get; set; }
        public IEnumerable<IOptimizationStep> OptimizationSteps { get; set; }

        public override void Cancel()
        {
            base.Cancel();
            
            foreach (var optimizationStep in OptimizationSteps)
            {
                optimizationStep.Cancel();
            }
        }

        public override Solution BuildSolution(Driver placeholderDriver, IList<INode> jobNodes, IList<Driver> drivers)
        {
            _logger.Info("Building starting solution");

            if (OptimizationSteps != null)
            {
                foreach (var optimizationStep in OptimizationSteps)
                {
                    optimizationStep.SolutionUpdated += optimizationStep_SolutionUpdated;
                }
            }


            Solution bestSolution = null;

            //MajorIterations = Math.Max(1, MajorIterations);

            //for (int z = 0; z < MajorIterations; z++)
            //{
            //    if (bestSolution != null && z % 2 == 0)
            //    {
            //        _pheromoneMatrix.UpdatePheromoneMatrix(bestSolution);
            //    }

            //    bestSolution = BuildSolutionIteration(placeholderDriver, jobNodes, driverNodes, bestSolution);
            //}

            bestSolution = BuildSolutionIteration(placeholderDriver, jobNodes, drivers, bestSolution);

            return bestSolution;
        }

        private void optimizationStep_SolutionUpdated(object sender, SolutionEventArgs e)
        {
            CurrentBestSolution = e.Solution;
        }

        public Solution BuildSolutionIteration(Driver placeholderDriver, IList<INode> jobNodes, IList<Driver> drivers, Solution bestSolution)
        {
            _logger.Info("Executing AntColony Optimization");
            var antColonySolution = base.BuildSolution(placeholderDriver, jobNodes, drivers);
            bestSolution = bestSolution == null ? antColonySolution : _routeService.GetBestSolution(bestSolution, antColonySolution);

            List<int> lstSeconds = new List<int>();
            
            // retain a reference to the old Solution - UnAssigned jobs will added to bestSolution after OptimizationStep iteration
            var oldSolution = bestSolution;

            if (OptimizationSteps != null)
            {
                foreach (var optimizationStep in OptimizationSteps.OrderBy(f => f.SortOrder))
                {
                    Stopwatch sw = new Stopwatch();
                    sw.Start();

                    _logger.Info("Executing optimization step: " + optimizationStep.Name);
                    bestSolution = optimizationStep.Execute(bestSolution);

                    sw.Stop();
                    lstSeconds.Add(Convert.ToInt32(sw.Elapsed.TotalSeconds));
                    Console.Write("Total Optimization Step Time " + sw.Elapsed.TotalSeconds);

                    if (_isCancelling)
                        break;
                }
            }
            
            bestSolution.PruneEmptySolutions();

            // re-add the UnassignedJobs, as they were lost in optimizationStep execution
            bestSolution.UnassignedJobNodes = oldSolution.UnassignedJobNodes;       

            return bestSolution;
        }
    }
}
