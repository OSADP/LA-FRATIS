﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Drayage.EnhancedOptimization.Model;
using PAI.Drayage.EnhancedOptimization.Services.ProbabilityMatrix;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Model.Planning;
using PAI.Drayage.Optimization.Reporting.Model;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.EnhancedOptimization.Services
{
    public class PlanGenerator : IPlanGenerator
    {
        private readonly IDrayageOptimizer _optimizer;
        private readonly IReportingService _reportingService;
        private readonly IRouteService _routeService;
        private readonly IPheromoneMatrix _pheromoneMatrix;
        private readonly IProbabilityMatrix _probabilityMatrix;
        private readonly IDistanceService _distanceService;
        private readonly IJobNodeService _jobNodeService;


        public PlanGenerator(IDrayageOptimizer optimizer, IReportingService reportingService, IRouteService routeService, IPheromoneMatrix pheromoneMatrix, IProbabilityMatrix probabilityMatrix, IJobNodeService jobNodeService, IDistanceService distanceService)
        {
            _optimizer = optimizer;
            _reportingService = reportingService;
            _routeService = routeService;
            _pheromoneMatrix = pheromoneMatrix;
            _probabilityMatrix = probabilityMatrix;
            _jobNodeService = jobNodeService;
            _distanceService = distanceService;
        }

        public Plan GeneratePlan(PlanConfig planConfigModel, Driver placeholderDriver, OptimizerSettings optimizerSettings)
        {
            planConfigModel.DefaultDriver = placeholderDriver;
            planConfigModel.DefaultDriver.StartingLocation = planConfigModel.Drivers.FirstOrDefault().StartingLocation;

            var enhancedProbabilityMatrix = _probabilityMatrix as EnhancedProbabilityMatrix;
            if (enhancedProbabilityMatrix != null)
            {
                enhancedProbabilityMatrix.Alpha = optimizerSettings.Alpha;
                enhancedProbabilityMatrix.Beta = optimizerSettings.Beta;
                enhancedProbabilityMatrix.Gamma = optimizerSettings.Gamma;
                enhancedProbabilityMatrix.ForcedHomeProbaility = optimizerSettings.ForcedHomeProbability;
                enhancedProbabilityMatrix.Zeta = optimizerSettings.Zeta;
            }

            var composableProbabilityMatrix = _probabilityMatrix as ComposableProbabilityMatrix;
            if (composableProbabilityMatrix != null)
            {
                composableProbabilityMatrix.SetModiferMultiplier("Pheromone", optimizerSettings.Alpha);
                composableProbabilityMatrix.SetModiferMultiplier("PerformanceMeasure", optimizerSettings.Beta);
                composableProbabilityMatrix.SetModiferMultiplier("TimeWindow", optimizerSettings.Gamma);
                composableProbabilityMatrix.SetModiferMultiplier("QueueTime", optimizerSettings.Lambda);
                
                composableProbabilityMatrix.ForcedHomeProbaility = optimizerSettings.ForcedHomeProbability;
            }

            // alpha, beta, gamma, initialpheromone, q, r
            _pheromoneMatrix.Rho = optimizerSettings.Rho;
            _pheromoneMatrix.Q = optimizerSettings.Q;
            _optimizer.MaxIterationSinceBestResult = optimizerSettings.MaxIterationSinceBestResult; // make setting
            _optimizer.EnableParallelism = optimizerSettings.EnableParallelism;
            _optimizer.MaxExecutionTime = optimizerSettings.MaxExecutionTime;
            _optimizer.MaxIterations = optimizerSettings.MaxIterations;
            _optimizer.DisallowPlaceholderDriver = optimizerSettings.DisallowPlaceholderDriver;
            _optimizer.PheromoneUpdateFrequency = optimizerSettings.PheromoneUpdateFrequency;
            _optimizer.FlexibleStartTime = optimizerSettings.FlexibleStartTime;
            _optimizer.UseTraffic = optimizerSettings.UseTraffic;

            // shuffle drivers for fairness (setting?)
            planConfigModel.Drivers = planConfigModel.Drivers.OrderBy(f => Guid.NewGuid()).ToList();

            Plan planModel = BuildSolution(planConfigModel);
            return planModel;
        }

        public void RecalculatePlanStatistics(Plan planModel)
        {
            _optimizer.UseTraffic = planModel.UseTraffic;

            // Some old data has invalid route segment statistic, even though this not best practice to do it here, but
            // it's the safest point

            foreach (PlanDriver driverPlan in planModel.DriverPlans)
            {
                var nodeSolution = NodeSolutionFromDriverPlan(driverPlan);
                var result = _optimizer.RecalculateRouteSolution(nodeSolution.DriverNode, nodeSolution.Nodes,
                    nodeSolution.StartTime);
                if (driverPlan.Driver.IsPlaceHolderDriver)
                {
                    driverPlan.RouteSegmentStatistics.Clear();
                }
                else
                {
                    driverPlan.RouteSegmentStatistics = result.RouteSegmentStatistics;
                }
            }
            
        }


        /// <summary>
        /// Builds a Plan with the given PlanConfig
        /// </summary>
        /// <param name="planConfig"></param>
        /// <returns></returns>
        public virtual Plan BuildSolution(PlanConfig planConfig)
        {
            if (planConfig == null)
            {
                throw new ArgumentNullException("planConfig");
            }

            // build the solution
            Solution solution = _optimizer.BuildSolution(planConfig.Drivers.ToList(), planConfig.DefaultDriver, planConfig.Jobs.ToList());

            // create a plan from the solution
            var plan = new Plan();

            // now that we've got the solution make a plan out of it
            foreach (NodeRouteSolution routeSolution in solution.RouteSolutions.Where(x => !x.DriverNode.Driver.IsPlaceHolderDriver))
            {
                PlanDriver driverPlan = DriverPlanFromNodeRouteSolution(routeSolution);
                plan.DriverPlans.Add(driverPlan);
            }

            // Add all jobs that goes to placeholder if there are any
            var unassignedJobs =
                solution.RouteSolutions.Where(x => x.DriverNode.Driver.IsPlaceHolderDriver)
                    .SelectMany(x => x.Nodes)
                    .Distinct()
                    .Cast<JobNode>().Select(x => x.Job).ToList();

            unassignedJobs.ForEach(plan.UnassignedJobs.Add);

            // Add the reminder from unassigned job nodes if there are any
            solution.UnassignedJobNodes.Cast<JobNode>().Select(x => x.Job).ToList().ForEach(plan.UnassignedJobs.Add);


            return plan;
        }

        public Solution GetSolutionFromPlan(Plan plan)
        {
            var result = new Solution();
            foreach (var nodeSolution in plan.DriverPlans.Select(NodeSolutionFromDriverPlan).Where(p => p != null && p.DriverNode != null && p.DriverNode.Driver != null && p.JobCount > 0))
            {
                result.RouteSolutions.Add(nodeSolution);
            }

            result.UnassignedJobNodes.AddRange(plan.UnassignedJobs.Select(f => new JobNode(f)));
           
            return result;
        }

        public SolutionPerformanceStatistics GetSolutionPerformanceStatistics(Plan plan)
        {
            var solution = GetSolutionFromPlan(plan);
            return _reportingService.GetSolutionPerformanceStatistics(solution);
        }

        public PlanDriver DriverPlanFromNodeRouteSolution(NodeRouteSolution routeSolution)
        {
            var driverPlan = new PlanDriver
            {
                Driver = routeSolution.DriverNode.Driver,
                JobPlans = new List<PlanDriverJob>(),
                RouteSegmentStatistics = routeSolution.RouteSegmentStatistics
            };
            
            if (routeSolution.Nodes.Count > 0)
            {
                // get route solution jobs
                
                List<JobNode> jobNodes = routeSolution.Nodes.Cast<JobNode>().ToList();

                driverPlan.DepartureTime = routeSolution.StartTime.Ticks;

                foreach (JobNode jobNode in jobNodes)
                {
                    var jobPlan = new PlanDriverJob
                    {
                        Job = jobNode.Job,
                        RouteStops = jobNode.Job.RouteStops.ToList(),
                        DepartureTime = jobNode.DepartureTime
                    };

                    driverPlan.JobPlans.Add(jobPlan);
                }
            }

            return driverPlan;
        }

        public NodeRouteSolution NodeSolutionFromDriverPlan(PlanDriver driverPlan)
        {
            try
            {
                var driverNode = new DriverNode(driverPlan.Driver);
                var jobNodes = driverPlan.JobPlans.Select((f, i) => _jobNodeService.CreateJobNode(f.Job, false, i != 0));
                driverNode.DepartureTime = driverPlan.DepartureTime;
                NodeRouteSolution routeSolution = _routeService.CreateRouteSolution(driverNode, jobNodes, false);
                routeSolution.StartTime = driverPlan.DepartureTimeSpan;
                return routeSolution;
            }
            catch
            {
                return null;
            }
        }
    }
}