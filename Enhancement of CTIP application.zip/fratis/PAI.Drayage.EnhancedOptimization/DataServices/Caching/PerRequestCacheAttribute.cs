using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Caching
{
    /// <summary>
    /// Attribute for PerRequestCacheManager
    /// Allows IoC to resolve ICacheManager to PerRequestCacheManager when decorated with this attribute
    /// </summary>
    public class PerRequestCacheAttribute: Attribute
    {
    }
}