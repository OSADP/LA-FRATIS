using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Caching
{
    /// <summary>
    /// Attribute for MemoryCacheManager
    /// Allows IoC to resolve ICacheManager to MemoryCacheManager when decorated with this attribute
    /// </summary>
    public class MemoryCacheAttribute : Attribute
    {
    }
}