using System.Linq;
using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Caching
{
    /// <summary>
    /// Extensions
    /// </summary>
    public static class CacheExtensions
    {
        public static bool Get<T>(this ICacheManager cacheManager, string key, Func<T> acquire, out T value)
        {
            return Get(cacheManager, key, 60, acquire, out value);
        }

        public static bool Get<T>(this ICacheManager cacheManager, string key, int cacheTime, Func<T> acquire, out T value) 
        {
            if (cacheManager.IsSet(key))
            {
                value = cacheManager.Get<T>(key);
                return true;
            }

            value = acquire();
            cacheManager.Set(key, value, cacheTime);
            return false;
        }
    }
}
