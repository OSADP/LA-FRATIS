using System.Linq;
using PAI.CTIP.Domain;

namespace PAI.CTIP.EnhancedOptimization.DataServices
{
    /// <summary>
    /// Represents the interface for basic <see cref="EntityBase"/> services
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public partial interface IEntityServiceBase<TEntity> where TEntity : EntityBase
    {
        /// <summary>
        /// Deletes an entity
        /// </summary>
        /// <param name="entity">entity</param>
        void Delete(TEntity entity);

        /// <summary>
        /// Gets an entity 
        /// </summary>
        /// <param name="entityId">entity identifier</param>
        /// <returns>Entity</returns>
        TEntity GetById(int entityId);

        /// <summary>
        /// Inserts an entity
        /// </summary>
        /// <param name="entity">Entity</param>
        void Insert(TEntity entity);

        /// <summary>
        /// Updates the entity
        /// </summary>
        /// <param name="entity">Entity</param>
        void Update(TEntity entity);

        /// <summary>
        /// Clear cache
        /// </summary>
        void ClearCache();

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of <see cref="TEntity"/>
        /// </summary>
        /// <returns><see cref="IQueryable"/> of <see cref="TEntity"/></returns>
        IQueryable<TEntity> Select();

        /// <summary>
        /// Attaches the entity to the underlying context of this reposity.  
        /// It is placed in the Unchanged state as if it was just read from the database
        /// </summary>
        /// <param name="entity">The entity to attach</param>
        /// <param name="markDirty">Marks the newly attached entity as modified</param>
        /// <returns></returns>
        void Attach(TEntity entity, bool markDirty = false);
    }
}