using System.Linq;
using System;
using PAI.CTIP.Domain;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    public static class EventPublisherExtensions
    {
        public static void EntityInserted<T>(this IEventPublisher eventPublisher, T entity) where T : EntityBase
        {
            eventPublisher.Publish(new EntityInserted<T>(entity));
        }

        public static void EntityUpdated<T>(this IEventPublisher eventPublisher, T entity) where T : EntityBase
        {
            eventPublisher.Publish(new EntityUpdated<T>(entity));
        }

        public static void EntityDeleted<T>(this IEventPublisher eventPublisher, T entity) where T : EntityBase
        {
            eventPublisher.Publish(new EntityDeleted<T>(entity));
        }
    }
}