using System.Linq;
using System;
using System.Collections.Generic;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    /// <summary>
    /// Event subscriber interface
    /// </summary>
    public interface ISubscriptionService
    {
        IEnumerable<IConsumer<T>> GetSubscriptions<T>() where T : IEvent;
    }
}