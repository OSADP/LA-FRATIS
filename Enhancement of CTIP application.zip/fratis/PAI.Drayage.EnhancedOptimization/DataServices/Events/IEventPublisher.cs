using System.Linq;
using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    /// <summary>
    /// Event publisher interface
    /// </summary>
    public interface IEventPublisher
    {
        void Publish<T>(T eventMessage) where T : IEvent;
    }
}
