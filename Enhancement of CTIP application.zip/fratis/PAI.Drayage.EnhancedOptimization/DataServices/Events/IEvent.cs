using System.Linq;
using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    /// <summary>
    /// Event message interface
    /// </summary>
    public interface IEvent
    {
    }
}