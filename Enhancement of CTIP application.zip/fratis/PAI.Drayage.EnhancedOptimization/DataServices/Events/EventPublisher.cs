using System;
using System.Linq;
using PAI.CTIP.EnhancedOptimization.DataServices.Logging;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    public class EventPublisher : IEventPublisher
    {
        private readonly ISubscriptionService _subscriptionService;
        private readonly ILogService _logService;

        public EventPublisher(ISubscriptionService subscriptionService, ILogService logService)
        {
            _subscriptionService = subscriptionService;
            _logService = logService;
        }

        public void Publish<T>(T eventMessage) where T : IEvent
        {
            var subscriptions = _subscriptionService.GetSubscriptions<T>();
            subscriptions.ToList().ForEach(x => PublishToConsumer(x, eventMessage));
        }

        private void PublishToConsumer<T>(IConsumer<T> x, T eventMessage) where T : IEvent
        {
            try
            {
                x.HandleEvent(eventMessage);
            }
            catch (Exception ex)
            {
                _logService.Error("PublishToConsumer", ex);
            }
        }
    }
}
