using System.Linq;
using System;
using PAI.CTIP.Domain;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    /// <summary>
    /// A container for entities that are updated.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class EntityUpdated<T> : IEvent where T : EntityBase
    {
        public EntityUpdated(T entity)
        {
            Entity = entity;
        }

        public T Entity { get; private set; }
    }
}