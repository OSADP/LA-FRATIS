using System.Linq;
using System;
using System.Collections.Generic;
using PAI.Infrastructure.Engine;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    public class SubscriptionService : ISubscriptionService
    {
        private readonly IEngine _engine;

        public SubscriptionService(IEngine engine)
        {
            _engine = engine;
        }

        public IEnumerable<IConsumer<T>> GetSubscriptions<T>() where T : IEvent
        {
            return _engine.GetAll<IConsumer<T>>();
        }
    }
}
