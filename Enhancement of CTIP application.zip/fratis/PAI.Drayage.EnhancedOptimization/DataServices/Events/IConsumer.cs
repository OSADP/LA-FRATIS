using System.Linq;
using System;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Events
{
    /// <summary>
    /// Event consumer interface
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IConsumer<T> where T: IEvent
    {
        void HandleEvent(T eventMessage);
    }
}