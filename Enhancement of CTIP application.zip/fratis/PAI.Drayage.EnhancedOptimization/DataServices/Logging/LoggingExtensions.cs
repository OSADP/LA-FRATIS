using System.Linq;
using System;
using PAI.CTIP.Domain.Logging;
using PAI.CTIP.Domain.Users;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Logging
{
    public static class LoggingExtensions
    {
        public static void Debug(this ILogService logger, string message, Exception exception = null, User user = null)
        {
            FilteredLog(logger, LogLevel.Debug, message, exception, user);
        }

        public static void Information(this ILogService logger, string message, Exception exception = null, User user = null)
        {
            FilteredLog(logger, LogLevel.Information, message, exception, user);
        }

        public static void Warning(this ILogService logger, string message, Exception exception = null, User user = null)
        {
            FilteredLog(logger, LogLevel.Warning, message, exception, user);
        }

        public static void Error(this ILogService logger, string message, Exception exception = null, User user = null)
        {
            FilteredLog(logger, LogLevel.Error, message, exception, user);
        }

        public static void Fatal(this ILogService logger, string message, Exception exception = null, User user = null)
        {
            FilteredLog(logger, LogLevel.Fatal, message, exception, user);
        }

        private static void FilteredLog(ILogService logger, LogLevel level, string message, Exception exception = null, User user = null)
        {
            if (logger == null) 
                return;

            //don't log thread abort exception
            if (exception is System.Threading.ThreadAbortException)
                return;
            
            //if (logger.IsEnabled(level))
            {
                string fullMessage = exception == null ? string.Empty : exception.ToString();
                logger.InsertLog(level, message, fullMessage, user);
            }
        }
    }
}
