using System.Linq;
using System;
using Ninject.Extensions.Logging;
using PAI.CTIP.Domain.Logging;
using PAI.CTIP.Domain.Users;
using PAI.Infrastructure.Data;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Logging
{

    public partial class LogService : ILogService
    {
        private readonly ILogger _logger;
        protected readonly IRepository<LogEntry> _repository;

        public LogService(ILogger logger, IRepository<LogEntry> repository)
        {
            _logger = logger;
            _repository = repository;
        }

        public bool IsEnabled(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Trace:
                    return _logger.IsTraceEnabled;

                case LogLevel.Debug:
                    return _logger.IsDebugEnabled;

                case LogLevel.Information:
                    return _logger.IsInfoEnabled;

                case LogLevel.Warning:
                    return _logger.IsWarnEnabled;

                case LogLevel.Error:
                    return _logger.IsErrorEnabled;

                case LogLevel.Fatal:
                    return _logger.IsFatalEnabled;
            }

            return false;
        }

        public void Delete(LogEntry entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            _repository.Delete(entity);
        }

        public LogEntry GetById(int entityId)
        {
            return _repository.GetById(entityId);
        }

        public void Insert(LogEntry entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            _repository.Insert(entity);
        }

        public void Update(LogEntry entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            _repository.Update(entity);
        }

        public IQueryable<LogEntry> GetAll()
        {
            return _repository.Select();
        }

        public void InsertLog(LogLevel level, string message, string fullMessage, User user)
        {
            var logEntry = new LogEntry()
                {
                    LogLevel = level,
                    Message = message,
                    FullMessage = fullMessage,
                    User = user,
                    AuditDate = DateTime.UtcNow
                };

            Insert(logEntry);
        }
    }
}
