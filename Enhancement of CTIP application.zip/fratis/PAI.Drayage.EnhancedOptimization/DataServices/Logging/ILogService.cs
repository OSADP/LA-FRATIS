using System.Linq;
using System;
using PAI.CTIP.Domain.Logging;
using PAI.CTIP.Domain.Users;

namespace PAI.CTIP.EnhancedOptimization.DataServices.Logging
{
    /// <summary>
    /// Logger interface
    /// </summary>
    public partial interface ILogService
    {
        bool IsEnabled(LogLevel level);

        /// <summary>
        /// Deletes an entity
        /// </summary>
        /// <param name="entity">entity</param>
        void Delete(LogEntry entity);

        /// <summary>
        /// Gets an entity 
        /// </summary>
        /// <param name="entityId">entity identifier</param>
        /// <returns>Entity</returns>
        LogEntry GetById(int entityId);

        /// <summary>
        /// Inserts an entity
        /// </summary>
        /// <param name="entity">Entity</param>
        void Insert(LogEntry entity);

        /// <summary>
        /// Updates the entity
        /// </summary>
        /// <param name="entity">Entity</param>
        void Update(LogEntry entity);

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of LogEntry
        /// </summary>
        /// <returns><see cref="IQueryable"/> of LogEntry</returns>
        IQueryable<LogEntry> GetAll();

        void InsertLog(LogLevel level, string message, string fullMessage, User user);
    }
}