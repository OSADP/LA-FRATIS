using System;
using System.Linq;
using PAI.CTIP.Domain;
using PAI.CTIP.EnhancedOptimization.DataServices.Caching;
using PAI.CTIP.EnhancedOptimization.DataServices.Events;
using PAI.Infrastructure.Data;

namespace PAI.CTIP.EnhancedOptimization.DataServices
{
    /// <summary>
    /// Represents the base class for basic <see cref="EntityBase"/> services
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public partial class EntityServiceBase<TEntity> : IEntityServiceBase<TEntity> where TEntity : EntityBase
    {
        protected readonly IRepository<TEntity> _repository;
        protected readonly ICacheManager _cacheManager;
        protected readonly IEventPublisher _eventPublisher;

        protected bool _enableCaching = true;
        protected bool _enableEventPublishing = true;

        private string _cachePatternKey;
        public virtual string CachePatternKey
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_cachePatternKey))
                {
                    string name = typeof (TEntity).FullName.Replace("+",".");
                    _cachePatternKey = name + ".";
                }
                return _cachePatternKey;
            }
        }

        protected virtual string CacheByIdPatternKey
        {
            get { return CachePatternKey + "id-{0}"; }
        }

        public string CachePatternAllKey
        {
            get { return CachePatternKey + "All"; }
        }

        public EntityServiceBase(IRepository<TEntity> repository, ICacheManager cacheManager, IEventPublisher eventPublisher)
        {
            _repository = repository;
            _cacheManager = cacheManager;
            _eventPublisher = eventPublisher;
        }

        /// <summary>
        /// Deletes an entity
        /// </summary>
        /// <param name="entity">entity</param>
        public virtual void Delete(TEntity entity)
        {
            if (entity == null) 
                throw new ArgumentNullException("entity");
            
            _repository.Delete(entity);

            // remove entity from cache
            if (_enableCaching)
                _cacheManager.RemoveByPattern(string.Format(CacheByIdPatternKey, entity.Id));

            // event notification
            if(_enableEventPublishing)
                _eventPublisher.EntityDeleted(entity);
        }

        /// <summary>
        /// Gets an entity 
        /// </summary>
        /// <param name="entityId">entity identifier</param>
        /// <returns>Entity</returns>
        public virtual TEntity GetById(int entityId)
        {
            if (_enableCaching)
            {
                var key = string.Format(CacheByIdPatternKey, entityId);

                TEntity entity;
                if (_cacheManager.Get(key, () => InternalGetById(entityId), out entity))
                {
                    _repository.Attach(entity);
                }
                return entity;
            }
            return InternalGetById(entityId);
        }

        /// <summary>
        /// Gets an <see cref="TEntity"/> by id
        /// Override to select eagerly when necessary
        /// </summary>
        /// <returns><see cref="TEntity"/></returns>
        protected virtual TEntity InternalGetById(int entityId)
        {
            return _repository.GetById(entityId);
        }

        /// <summary>
        /// Inserts an entity
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void Insert(TEntity entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            _repository.Insert(entity);

            // event notification
            if (_enableEventPublishing)
                _eventPublisher.EntityInserted(entity);
        }

        /// <summary>
        /// Updates the entity
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void Update(TEntity entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            _repository.Update(entity);

            // remove entity from cache
            if (_enableCaching)
                _cacheManager.RemoveByPattern(string.Format(CacheByIdPatternKey, entity.Id));

            // event notification
            if (_enableEventPublishing)
                _eventPublisher.EntityUpdated(entity);
        }

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of <see cref="TEntity"/>
        /// </summary>
        /// <returns><see cref="IQueryable"/> of <see cref="TEntity"/></returns>
        public virtual IQueryable<TEntity> Select()
        {
            return InternalSelect();
        }

        public void Attach(TEntity entity, bool markDirty = false)
        {
            _repository.Attach(entity, markDirty);
        }

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of <see cref="TEntity"/>
        /// Override to select eagerly when necessary
        /// </summary>
        /// <returns><see cref="IQueryable"/> of <see cref="TEntity"/></returns>
        protected virtual IQueryable<TEntity> InternalSelect()
        {
            return _repository.Select();
        }
        
        /// <summary>
        /// Clear cache
        /// </summary>
        public virtual void ClearCache()
        {
            if (_enableCaching)
                _cacheManager.RemoveByPattern(CachePatternKey);
        }
    }
}