﻿using System.Collections.Generic;

namespace PAI.Drayage.EnhancedOptimization.Model
{
    /// <summary>
    /// A Validation Result
    /// </summary>
    public struct ValidationResult
    {
        /// <summary>
        /// Gets or sets whether validation was successful
        /// </summary>
        public bool Successful { get; set; }

        /// <summary>
        /// Gets or sets the list of errors
        /// </summary>
        public List<string> Errors { get; set; }
    }
}
