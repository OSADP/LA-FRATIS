namespace PAI.Drayage.EnhancedOptimization.Model
{
    public class OptimizerSettings
    {
        public bool DisallowPlaceholderDriver { get; set; }

        public float Alpha { get; set; }

        public float Beta { get; set; }

        public float Gamma { get; set; }

        public float Lambda { get; set; }

        public double InitialPheromoneValue { get; set; }

        public double Q { get; set; }

        public double Rho { get; set; }

        public float Zeta { get; set; }

        public double? ForcedHomeProbability { get; set; }
        public int MaxIterationSinceBestResult { get; set; }
        public bool EnableParallelism { get; set; }
        public int MaxExecutionTime { get; set; }
        public int MaxIterations { get; set; }
        public int PheromoneUpdateFrequency { get; set; }
        public bool FlexibleStartTime { get; set; }
        public bool UseTraffic { get; set; }

        public OptimizerSettings()
        {
            Alpha = 1f; // Pheromone
            Beta = 3f; // PerformanceMeasure
            Gamma = 1.8f; //1.83f;// 1.803f; // TimeWindow
            Lambda = 0f; // QueueTime
            Q = 1000.0; // Pheromone Increment
            Rho = 0.5; // Pheromone Evaporation
            Zeta = 100f;
            DisallowPlaceholderDriver = false;
            MaxIterationSinceBestResult = 3000; // make setting
            EnableParallelism = false;
            MaxExecutionTime = 300000;
            MaxIterations = 200000;
            PheromoneUpdateFrequency = 5;
            FlexibleStartTime = false;
            UseTraffic = false;
        }
    }
}
