using System.Collections.Generic;
using System.Linq;
using System;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Model.Planning;
using PAI.Drayage.Optimization.Reporting.Model;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Optimization.Reporting.Services
{
    public interface IDataExtractor
    {
        SolutionPerformanceStatistics GetSolutionPerformanceStatistics(Solution solution);
    }

    public class DataExtractor: IDataExtractor
    {
        readonly IRouteStatisticsService _routeStatisticsService;
        readonly IRouteStopService _routeStopService;
        readonly IRouteService _routeService;
        readonly IDrayageOptimizer _drayageOptimizer;

        public DataExtractor(IRouteStatisticsService routeStatisticsService, IRouteStopService routeStopService, IRouteService routeService, IDrayageOptimizer drayageOptimizer)
        {
            _routeStatisticsService = routeStatisticsService;
            _routeStopService = routeStopService;
            _routeService = routeService;
            _drayageOptimizer = drayageOptimizer;
        }

        public int CalculateNumberOfBackhauls(NodeRouteSolution routeSolution)
        {
            int result = 0;
            result = routeSolution.Nodes.Count - 1;
            return result;
        }

        /// <summary>
        /// Computes the number of load maches for the given route solution
        /// </summary>
        /// <param name="routeSolution"></param>
        /// <returns></returns>
        public int CalculateNumberOfLoadMatches(NodeRouteSolution routeSolution)
        {
            int result = 0;

            foreach (var node in routeSolution.Nodes)
            {
                bool hasLiveUnloading = false;
                bool hasBoth = false;

                foreach (var routeStop in node.RouteStops)
                {
                    if (routeStop.StopAction == StopActions.LiveUnloading)
                    {
                        hasLiveUnloading = true;
                    }
                    else
                    {
                        if (hasLiveUnloading && routeStop.StopAction == StopActions.LiveLoading)
                        {
                            hasBoth = true;
                        }
                        else if (hasLiveUnloading && routeStop.StopAction != StopActions.LiveLoading)
                        {
                            hasLiveUnloading = false;
                            hasBoth = false;
                        }
                    }

                    if (hasBoth)
                    {
                        result++;
                        hasLiveUnloading = false;
                        hasBoth = false;
                    }
                }
            }

            return result;
        }

        private PerformanceStatistics CalculatePerformanceStatistics(NodeRouteSolution routeSolution)
        {
            var result = new PerformanceStatistics
            {
                    NumberOfJobs = routeSolution.JobCount,
                    //DriverDutyHourUtilization = routeSolution.RouteStatistics.TotalTime.TotalHours / routeSolution.DriverNode.Driver.AvailableDutyTime.TotalHours,
                    DriverDutyHourUtilization = routeSolution.RouteStatistics.TotalNonIdleTime.TotalHours / routeSolution.DriverNode.Driver.AvailableDutyTime.TotalHours,
                    DriverDrivingUtilization = routeSolution.RouteStatistics.TotalTravelTime.TotalHours / routeSolution.DriverNode.Driver.AvailableDrivingTime.TotalHours,
                    DrivingTimePercentage = routeSolution.RouteStatistics.TotalTravelTime.TotalHours / routeSolution.RouteStatistics.TotalTime.TotalHours,
                    WaitingTimePercentage = routeSolution.RouteStatistics.TotalIdleTime.TotalHours / routeSolution.RouteStatistics.TotalTime.TotalHours,
                    NumberOfBackhauls = CalculateNumberOfBackhauls(routeSolution),
                    NumberOfLoadmatches = CalculateNumberOfLoadMatches(routeSolution)
                };

            return result;
        }

        public IList<RouteSegmentStatistics> GetRouteSegmentStats(NodeRouteSolution routeSolution)
        {
            var startTime = routeSolution.StartTime;
            var routeStops = _routeService.GetRouteStopsForRouteSolution(routeSolution);

            return _routeStopService.CalculateRouteSegmentStatistics(startTime, routeStops, false);
        }

        public TruckPerformanceStatistics CalculateTruckPerformanceStatistics(NodeRouteSolution routeSolution)
        {
            var nodes = routeSolution.AllNodes.Select(x => x).ToList();
            var currentRouteStatistice = new RouteStatistics();
            var cumulativeRouteStatistics = new RouteStatistics();
            var nodeTimingList = new List<NodeTiming>();
            var segmentList = new List<RouteSegmentStatistics>();

            var routeList = nodes.SelectMany(x => x.RouteStops).ToList();

            for (var i = 1; i < nodes.Count; i++)
            {
                var startNode = nodes[i - 1];
                var endNode = nodes[i];
                var startNodeEndTime = routeSolution.StartTime;
                if (nodeTimingList.Any())
                {
                    startNodeEndTime = nodeTimingList.Last().EndExecutionTime;
                }
                var nodeTiming = _routeStatisticsService.GetNodeTiming(startNode, endNode, startNodeEndTime, false, currentRouteStatistice);
                nodeTimingList.Add(nodeTiming);
                cumulativeRouteStatistics += nodeTimingList.Last().CumulativeRouteStatistics;
            }
            var routeSegmaneStatistics = _routeStopService.CalculateRouteSegmentStatistics(routeSolution.StartTime, routeList, false);
            segmentList.AddRange(routeSegmaneStatistics);

            var segmentStats = GetRouteSegmentStats(routeSolution);

            var truckPreformanceStatistics =
                new TruckPerformanceStatistics
                    {
                        PerformanceStatistics = CalculatePerformanceStatistics(routeSolution),
                        RouteSegmentStatistics = segmentList,
                        RouteStatistics = cumulativeRouteStatistics,
                        RouteStatisticsByTruckState =
                            (from segment in segmentStats
                             group segment by segment.TruckState
                             into g
                             select new
                                 {
                                     TruckState = g.Key,
                                     Statistics = g.Aggregate(new RouteStatistics(), (seed, segment) => seed + segment.Statistics)
                                 })
                                .ToDictionary(key => key.TruckState, value => value.Statistics)
                    };

            return truckPreformanceStatistics;
            /*          
                      var segmentStats = GetRouteSegmentStats(routeSolution);

                      // calculate the statistics by truck state
                      var statsByTructState = (from segment in segmentStats
                                               group segment by segment.TruckState into g
                                               select new
                                               {
                                                   TruckState = g.Key,
                                                   Statistics = g.Aggregate(new RouteStatistics(), (seed, segment) => seed + segment.Statistics)
                                               })
                              .ToDictionary(key => key.TruckState, value => value.Statistics);

                      // compute the sum of all the route statistics
                      var totalRouteStatistics = segmentStats.Aggregate(new RouteStatistics(), (seed, segment) => seed + segment.Statistics);

                      var performanceStatistics = CalculatePerformanceStatistics(routeSolution);

                      var truckStatistics = new TruckPerformanceStatistics
                      {
                          RouteStatisticsByTruckState = statsByTructState,
                          RouteStatistics = totalRouteStatistics,
                          PerformanceStatistics = performanceStatistics,
                          RouteSegmentStatistics = segmentStats
                      };

                      return truckStatistics;
             */
        }

        public SolutionPerformanceStatistics GetSolutionPerformanceStatistics(Solution solution)
        {
            var truckStatisticBySolution = new Dictionary<NodeRouteSolution, TruckPerformanceStatistics>();
            var totalRouteStatisticsByTruckState = new Dictionary<TruckState, RouteStatistics>();
            var totalPerformanceStatistics = new PerformanceStatistics();
            var totalRouteStatistics = new RouteStatistics();

            foreach (var routeSolution in solution.RouteSolutions)
            {
                // calculate truck performance statistics
                var truckStatistics = CalculateTruckPerformanceStatistics(routeSolution);
                truckStatisticBySolution[routeSolution] = truckStatistics;

                // calculate total route statistics by truck state
                foreach (var truckState in truckStatistics.RouteStatisticsByTruckState.Keys)
                {
                    if (!totalRouteStatisticsByTruckState.ContainsKey(truckState))
                    {
                        totalRouteStatisticsByTruckState[truckState] = new RouteStatistics();
                    }

                    totalRouteStatisticsByTruckState[truckState] += truckStatistics.RouteStatisticsByTruckState[truckState];
                }

                // sum up performance & route stats
                totalPerformanceStatistics += truckStatistics.PerformanceStatistics;
                totalRouteStatistics += truckStatistics.RouteStatistics;
            }

            double solutionCount = solution.RouteSolutions.Count;

            var result = new SolutionPerformanceStatistics
                {
                    TruckStatistics = truckStatisticBySolution,
                    TotalRouteStatisticsByTruckState = totalRouteStatisticsByTruckState,
                    TotalRouteStatistics = totalRouteStatistics,
                    NumberOfBackhauls = totalPerformanceStatistics.NumberOfBackhauls,
                    AverageNumberOfBackhauls = totalPerformanceStatistics.NumberOfBackhauls / solutionCount,
                    NumberOfLoadmatches = totalPerformanceStatistics.NumberOfLoadmatches,
                    AverageNumberOfLoadmatches = totalPerformanceStatistics.NumberOfLoadmatches / solutionCount,
                    NumberOfJobs = totalPerformanceStatistics.NumberOfJobs,
                    AverageNumberOfJobs = totalPerformanceStatistics.NumberOfJobs / solutionCount,
                    AverageDriverDutyHourUtilization = totalPerformanceStatistics.DriverDutyHourUtilization / solutionCount,
                    AverageDriverDrivingUtilization = totalPerformanceStatistics.DriverDrivingUtilization / solutionCount,
                    DrivingTimePercentage = totalRouteStatistics.TotalTravelTime.TotalHours / totalRouteStatistics.TotalTime.TotalHours,
                    WaitingTimePercentage = totalRouteStatistics.TotalIdleTime.TotalHours / totalRouteStatistics.TotalTime.TotalHours
                };

            return result;
        }

        protected Solution GetSolutionFromPlan(Plan plan)
        {
            var solution = new Solution();
            var unassignedJobNodes = plan.UnassignedJobs.Select(x => new JobNode(x)).Cast<INode>().ToList();
            solution.UnassignedJobNodes.AddRange(unassignedJobNodes);

            foreach (var driverPlan in plan.DriverPlans.Where(x => x.JobPlans.Count > 0))
            {
                var driverNode = new DriverNode(driverPlan.Driver);
                var nodeRouteSolution = new NodeRouteSolution();
                nodeRouteSolution.Nodes = new List<INode>();
                nodeRouteSolution.Nodes = nodeRouteSolution.Nodes.Concat(new List<INode> { driverNode }).ToList();
                var routeStatistics = new RouteStatistics();
                foreach (var routeSegmentStatistics in driverPlan.RouteSegmentStatistics)
                {
                    routeStatistics += routeSegmentStatistics.Statistics;
                }
                nodeRouteSolution.RouteStatistics = routeStatistics;
                var startTime = driverPlan.JobPlans.Min(x => x.DepartureTime);
                nodeRouteSolution.StartTime = new TimeSpan(startTime);
                nodeRouteSolution.DriverNode = driverNode;
                foreach (var planDriverJob in driverPlan.JobPlans)
                {
                    var nodes = new List<INode> { new JobNode(planDriverJob.Job) }.ToList();
                    nodeRouteSolution.Nodes = nodeRouteSolution.Nodes.Concat(nodes).ToList();
                }
                nodeRouteSolution.Nodes = nodeRouteSolution.Nodes.Concat(new List<INode> { driverNode }).ToList();
                solution.RouteSolutions.Add(nodeRouteSolution);
            }
            return solution;
        }

        public SolutionPerformanceStatistics GetSolutionPerformanceStatistics(Plan plan)
        {
            return GetSolutionPerformanceStatistics(GetSolutionFromPlan(plan));
        }
    }
}