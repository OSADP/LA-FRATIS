using System.Collections.Generic;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Reporting.Model
{
    public class TruckPerformanceStatistics
    {
        public Dictionary<TruckState, RouteStatistics> RouteStatisticsByTruckState { get; set; }

        public RouteStatistics RouteStatistics { get; set; }

        public PerformanceStatistics PerformanceStatistics { get; set; }

        public IList<RouteSegmentStatistics> RouteSegmentStatistics { get; set; }
    }
}