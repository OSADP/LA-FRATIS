//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Domain.Equipment
{
    /// <summary>
    /// Represents a vehicle
    /// </summary>
    public class Vehicle : EntityBase
    {
        #region Public Properties

        public virtual Driver Driver { get; set; }

        /// <summary>
        /// Gets or sets the driver id
        /// </summary>
        public int? DriverId { get; set; }

        /// <summary>
        /// Gets or sets the vehicle legacy id
        /// </summary>
        public string LegacyId { get; set; }

        /// <summary>
        /// License plate for the provided vehicle
        /// </summary>
        public string LicensePlate { get; set; }

        /// <summary>
        /// Gets or sets the vehicle name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the latest WebFleet vehicle location
        /// </summary>

        /// <summary>
        /// Gets or sets the latest reported vehicle position string
        /// </summary>
        public string PositionText { get; set; }

        /// <summary>
        /// Gets or sets the vehicle type
        /// </summary>
        public string VehicleType { get; set; }

        #endregion
    }
}