using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Extensions;

namespace PAI.Common.Core.EventBroker
{
    public class BasicPubSubService : IPubSubService
    {
        public readonly IDictionary<string, IList<Action<string, string>>> _subscriptions =
            new Dictionary<string, IList<Action<string, string>>>();

        private readonly ReaderWriterLockSlim _lockSlim = new ReaderWriterLockSlim();

        public void Publish(string channel, string message)
        {
            using (_lockSlim.Read())
            {
                IList<Action<string, string>> handlers;
                if (_subscriptions.TryGetValue(channel, out handlers))
                {
                    foreach (var handler in handlers)
                    {
                        handler.Invoke(channel, message);
                    }
                }
            }
        }
        
        public async Task PublishAsync(string channel, string message)
        {
            Task t = null;

            using (_lockSlim.Read())
            {
                IList<Action<string, string>> handlers;
                if (_subscriptions.TryGetValue(channel, out handlers))
                {
                    // invoke all handlers asynchronously
                    t = Task.WhenAll(handlers.Select(handler =>
                        Task.Factory.FromAsync(handler.BeginInvoke, handler.EndInvoke, channel, message, null)));
                }
            }

            // need to await outside of ReaderWriterLockSlim
            if (t != null)
            {
                await t.ConfigureAwait(false);
            }
        }

        public void Subscribe(string channel, Action<string, string> handler)
        {
            using (_lockSlim.Write())
            {
                IList<Action<string, string>> handlers;
                if (!_subscriptions.TryGetValue(channel, out handlers))
                {
                    handlers = new List<Action<string, string>>();
                    _subscriptions[channel] = handlers;
                }

                handlers.Add(handler);
            }
        }
        
        public async Task SubscribeAsync(string channel, Action<string, string> handler)
        {
            await Task.Run(() => Subscribe(channel, handler)).ConfigureAwait(false);
        }

        public void Unsubscribe(string channel, Action<string, string> handler = null)
        {
            using (_lockSlim.Write())
            {
                IList<Action<string, string>> handlers;
                if (_subscriptions.TryGetValue(channel, out handlers))
                {
                    if (handler == null)
                    {
                        handlers.Clear();
                    }
                    else
                    {
                        handlers.Remove(handler);
                    }
                }
            }
        }

        public async Task UnsubscribeAsync(string channel, Action<string, string> handler = null)
        {
            await Task.Run(() => Unsubscribe(channel, handler)).ConfigureAwait(false);
        }

        public void UnsubscribeAll()
        {
            _subscriptions.Clear();
        }

        public async Task UnsubscribeAllAsync()
        {
            _subscriptions.Clear();
        }
    }
}