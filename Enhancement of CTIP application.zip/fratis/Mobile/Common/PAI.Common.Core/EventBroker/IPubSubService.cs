﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace PAI.Common.Core.EventBroker
{
    public interface IPubSubService
    {
        /// <summary>
        /// Posts a message to the given channel.
        /// </summary>
        void Publish(string channel, string message);

        /// <summary>
        /// Posts a message to the given channel.
        /// </summary>
        Task PublishAsync(string channel, string message);

        /// <summary>
        /// Subscribe to perform some operation.
        /// </summary>
        void Subscribe(string channel, Action<string, string> handler);

        /// <summary>
        /// Subscribe to perform some operation.
        /// </summary>
        Task SubscribeAsync(string channel, Action<string, string> handler);

        /// <summary>
        /// Unsubscribe from a specified message channel
        /// </summary>
        void Unsubscribe(string channel, Action<string, string> handler = null);

        /// <summary>
        /// Unsubscribe from a specified message channel
        /// </summary>
        Task UnsubscribeAsync(string channel, Action<string, string> handler = null);

        /// <summary>
        /// Unsubscribe all subscriptions on this instance
        /// </summary>
        void UnsubscribeAll();

        /// <summary>
        /// Unsubscribe all subscriptions on this instance
        /// </summary>
        Task UnsubscribeAllAsync();
    }

    public static class PubSubServiceExt
    {
        private static readonly JsonSerializerSettings _jsonSerializerSettings = new JsonSerializerSettings()
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver(),
            Formatting = Formatting.Indented
        };
        
        /// <summary>
        /// Posts a message to the given channel.
        /// </summary>
        public static void Publish<T>(this IPubSubService service, string channel, T message)
        {
            var json = JsonConvert.SerializeObject(message, _jsonSerializerSettings);
            service.Publish(channel, json);
        }

        /// <summary>
        /// Subscribe to perform some operation.
        /// </summary>
        public static void Subscribe<T>(this IPubSubService service, string channel, Action<string, T> handler)
        {
            service.Subscribe(channel, (c, message) =>
                {
                    var obj = JsonConvert.DeserializeObject<T>(message, _jsonSerializerSettings);
                    handler.Invoke(c, obj);
                }
            );
        }


    }


}
