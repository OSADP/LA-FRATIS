using System;

namespace PAI.Common.Core
{
    public interface IDateTimeHelper
    {
        TimeZoneInfo GetTimeZoneInfo(string timeZoneId);
        TimeZoneInfo GetLocalTimeZoneInfo();

        DateTime ConvertToTime(DateTime dt, TimeZoneInfo sourceTimeZone, TimeZoneInfo destinationTimeZone);

        DateTime ConvertUtcToLocalTime(DateTime dt, bool forceSourceDateToUtcIfUnspecified = true);

        DateTime ConvertLocalToUtcTime(DateTime dt);

        DateTime GetLocalTime();

        DateTime ConvertUnixTimeToDateTime(double unixTime);

        double ConvertDateTimeToUnixTime(DateTime dt);

        DateTime GetVirtualUtcNow(bool extendTimeStamp = false);

        DateTimeHelper SetCurrentTimeZone(TimeZoneInfo timeZoneInfo);

        DateTimeHelper SetCurrentTimeZone(string timeZoneId);
    }
}