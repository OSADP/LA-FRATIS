﻿using System;

namespace PAI.Common.Core
{
    public class MathUtils
    {
        public const decimal EpsilonDecimal = .0000001m;
        public const double EpsilonDouble = .0000001;
        public const float EpsilonFloat = .0000001f;

        public static bool IsNearlyZero(decimal value, decimal tolerance = EpsilonDecimal)
        {
            return Math.Abs(value) < tolerance;
        }

        public static bool IsNearlyZero(float value, double tolerance = EpsilonDouble)
        {
            return Math.Abs(value) < tolerance;
        }

        public static bool IsNearlyZero(double value, double tolerance = EpsilonDouble)
        {
            return Math.Abs(value) < tolerance;
        }

        public static bool IsNearlyEquals(decimal value, decimal target, decimal tolerance = EpsilonDecimal)
        {
            return Math.Abs(value - target) < tolerance;
        }

        public static bool IsNearlyEquals(float value, float target, double tolerance = EpsilonDouble)
        {
            return Math.Abs(value - target) < tolerance;
        }

        public static bool IsNearlyEquals(double value, double target, double tolerance = EpsilonDouble)
        {
            return Math.Abs(value - target) < tolerance;
        }
    }

    public static class MathExtensions
    {
        public static bool IsNearlyZero(this decimal value, decimal tolerance = MathUtils.EpsilonDecimal)
        {
            return MathUtils.IsNearlyZero(value, tolerance);
        }

        public static bool IsNearlyZero(this float value, double tolerance = MathUtils.EpsilonDouble)
        {
            return MathUtils.IsNearlyZero(value, tolerance);
        }

        public static bool IsNearlyZero(this double value, double tolerance = MathUtils.EpsilonDouble)
        {
            return MathUtils.IsNearlyZero(value, tolerance);
        }
        
    }
}
