namespace PAI.Common.Core.Infrastructure
{
    /// <summary>
    /// This class provides the ambient container for this application. If your
    /// framework defines such an ambient container, use ServiceLocator.Current
    /// to get it.
    /// </summary>
    public static class ServiceLocator
    {
        static ServiceLocatorProvider _currentProvider;

        /// <summary>
        /// Gets the current ambient container.
        /// </summary>
        public static IServiceLocator Current
        {
            get
            {
                return _currentProvider != null ? _currentProvider() : null;
            }
        }

        /// <summary>Set the delegate that is used to retrieve the current container.</summary>
        /// <param name="newProvider">Delegate that, when called, will return
        /// the current ambient container.</param>
        public static void SetLocatorProvider(ServiceLocatorProvider newProvider)
        {
            _currentProvider = newProvider;
        }
    }
}