﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace PAI.Common.Core.Diagnostics
{
    public class StopwatchBreadcrum
    {
        private readonly Stopwatch _sw;
        private readonly List<StopwatchSnapshot> _snapshots = new List<StopwatchSnapshot>();
        private TimeSpan _lastSnapshot = TimeSpan.Zero;

        public IEnumerable<StopwatchSnapshot> Snapshots
        {
            get
            {
                return _snapshots;
            }
        }

        public StopwatchBreadcrum(bool startImmediately = true)
        {
            _sw = new Stopwatch();

            if (startImmediately)
                _sw.Start();
        }

        public void Start()
        {
            _lastSnapshot = TimeSpan.Zero;
            _sw.Restart();
        }

        public void Stop()
        {
            _sw.Stop();
        }

        public void TakeSnapshot(string title)
        {
            var elapsed = _sw.Elapsed;

            _snapshots.Add(new StopwatchSnapshot()
            {
                Title = title,
                Timestamp = elapsed,
                Consumed = elapsed - _lastSnapshot
            });

            _lastSnapshot = elapsed;
        }

        public class StopwatchSnapshot
        {
            public string Title { get; set; }
            public TimeSpan Timestamp { get; set; }
            public TimeSpan Consumed { get; set; }
        }
    }
}
