﻿using System;
using System.Linq;
using System.Security.Principal;

namespace PAI.Common.Core
{
    public interface IUserContext
    {
        IPrincipal Principal { get;  }
    }

    public class UserContext : IUserContext
    {
        public IPrincipal Principal { get; private set; }

        public UserContext()
        {
            
        }
        
        //public UserContext(IWindowsAuthenticationProvider authenticationProvider)
        //{
        //    Principal = authenticationProvider.GetPrincipal();
        //}

    }

    public class EmptyUserContext : IUserContext
    {
        public IPrincipal Principal { get; private set; }

        public EmptyUserContext()
        {
            Principal = new EmptyPrincipal();
        }
    }

    public class EmptyPrincipal : IPrincipal
    {
        public EmptyPrincipal()
        {
            Identity = new EmptyIdentity();
        }

        public bool IsInRole(string role)
        {
            return false;
        }

        public IIdentity Identity { get; private set; }
    }

    public class EmptyIdentity : IIdentity
    {
        public EmptyIdentity()
        {
            Name = string.Empty;
            AuthenticationType = string.Empty;
            IsAuthenticated = false;
        }

        public string Name { get; private set; }
        public string AuthenticationType { get; private set; }
        public bool IsAuthenticated { get; private set; }
    }
    
    public interface IWindowsAuthenticationProvider
    {
        bool CanAuthenticate { get; }
        IPrincipal GetPrincipal();
    }

    
}
