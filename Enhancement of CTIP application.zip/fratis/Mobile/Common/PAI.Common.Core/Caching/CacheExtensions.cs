﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace PAI.Common.Core.Caching
{
    public static class CacheExtensions
    {
        private static readonly TimeSpan DefaultCacheTime = TimeSpan.FromMinutes(2);

        public static void Set<T>(this ICacheService cacheService, string key, T value)
        {
            cacheService.Set(key, value, DefaultCacheTime);
        }

        public static bool GetOrAdd<T>(this ICacheService cacheService, string key, Func<T> acquire, out T value)
        {
            return GetOrAdd(cacheService, key, acquire, DefaultCacheTime, out value);
        }
        
        public static bool GetOrAdd<T>(this ICacheService cacheService, string key, Func<T> acquire, TimeSpan? cacheTime, out T value)
        {
            if (cacheService.IsSet(key))
            {
                value = cacheService.Get<T>(key);
                return true;
            }

            value = acquire();
            cacheService.Set(key, value, cacheTime);
            return false;
        }

        public static Task SetAsync<T>(this ICacheService cacheService, string key, T value)
        {
            return cacheService.SetAsync(key, value, DefaultCacheTime);
        }

        public static Task<T> GetOrAddAsync<T>(this ICacheService cacheService, string key, Func<Task<T>> acquire)
        {
            return GetOrAddAsync(cacheService, key, acquire, DefaultCacheTime);
        }

        public static async Task<T> GetOrAddAsync<T>(this ICacheService cacheService, string key, Func<Task<T>> acquire, TimeSpan? cacheTime)
        {
            var value = await cacheService.GetAsync<T>(key).ConfigureAwait(false);

            if (value == null)
            {
                value = await acquire().ConfigureAwait(false);

                if (value != null)
                {
                    await cacheService.SetAsync(key, value, cacheTime).ConfigureAwait(false);
                }
            }
            
            return value;
        }


        
    }
}