﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PAI.Common.Core.Caching
{
    /// <summary>
    /// Represents a Memory Cache Provider
    /// </summary>
    public class MemoryCacheService : ICacheService
    {
        /// <summary>
        /// Returns the items contained in this cache
        /// </summary>
        protected ObjectCache Cache
        {
            get
            {
                return MemoryCache.Default;
            }
        }

        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        public T Get<T>(string key)
        {
            return (T)Cache[key];
        }

        public Task<T> GetAsync<T>(string key)
        {
            return Task.FromResult(Get<T>(key));
        }

        public T[] Get<T>(string[] keys)
        {
            var results = new List<T>();

            foreach (var key in keys)
            {
                var cacheItem = Get<T>(key);
                if (cacheItem == null)
                {
                    results.Add(default(T));
                }
                else
                {
                    results.Add(cacheItem);
                }
            }

            return results.ToArray();
        }

        public async Task<T[]> GetAsync<T>(string[] keys)
        {
            var results = new List<T>();

            foreach (var key in keys)
            {
                //TODO - Use and test Cache.GetValues() instead to get all the keys at once
                var cacheItem = await GetAsync<T>(key).ConfigureAwait(false);
                if (cacheItem == null)
                {
                    results.Add(default(T));
                }
                else
                {
                    results.Add(cacheItem);
                }
            }

            return results.ToArray();
        }

        /// <summary>Adds the specified key and object to the cache.</summary>
        /// <param name="key">key</param>
        /// <param name="data">Data</param>
        /// <param name="cacheTime">Cache time</param>
        public void Set<T>(string key, T data, TimeSpan? cacheTime = null)
        {
            if (data == null)
            {
                return;
            }

            var cacheItemPolicy = new CacheItemPolicy();

            if (cacheTime.HasValue)
            {
                cacheItemPolicy.SlidingExpiration = cacheTime.Value;
            }

            Cache.Set(new CacheItem(key, data), cacheItemPolicy);
        }

        public Task SetAsync<T>(string key, T data, TimeSpan? cacheTime = null)
        {
            return Task.Factory.StartNew(() => Set(key, data, cacheTime));
        }

        /// <summary>Gets a value indicating whether the value associated with the specified key is cached</summary>
        /// <param name="key">key</param>
        /// <returns>Result</returns>
        public bool IsSet(string key)
        {
            return Cache.Contains(key);
        }

        public Task<bool> IsSetAsync(string key)
        {
            return Task.FromResult(IsSet(key));
        }

        /// <summary>Removes the value with the specified key from the cache</summary>
        /// <param name="key">/key</param>
        public void Remove(string key)
        {
            Cache.Remove(key);
        }

        public Task RemoveAsync(string key)
        {
            return Task.Factory.StartNew(() => Remove(key));
        }

        /// <summary>Removes items by pattern</summary>
        /// <param name="pattern">pattern</param>
        public void RemoveByPattern(string pattern)
        {
            var regex = new Regex(pattern, RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            var keysToRemove = (from item in Cache where regex.IsMatch(item.Key) select item.Key).ToList();

            foreach (string key in keysToRemove)
            {
                Remove(key);
            }
        }

        public Task RemoveByPatternAsync(string pattern)
        {
            return Task.Factory.StartNew(() => RemoveByPattern(pattern));
        }

        /// <summary>
        /// Clear all cache data
        /// </summary>
        public void Clear()
        {
            foreach (var item in Cache)
            {
                Remove(item.Key);
            }
        }

        public Task ClearAsync()
        {
            return Task.Factory.StartNew(Clear);
        }
    }
}