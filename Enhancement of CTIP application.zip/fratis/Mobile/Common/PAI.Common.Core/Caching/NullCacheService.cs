﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace PAI.Common.Core.Caching
{
    public class NullCacheService : ICacheService
    {
        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        public T Get<T>(string key)
        {
            return default(T);
        }

        public Task<T> GetAsync<T>(string key)
        {
            return Task.FromResult(default(T));
        }

        public T[] Get<T>(string[] keys)
        {
            throw new NotImplementedException();
        }

        public Task<T[]> GetAsync<T>(string[] keys)
        {
            throw new NotImplementedException();
        }

        public void Set<T>(string key, T data, TimeSpan? cacheTime = null)
        {
            
        }

        public async Task SetAsync<T>(string key, T data, TimeSpan? cacheTime = null)
        {
        }

        public bool IsSet(string key)
        {
            return false;
        }

        public Task<bool> IsSetAsync(string key)
        {
            return Task.FromResult(false);
        }

        /// <summary>Removes the value with the specified key from the cache</summary>
        /// <param name="key">key</param>
        public void Remove(string key)
        {
        }

        public async Task RemoveAsync(string key)
        {
        }

        /// <summary>Removes items by pattern</summary>
        /// <param name="pattern">pattern</param>
        public void RemoveByPattern(string pattern)
        {
        }

        public async Task RemoveByPatternAsync(string pattern)
        {
        }

        /// <summary>
        /// Clear all cache data
        /// </summary>
        public void Clear()
        {
        }

        public async Task ClearAsync()
        {
        }
    }
}