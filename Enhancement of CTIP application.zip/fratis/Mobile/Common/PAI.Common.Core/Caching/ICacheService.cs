﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace PAI.Common.Core.Caching
{
    /// <summary>
    /// Cache Provider interface
    /// </summary>
    public interface ICacheService
    {
        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        T Get<T>(string key);

        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        Task<T> GetAsync<T>(string key);


        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="keys">The keys of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        T[] Get<T>(string[] keys);

        /// <summary>Gets or sets the value associated with the specified key.</summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="keys">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        Task<T[]> GetAsync<T>(string[] keys);

        /// <summary>Adds the specified key and object to the cache.</summary>
        /// <param name="key">key</param>
        /// <param name="data">Data</param>
        /// <param name="cacheTime"></param>
        void Set<T>(string key, T data, TimeSpan? cacheTime = null);

        /// <summary>Adds the specified key and object to the cache.</summary>
        /// <param name="key">key</param>
        /// <param name="data">Data</param>
        /// <param name="cacheTime">Seconds to cache the data</param>
        Task SetAsync<T>(string key, T data, TimeSpan? cacheTime = null);

        /// <summary>Gets a value indicating whether the value associated with the specified key is cached</summary>
        /// <param name="key">key</param>
        /// <returns>Result</returns>
        bool IsSet(string key);

        /// <summary>Gets a value indicating whether the value associated with the specified key is cached</summary>
        /// <param name="key">key</param>
        /// <returns>Result</returns>
        Task<bool> IsSetAsync(string key);

        /// <summary>Removes the value with the specified key from the cache</summary>
        /// <param name="key">key</param>
        void Remove(string key);

        /// <summary>Removes the value with the specified key from the cache</summary>
        /// <param name="key">key</param>
        Task RemoveAsync(string key);

        /// <summary>Removes items by pattern</summary>
        /// <param name="pattern">pattern</param>
        void RemoveByPattern(string pattern);

        /// <summary>Removes items by pattern</summary>
        /// <param name="pattern">pattern</param>
        Task RemoveByPatternAsync(string pattern);

        /// <summary>
        /// Clear all cache data
        /// </summary>
        void Clear();

        /// <summary>
        /// Clear all cache data
        /// </summary>
        Task ClearAsync();
    }
}