﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace PAI.Common.Core.Extensions
{
    public static class StringExtensions
    {
        public static string UppercaseSpaceFormat(this string stringToFormat)
        {
            return
                string.Join(String.Empty,
                    stringToFormat.ToCharArray().Select(x => Char.IsUpper(x) ? " " + x : x.ToString()).ToArray())
                    .TrimStart(' ');
        }

        public static string SplitCamelCase(this string str)
        {
            return Regex.Replace(
                Regex.Replace(
                    str,
                    @"(\P{Ll})(\P{Ll}\p{Ll})",
                    "$1 $2"
                    ),
                @"(\p{Ll})(\P{Ll})",
                "$1 $2"
                );
        }
    }
}