﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PAI.Common.Core.Extensions
{
    /// <summary>
    /// Extensions for statistics related.
    /// </summary>
    public static class StatisticsCalculationExtension
    {
        /// <summary>
        /// Allow TimeSpan to be used in LINQ Sum.  Somehow Microsoft doesn't implement built in sum for TimeSpan in LINQ, this implementation
        /// however still using TimeSpan's built in + operator.
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="source"></param>
        /// <param name="selector"></param>
        /// <returns></returns>
        public static TimeSpan Sum<TSource>(this IEnumerable<TSource> source, Func<TSource, TimeSpan> selector)
        {
            return source.Select(selector).Aggregate(TimeSpan.Zero, (t1, t2) => t1 + t2);
        }
    }
}