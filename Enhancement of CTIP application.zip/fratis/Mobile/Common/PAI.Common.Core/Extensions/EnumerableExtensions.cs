using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace PAI.Common.Core.Extensions
{
    public static class EnumerableExtensions
    {
        /// <summary>
        /// Determines whether a sequence contains all of the specified values.
        /// 
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam><param name="source">A sequence in which to locate the values.</param><param name="values">The values to locate in the sequence.</param>
        /// <returns>
        /// True if the sequence contains all of the specified values.
        /// </returns>
        public static bool ContainsAll<TSource>(this IEnumerable<TSource> source, IEnumerable<TSource> values)
        {
            return Enumerable.All<TSource>(values, (Func<TSource, bool>)(v => Enumerable.Contains<TSource>(source, v)));
        }

        /// <summary>
        /// Determines whether a sequence contains any of the specified values.
        /// 
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam><param name="source">A sequence in which to locate the values.</param><param name="values">The values to locate in the sequence.</param>
        /// <returns>
        /// True if the sequence contains any of the specified values.
        /// </returns>
        public static bool ContainsAny<TSource>(this IEnumerable<TSource> source, IEnumerable<TSource> values)
        {
            return Enumerable.Any<TSource>(source, (Func<TSource, bool>)(s => Enumerable.Contains<TSource>(values, s)));
        }

        public static void Each<T>(this IEnumerable<T> instance, Action<T, int> action)
        {
            int index = 0;
            foreach (T item in instance)
            {
                action(item, index++);
            }
        }

        /// <summary>Executes the provided delegate for each item.</summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        /// <param name="action">The action to be applied.</param>
        public static void Each<T>(this IEnumerable<T> instance, Action<T> action)
        {
            foreach (T item in instance)
            {
                action(item);
            }
        }

        public static IEnumerable<string> SplitAndTrim(this string value, char delimiter)
        {
            return value.Split(delimiter).Select(v => v.Trim()).Where(v => !string.IsNullOrWhiteSpace(v));
        }

        public static IEnumerable AsGenericEnumerable(this IEnumerable source)
        {
            Type elementType = typeof(object);

            Type type = source.GetType().FindGenericType(typeof(IEnumerable<>));
            if (type != null)
            {
                return source;
            }

            IEnumerator enumerator = source.GetEnumerator();

            while (enumerator.MoveNext())
            {
                if (enumerator.Current != null)
                {
                    elementType = enumerator.Current.GetType();
                    try
                    {
                        enumerator.Reset();
                    }
                    catch
                    {
                    }

                    break;
                }
            }

            Type genericType = typeof(GenericEnumerable<>).MakeGenericType(elementType);
            var constructorParameters = new object[] { source };

            return (IEnumerable)Activator.CreateInstance(genericType, constructorParameters);
        }

        public static int IndexOf(this IEnumerable source, object item)
        {
            int index = 0;
            foreach (object i in source)
            {
                if (Equals(i, item))
                {
                    return index;
                }

                index++;
            }

            return -1;
        }

        /// <summary>The element at.</summary>
        /// <param name="source">The source.</param>
        /// <param name="index">The index.</param>
        /// <exception cref="ArgumentOutOfRangeException"><c>index</c> is out of range.</exception>
        /// <returns>The <see cref="object"/>.</returns>
        public static object ElementAt(this IEnumerable source, int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index");
            }

            var list = source as IList;
            if (list != null && list.Count > 0)
            {
                return list[index];
            }

            foreach (var item in source)
            {
                if (index == 0)
                {
                    return item;
                }

                index--;
            }

            return null;
        }

        // Source: http://work.j832.com/2008/01/selectrecursive-if-3rd-times-charm-4th.html
        public static IEnumerable<TSource> SelectRecursive<TSource>(this IEnumerable<TSource> source, Func<TSource, IEnumerable<TSource>> recursiveSelector)
        {
            Stack<IEnumerator<TSource>> stack = new Stack<IEnumerator<TSource>>();
            stack.Push(source.GetEnumerator());

            try
            {
                while (stack.Count > 0)
                {
                    if (stack.Peek().MoveNext())
                    {
                        TSource current = stack.Peek().Current;

                        yield return current;

                        IEnumerable<TSource> children = recursiveSelector(current);
                        if (children != null)
                        {
                            stack.Push(children.GetEnumerator());
                        }
                    }
                    else
                    {
                        stack.Pop().Dispose();
                    }
                }
            }
            finally
            {
                while (stack.Count > 0)
                {
                    stack.Pop().Dispose();
                }
            }
        }

        public static IEnumerable<TResult> Consolidate<TFirst, TSecond, TResult>(
            this IEnumerable<TFirst> first, IEnumerable<TSecond> second, Func<TFirst, TSecond, TResult> resultSelector)
        {
            if (first == null)
            {
                throw new ArgumentNullException("first");
            }

            if (second == null)
            {
                throw new ArgumentNullException("second");
            }

            if (resultSelector == null)
            {
                throw new ArgumentNullException("resultSelector");
            }

            return ZipIterator(first, second, resultSelector);
        }

        public static ReadOnlyCollection<T> ToReadOnlyCollection<T>(this IEnumerable<T> sequence)
        {
            if (sequence == null)
            {
                return DefaultReadOnlyCollection<T>.Empty;
            }

            ReadOnlyCollection<T> onlys = sequence as ReadOnlyCollection<T>;
            if (onlys != null)
            {
                return onlys;
            }

            return new ReadOnlyCollection<T>(sequence.ToArray());
        }

        private static IEnumerable<TResult> ZipIterator<TFirst, TSecond, TResult>(
            IEnumerable<TFirst> first, IEnumerable<TSecond> second, Func<TFirst, TSecond, TResult> resultSelector)
        {
            using (IEnumerator<TFirst> e1 = first.GetEnumerator())
            {
                using (IEnumerator<TSecond> e2 = second.GetEnumerator())
                    while (e1.MoveNext() && e2.MoveNext())
                    {
                        yield return resultSelector(e1.Current, e2.Current);
                    }
            }
        }

        private static class DefaultReadOnlyCollection<T>
        {
            private static ReadOnlyCollection<T> defaultCollection;

            public static ReadOnlyCollection<T> Empty
            {
                get
                {
                    if (defaultCollection == null)
                    {
                        defaultCollection = new ReadOnlyCollection<T>(new T[0]);
                    }

                    return defaultCollection;
                }
            }
        }

        public class GenericEnumerable<T> : IEnumerable<T>
        {
            private readonly IEnumerable source;

            /// <summary>Initializes a new instance of the <see cref="GenericEnumerable{T}"/> class.</summary>
            /// <param name="source">The source.</param>
            public GenericEnumerable(IEnumerable source)
            {
                this.source = source;
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return source.GetEnumerator();
            }

            IEnumerator<T> IEnumerable<T>.GetEnumerator()
            {
                foreach (T item in source)
                {
                    yield return item;
                }
            }
        }

        public static IEnumerable<TResult> Pairwise<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, TSource, TResult> resultSelector)
        {
            TSource previous = default(TSource);

            using (var it = source.GetEnumerator())
            {
                if (it.MoveNext())
                    previous = it.Current;

                while (it.MoveNext())
                    yield return resultSelector(previous, previous = it.Current);
            }
        }

        public static IEnumerable<TResult> SlidingWindow<TSource, TResult>(this IEnumerable<TSource> source, int windowSize, Func<TSource[], TResult> resultSelector)
        {
            if (windowSize < 1)
                yield break;

            int index = 0;
            
            TSource[] window = new TSource[windowSize];

            foreach (var item in source)
            {
                bool initializing = index < windowSize;

                // shift initialized window to accomodate new item.
                if (!initializing)
                    Array.Copy(window, 1, window, 0, windowSize - 1);

                // Add current item to window.
                int itemIndex = initializing ? index : windowSize - 1;
                window[itemIndex] = item;

                index++;
                bool initialized = index >= windowSize;
                if (initialized)
                    yield return resultSelector(window);
            }
        }
    }
}