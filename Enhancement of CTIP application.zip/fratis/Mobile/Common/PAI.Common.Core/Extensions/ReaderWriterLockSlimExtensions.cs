using System;
using System.Threading;

namespace PAI.Common.Core.Extensions
{
    public static class ReaderWriterLockSlimExtensions
    {
        /// <summary>
        /// Starts thread safe read write code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <returns></returns>
        public static IDisposable ReadAndWrite(this ReaderWriterLockSlim rwLock)
        {
            rwLock.EnterUpgradeableReadLock();
            return new DisposableCodeBlock(rwLock.ExitUpgradeableReadLock);
        }

        /// <summary>
        /// Starts thread safe read code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <returns></returns>
        public static IDisposable Read(this ReaderWriterLockSlim rwLock)
        {
            rwLock.EnterReadLock();
            return new DisposableCodeBlock(rwLock.ExitReadLock);
        }

        /// <summary>
        /// Starts thread safe write code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <returns></returns>
        public static IDisposable Write(this ReaderWriterLockSlim rwLock)
        {
            rwLock.EnterWriteLock();
            return new DisposableCodeBlock(rwLock.ExitWriteLock);
        }


        /// <summary>
        /// Starts thread safe read write code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public static IDisposable ReadAndWrite(this ReaderWriterLockSlim rwLock, TimeSpan timeout)
        {
            if (!rwLock.TryEnterUpgradeableReadLock(timeout))
                throw new TimeoutException();

            return new DisposableCodeBlock(rwLock.ExitUpgradeableReadLock);
        }

        /// <summary>
        /// Starts thread safe read code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public static IDisposable Read(this ReaderWriterLockSlim rwLock, TimeSpan timeout)
        {
            if (!rwLock.TryEnterReadLock(timeout))
                throw new TimeoutException();

            return new DisposableCodeBlock(rwLock.ExitReadLock);
        }

        /// <summary>
        /// Starts thread safe write code block.
        /// </summary>
        /// <param name="rwLock">The rwLock.</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public static IDisposable Write(this ReaderWriterLockSlim rwLock, TimeSpan timeout)
        {
            if (!rwLock.TryEnterWriteLock(timeout))
                throw new TimeoutException();

            return new DisposableCodeBlock(rwLock.ExitWriteLock);
        }

        private sealed class DisposableCodeBlock : IDisposable
        {
            private readonly Action _action;

            public DisposableCodeBlock(Action action)
            {
                _action = action;
            }

            public void Dispose()
            {
                _action();
            }
        }
    }
}