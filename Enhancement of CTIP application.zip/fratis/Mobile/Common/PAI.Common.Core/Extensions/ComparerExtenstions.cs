using System.Collections.Generic;

namespace PAI.Common.Core.Extensions
{
    public static class ComparerExtenstions
    {
        /// <summary>
        /// Returns the smallest of the two objects
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static T Min<T>(this IComparer<T> value, T x, T y)
        {
            return value.Compare(x, y) > 0 ? y : x;
        }
    }
}