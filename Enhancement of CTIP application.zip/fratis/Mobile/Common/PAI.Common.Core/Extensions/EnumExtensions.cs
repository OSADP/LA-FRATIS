﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PAI.Common.Core.Extensions
{
    public static class EnumExtensions
    {
        public static string UppercaseSpaceFormat(this Enum enumToFormat)
        {
            return enumToFormat.ToString().UppercaseSpaceFormat();
        }

        public static IEnumerable<T> GetValues<T>() where T : struct
        {
            return Enum.GetValues(typeof(T)).Cast<T>();
        }
    }
}
