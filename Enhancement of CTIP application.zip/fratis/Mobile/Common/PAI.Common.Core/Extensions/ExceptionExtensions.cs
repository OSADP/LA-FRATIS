﻿using System;
//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Extensions
{
    public static class ExceptionExtensions
    {
        public static bool IsHttpStatusCodeUnauthorized(this Exception exception)
        {
            return exception.GetType().Name == "HttpRequestException" &&
                   exception.Message.Contains("401") &&
                   exception.Message.Contains("Unauthorized");
        }
    }
}
