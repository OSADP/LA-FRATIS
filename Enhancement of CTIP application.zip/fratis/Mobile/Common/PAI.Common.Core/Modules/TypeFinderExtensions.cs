using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using PAI.Common.Core.Infrastructure;

namespace PAI.Common.Core.Modules
{
    public static class TypeFinderExtensions
    {
        public static IEnumerable<Type> GetTypes(this IEnumerable<Assembly> assemblies)
        {
            var typeSelector = ServiceLocator.Current.GetInstance<ITypeSelector>();
            return typeSelector.GetAllTypes(assemblies);
        }

        /// <summary>
        /// Returns whether the type is inherited from the target type
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static bool IsInheritedFrom<T>(this Type type)
        {
            var typeFilter = ServiceLocator.Current.GetInstance<ITypeFilter>();
            return typeFilter.IsTypeInheritedFromAny(type, new[] { typeof(T) });
        }

        /// <summary>
        /// Finds assemblies matching the given patterns
        /// </summary>
        /// <param name="assemblyFinder"></param>
        /// <param name="patterns"></param>
        /// <returns></returns>
        public static IEnumerable<Assembly> FindAssembliesMatching(this IAssemblyFinder assemblyFinder, params string[] patterns)
        {
            var assemblyNames = assemblyFinder.FindAssembliesMatching(patterns);
            var assemblies = assemblyFinder.FindAssemblies(assemblyNames, f => true);
            return assemblies;
        }
    }
}