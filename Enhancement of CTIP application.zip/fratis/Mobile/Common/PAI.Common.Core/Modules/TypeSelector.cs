using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PAI.Common.Core.Modules
{
    /// <summary>
    /// Selects types from the given assemblies.
    /// </summary>
    public class TypeSelector : ITypeSelector
    {
        /// <summary>Gets all exported types from the specified assemblies.</summary>
        /// <param name="assemblies">The assemblies to search for types.</param>
        /// <returns>All exported types from the specified assemblies.</returns>
        public IEnumerable<Type> GetExportedTypes(IEnumerable<Assembly> assemblies)
        {
            return assemblies.SelectMany(asm => asm.GetExportedTypes());
        }

        /// <summary>Gets all types from the specified assemblies.</summary>
        /// <param name="assemblies">The assemblies to search for types.</param>
        /// <returns>All types from the specified assemblies.</returns>
        public IEnumerable<Type> GetAllTypes(IEnumerable<Assembly> assemblies)
        {
            return assemblies.SelectMany(asm => asm.GetTypes());
        }
    }
}