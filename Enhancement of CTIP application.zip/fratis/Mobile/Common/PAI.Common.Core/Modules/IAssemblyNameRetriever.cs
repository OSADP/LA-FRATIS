﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PAI.Common.Core.Modules
{
    public interface IAssemblyNameRetriever
    {
        /// <summary>Gets all assembly names of the assemblies in the given files that match the filter.</summary>
        /// <param name="filenames">The filenames.</param>
        /// <param name="filter">The filter.</param>
        /// <returns>All assembly names of the assemblies in the given files that match the filter.</returns>
        IEnumerable<AssemblyName> GetAssemblyNames(IEnumerable<string> filenames, Predicate<Assembly> filter);
    }
}