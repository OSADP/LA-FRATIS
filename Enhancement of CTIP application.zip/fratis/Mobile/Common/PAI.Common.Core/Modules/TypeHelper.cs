using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reflection;

namespace PAI.Common.Core.Modules
{
    public class TypeHelper
    {
        private static readonly ConcurrentDictionary<Type, Lazy<IEnumerable<PropertyInfo>>> _propertiesByType =
            new ConcurrentDictionary<Type, Lazy<IEnumerable<PropertyInfo>>>();

        public static IEnumerable<PropertyInfo> GetProperties(object instance)
        {
            var t = instance.GetType();
            return GetProperties(t);
        }

        public static IEnumerable<PropertyInfo> GetProperties(Type type)
        {
            var lazy = _propertiesByType.GetOrAdd(type, t => 
                new Lazy<IEnumerable<PropertyInfo>>(t.GetProperties));

            return lazy.Value;
        }
    }

    public static class TypeHelperExtensions
    {
        public static IEnumerable<PropertyInfo> GetPropertiesFast(this object instance)
        {
            return TypeHelper.GetProperties(instance);
        }

        public static IEnumerable<PropertyInfo> GetPropertiesFast(this Type type)
        {
            return TypeHelper.GetProperties(type);
        }
    }
}