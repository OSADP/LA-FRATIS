using System.Linq;

namespace PAI.Common.Core.Modules
{
    public class TypeFinder
    {
        private readonly IAssemblyFinder _assemblyFinder;
        private readonly ITypeFilter _typeFilter;
        private readonly ITypeSelector _typeSelector;

        public TypeFinder(IAssemblyFinder assemblyFinder, ITypeFilter typeFilter, ITypeSelector typeSelector)
        {
            _assemblyFinder = assemblyFinder;
            _typeFilter = typeFilter;
            _typeSelector = typeSelector;
        }

    }
}