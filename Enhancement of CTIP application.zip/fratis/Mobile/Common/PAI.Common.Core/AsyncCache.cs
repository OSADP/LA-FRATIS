﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PAI.Common.Core
{
    public class AsyncCache<TKey, TValue>
    {
        private readonly Func<TKey, Task<TValue>> _valueFactory;
        private readonly ConcurrentDictionary<TKey, Lazy<Task<TValue>>> _map;

        public AsyncCache(Func<TKey, Task<TValue>> valueFactory, IEnumerable<KeyValuePair<TKey, TValue>> initial = null)
        {
            if (valueFactory == null)
                throw new ArgumentNullException("valueFactory");

            _valueFactory = valueFactory;

            if (initial == null)
            {
                _map = new ConcurrentDictionary<TKey, Lazy<Task<TValue>>>();
            }
            else
            {
                _map = new ConcurrentDictionary<TKey, Lazy<Task<TValue>>>(
                    initial.Select(kvp => new KeyValuePair<TKey, Lazy<Task<TValue>>>(
                        kvp.Key,
                        new Lazy<Task<TValue>>(() => new Task<TValue>(() => kvp.Value)))
                        )
                    );
            }
        }

        public Task<TValue> this[TKey key]
        {
            get
            {
                if (key == null)
                    throw new ArgumentNullException("key");

                return _map.GetOrAdd(key, toAdd => new Lazy<Task<TValue>>(
                    () => _valueFactory(toAdd))).Value;
            }
        }
    }
}