﻿using System;
using System.Linq;
using System.Runtime.Caching;
using System.Threading;

namespace PAI.Common.Core
{

    public interface IDistributedLockService
    {
        IDisposable AcquireLock(string key);
        IDisposable AcquireLock(string key, TimeSpan timeOut);
    }

    public class NullDistributedLockService : IDistributedLockService
    {
        public IDisposable AcquireLock(string key)
        {
            return new NullCodeBlock();
        }

        public IDisposable AcquireLock(string key, TimeSpan timeOut)
        {
            return new NullCodeBlock();
        }

        private sealed class NullCodeBlock : IDisposable
        {
            public void Dispose()
            {
            }
        }
    }

    public class MemoryDistributedLock : IDistributedLockService
    {
        private readonly MemoryCache _lockCache = MemoryCache.Default;

        private SemaphoreSlim GetSemaphore(string key)
        {
            var rwLock = new SemaphoreSlim(1);

            var cachedLock = _lockCache.AddOrGetExisting(key, rwLock, new CacheItemPolicy()
            {
                SlidingExpiration = TimeSpan.FromMinutes(2)
            }) as SemaphoreSlim;

            if (cachedLock != null)
            {
                rwLock = cachedLock;
            }

            return rwLock;
        }

        public IDisposable AcquireLock(string key)
        {
            var semaphore = GetSemaphore(key);
            
            semaphore.Wait();

            return new DisposableCodeBlock(() => 
            {
                semaphore.Release();
            });
        }

        public IDisposable AcquireLock(string key, TimeSpan timeOut)
        {
            var semaphore = GetSemaphore(key);

            var lockAquired = semaphore.Wait(timeOut);

            return new DisposableCodeBlock(() =>
            {
                if (lockAquired)
                {
                    semaphore.Release();
                }
            });
        }

        private sealed class DisposableCodeBlock : IDisposable
        {
            private readonly Action _action;

            public DisposableCodeBlock(Action action)
            {
                _action = action;
            }

            public void Dispose()
            {
                _action();
            }
        }
    }

}
