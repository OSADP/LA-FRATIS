﻿using System;
using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace PAI.Common.Core
{
    public class XmlSerialization
    {
        public static string SerializeToXml(object source)
        {
            var settings = new XmlWriterSettings()
            {
                Indent = true,
                ConformanceLevel = ConformanceLevel.Auto,
                OmitXmlDeclaration = true
            };

            return SerializeToXml(source, settings);
        }

        public static string SerializeToXml(object source, XmlWriterSettings settings)
        {
            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add("", "");

            return SerializeToXml(source, settings, namespaces);
        }

        public static string SerializeToXml(object source, string namespacePrefix, string namespaceName)
        {
            var settings = new XmlWriterSettings()
            {
                Indent = true,
                ConformanceLevel = ConformanceLevel.Auto,
                OmitXmlDeclaration = true
            };

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(namespacePrefix, namespaceName);

            return SerializeToXml(source, settings, namespaces);
        }

        public static string SerializeToXml(object source, XmlWriterSettings settings, XmlSerializerNamespaces namespaces)
        {
            string xml = string.Empty;
            var xs = new XmlSerializer(source.GetType());

            using (var sw = new StringWriter())
            {
                var xw = XmlWriter.Create(sw, settings);
                xs.Serialize(xw, source, namespaces);
                xw.Flush();
                xw.Close();

                xml = sw.ToString();
            }
            return xml;
        }

        public static T DeserializeFromXml<T>(string xml)
        {
            if (xml == null) xml = string.Empty;
            T ret;

            try
            {
                var xs = new XmlSerializer(typeof(T));

                using (var stringReader = new StringReader(xml))
                {
                    ret = ((T)(xs.Deserialize(XmlReader.Create(stringReader))));
                }
                return ret;
            }
            catch (Exception ex)
            {
                return Activator.CreateInstance<T>();
            }
       }

        public static T DeserializeFromXml<T>(string xml, XmlReaderSettings settings)
        {
            if (xml == null) xml = string.Empty;

            T ret;
            var xs = new XmlSerializer(typeof(T));

            using (var stringReader = new StringReader(xml))
            {
                ret = ((T)(xs.Deserialize(XmlReader.Create(stringReader, settings))));
            }
            return ret;
        }

        public static T ShallowCopy<T>(T source)
        {
            T result = default(T);
            var memoryStream = new MemoryStream();
            try
            {
                var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                formatter.Serialize(memoryStream, source);
                memoryStream.Position = 0;
                result = (T) formatter.Deserialize(memoryStream);
            }
            finally
            {
                memoryStream.Dispose();
            }
            return result;
        }

    }
}
