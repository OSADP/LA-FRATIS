using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Linq;

namespace PAI.Common.Core
{
    public interface IConfigurationManagerProvider
    {
        NameValueCollection AppSettings { get; }

        ConnectionStringSettingsCollection ConnectionStrings { get; }
    }

    public static class ConfigurationManagerProviderExt
    {
        public static T Get<T>(this IConfigurationManagerProvider configurationManager, string key)
        {
            var result = default(T);
            var value = configurationManager.AppSettings[key];

            if (value != null)
            {
                TypeConverter typeConverter = TypeDescriptor.GetConverter(typeof(T));
                result = (T)typeConverter.ConvertFromString(value);
            }

            return result;
        }
    }

    public class ConfigurationManagerProvider : IConfigurationManagerProvider
    {
        public NameValueCollection AppSettings
        {
            get
            {
                return ConfigurationManager.AppSettings;
            }
        }

        public ConnectionStringSettingsCollection ConnectionStrings
        {
            get
            {
                return ConfigurationManager.ConnectionStrings;
            }
        }
    }
}