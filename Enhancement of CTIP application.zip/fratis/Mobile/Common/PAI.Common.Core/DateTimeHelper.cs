using System;

namespace PAI.Common.Core
{
    public class DateTimeHelper : IDateTimeHelper
    {
        public TimeZoneInfo GetTimeZoneInfo(string timeZoneId)
        {
            return TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
        }

        public TimeZoneInfo GetLocalTimeZoneInfo()
        {
            return this.CurrentTimeZone;
        }

        private TimeZoneInfo _timeZone = null;
        public TimeZoneInfo CurrentTimeZone
        {
            get
            {
                return _timeZone ?? (_timeZone = TimeZoneInfo.Local);
            }
        }

        public DateTimeHelper SetCurrentTimeZone(TimeZoneInfo timeZoneInfo)
        {
            _timeZone = timeZoneInfo;
            return this;
        }

        public DateTimeHelper SetCurrentTimeZone(string timeZoneId)
        {
            try
            {
                return SetCurrentTimeZone(TimeZoneInfo.FindSystemTimeZoneById(timeZoneId));                
            }
            catch
            {
                return new DateTimeHelper();
            }
        }
        
        public DateTime ConvertToTime(DateTime dt, TimeZoneInfo sourceTimeZone, TimeZoneInfo destinationTimeZone)
        {
            try
            {
                // TODO - below may not be necessary
                if (dt.Kind == DateTimeKind.Local)
                    sourceTimeZone = this.CurrentTimeZone;
                else if (dt.Kind == DateTimeKind.Utc)
                    sourceTimeZone = TimeZoneInfo.Utc;
                //else if (dt.Kind == DateTimeKind.Unspecified)
                //  dt = new DateTime(dt.Ticks, DateTimeKind.Utc);

                // convert sourceTimeZone and dt to UTC in order to complete the conversion
                dt = TimeZoneInfo.ConvertTime(dt, sourceTimeZone, TimeZoneInfo.Utc);
                sourceTimeZone = TimeZoneInfo.Utc;

                // now convert to desired destination time zone
                if (dt.Kind == DateTimeKind.Utc)
                {
                    dt = TimeZoneInfo.ConvertTimeFromUtc(dt, destinationTimeZone);
                }
                else
                {
                    dt = TimeZoneInfo.ConvertTimeToUtc(dt, sourceTimeZone);
                }
                //dt = TimeZoneInfo.ConvertTime(dt, sourceTimeZone, destinationTimeZone);

                return dt;

            }
            catch (ArgumentException ex)
            {
                throw new Exception("ConvertToTime Argument Exception");
            }
        }

        public DateTime ConvertUtcToLocalTime(DateTime dt, bool forceSourceDateToUtcIfUnspecified = true)
        {
            if (dt.Kind != DateTimeKind.Utc && forceSourceDateToUtcIfUnspecified)
            {
                dt = new DateTime(dt.Ticks, DateTimeKind.Utc);
            }

            return dt.Kind == DateTimeKind.Local 
                ? dt 
                : ConvertToTime(dt, TimeZoneInfo.Utc, this.CurrentTimeZone);
        }

        public DateTime ConvertLocalToUtcTime(DateTime dt)
        {
            return dt.Kind == DateTimeKind.Utc 
                ? dt 
                : this.ConvertToTime(dt, this.CurrentTimeZone, TimeZoneInfo.Utc);
        }

        public DateTime GetLocalTime()
        {
            return ConvertUtcToLocalTime(DateTime.UtcNow);
        }

        public DateTime ConvertUnixTimeToDateTime(double unixTime)
        {
            var dt = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            dt = dt.AddSeconds(unixTime).ToLocalTime();
            return dt;
        }

        public double ConvertDateTimeToUnixTime(DateTime dt)
        {
            return (dt - new DateTime(1970, 1, 1).ToLocalTime()).TotalSeconds;
        }

        private TimeSpan _advanceCheckIncrement = TimeSpan.FromMinutes(15);
        public DateTimeHelper SetAdvanceCheckIncrement(TimeSpan ts)
        {
            _advanceCheckIncrement = ts;
            return this;
        }

        public DateTime GetVirtualUtcNow(bool extendVirtualUtcNow = false)
        {
            var utcNow = DateTime.UtcNow;
            if (extendVirtualUtcNow)
            {
                utcNow = utcNow.Add(_advanceCheckIncrement);
            }

            return utcNow;
        }
    }
}
