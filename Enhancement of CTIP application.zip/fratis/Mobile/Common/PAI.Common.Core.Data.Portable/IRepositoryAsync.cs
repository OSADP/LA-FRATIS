﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace PAI.Common.Core.Data.Portable
{
    public interface IRepository<TEntity>
        where TEntity : class, IEntity
    {
        /// <summary>
        /// Asynchronously Gets the entities by the specified predicates, if they are supplied, 
        /// and then orders them based on the specified orderByRequests, if they are supplied.
        /// 
        /// Note: The execution order of the OrderBy statements are determined by the order of the orderByRequests object collection.
        /// The execution order begins at the begginning of the orderByRequests collection.
        /// </summary>
        /// <param name="predicates">Where Predicates, can be null if they are not supplied.</param>
        /// <param name="orderByRequests">Can be null if they are not supplied. See Summary Note for OrderBy Execution Order.</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<IList<TEntity>> GetAsync(IEnumerable<Expression<Func<TEntity, bool>>> predicates, IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken);

        /// <summary>
        /// Asynchronously Gets the entities by the specified predicate, if it's supplied, 
        /// and then orders them based on the specified orderByRequest, if it's supplied.
        /// </summary>
        /// <param name="predicate">Where Predicate, can be null if no predicate is supplied.</param>
        /// <param name="orderByRequest">Can be null if no orderByRequest is supplied.</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<IList<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate, OrderByRequest<TEntity> orderByRequest, CancellationToken cancellationToken);

        /// <summary>
        /// Asynchronously Gets entity by id
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="token">the cancellation token</param>
        Task<TEntity> GetByIdAsync(string id, CancellationToken token);

        /// <summary>
        /// Asynchronously Gets single entity by predicate
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <param name="token"></param>
        Task<TEntity> GetOneByAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken token);

        /// <summary>
        /// Asynchronously Adds the new entity in the repository.
        /// </summary>
        /// <param name="entity">The entity to add.</param>
        /// <param name="token">the cancellation token</param>
        /// <returns>The added entity including its new ObjectId.</returns>
        Task<TEntity> InsertAsync(TEntity entity, CancellationToken token);

        /// <summary>
        /// Asynchronously Adds the new entities in the repository.
        /// </summary>
        /// <param name="entities">The entities of type T.</param>
        /// <param name="token">the cancellation token</param>
        Task InsertAsync(IEnumerable<TEntity> entities, CancellationToken token);

        /// <summary>
        /// Asynchronously Updates an entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="token">the cancellation token</param>
        /// <returns>The updated entity.</returns>
        Task<TEntity> UpdateAsync(TEntity entity, CancellationToken token);

        /// <summary>
        /// Asynchronously Updates the entities.
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<IEnumerable<TEntity>> UpdateAsync(IEnumerable<TEntity> entities, CancellationToken token);

        /// <summary>
        /// Asynchronously Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="token">the cancellation token</param>
        Task DeleteAsync(TEntity entity, CancellationToken token);

        /// <summary>
        /// Asynchronously Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        Task DeleteAsync(string id, CancellationToken token);

        /// <summary>
        /// Asynchronously Deletes entities from the repository by their id.
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        Task DeleteAsync(IEnumerable<string> ids, CancellationToken token);
    }
}
