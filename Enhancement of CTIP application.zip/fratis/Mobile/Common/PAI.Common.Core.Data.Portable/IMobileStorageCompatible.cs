﻿namespace PAI.Common.Core.Data.Portable
{
    /// <summary>
    /// Signifies whether the object is capable of being stored locally on the Mobile device
    /// </summary>
    public interface IMobileStorageCompatible
    {
    }
}
