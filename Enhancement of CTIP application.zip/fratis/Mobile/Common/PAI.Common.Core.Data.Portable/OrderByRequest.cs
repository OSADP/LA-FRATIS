﻿using System;
using System.Linq.Expressions;

namespace PAI.Common.Core.Data.Portable
{
    public enum OrderByDirection
    {
        Ascending = 1,
        Descending = 2
    }

    public class OrderByRequest<TEntity> where TEntity : class, IEntity
    {
        public Expression<Func<TEntity, object>> Expression { get; private set; }
        public OrderByDirection Direction { get; private set; }

        public OrderByRequest(Expression<Func<TEntity, object>> expression, OrderByDirection direction)
        {
            Expression = expression;
            Direction = direction;
        }
    }
}
