﻿namespace PAI.Common.Core.Data.Portable
{
    public interface IPathConfig
    {
        string DatabasePath { get; set; }
    }

    public class PathConfig : IPathConfig
    {
        public string DatabasePath { get; set; }

        public PathConfig(string databasePath)
        {
            DatabasePath = databasePath;
        }
    }
}