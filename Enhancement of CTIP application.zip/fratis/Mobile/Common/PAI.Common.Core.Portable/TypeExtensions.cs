﻿using System.Reflection;

namespace PAI.Common.Core.Portable
{
    public static class TypeExtensions
    {
        public static bool IsAssignableFrom<T1, T2>()
        {
            return typeof(T1).GetTypeInfo().IsAssignableFrom(typeof(T2).GetTypeInfo());
        }
    }
}
