using System;
using System.Linq;

namespace PAI.Common.Core.Data
{
    public class AppConfigConnectionStringProvider : IConnectionStringProvider
    {
        public AppConfigConnectionStringProvider(string connectionStringName, string dataBaseName, string webServerConnectionStringName)
        {
            this.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
            this.DatabaseName = System.Configuration.ConfigurationManager.AppSettings[dataBaseName];
            this.WebServerConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[webServerConnectionStringName].ConnectionString;
        }
        
        public string ConnectionString { get; private set; }

        public string DatabaseName { get; private set; }

        public string WebServerConnectionString { get; private set; }
    }
}