﻿using System;
//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Data
{
    /// <summary>
    /// Interface for dated entities, providing created and modified timestamps
    /// </summary>
    public interface IDatedEntity
    {
        /// <summary>
        /// Gets or sets the date in which the entity / record was created
        /// </summary>
        DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the date in which the entity / record was last modified
        /// </summary>
        DateTime? LastModifiedDate { get; set; }
    }
}
