﻿namespace PAI.Common.Core.Data
{
    /// <summary>
    /// Inteface for archived entities that should not permanently be
    /// deleted from the backing store, but instead marked as IsDeleted
    /// </summary>
    public interface IArchivedEntity
    {
        /// <summary>
        /// Gets or sets whether the entity is in the "deleted" state
        /// </summary>
        bool IsDeleted { get; set; }
    }
}
