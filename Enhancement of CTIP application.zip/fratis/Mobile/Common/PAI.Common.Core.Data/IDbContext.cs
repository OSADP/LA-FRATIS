using System;

namespace PAI.Common.Core.Data
{
    public interface IDbContext: IDisposable
    {
        /// <summary>
        /// Saves all changes made in this context to the underlying database
        /// </summary>
        /// <returns>The number of objects written to the underlying database.</returns>
        int SaveChanges();
    }
}