using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
//WARNING - This file is being linked in the PAI.RP.Portable solution as well.
namespace PAI.Common.Core.Data
{
   
    public partial interface IRepository<TEntity> : IDisposable
        where TEntity : class, IEntity
    {
        /// <summary>
        /// Asynchronously Gets entity by id
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="token">the cancellation token</param>
        Task<TEntity> GetByIdAsync(string id, CancellationToken token);

        /// <summary>
        /// Asynchronously Gets single entity by predicate
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <param name="token"></param>
        Task<TEntity> GetOneByAsync(Func<TEntity, bool> predicate, CancellationToken token);

        /// <summary>
        /// Asynchronously Adds the new entity in the repository.
        /// </summary>
        /// <param name="entity">The entity to add.</param>
        /// <param name="token">the cancellation token</param>
        /// <returns>The added entity including its new ObjectId.</returns>
        Task<TEntity> InsertAsync(TEntity entity, CancellationToken token);

        /// <summary>
        /// Asynchronously Adds the new entities in the repository.
        /// </summary>
        /// <param name="entities">The entities of type T.</param>
        /// <param name="token">the cancellation token</param>
        Task InsertAsync(IEnumerable<TEntity> entities, CancellationToken token);

        /// <summary>
        /// Asynchronously Upserts an entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="token">the cancellation token</param>
        /// <returns>The updated entity.</returns>
        Task<TEntity> UpdateAsync(TEntity entity, CancellationToken token);

        /// <summary>
        /// Asynchronously Upserts the entities.
        /// </summary>
        /// <param name="entities">The entities to update.</param>
        /// <param name="token">the cancellation token</param>
        Task UpdateAsync(IEnumerable<TEntity> entities, CancellationToken token);

        /// <summary>
        /// Asynchronously Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="id">The entity's id.</param>
        /// <param name="token">the cancellation token</param>
        Task DeleteAsync(string id, CancellationToken token);

        /// <summary>
        /// Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// /// <param name="token">the cancellation token</param>
        Task DeleteAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken token);

        Task<int> AutoIncrementSubscriberOrderNumberAsync(string subscriberId, CancellationToken token);
    }


    public static partial class RepositoryExtensions
    {
        /// <summary>
        /// Asynchrously Deletes the given entity.
        /// </summary>
        /// <param name="entity">The entity to delete.</param>
        /// <param name="token">the cancellation token</param>
        public static Task DeleteAsync<TEntity>(this IRepository<TEntity> repository, TEntity entity, CancellationToken token) 
            where TEntity : class, IEntity
        {
            return repository.DeleteAsync(entity.Id, token);
        }

        /// <summary>
        /// Asynchrously Deletes the given entity.
        /// </summary>
        /// <param name="entity">The entity to delete.</param>
        public static Task DeleteAsync<TEntity>(this IRepository<TEntity> repository, TEntity entity)
            where TEntity : class, IEntity
        {
            return repository.DeleteAsync(entity, CancellationToken.None);
        }

    }

}