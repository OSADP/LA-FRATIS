using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace PAI.Common.Core.Data
{
    /// <summary>
    /// Repository interface
    /// </summary>
    /// <typeparam name="TEntity">entity type</typeparam>
    public partial interface IRepository<TEntity> : IDisposable
        where TEntity : class, IEntity
    {

        IDbContext CreateDbContextScope();

        /// <summary>
        /// Retuns an IQueryable for this entity
        /// </summary>
        IQueryable<TEntity> AsQueryable(IDbContext context);

        /// <summary>
        /// Gets entity by id
        /// </summary>
        /// <param name="id">The id.</param>
        TEntity GetById(string id);

        /// <summary>
        /// Gets single entity by predicate
        /// </summary>
        /// <param name="predicate">The predicate</param>
        TEntity GetOneBy(Func<TEntity, bool> predicate);

        /// <summary>
        /// Adds the new entity in the repository.
        /// </summary>
        /// <param name="entity">The entity to add.</param>
        /// <returns>The added entity including its new ObjectId.</returns>
        TEntity Insert(TEntity entity);

        /// <summary>
        /// Adds the new entities in the repository.
        /// </summary>
        /// <param name="entities">The entities of type T.</param>
        void Insert(IEnumerable<TEntity> entities);

        /// <summary>
        /// Upserts an entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>The updated entity.</returns>
        TEntity Update(TEntity entity);

        /// <summary>
        /// Upserts the entities.
        /// </summary>
        /// <param name="entities">The entities to update.</param>
        void Update(IEnumerable<TEntity> entities);

        /// <summary>
        /// Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="id">The entity's id.</param>
        void Delete(string id);

        /// <summary>
        /// Deletes an entity from the repository by its id.
        /// </summary>
        /// <param name="predicate">The predicate</param>
        void Delete(Expression<Func<TEntity, bool>> predicate);
    }


    public static partial class RepositoryExtensions
    {
        /// <summary>
        /// Deletes the given entity.
        /// </summary>
        /// <param name="entity">The entity to delete.</param>
        public static void Delete<TEntity>(this IRepository<TEntity> repository, TEntity entity) 
            where TEntity : class, IEntity
        {
            repository.Delete(entity.Id);
        }
    }

}