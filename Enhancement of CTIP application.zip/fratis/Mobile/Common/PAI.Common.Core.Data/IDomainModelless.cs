using System.Linq;
using System;

namespace PAI.Common.Core.Data
{
    public interface IDomainModelless
    {
        
    }
}