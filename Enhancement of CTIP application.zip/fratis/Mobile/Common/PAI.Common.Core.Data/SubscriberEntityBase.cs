//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!

using System;

namespace PAI.Common.Core.Data
{

    public interface ISubscriberEntity : IEntity, ISubscriber, IEquatable<ISubscriberEntity>
    {
    }

    /// <summary>
    /// Represents an entity that belongs to a particular Subscriber
    /// and thereby contains a SubscriberId unique identifier FK
    /// </summary>
    public class SubscriberEntityBase : EntityBase, ISubscriberEntity, IEquatable<ISubscriberEntity>
    {
        public string SubscriberId { get; set; }

        public bool Equals(ISubscriberEntity other)
        {
            if (other == null)
            {
                return false;
            }

            if (this.GetType() != other.GetType())
            {
                return false;
            }

            return this.Id == other.Id;
        }

        public static bool operator ==(SubscriberEntityBase a, SubscriberEntityBase b)
        {
            if (ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || (object)b == null)
            {
                return false;
            }

            return a.Equals(b);
        }

        public static bool operator !=(SubscriberEntityBase a, SubscriberEntityBase b)
        {
            return !(a == b);
        }
    }
}