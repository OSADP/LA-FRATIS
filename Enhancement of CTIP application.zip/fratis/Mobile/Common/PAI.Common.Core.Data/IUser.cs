﻿//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Data
{
    public interface IUser
    {
        string UserId { get; set; }
    }
}
