//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Data
{
    /// <summary>
    /// Entity interface.
    /// </summary>
    public interface IEntity
    {
        /// <summary>
        /// Gets or sets the Id of the Entity.
        /// </summary>
        /// <value>Id of the Entity.</value>
        string Id { get; set; }
    }

}