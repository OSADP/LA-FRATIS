namespace PAI.Common.Core.Data
{
    public interface IRepositoryFactory
    {
        /// <summary>
        /// Creates an instance of a Repository for the given entity type
        /// </summary>
        /// <typeparam name="TEntity">the entity type</typeparam>
        /// <returns>the repository</returns>
        IRepository<TEntity> CreateRepository<TEntity>() where TEntity : class, IEntity;
    }
}