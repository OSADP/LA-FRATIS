﻿//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Data
{
    public interface ISubscriber
    {
        string SubscriberId { get; set; }
    }
}
