//WARNING - This file is being linked in the PAI.RP.Portable solution.  Do not remove!
namespace PAI.Common.Core.Data
{
    public class EntityBase : IEntity
    {
        public string Id { get; set; }
    }
}