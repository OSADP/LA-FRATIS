

namespace PAI.Common.Core.Data
{
    public interface IConnectionStringProvider
    {
        string ConnectionString { get; }

        string DatabaseName { get; }

        string WebServerConnectionString { get; }
    }

    public class StaticConnectionString : IConnectionStringProvider
    {
        public StaticConnectionString(string connectionString, string databaseName, string webServerConnectionString)
        {
            this.ConnectionString = connectionString;
            this.DatabaseName = databaseName;
            this.WebServerConnectionString = webServerConnectionString;
        }

        public string ConnectionString { get; private set; }

        public string DatabaseName { get; private set; }

        public string WebServerConnectionString { get; private set; }
    }
}