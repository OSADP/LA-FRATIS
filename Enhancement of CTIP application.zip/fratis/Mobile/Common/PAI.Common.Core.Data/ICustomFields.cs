﻿using System.Collections.Generic;

namespace PAI.Common.Core.Data
{
    /// <summary>
    /// Interface for specifying that the Entity uses custom fields and has corresponding CustomFieldSchemas for properties for the EntityType
    /// </summary>
    public interface ICustomFields
    {
        Dictionary<string, object> CustomFields { get; set; }
    }
}
