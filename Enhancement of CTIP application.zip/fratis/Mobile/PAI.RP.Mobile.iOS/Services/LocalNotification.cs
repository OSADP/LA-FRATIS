﻿using Foundation;
using PAI.RP.Mobile.iOS.Services;
using PAI.RP.Mobile.Services;
using UIKit;
using Xamarin.Forms;

[assembly: Dependency(typeof(LocalNotification))]
namespace PAI.RP.Mobile.iOS.Services
{
    public class LocalNotification : ILocalNotification
    {

        public void Notify(string title, string body)
        {

            var notification = new UILocalNotification
            {
                AlertAction = title,
                AlertBody = body,
                ApplicationIconBadgeNumber = 1,
                SoundName = UILocalNotification.DefaultSoundName
            };
        
            UIApplication.SharedApplication.ScheduleLocalNotification(notification);
        }
    }
}