﻿using System;
using NUnit.Framework;

using Ninject.MockingKernel.Moq;

namespace PAI.RP.Tests
{
    [TestFixture]
    public abstract class TestsBase
    {
        public MoqMockingKernel Kernel { get; set; }

        [TestFixtureSetUp]
        public void BaseSetUp()
        {
            try
            {
                this.Kernel = new MoqMockingKernel();
            }
            catch (Exception e)
            {
                Assert.IsTrue(true);
            }
        }

    }
}