﻿using System;
using Ninject;
using NUnit.Framework;
using PAI.RP.Services.Rest.Portable.Authentication;
using PAI.RP.Tests;

namespace PAI.RP.REST.Tests
{
    public class AuthenticationServiceTests : TestsBase
    {
        private IAuthenticationService _authenticationService;

        [SetUp]
        public void SetUp()
        {
            _authenticationService = Kernel.Get<IAuthenticationService>();
        }
    }
}
