﻿using System.Threading;
using System.Threading.Tasks;
using Ninject;
using NUnit.Framework;
using PAI.RP.Services.Rest.Portable.Planning;
using PAI.RP.Services.Rest.Portable.Subscribers;

namespace PAI.RP.REST.Tests
{
    public class PlanServiceTests : TestsRestBase
    {
        private IPlanService _planService;
        private IUserService _userService;

        [TestFixtureSetUp]
        public void SetUp()
        {
            _planService = Kernel.Get<IPlanService>();
            _userService = Kernel.Get<IUserService>();
        }

        //[Test]
        //[Explicit]
        //public async Task Get_Plans_Async_Should_Work()
        //{
        //    await LoginAsync();

        //    var plans = await _planService.GetAsync<PlanViewModel, List<PlanViewModel>>(null, null, CancellationToken.None);
        //    plans.ShouldNotBeNull();
        //}

        //[Test]
        //[Explicit]
        //public async Task Get_Plans_For_User_Async_Should_Work()
        //{
        //    await LoginAsync();

        //    var plans = await _planService.GetByUserAsync<PlanViewModel>(UserId, null, CancellationToken.None);
        //    plans.ShouldNotBeNull();
        //}

        //[Test]
        //[Explicit]
        //public async Task Start_First_Plan()
        //{
        //    await LoginAsync();

        //    var plans = await _planService.GetByUserAsync<PlanViewModel>(UserId, null, CancellationToken.None);

        //    var firstActivePlan = plans.FirstOrDefault(x => x.Status == PlanStatus.Received);
        //    firstActivePlan.Status = PlanStatus.InProgress;

        //    var a = await _planService.SaveAsync<PlanViewModel>(firstActivePlan, CancellationToken.None);
        //}

        //[Test]
        //[Explicit]
        //public async Task Optimize_Plan()
        //{
        //    await LoginAsync();

        //    var result = await _planService.GetByDriverAsync("", CancellationToken.None);
        //}

    }
}
