﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Ninject;
using NUnit.Framework;
using PAI.RP.Domain.Tests;
using PAI.RP.Services.Rest.Portable.Customers;
using PAI.RP.Tests;

namespace PAI.RP.REST.Tests
{
    public class CustomerServiceTests : TestsBase
    {
        private ICustomerService _customerService;

        [SetUp]
        public void SetUp()
        {
            _customerService = Kernel.Get<ICustomerService>();
        }

        [Test]
        public async Task Get_Customers_Async_Should_Work()
        {
            //var customers = await _customerService.GetAsync<CustomerViewModel, List<CustomerViewModel>>(null, null, CancellationToken.None);
            //customers.ShouldNotBeNull();
        }

        [Test]
        public async Task Delete_Customers_Async_Should_Work()
        {
            //var result = await _customerService.DeleteAsync(new CustomerViewModel { Id = "53ea3f612a8fd00360fca009"}, CancellationToken.None);
        }
    }
}
