﻿using System;
using Ninject;
using NUnit.Framework;
using PAI.RP.Services.Rest.Portable.Subscribers;

namespace PAI.RP.REST.Tests
{
    public class UserServiceTests : TestsRestBase
    {
        private IUserService _userService;

        [SetUp]
        public void SetUp()
        {
            _userService = Kernel.Get<IUserService>();
        }
    }
}
