﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using NUnit.Framework;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.REST.Tests
{
    public class GeolocationServiceTests
    {
        private List<Geolocation> _geolocations = new List<Geolocation>
        {
            new Geolocation
            {
                SubscriberId = "53e1257c2a8fd01764c2fcd6",
                UserId = "53ee9abb2a8fd313009c0126",
                Latitude = 27.8223,
                Longitude = -82.2797,
                TimeStamp = DateTime.UtcNow
            }
        };


        [Test]
        public void Get_Json()
        {
            var res = JsonConvert.SerializeObject(_geolocations);
        }
    }
}
