﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using Ninject;
using NUnit.Framework;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable;
using PAI.RP.Services.Rest.Portable.Authentication;
using PAI.RP.Services.Rest.Portable.Customers;
using PAI.RP.Services.Rest.Portable.Model;
using PAI.RP.Services.Rest.Portable.Orders;
using PAI.RP.Services.Rest.Portable.Planning;
using PAI.RP.Services.Rest.Portable.Subscribers;
using PAI.RP.Tests;

namespace PAI.RP.REST.Tests
{
    [TestFixture]
    public abstract class TestsRestBase : TestsBase
    {
        protected string UserId { get; set; }
        protected string SubscriberId { get; set; }
        protected string TokenString { get; set; }
        protected bool LoggedIn { get; set; }

        private IAuthenticationService _authenticationService;

        [TestFixtureSetUp]
        public void RestBaseSetUp()
        {
            LoggedIn = false;
            Kernel.Bind<IRestClientProvider>().ToConstant(new RestClientProvider { BaseUrl = "http://localhost:56981", ApiVersion = "v1" });//Local Dev
            //Kernel.Bind<IRestClientProvider>().ToConstant(new RestClientProvider { BaseUrl = "http://rp.productivityapex.com", ApiVersion = "v1" });//RP Site

            //Authentication
            Kernel.Bind<IRestClientFactory>().To<RestClientFactory>();
            UserAuthentication.AuthenticationProvider = new AuthenticationProvider();
            Kernel.Bind<IAuthenticationService>().To<AuthenticationService>();
            Kernel.Bind<IAuthenticationProvider>().ToConstant(UserAuthentication.AuthenticationProvider);

            //Rest Services
            Kernel.Bind<IPlanService>().To<PlanService>();
            Kernel.Bind<IOrderService>().To<OrderService>();
            Kernel.Bind<IUserService>().To<UserService>();
            Kernel.Bind<ICustomerService>().To<CustomerService>();

            _authenticationService = Kernel.Get<IAuthenticationService>();

            //Mapper.CreateMap<Customer, CustomerViewModel>();
            //Mapper.CreateMap<CustomerViewModel, Customer>();

            //Mapper.CreateMap<Plan, PlanViewModel>();
            //Mapper.CreateMap<PlanViewModel, Plan>();

            Mapper.CreateMap<Order, OrderViewModel>();
            Mapper.CreateMap<OrderViewModel, Order>();

            Mapper.CreateMap<Geolocation, GeolocationViewModel>();
            Mapper.CreateMap<GeolocationViewModel, Geolocation>();

            Mapper.CreateMap<User, UserViewModel>();
            Mapper.CreateMap<UserViewModel, User>();

            //Mapper.CreateMap<OrderNote, OrderNoteViewModel>();
            //Mapper.CreateMap<OrderNoteViewModel, OrderNote>();

            //Mapper.CreateMap<OrderLocation, OrderLocationViewModel>();
            //Mapper.CreateMap<OrderLocationViewModel, OrderLocation>();

            //Mapper.CreateMap<TimeWindow, TimeWindowViewModel>();
            //Mapper.CreateMap<TimeWindowViewModel, TimeWindow>();
        }

        protected async Task LoginAsync()
        {
            AuthenticationResponseViewModel loginResponse;
            try
            {
                loginResponse = await _authenticationService.PostAsync<AuthenticationRequestViewModel, AuthenticationResponseViewModel>
                (new AuthenticationRequestViewModel { Username = "demo", Password = "demo" }, "/login");
            }
            catch (Exception)
            {
                loginResponse = null;
            }

            if (loginResponse != null && !string.IsNullOrWhiteSpace(loginResponse.Token))
            {
                LoggedIn = true;
                UserAuthentication.AuthenticationProvider.TokenString = loginResponse.Token;
                UserAuthentication.AuthenticationProvider.UserId = loginResponse.User.Id;
                UserAuthentication.AuthenticationProvider.DriverId = loginResponse.DriverId;
                TokenString = loginResponse.Token;
                UserId = loginResponse.User.Id;
                Kernel.Rebind<IAuthenticationProvider>().ToConstant(UserAuthentication.AuthenticationProvider);
            }
        }
    }
}
