﻿using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Rest.Portable.Customers
{
    public interface ICustomerService : IEntityRestServiceBase<Customer>
    {
    }

    public class CustomerService : EntityRestServiceBase<Customer>, ICustomerService
    {
        public CustomerService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/customers";
        }
    }
}
