﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.Common.Core.Data;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable.Model;
using PortableRest;

namespace PAI.RP.Services.Rest.Portable
{
    public interface IRestServiceBase
    {
        string BaseUrl { get; }
        string BaseRequestUrl { get; }
        string ApiVersion { get; }

        Task<TResponseViewModel> PostAsync<TRequestViewModel, TResponseViewModel>(
            TRequestViewModel requestViewModel, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class;

        Task<TResponseViewModel> PostAsync<TRequestViewModel, TResponseViewModel>(
            TRequestViewModel requestViewModel, string extendedRequestUrl, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class;

        Task<TResponseViewModel> GetAsync<TRequestViewModel, TResponseViewModel>(
            TRequestViewModel requestViewModel, string extendedRequestUrl, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class;
    }

    public static class RestServiceBaseExtensions
    {
        public static async Task<TResponseViewModel> PostAsync<TRequestViewModel, TResponseViewModel>(
            this IRestServiceBase restService, TRequestViewModel requestViewModel, string extendedRequestUrl)
            where TRequestViewModel : class where TResponseViewModel : class
        {
            return await restService.PostAsync<TRequestViewModel, TResponseViewModel>(requestViewModel, extendedRequestUrl, CancellationToken.None);
        }
    }

    public abstract class RestServiceBase : IRestServiceBase
    {
        public string BaseUrl { get; private set; }
        public string BaseRequestUrl { get; protected set; }
        public string ApiVersion { get; private set; }

        //protected readonly RestClient Client;
        protected readonly IRestClientFactory _restClientFactory;
        protected readonly IAuthenticationProvider AuthenticationProvider;
        protected readonly IDictionary<string, string> AdditionalQueryStringParameters;

        protected RestServiceBase(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
        {
            //Client = restClientFactory.RestClient;
            _restClientFactory = restClientFactory;
            AuthenticationProvider = authenticationProvider;
            AdditionalQueryStringParameters = new Dictionary<string, string>();
            BaseUrl = restClientProvider.BaseUrl;
            ApiVersion = restClientProvider.ApiVersion;
        }

        protected RestRequest CreateRequest<TRequestViewModel>(HttpMethod httpMethod)
            where TRequestViewModel : class
        {
            return CreateRequest<TRequestViewModel>(null, null, httpMethod);
        }

        protected RestRequest CreateRequest<TRequestViewModel>(string extendedRequestUrl, HttpMethod httpMethod)
            where TRequestViewModel : class
        {
            return CreateRequest<TRequestViewModel>(null, extendedRequestUrl, httpMethod);
        }

        protected RestRequest CreateRequest<TRequestViewModel>(TRequestViewModel requestViewModel, HttpMethod httpMethod)
            where TRequestViewModel : class
        {
            return CreateRequest(requestViewModel, null, httpMethod);
        }

        protected RestRequest CreateRequest<TRequestViewModel>(TRequestViewModel requestViewModel, string extendedRequestUrl, HttpMethod httpMethod)
            where TRequestViewModel : class
        {
            if (string.IsNullOrWhiteSpace(extendedRequestUrl))
            {
                extendedRequestUrl = string.Empty;
            }
            var request = new RestRequest(BaseRequestUrl + extendedRequestUrl, httpMethod);
            SetupRequest(request, requestViewModel);

            return request;
        }

        protected RestRequest SetupRequest<TRequestViewModel>(RestRequest request)
            where TRequestViewModel : class
        {
            return SetupRequest<TRequestViewModel>(request, null);
        }

        protected RestRequest SetupRequest<TRequestViewModel>(RestRequest request, TRequestViewModel requestViewModel)
            where TRequestViewModel : class
        {
            if (AuthenticationProvider != null && !string.IsNullOrWhiteSpace(AuthenticationProvider.TokenString))
            {
                request.AddHeader("Authorization", "Token " + AuthenticationProvider.TokenString);
            }
            request.AddHeader("Accept", "*/*");
            if (requestViewModel != null)
            {
                request.AddViewModel(requestViewModel);
            }
            foreach (var additionalQueryStringParameter in AdditionalQueryStringParameters)
            {
                request.AddQueryString(additionalQueryStringParameter.Key, additionalQueryStringParameter.Value);
            }
            return request;
        }

        public virtual async Task<TResponseViewModel> PostAsync<TRequestViewModel, TResponseViewModel>(TRequestViewModel requestViewModel, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class
        {
            return await PostAsync<TRequestViewModel, TResponseViewModel>(requestViewModel, null, cancellationToken);
        }

        public virtual async Task<TResponseViewModel> PostAsync<TRequestViewModel, TResponseViewModel>(TRequestViewModel requestViewModel, string extendedRequestUrl, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class
        {
            var request = CreateRequest(requestViewModel, extendedRequestUrl, HttpMethod.Post);
            return await _restClientFactory.RestClient.ExecuteAsync<TResponseViewModel>(request, cancellationToken);
        }

        public virtual async Task<TResponseViewModel> GetAsync<TRequestViewModel, TResponseViewModel>(TRequestViewModel requestViewModel, string extendedRequestUrl, CancellationToken cancellationToken)
            where TRequestViewModel : class where TResponseViewModel : class
        {
            var request = CreateRequest(requestViewModel, extendedRequestUrl, HttpMethod.Get);
            var viewModels = await _restClientFactory.RestClient.ExecuteAsync<TResponseViewModel>(request, cancellationToken);

            return viewModels;
        }
    }

    public interface IEntityRestServiceBase<TEntity> : IRestServiceBase 
        where TEntity : class, IEntity
    {
        Task<TEntity> GetByIdAsync<TEntitityViewModel>(string id, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task<TEntity> SaveAsync<TEntitityViewModel>(TEntity entity, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task<IEnumerable<TEntity>> SaveAsync<TEntitityViewModel>(IEnumerable<TEntity> entities, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task<string> DeleteAsync(string id, CancellationToken cancellationToken);
    }

    public abstract class EntityRestServiceBase<TEntity> : RestServiceBase, IEntityRestServiceBase<TEntity> 
        where TEntity : class, IEntity
    {
        protected EntityRestServiceBase(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
        }

        public virtual async Task<TEntity> GetByIdAsync<TEntitityViewModel>(string id, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            if (extendedRequestUrl == null)
            {
                extendedRequestUrl = string.Empty;
            }
            var request = CreateRequest<string>(extendedRequestUrl + "/" + id, HttpMethod.Get);
            var viewModel = await _restClientFactory.RestClient.ExecuteAsync<TEntitityViewModel>(request, cancellationToken);

            return Mapper.Map<TEntitityViewModel, TEntity>(viewModel);
        }

        public virtual async Task<TEntity> SaveAsync<TEntitityViewModel>(TEntity entity, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            var viewModel = Mapper.Map<TEntity, TEntitityViewModel>(entity);
            viewModel = await base.PostAsync<TEntitityViewModel, TEntitityViewModel>(viewModel, cancellationToken);
            entity = Mapper.Map<TEntitityViewModel, TEntity>(viewModel);

            return entity;
        }

        public virtual async Task<IEnumerable<TEntity>> SaveAsync<TEntitityViewModel>(IEnumerable<TEntity> entities, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            var viewModels = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TEntitityViewModel>>(entities);
            viewModels = await base.PostAsync<IEnumerable<TEntitityViewModel>, List<TEntitityViewModel>>(viewModels, cancellationToken);
            entities = Mapper.Map<IEnumerable<TEntitityViewModel>, IEnumerable<TEntity>>(viewModels);

            return entities;
        }

        public virtual async Task<string> DeleteAsync(string id, CancellationToken cancellationToken)
        {
            //TODO - Add back in DeleteAsync after Server modules have been implemented
            //var request = CreateRequest<string>(HttpMethod.Delete);
            //request.AddQueryString("id", id);
            //var result = await Client.ExecuteAsync<string>(request, cancellationToken);
            var result = "true";

            return result;
        }
    }

    public interface IUserRestServiceBase<TEntity> : IEntityRestServiceBase<TEntity>
        where TEntity : class, IEntity, ISubscriber, IUser
    {
        Task<IEnumerable<TEntity>> GetByUserAsync<TEntitityViewModel>(string userId, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity, ISubscriber, IUser;
    }

    public abstract class UserRestServiceBase<TEntity> : EntityRestServiceBase<TEntity>, IUserRestServiceBase<TEntity>
        where TEntity : class, IEntity, ISubscriber, IUser
    {
        protected UserRestServiceBase(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
        }

        public virtual async Task<IEnumerable<TEntity>> GetByUserAsync<TEntitityViewModel>(string userId, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity, ISubscriber, IUser
        {
            var originalBaseRequestUrl = BaseRequestUrl;
            BaseRequestUrl = "api/" + ApiVersion + "/users/" + userId;
            IEnumerable<TEntitityViewModel> responseViewModels;
            try
            {
                var pagedResult = await this.GetAsync<TEntitityViewModel, PagedResultViewModel<TEntitityViewModel>>(null, extendedRequestUrl, cancellationToken);
                responseViewModels = pagedResult.Items;
            }
            finally
            {
                BaseRequestUrl = originalBaseRequestUrl;
            }

            return Mapper.Map<IEnumerable<TEntitityViewModel>, IEnumerable<TEntity>>(responseViewModels);
        }
    }
}
