﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Rest.Portable.Setting
{
    public interface IGeneralPreferenceServiceService : IEntityRestServiceBase<GeneralPreference>
    {
        Task<SettingViewModel> GetAsync(CancellationToken cancellationToken);
    }

    public class GeneralPreferenceService : EntityRestServiceBase<GeneralPreference>, IGeneralPreferenceServiceService
    {
        public GeneralPreferenceService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/settings";
        }

        public async Task<SettingViewModel> GetAsync(CancellationToken cancellationToken)
        {
            return await GetAsync<string, SettingViewModel>(null, "/general", cancellationToken);
        }
    }
}
