﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Rest.Portable.Authentication
{
    public interface IAuthenticationService : IRestServiceBase
    {
        Task<AuthenticationResponseViewModel> AuthenticateAsync(string username, string password);

        Task<PasswordChangeResultViewModel> ResetPasswordAsync(string username, CancellationToken cancellationToken);
    }

    public class AuthenticationService : RestServiceBase, IAuthenticationService
    {
        public AuthenticationService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/auth";
        }

        public async Task<AuthenticationResponseViewModel> AuthenticateAsync(string username, string password)
        {
            return await this.PostAsync<AuthenticationRequestViewModel, AuthenticationResponseViewModel>
                (new AuthenticationRequestViewModel {Username = username, Password = password, IsMobileLogin = true}, "/login");
        }

        public async Task<PasswordChangeResultViewModel> ResetPasswordAsync(string username, CancellationToken cancellationToken)
        {
            return await this.PostAsync<AuthenticationRequestViewModel, PasswordChangeResultViewModel>
                (new AuthenticationRequestViewModel { Username = username }, "/resetpassword");
        }
    }
}
