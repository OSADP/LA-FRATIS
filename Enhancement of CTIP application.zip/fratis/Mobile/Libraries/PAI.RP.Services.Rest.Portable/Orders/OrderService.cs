﻿using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Rest.Portable.Orders
{
    public interface IOrderService : IUserRestServiceBase<Order>
    {

    }

    public class OrderService : UserRestServiceBase<Order>, IOrderService
    {
        public OrderService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/orders";
        }
    }
}
