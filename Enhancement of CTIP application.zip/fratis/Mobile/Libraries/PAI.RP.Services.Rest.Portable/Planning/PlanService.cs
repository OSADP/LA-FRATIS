﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Rest.Portable.Planning
{
    public interface IPlanService : IUserRestServiceBase<Plan>
    {
        Task<IEnumerable<PlanDriverPlanViewModel>> GetByDriverAsync(string driverId, DateTime? afterUtcDate, CancellationToken cancellationToken);
        Task<PlanDriverPlanViewModel> SaveAsync(PlanDriverPlanViewModel planDriverPlanViewModel, CancellationToken cancellationToken);
    }

    public class PlanService : UserRestServiceBase<Plan>, IPlanService
    {
        public PlanService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/driverplans";
        }

        public async Task<IEnumerable<PlanDriverPlanViewModel>> GetByDriverAsync(string driverId, DateTime? afterUtcDate, CancellationToken cancellationToken) 
        {
            return await base.GetAsync<object, List<PlanDriverPlanViewModel>>(new { AfterUtcDate = afterUtcDate }, null, cancellationToken);
        }

        public async Task<PlanDriverPlanViewModel> SaveAsync(PlanDriverPlanViewModel planDriverPlanViewModel, CancellationToken cancellationToken)
        {
            return await base.PostAsync<PlanDriverPlanViewModel, PlanDriverPlanViewModel>(planDriverPlanViewModel, cancellationToken);
        }
    }
}
