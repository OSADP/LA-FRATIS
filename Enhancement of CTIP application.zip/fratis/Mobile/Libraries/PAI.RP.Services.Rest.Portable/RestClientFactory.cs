﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using PAI.RP.Domain.Portable;
using PortableRest;

namespace PAI.RP.Services.Rest.Portable
{
    public interface IRestClientFactory
    {
        RestClient RestClient { get; }
    }

    public class RestClientFactory : IRestClientFactory
    {
        private RestClient _restClient;
        public RestClient RestClient => new RestClient
        {
            BaseUrl = _restClientProvider.BaseUrl,
            JsonSerializerSettings =
                new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                }
        };

        private readonly IRestClientProvider _restClientProvider;
        public RestClientFactory(IRestClientProvider restClientProvider)
        {
            _restClientProvider = restClientProvider;
        }
    }
}
