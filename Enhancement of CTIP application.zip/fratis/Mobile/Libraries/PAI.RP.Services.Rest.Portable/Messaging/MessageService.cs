﻿using PAI.RP.Domain.Portable;

namespace PAI.RP.Services.Rest.Portable.Messaging
{
    public interface IMessageService : IRestServiceBase
    {
    }

    public class MessageService : RestServiceBase, IMessageService
    {
        public MessageService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/messages";
        }
    }
}
