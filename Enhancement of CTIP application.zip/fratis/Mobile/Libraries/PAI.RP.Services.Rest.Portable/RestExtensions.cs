﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using PortableRest;

namespace PAI.RP.Services.Rest.Portable
{
    public static class RestExtensions
    {
        public static void AddViewModel<TViewModel>(this RestRequest request, TViewModel viewModel)
        {
            request.ContentType = ContentTypes.Json;

            if (request.Method == HttpMethod.Post)
            {
                request.AddParameter(viewModel);
            }
            else if (request.Method == HttpMethod.Get)
            {
                //TODO - This process will not parse strings correctly with values containing the string literal  \":
                //TODO - i.e. this won't work parse correctly in its current state: new {Fruits = "apples, \"oranges\":\"tangerine\", bannanas"}
                //TODO - Refine this process in the future
                var jsonString = JsonConvert.SerializeObject(viewModel).Trim(' ');

                if (jsonString.StartsWith("["))
                {
                    throw new JsonException("Provided viewModel cannot be a collection, only a single object.");
                }

                foreach (var line in jsonString.Trim('{', '}').Split(new string[] { ",\"" }, StringSplitOptions.None))
                {
                    new List<string> {",\""};
                    var kvp = line.Split(new string[] { "\":" }, StringSplitOptions.None);
                    var key = kvp[0].Trim(' ', '"', '\\');
                    var value = kvp[1].Trim(' ', '"', '\\');

                    request.AddQueryString(key, value);
                }
            }
        }
    }
}
