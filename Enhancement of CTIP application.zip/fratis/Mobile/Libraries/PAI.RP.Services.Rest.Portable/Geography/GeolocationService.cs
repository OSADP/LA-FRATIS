﻿using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Rest.Portable.Geography
{
    public interface IGeolocationService : IUserRestServiceBase<Geolocation>
    {
    }

    public class GeolocationService : UserRestServiceBase<Geolocation>, IGeolocationService
    {
        public GeolocationService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider) 
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/geolocations";
        }
    }
}
