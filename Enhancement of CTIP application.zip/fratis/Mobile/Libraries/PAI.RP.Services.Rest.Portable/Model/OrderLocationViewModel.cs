﻿using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderLocationViewModel : LocationViewModel
    {
        public IList<TimeWindowViewModel> TimeWindows { get; set; }

        public double ServiceTime { get; set; }
    }
}
