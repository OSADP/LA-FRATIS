﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class RouteStatisticsViewModel
    {
        /// <summary>
        /// Gets or sets the total idle time in minutes
        /// </summary>
        public double TotalIdleTime { get; set; }

        /// <summary>
        /// Gets or sets the total queue time in minutes
        /// </summary>
        public double TotalQueueTime { get; set; }

        /// <summary>
        /// Gets or sets the total execution time in minutes
        /// </summary>
        public double TotalExecutionTime { get; set; }

        /// <summary>
        /// Gets or sets the total travel time in minutes
        /// </summary>
        public double TotalTravelTime { get; set; }

        /// <summary>
        /// Gets or sets the total travel distance in miles
        /// </summary>
        public double d { get; set; }

        /// <summary>
        /// Gets or sets the total time in minutes
        /// </summary>
        public double TotalTime { get; set; }

        /// <summary>
        /// Gets or sets the total capacity
        /// </summary>
        public double TotalCapacity { get; set; }
    }
}
