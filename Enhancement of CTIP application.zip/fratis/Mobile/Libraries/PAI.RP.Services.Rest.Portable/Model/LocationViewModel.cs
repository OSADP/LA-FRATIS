﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class LocationViewModel
    {
        public LocationViewModel()
        {
            Address = new AddressViewModel();
        }

        /// <summary>
        /// Gets or sets the address
        /// </summary>
        public AddressViewModel Address { get; set; }

        /// <summary>
        /// Gets or sets the latitude in degrees
        /// </summary>
        public double? Latitude { get; set; }

        /// <summary>
        /// Gets or sets the longitude in degrees
        /// </summary>
        public double? Longitude { get; set; }
    }

    public class LocationModelSlim
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }

        public string WebFleetId { get; set; }

        public double? Longitude { get; set; }

        public double? Latitude { get; set; }

        public string StreetAddress { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public string Address { get; set; }

    }

    public class AddressViewModel
    {
        /// <summary>
        /// Gets or sets address line 1
        /// </summary>
        public string Line1 { get; set; }

        /// <summary>
        /// Gets or sets address line 2
        /// </summary>
        public string Line2 { get; set; }

        /// <summary>
        /// Gets or sets address line 3
        /// </summary>
        public string Line3 { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public string Zip { get; set; }

        public string FullAddress { get; set; }
    }
}
