﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class GeneralPrefsHashViewModel
    {
        public string SubscriberId { get; set; }

        public string Hash { get; set; }
    }
}
