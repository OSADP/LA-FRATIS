﻿using System;
using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class RequestMessageViewModel
    {
        public DateTime? LastRequestDate { get; set; }
        public IEnumerable<MessageViewModel> Messages { get; set; }
    }

    public class ResponseMessageViewModel
    {
        public IEnumerable<MessageViewModel> Messages { get; set; }
    }

    public class MessageViewModel
    {
        public string ToUserId { get; set; }
        public MessageType MessageType { get; set; }
        public string MessageData { get; set; }
        public DateTime LatestTimeStamp { get; set; }
    }

    public enum MessageType
    {
        /// <summary>
        /// Send the message as free text for reading.
        /// </summary>
        FreeForm = 1,
        /// <summary>
        /// Instructs the recipient that geolocations are being transmitted in the MessageData property.
        /// </summary>
        SendGeolocations = 2,
        /// <summary>
        /// Instructs the recipient that plans are being transmitted in the MessageData property.
        /// </summary>
        SendPlans = 3,
        /// <summary>
        /// Instructs the recipient that orders are being transmitted in the MessageData property.
        /// </summary>
        SendOrders = 4,
        /// <summary>
        /// Instructs the recipient that hash representations for the plans are being transmitted in the MessageData property.
        /// </summary>
        SendPlansHashCheck = 5,
        /// <summary>
        /// Instructs the recipient that hash representations for the orders are being transmitted in the MessageData property.
        /// </summary>
        SendOrdersHashCheck = 6,
        /// <summary>
        /// Instructs the recipient that hash representations for the Custom Field Preferences are being transmitted in the MessageData property.
        /// </summary>
        SendCustomFieldPreferencesHash = 7,
        /// <summary>
        /// Instructs the recipient that Custom Field Preferences are being transmitted in the MessageData property.
        /// </summary>
        SendCustomFieldPreferences = 8,
        /// <summary>
        /// Instructs the recipient that hash representations for the General Preferences are being transmitted in the MessageData property.
        /// </summary>
        SendGeneralPreferencesHash = 9,
        /// <summary>
        /// Instructs the recipient that General Preferences are being transmitted in the MessageData property.
        /// </summary>
        SendGeneralPreferences = 10,
        /// <summary>
        /// Instructs the recipient that the Driver Plan is being transmitted in the MessageData property.
        /// </summary>
        SendDriverPlan = 11,
        /// <summary>
        /// Instructs the recipient that hash representations for the driver plan is being transmitted in the MessageData property.
        /// </summary>
        SendDriverPlanHashCheck = 12,
    }
}
