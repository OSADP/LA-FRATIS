﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class CustomFieldPrefHashViewModel
    {
        public string EntityType { get; set; }

        public string PropertyName { get; set; }

        public string Hash { get; set; }
    }
}
