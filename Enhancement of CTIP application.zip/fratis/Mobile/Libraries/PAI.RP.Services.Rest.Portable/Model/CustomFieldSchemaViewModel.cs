﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class CustomFieldSchemaViewModel
    {
        public int SortIndex { get; set; }
        public string EntityType { get; set; }
        public string PropertyName { get; set; }
        public string DisplayName { get; set; }
        public string ValueType { get; set; }
        public string Hash { get; set; }
    }
}
