﻿using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class PagedResultViewModel<T>
    {
        /// <summary>
        /// Gets or sets the TotalItems.
        /// </summary>
        public int Total { get; set; }

        /// <summary>
        /// Gets or sets the Type.
        /// </summary>
        public IList<T> Items { get; set; }
    }
}
