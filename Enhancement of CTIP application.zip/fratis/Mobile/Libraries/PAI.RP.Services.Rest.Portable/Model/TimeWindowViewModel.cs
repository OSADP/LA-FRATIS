﻿using System;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class TimeWindowViewModel
    {
        public DateTime? StartTime { get; set; }

        public DateTime? EndTime { get; set; }
    }
}
