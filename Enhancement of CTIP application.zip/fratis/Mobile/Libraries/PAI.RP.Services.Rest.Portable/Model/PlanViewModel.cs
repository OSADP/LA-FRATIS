﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using PAI.RP.Domain.Portable;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class PlanViewModel
    {
        public string Name { get; set; }

        public DateTime ExecutionDate { get; set; }

        public IList<PlanDriverPlanViewModel> DriverPlans { get; set; }

        public IList<PlanDriverPlanViewModel> CommittedDriverPlans { get; set; }

        public IList<OrderViewModel> UnassignedOrders { get; set; }
    }

    public class PlanDriverPlanStatusStampViewModel
    {
        public string UserId { get; set; }

        public PlanStatus Status { get; set; }

        public DateTime TimeStamp { get; set; }
    }

    public class PlanDriverPlanViewModel
    {
        public PlanDriverPlanViewModel()
        {
            Orders = new List<PlanOrderViewModel>();
        }

        public string Id { get; set; }

        public string DriverId { get; set; }

        public string PlanName { get; set; }

        public DateTime PlanExecutionDate { get; set; }

        public PlanDriverViewModel Driver { get; set; }

        public PlanStatus Status { get; set; }

        public IEnumerable<PlanDriverPlanStatusStampViewModel> Statuses { get; set; }

        public IList<PlanOrderViewModel> Orders { get; set; }

        public IList<PlanOrderViewModel> CommittedOrders { get; set; }

        public bool IsLocked { get; set; }

        public RouteStatisticsViewModel Statistics { get; set; }

        //public IList<RouteSegmentStatisticsViewModel> RouteSegmentStatistics { get; set; }

        public string Hash { get; set; }
    }

    public class PlanDriverViewModel
    {
        public PlanDriverViewModel()
        {
            StartLocation = new LocationViewModel();
        }

        public string Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string DriverNumber { get; set; }

        public double MaximumWorkingHours { get; set; }

        public double MaximumDrivingHours { get; set; }

        public TimeSpan EarliestStartTime { get; set; }

        public LocationViewModel StartLocation { get; set; }

        public LocationViewModel CurrentLocation { get; set; }
    }

    public class PlanOrderDetailsViewModel
    {
        public PlanOrderDetailsViewModel()
        {
            Locations = new List<OrderLocationViewModel>();
        }

        /// <summary>
        /// Gets or sets the OrderId
        /// </summary>
        public string Id { get; set; }

        public DateTime? ScheduledDate { get; set; }

        public string RequiredDriverId { get; set; }

        public IList<OrderLocationViewModel> Locations { get; set; }

        public string Number { get; set; }
    }

    public class PlanOrderViewModel
    {
        public string Id { get; set; }

        public string PlanId { get; set; }

        public IList<OrderStatusTimeViewModel> OrderStatusTimes { get; set; }

        public string RequiredDriverId { get; set; }

        public DateTime? ScheduledDate { get; set; }

        public string Number { get; set; }

        public OrderStatus Status { get; set; }

        public IList<RouteStopViewModel> RouteStops { get; set; } 

        public string Description { get; set; }

        public IList<OrderNoteViewModel> Notes { get; set; }

        public string CustomerId { get; set; }

        public IList<OrderLocationViewModel> Locations { get; set; }

        public CustomerViewModel Customer { get; set; }

        public OrderType OrderType { get; set; }

        public string ReferenceNumber { get; set; }

        public Dictionary<string, object> CustomFields { get; set; }

        public string Priority { get; set; }

        public string Hash { get; set; }

        public string PickupNumber { get; set; }

        public string BookingNumber { get; set; }

        public string BillOfLading { get; set; }

        public string ConsigneeName { get; set; }

        public string ShipperName { get; set; }

        public string ContainerOwner { get; set; }

        public string ContainerNumber { get; set; }
        public string Container { get; set; }

        public string ChassisOwner { get; set; }

        public string Chassis { get; set; }

        public string ChassisNumber { get; set; }

        public string CustomField1 { get; set; }

        public string CustomField2 { get; set; }
        public string CustomField3 { get; set; }
        public string CustomField4 { get; set; }
        public string CustomField5 { get; set; }
    }


    public class PlanUpdatedViewModel
    {
        /// <summary>
        /// The name of the plan
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The execution date
        /// </summary>
        public DateTime? ExecutionDate { get; set; }

        /// <summary>
        /// A list of driver plans that have been added or updated
        /// </summary>
        public IList<DriverPlanUpdatedViewModel> DriverPlans { get; set; }

        /// <summary>
        /// A list of driver plans that have been removed from the plan
        /// </summary>
        public IList<string> DriverPlansRemoved { get; set; }

        /// <summary>
        /// A list of orders that have been added or updated in the plan
        /// </summary>
        public IList<PlanOrderViewModel> OrdersUpdated { get; set; }

        /// <summary>
        /// A list of orders that have been removed from the plan
        /// </summary>
        public IList<string> OrdersRemoved { get; set; }

        /// <summary>
        /// A list of driver plans that have been removed from the plan
        /// </summary>
        public IList<string> UnassignedOrders { get; set; }
    }

    public class DriverPlanUpdatedViewModel
    {
        public string DriverId { get; set; }

        public bool? IsLocked { get; set; }

        public IList<string> OrderIds { get; set; }

        //public RouteStatisticsViewModel Statistics { get; set; }

        //public IList<RouteSegmentStatisticsViewModel> RouteSegmentStatistics { get; set; }
    }

    public class OptimizePlanRequestModel
    {
        public string PlanId { get; set; }

        public IList<string> DriverPlanIds { get; set; }
    }
}
