﻿using System;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using PAI.RP.Domain.Portable;
using Xamarin.Forms;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class RouteStopViewModel 
    {
        public int JobId { get; set; }

       
        public int SortOrder { get; set; }
        public LocationModelSlim Location { get; set; }
        public RouteStopStatus RouteStopStatus { get; set; }
        public long WindowStart { get; set; }
        public int? StopActionId { get; set; }

        public DateTime WindowStartDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowStart) : DateTime.UtcNow.Date.AddTicks(WindowStart);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);
                var dt = new DateTime(WindowStart);
                return dt;
            }
        }

        private string _startTimeDisplayInShortTimePattern;
        public string StartTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_startTimeDisplayInShortTimePattern) ? WindowStartDateTime.ToString("h:mm tt") : _startTimeDisplayInShortTimePattern; }
            set { _startTimeDisplayInShortTimePattern = value; }
        }

        public long WindowEnd { get; set; }

        public DateTime WindowEndDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowEnd) : DateTime.UtcNow.Date.AddTicks(WindowEnd);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);

                var dt = new DateTime(WindowEnd);
                return dt;
            }
        }

        private string _endTimeDisplayInShortTimePattern;
        public string EndTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_endTimeDisplayInShortTimePattern) ? WindowEndDateTime.ToString("h:mm tt") : _endTimeDisplayInShortTimePattern; }
            set { _endTimeDisplayInShortTimePattern = value; }
        }

        public TimeSpan ServiceTime { get; set; }

        /// <summary>
        /// Gets or sets the stop delay in ticks
        /// </summary>
        public virtual long? StopDelay { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public DateTime? EstimatedETA { get; set; }

        public DateTime? ActualETA { get; set; }
    }
}