﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderNoteViewModel : IUser
    {
        public string UserId { get; set; }

        public string UserName { get; set; }

        public string Note { get; set; }

        public DateTime TimeStamp { get; set; }
    }
}
