﻿using System;
using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderDetailsViewModel
    {
        public OrderDetailsViewModel()
        {
            Locations = new List<OrderLocationViewModel>();
        }

        public OrderDetailsViewModel(IEnumerable<OrderLocationViewModel> locations)
        {
            Locations = locations;
        }

        /// <summary>
        /// Gets or sets the order id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the Scheduled Date for the order
        /// </summary>
        public DateTime? ScheduledDate { get; set; }

        /// <summary>
        /// Gets or sets the Required Driver for the order
        /// </summary>
        public string RequiredDriverId { get; set; }

        /// <summary>
        /// Gets or sets order locations
        /// </summary>
        public IEnumerable<OrderLocationViewModel> Locations { get; set; }

        public string Number { get; set; }
    }
}
