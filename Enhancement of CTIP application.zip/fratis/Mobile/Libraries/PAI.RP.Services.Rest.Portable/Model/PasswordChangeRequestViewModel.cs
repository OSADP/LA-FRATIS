﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class PasswordChangeRequestViewModel
    {
        public string Username { get; set; }
        public string OldPassword { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}