﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class TagViewModel
    {
        public string Text { get; set; }
    }
}
