﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderHashViewModel
    {
        public string OrderId { get; set; }

        public string Hash { get; set; }
    }
}
