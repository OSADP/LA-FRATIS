﻿using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class PasswordChangeResultViewModel
    {
        public bool IsSuccessful { get; set; }
        public IList<string> Errors { get; set; }
    }
}
