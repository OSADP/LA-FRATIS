﻿using PAI.RP.Domain.Portable;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class GeneralPrefsViewModel
    {
        public string SubscriberId { get; set; }
        public int TrackingFrequency { get; set; }
        public MapNavigationPreference MapNavigationPreference { get; set; }
        public string Hash { get; set; }
    }
}