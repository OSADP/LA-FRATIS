﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using PAI.RP.Domain.Portable;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderViewModel : IEntity
    {
        public OrderDetailsViewModel OrderDetails { get; set; }

        public IList<OrderStatusTimeViewModel> OrderStatusTimes { get; set; }

        public string Id { get; set; }

        public string PlanId { get; set; }

        public string Number { get; set; }

        public string RequiredDriverId { get; set; }

        public OrderStatus Status { get; set; }

        public string Description { get; set; }

        public IList<OrderNoteViewModel> Notes { get; set; }

        public IList<OrderLocationViewModel> Locations { get; set; }

        public string CustomerId { get; set; }

        public virtual CustomerViewModel Customer { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? LastModifiedDate { get; set; }

        public DateTime? ScheduledDate { get; set; }

        public OrderType OrderType { get; set; }

        public string LoadUnit { get; set; }

        public double? Unit { get; set; }

        public string ReferenceNumber { get; set; }

        public List<TagViewModel> Tags { get; set; }

        public List<TagViewModel> ConstraintTags { get; set; }

        public Dictionary<string, object> CustomFields { get; set; }

        public string Priority { get; set; }

        public string Hash { get; set; }

        public bool IsValid { get; set; }

        public IList<RouteStopViewModel> RouteStops { get; set; }

        public string PickupNumber { get; set; }

        public string BookingNumber { get; set; }

        public string BillOfLading { get; set; }

        public string ConsigneeName { get; set; }

        public string ShipperName { get; set; }

        public string ContainerOwner { get; set; }
        public string Container { get; set; }

        public string ContainerNumber { get; set; }
        public string ChassisOwner { get; set; }

        public string Chassis { get; set; }

        public string ChassisNumber { get; set; }

        public string CustomField1 { get; set; }

        public string CustomField2 { get; set; }
        public string CustomField3 { get; set; }
        public string CustomField4 { get; set; }
        public string CustomField5 { get; set; }

    }
}
