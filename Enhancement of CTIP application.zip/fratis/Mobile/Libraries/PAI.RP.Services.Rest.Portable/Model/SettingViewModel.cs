﻿using PAI.Common.Core.Data;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class SettingViewModel : ISubscriber
    {
        public string SubscriberId { get; set; }

        public string SettingKey { get; set; }

        public object Value { get; set; }
    }
}
