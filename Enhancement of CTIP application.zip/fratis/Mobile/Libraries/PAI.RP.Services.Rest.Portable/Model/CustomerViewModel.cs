﻿using System.Collections.Generic;
using PAI.Common.Core.Data;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class CustomerViewModel : IEntity
    {
        public CustomerViewModel()
        {
            Location = new LocationViewModel();
        }

        public string Id { get; set; }

        public string Name { get; set; }

        public string CustomerNumber { get; set; }

        public string PhoneNumber { get; set; }

        public List<TagViewModel> Tags { get; set; }

        public string Email { get; set; }

        public LocationViewModel Location { get; set; }
    }
}
