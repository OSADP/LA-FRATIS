﻿using System.Collections.Generic;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class AuthenticationResponseViewModel
    {
        public string Token { get; set; }
        public string Username { get; set; }
        public UserViewModel User { get; set; }
        public IEnumerable<string> Claims { get; set; }
        public string DriverId { get; set; }
    }
}
