﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class GeolocationsViewModel : IEntity, ISubscriber, IUser
    {
        public string Id { get; set; }
        public string SubscriberId { get; set; }
        public string UserId { get; set; }

        public IList<GeolocationViewModel> Geolocations { get; set; }
    }

    public class GeolocationViewModel
    {
        public double Lat { get; set; }
        public double Lon { get; set; }
        public DateTime T { get; set; }

        //TODO - Remove after GPS testing
        public double? Accuracy { get; set; }
        public double? Speed { get; set; }
    }
}
