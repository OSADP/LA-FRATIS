﻿namespace PAI.RP.Services.Rest.Portable.Model
{
    public class AuthenticationRequestViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool IsMobileLogin { get; set; }
        public string ApplicationVersionName { get; set; }
    }
}