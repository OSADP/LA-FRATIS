﻿using System;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class PlanRequestViewModel
    {
        public DateTime? AfterUtcDate { get; set; }
    }
}
