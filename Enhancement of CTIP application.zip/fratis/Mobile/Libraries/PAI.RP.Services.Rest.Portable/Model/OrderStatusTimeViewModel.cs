﻿using System;
using PAI.RP.Domain.Portable;

namespace PAI.RP.Services.Rest.Portable.Model
{
    public class OrderStatusTimeViewModel
    {
        public string UserId { get; set; }
        public OrderStatus Status { get; set; }
        public DateTime TimeStamp { get; set; }
    }
}
