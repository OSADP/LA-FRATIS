﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Rest.Portable.Subscribers
{
    public interface IUserService : IEntityRestServiceBase<User>
    {
        Task<PasswordChangeResultViewModel> ChangePasswordAsync(PasswordChangeRequestViewModel requestViewModel, CancellationToken cancellationToken);
    }

    public class UserService : EntityRestServiceBase<User>, IUserService
    {
        public UserService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/users";
        }

        public async Task<PasswordChangeResultViewModel> ChangePasswordAsync(PasswordChangeRequestViewModel requestViewModel, CancellationToken cancellationToken)
        {
            return await PostAsync<PasswordChangeRequestViewModel, PasswordChangeResultViewModel>(requestViewModel, "/changepassword", cancellationToken);
        }
    }
}
