﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Rest.Portable.Subscribers
{
    public interface ICustomFieldPreferencesService : IEntityRestServiceBase<CustomFieldPreference>
    {
        Task<IEnumerable<CustomFieldSchemaViewModel>> GetAllAsync(CancellationToken cancellationToken);

        Task<IEnumerable<CustomFieldSchemaViewModel>> GetByEntityTypeAsync(string entityType,
            CancellationToken cancellationToken);
    }

    public class CustomFieldPreferencesService : EntityRestServiceBase<CustomFieldPreference>, ICustomFieldPreferencesService
    {
        public CustomFieldPreferencesService(IRestClientFactory restClientFactory, IRestClientProvider restClientProvider, IAuthenticationProvider authenticationProvider)
            : base(restClientFactory, restClientProvider, authenticationProvider)
        {
            BaseRequestUrl = "api/" + ApiVersion + "/schema";
        }

        public async Task<IEnumerable<CustomFieldSchemaViewModel>> GetAllAsync(CancellationToken cancellationToken)
        {
            return await GetAsync<string, List<CustomFieldSchemaViewModel>>(null, null, cancellationToken);
        }


        public async Task<IEnumerable<CustomFieldSchemaViewModel>> GetByEntityTypeAsync(string entityType, CancellationToken cancellationToken)
        {
            return await GetAsync<string, List<CustomFieldSchemaViewModel>>(null, "/" + entityType, cancellationToken);
        }
    }
}
