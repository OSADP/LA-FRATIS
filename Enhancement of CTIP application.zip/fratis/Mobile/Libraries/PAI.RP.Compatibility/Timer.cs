﻿using System;

namespace PAI.RP.Compatibility.Portable
{
    public class Timer
    {
        private readonly System.Threading.Timer _timer;
        private readonly Action _action;
        private readonly TimeSpan _period;
        private bool _started;

        /// <summary>
        /// Creates a new System.Threading.Timer with the specified Action to execute and wait period time between each re-execution.
        /// The timer does not start automatically.
        /// </summary>
        /// <param name="action"></param>
        /// <param name="period">Specify negative one (-1) milliseconds to disable re-execution period time.</param>
        public Timer(Action action, TimeSpan period)
        {
            _timer = new System.Threading.Timer(TimerCallback, null, TimeSpan.FromMilliseconds(-1), period);
            _action = action;
            _period = period;
            _started = false;
        }

        private void TimerCallback(object state)
        {
            if (_action != null)
            {
                _action();
            }
        }

        /// <summary>
        /// Immediately executes the specified action and re-executes the action every specified period.
        /// </summary>
        public void Start()
        {
            this.Start(TimeSpan.Zero);
        }

        /// <summary>
        /// Wait the time specified by dueTime, then execute the specified action and re-execute the action every specified period.
        /// </summary>
        public void Start(TimeSpan dueTime)
        {
            if (!_started)
            {
                _started = true;
                _timer.Change(dueTime, _period);
            }
        }

        /// <summary>
        /// Wait the time specified by dueTime, then execute the specified action once.
        /// </summary>
        public void StartOnce(TimeSpan dueTime)
        {
            if (!_started)
            {
                _started = true;
                _timer.Change(dueTime, TimeSpan.FromMilliseconds(-1));
            }
        }

        /// <summary>
        /// Stops the timer from executing any further actions until started again.
        /// </summary>
        public void Stop()
        {
            if (_started)
            {
                _started = false;
                _timer.Change(TimeSpan.FromMilliseconds(-1), TimeSpan.FromMilliseconds(-1));
            }
        }
    }
}
