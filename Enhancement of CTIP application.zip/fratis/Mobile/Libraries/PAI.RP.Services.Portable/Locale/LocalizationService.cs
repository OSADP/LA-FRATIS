﻿using System;
using System.Collections.Generic;

namespace PAI.RP.Services.Portable.Locale
{
    public interface IVendorType
    {
        VendorTypeOption Vendor { get; set; }
    }

    public class VendorType : IVendorType
    {
        public VendorTypeOption Vendor { get; set; }

        public VendorType()
        {
            Vendor = VendorTypeOption.Rp;
        }

        public VendorType(VendorTypeOption vendorTypeOption)
        {
            Vendor = vendorTypeOption;
        }
    }

    public enum VendorTypeOption
    {
        Rp = 1,
        SanAntonio = 2
    }

    public interface ILocalizationService
    {
        VendorTypeOption Vendor { get; }
        string Driver { get; }
        string Drivers { get; }
        string Order { get; }
        string Orders { get; }
        string Plan { get; }
        string Plans { get; }
        string ReferenceNumber { get; }
        string OrderDescription { get; }
        string OrderNumber { get; }
        string AppName { get; }
        string Priority { get; }
    }

    public class LocalizationService : ILocalizationService
    {
        private readonly IDictionary<string, string> _locale = new Dictionary<string, string>();

        private readonly VendorTypeOption _vendor;
        public VendorTypeOption Vendor { get { return _vendor; } }

        private const string DriverKey = "Driver";
        public string Driver { get { return _locale[DriverKey]; } }
        private const string DriversKey = "Drivers";
        public string Drivers { get { return _locale[DriversKey]; } }
        private const string OrderKey = "Order";
        public string Order { get { return _locale[OrderKey]; } }
        private const string OrdersKey = "Orders";
        public string Orders { get { return _locale[OrdersKey]; } }
        private const string PlanKey = "Plan";
        public string Plan { get { return _locale[PlanKey]; } }
        private const string PlansKey = "Plans";
        public string Plans { get { return _locale[PlansKey]; } }
        private const string ReferenceNumberKey = "ReferenceNumber";
        public string ReferenceNumber { get { return _locale[ReferenceNumberKey]; } }
        private const string OrderDescriptionKey = "DescriptionKey";
        public string OrderDescription { get { return _locale[OrderDescriptionKey]; } }
        private const string OrderNumberKey = "OrderNumberKey";
        public string OrderNumber { get { return _locale[OrderNumberKey]; } }
        private const string AppNameKey = "AppNameKey";
        public string AppName { get { return _locale[AppNameKey]; } }
        private const string PriorityKey = "PriorityKey";
        public string Priority { get { return _locale[PriorityKey]; } }
        
        public LocalizationService(IVendorType vendorType)
        {
            _vendor = vendorType.Vendor;
            switch (_vendor)
            {
                case VendorTypeOption.Rp:
                    _locale.Add(DriverKey, "Driver");
                    _locale.Add(DriversKey, "Drivers");
                    _locale.Add(OrderKey, "Order");
                    _locale.Add(OrdersKey, "Orders");
                    _locale.Add(PlanKey, "Plan");
                    _locale.Add(PlansKey, "Plans");
                    _locale.Add(ReferenceNumberKey, "Reference Number");
                    _locale.Add(OrderDescriptionKey, "Order Description");
                    _locale.Add(OrderNumberKey, "Order Number");
                    _locale.Add(AppNameKey, "Driver Application");
                    _locale.Add(PriorityKey, "Priority");
                    break;
                case VendorTypeOption.SanAntonio:
                    _locale.Add(DriverKey, "Inspector");
                    _locale.Add(DriversKey, "Inspectors");
                    _locale.Add(OrderKey, "Inspection");
                    _locale.Add(OrdersKey, "Inspections");
                    _locale.Add(PlanKey, "Plan");
                    _locale.Add(PlansKey, "Plans");
                    _locale.Add(ReferenceNumberKey, "Permit Number");
                    _locale.Add(OrderDescriptionKey, "Location Description");
                    _locale.Add(OrderNumberKey, "Inspection Number");
                    _locale.Add(AppNameKey, "Inspector App");
                    _locale.Add(PriorityKey, "Inspection Priority");
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
