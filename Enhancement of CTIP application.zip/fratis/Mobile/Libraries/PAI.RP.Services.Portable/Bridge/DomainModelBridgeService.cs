﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Bridge
{
    public interface IDomainModelBridgeService
    {
        Plan BridgePlan(PlanDriverPlanViewModel driverPlanViewModel);
        IEnumerable<Plan> BridgePlans(IEnumerable<PlanDriverPlanViewModel> planDriverPlanViewModels);
        PlanDriverPlanViewModel BridgePlan(Plan plans);
        Plan BridgePlan(PlanDriverPlanViewModel source, Plan target);
        IEnumerable<Order> BridgeOrders(IEnumerable<PlanOrderViewModel> orderViewModels);
        IEnumerable<Order> BridgeOrders(IEnumerable<OrderViewModel> orderViewModels, IEnumerable<Order> originalOrders);
        IEnumerable<PlanOrderViewModel> BridgeOrdersToPlanOrder(IEnumerable<Order> orders);
        IEnumerable<OrderViewModel> BridgeOrders(IEnumerable<Order> orders);
    }

    public class DomainModelBridgeService : IDomainModelBridgeService
    {
        private readonly IAuthenticationProvider _authenticationProvider;

        public DomainModelBridgeService(IAuthenticationProvider authenticationProvider)
        {
            _authenticationProvider = authenticationProvider;
        }

        public Plan BridgePlan(PlanDriverPlanViewModel driverPlanViewModel)
        {
            var orderViewModels = driverPlanViewModel.CommittedOrders;
            var orders = BridgeOrders(orderViewModels).ToList();
            var uncommittedOrderViewModels = driverPlanViewModel.Orders;
            var uncommittedOrders = BridgeOrders(uncommittedOrderViewModels).ToList();

            double totalTravelDistance = 0;
            if (driverPlanViewModel.Statistics != null)
            {
                totalTravelDistance = driverPlanViewModel.Statistics.d;
            }

            var plan = new Plan
            {
                //Mobile Plan Id is the DriverPlan's Unique Id!!!
                Id = driverPlanViewModel.Id,
                UniqueId = driverPlanViewModel.Id,
                SubscriberId = _authenticationProvider.SubscriberId,
                UserId = _authenticationProvider.UserId,
                DriverId = _authenticationProvider.DriverId,
                Name = driverPlanViewModel.PlanName,
                OrderIds = orders.Select(x => x.Id).ToList(),
                Orders = orders,
                UncommittedOrderIds = uncommittedOrders.Select(x => x.Id).ToList(),
                UncommittedOrders = uncommittedOrders,
                ExecutionDate = driverPlanViewModel.PlanExecutionDate,
                Status = driverPlanViewModel.Status,
                Hash = driverPlanViewModel.Hash,
                TotalTravelDistance = totalTravelDistance,
                PlanStatusTimes = Mapper.Map<IEnumerable<PlanDriverPlanStatusStampViewModel>, IEnumerable<PlanStatusTime>>(driverPlanViewModel.Statuses)
            };

            return plan;
        }

        public IEnumerable<Plan> BridgePlans(IEnumerable<PlanDriverPlanViewModel> planDriverPlanViewModels)
        {
            var plans = new List<Plan>();
            foreach (var planDriverPlanViewModel in planDriverPlanViewModels)
            {
                var plan = BridgePlan(planDriverPlanViewModel);
                plans.Add(plan);
            }

            return plans;
        }

        public PlanDriverPlanViewModel BridgePlan(Plan plan)
        {
            var result = new PlanDriverPlanViewModel
            {
                Id = plan.UniqueId,
                DriverId = plan.DriverId,
                Status = plan.Status,
                Statuses = Mapper.Map<IEnumerable<PlanStatusTime>, IEnumerable<PlanDriverPlanStatusStampViewModel>>(plan.PlanStatusTimes),
                Hash = plan.Hash,
                Statistics = new RouteStatisticsViewModel{d = plan.TotalTravelDistance},
                Orders = Mapper.Map<IEnumerable<Order>, IEnumerable<PlanOrderViewModel>>(plan.UncommittedOrders).ToList(),
                CommittedOrders = Mapper.Map<IEnumerable<Order>, IEnumerable<PlanOrderViewModel>>(plan.Orders).ToList(),
            };
            foreach (var driverPlanOrderViewModel in result.CommittedOrders)
            {
                var matchingOrder = plan.Orders.FirstOrDefault(x => x.Id == driverPlanOrderViewModel.Id);
                foreach (var matchingOrderLocation in matchingOrder.Locations)
                {
                    var orderLocationViewModel = Mapper.Map<OrderLocation, OrderLocationViewModel>(matchingOrderLocation);
                    orderLocationViewModel.ServiceTime = matchingOrderLocation.ServiceTime.TotalMinutes;
                    orderLocationViewModel.Address.Line1 = matchingOrderLocation.Line1;
                    orderLocationViewModel.Address.Line2 = matchingOrderLocation.Line2;
                    orderLocationViewModel.Address.Line3 = matchingOrderLocation.Line3;
                    orderLocationViewModel.Address.City = matchingOrderLocation.City;
                    orderLocationViewModel.Address.State = matchingOrderLocation.State;
                    orderLocationViewModel.Address.Zip = matchingOrderLocation.Zip;
                    driverPlanOrderViewModel.Locations.Add(orderLocationViewModel);
                }
            }

            return result;
        }

        public Plan BridgePlan(PlanDriverPlanViewModel source, Plan target)
        {
            target.PlanStatusTimes = Mapper.Map<IEnumerable<PlanDriverPlanStatusStampViewModel>, IEnumerable<PlanStatusTime>>(source.Statuses);
            
            return target;
        }

        public IEnumerable<Order> BridgeOrders(IEnumerable<PlanOrderViewModel> orderViewModels)
        {
            var orders = new List<Order>();

            var i = 1;
            foreach (var orderViewModel in orderViewModels)
            {
                if (orderViewModel.Locations == null || orderViewModel.Locations.Count == 0)
                {
                    throw new Exception("OrderViewModel must contain one location");
                }

                var customer = BridgeCustomer(orderViewModel.Customer);
                var locations = new List<OrderLocation>();
                             
                foreach (var orderLocationViewModel in orderViewModel.Locations)
                {
                    locations.Add(new OrderLocation
                    {
                        TimeWindows =
                            Mapper.Map<IEnumerable<TimeWindowViewModel>, IEnumerable<TimeWindow>>(
                                orderLocationViewModel.TimeWindows),
                        ServiceTime = TimeSpan.FromMinutes(orderLocationViewModel.ServiceTime),
                        CustomerId = customer != null ? customer.Id : null,
                        Customer = customer,
                        Line1 = orderLocationViewModel.Address.Line1,
                        Line2 = orderLocationViewModel.Address.Line2,
                        Line3 = orderLocationViewModel.Address.Line3,
                        City = orderLocationViewModel.Address.City,
                        State = orderLocationViewModel.Address.State,
                        Zip = orderLocationViewModel.Address.Zip,
                        Latitude = orderLocationViewModel.Latitude,
                        Longitude = orderLocationViewModel.Longitude
                    });
                }

                

                //TODO - Map the values first, then fill in the gaps
                var order = Mapper.Map<Order>(orderViewModel);
                order.SubscriberId = _authenticationProvider.SubscriberId;
                order.UserId = _authenticationProvider.UserId;
                order.DriverId = _authenticationProvider.DriverId;
                order.ScheduledDate = orderViewModel.ScheduledDate.HasValue ? orderViewModel.ScheduledDate.Value : DateTime.MinValue;
                order.CustomerId = customer != null ? customer.Id : null;
                order.Customer = customer;
                order.Locations = locations;
                order.CustomFields = orderViewModel.CustomFields ?? new Dictionary<string, object>();
                //TODO - Move the Number over to this!!
                
                //order.Number = orderViewModel.OrderDetails.Number,

                orders.Add(order);
                ++i;
            }

            return orders;
        }

        public IEnumerable<Order> BridgeOrders(IEnumerable<OrderViewModel> orderViewModels, IEnumerable<Order> originalOrders)
        {
            var orders = Mapper.Map<IEnumerable<OrderViewModel>, IEnumerable<Order>>(orderViewModels);
            foreach (var order in orders)
            {
                var matchingOrderViewModel = orderViewModels.FirstOrDefault(x => x.Id == order.Id);
                if (matchingOrderViewModel != null && matchingOrderViewModel.OrderDetails != null)
                {
                    var locations = new List<OrderLocation>();
                    var customer = BridgeCustomer(matchingOrderViewModel.Customer);
                    foreach (var orderLocationViewModel in matchingOrderViewModel.OrderDetails.Locations)
                    {
                        var location = Mapper.Map(orderLocationViewModel, new OrderLocation());
                        location.ServiceTime = TimeSpan.FromMinutes(orderLocationViewModel.ServiceTime);
                        location.CustomerId = customer.Id;
                        location.Customer = customer;
                        location.Line1 = orderLocationViewModel.Address.Line1;
                        location.Line2 = orderLocationViewModel.Address.Line2;
                        location.Line3 = orderLocationViewModel.Address.Line3;
                        location.City = orderLocationViewModel.Address.City;
                        location.State = orderLocationViewModel.Address.State;
                        location.Zip = orderLocationViewModel.Address.Zip;

                        locations.Add(location);
                    }
                    order.Locations = locations;
                    order.CustomerId = customer.Id;
                    order.Customer = customer;
                    //TODO - Move the Number over to this!!
                    //order.Number = matchingOrderViewModel.OrderDetails.Number;
                }
            }

            return orders;
        }

        public IEnumerable<PlanOrderViewModel> BridgeOrdersToPlanOrder(IEnumerable<Order> orders)
        {
            return Mapper.Map<IEnumerable<Order>, IEnumerable<PlanOrderViewModel>>(orders);
        }

        public IEnumerable<OrderViewModel> BridgeOrders(IEnumerable<Order> orders)
        {
            var orderViewModels = Mapper.Map(orders, new List<OrderViewModel>());
            foreach (var orderViewModel in orderViewModels)
            {
                var matchingOrder = orders.FirstOrDefault(x => x.Id == orderViewModel.Id);
                if (matchingOrder != null)
                {
                    var locations = new List<OrderLocationViewModel>();
                    foreach (var orderLocation in matchingOrder.Locations)
                    {
                        var location = Mapper.Map(orderLocation, new OrderLocationViewModel());
                        location.ServiceTime = orderLocation.ServiceTime.TotalMinutes;
                        location.Address.Line1 = orderLocation.Line1;
                        location.Address.Line2 = orderLocation.Line2;
                        location.Address.Line3 = orderLocation.Line3;
                        location.Address.City = orderLocation.City;
                        location.Address.State = orderLocation.State;
                        location.Address.Zip = orderLocation.Zip;

                        locations.Add(location);
                    }

                    var routeStops = new List<RouteStopViewModel>();
                    foreach (var routeStopOrder in matchingOrder.RouteStops)
                    {
                        var routeStop = Mapper.Map(routeStopOrder, new RouteStopViewModel());

                        routeStop.RouteStopStatus = routeStopOrder.RouteStopStatus;
                        routeStops.Add(routeStop);
                    }

                    orderViewModel.OrderDetails = new OrderDetailsViewModel
                    {
                        Locations = locations,
                        Number = matchingOrder.Number,
                        ScheduledDate = matchingOrder.ScheduledDate,
                    };
                    orderViewModel.RouteStops = routeStops;
                    //TODO - Maybe phase this out on the dashboard, since the orderDetails already has this?
                    orderViewModel.Locations = locations;
                }
            }

            return orderViewModels;
        }

        private Domain.Portable.StorageCompatible.Customer BridgeCustomer(CustomerViewModel customerViewModel)
        {
            if (customerViewModel == null)
            {
                return new Domain.Portable.StorageCompatible.Customer{Id = Guid.NewGuid().ToString()};
                //return null;
            }

            var customer = Mapper.Map<CustomerViewModel, Domain.Portable.StorageCompatible.Customer>(customerViewModel);
            customer.SubscriberId = _authenticationProvider.SubscriberId;
            customer.Line1 = customerViewModel.Location.Address.Line1;
            customer.Line2 = customerViewModel.Location.Address.Line2;
            customer.Line3 = customerViewModel.Location.Address.Line3;
            customer.City = customerViewModel.Location.Address.City;
            customer.State = customerViewModel.Location.Address.State;
            customer.Zip = customerViewModel.Location.Address.Zip;
            customer.Latitude = customerViewModel.Location.Latitude;
            customer.Longitude = customerViewModel.Location.Longitude;

            return customer;
        }

        private PlanStatus MapPlanStatus(DriverPlanStatus driverPlanStatus)
        {
            switch (driverPlanStatus)
            {
                case DriverPlanStatus.NotSent:
                case DriverPlanStatus.Received:
                    return PlanStatus.Received;

                case DriverPlanStatus.InProgress:
                    return PlanStatus.InProgress;

                case DriverPlanStatus.Completed:
                    return PlanStatus.Completed;
                default:
                    throw new ArgumentOutOfRangeException("driverPlanStatus");
            }
        }

        private DriverPlanStatus MapPlanStatus(PlanStatus planStatus)
        {
            switch (planStatus)
            {
                case PlanStatus.NotSent:
                case PlanStatus.Received:
                    return DriverPlanStatus.Received;

                case PlanStatus.InProgress:
                    return DriverPlanStatus.InProgress;

                case PlanStatus.Completed:
                    return DriverPlanStatus.Completed;
                default:
                    throw new ArgumentOutOfRangeException("planStatus");
            }
        }
    }
}
