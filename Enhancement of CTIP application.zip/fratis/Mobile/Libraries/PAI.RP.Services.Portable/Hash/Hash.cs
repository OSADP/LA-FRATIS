﻿namespace PAI.RP.Services.Portable.Hash
{
    public static class Hash
    {
        public const string DirtyHashMarker = "dirtyhash";
    }
}
