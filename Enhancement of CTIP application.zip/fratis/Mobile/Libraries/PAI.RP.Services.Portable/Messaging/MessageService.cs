﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Portable.Geography;
using PAI.RP.Services.Portable.Subscribers;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Messaging
{
    public interface IMessageService
    {
        IMessageResponseResolver MessageResponseResolver { get; }

        Task SynchronizeAsync(CancellationToken cancellationToken);
    }

    public class MessageService : IMessageService
    {
        private readonly Rest.Portable.Messaging.IMessageService _restMessageService;
        private readonly IMessageRequestBuilder _messageRequestBuilder;
        private readonly IUserSettingsService _userSettingsService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IGeolocationService _geolocationService;
        public IMessageResponseResolver MessageResponseResolver { get; private set; }

        public MessageService(Rest.Portable.Messaging.IMessageService restMessageService,
            IMessageRequestBuilder messageRequestBuilder, IUserSettingsService userSettingsService,
            IAuthenticationProvider authenticationProvider,
            IMessageResponseResolver messageResponseResolver, IGeolocationService geolocationService)
        {
            _restMessageService = restMessageService;
            _messageRequestBuilder = messageRequestBuilder;
            _userSettingsService = userSettingsService;
            _authenticationProvider = authenticationProvider;
            _geolocationService = geolocationService;
            MessageResponseResolver = messageResponseResolver;
        }

        public async Task SynchronizeAsync(CancellationToken cancellationToken)
        {
            var lastSynchronizationDate = DateTime.Now;
            var requestMessageViewModel = await _messageRequestBuilder.BuildAsync(cancellationToken);
            ResponseMessageViewModel responseMessageViewModel = null;

            responseMessageViewModel = 
                await _restMessageService.PostAsync<RequestMessageViewModel, ResponseMessageViewModel>(requestMessageViewModel, cancellationToken);

            if (responseMessageViewModel != null)
            {
                await _userSettingsService.SaveLocallyAsync(
                    new UserSettings
                    {
                        SubscriberId = _authenticationProvider.SubscriberId,
                        UserId = _authenticationProvider.UserId,
                        LastSynchronizationDate = lastSynchronizationDate
                    }, cancellationToken);
                //Delete the recorded geolocations after submitting them
                var geolocationIds =
                    (await
                        _geolocationService.GetLocallyAsync(x => x.TimeStamp <= lastSynchronizationDate, null,
                            cancellationToken)).Select(x => x.Id).ToList();
                if (geolocationIds.Count > 0)
                {
                    await _geolocationService.DeleteLocallyAsync(geolocationIds, cancellationToken);
                }

            }

            await MessageResponseResolver.ResolveAsync(responseMessageViewModel, cancellationToken);
        }
    }
}
