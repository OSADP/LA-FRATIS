﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Newtonsoft.Json;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Portable.Bridge;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Setting;
using PAI.RP.Services.Portable.Subscribers;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Messaging
{
    public interface IMessageResponseResolver
    {
        event EventHandler<MessageResponseEventArgs<Plan>> OnSendPlansMessageResponseReceived;
        event EventHandler<MessageResponseEventArgs<Order>> OnSendOrdersMessageResponseReceived;
        event EventHandler<MessageResponseEventArgs<string>> OnFreeFormMessageResponseReceived;
		event EventHandler<MessageResponseEventArgs<string>> OnDataRefreshMessageReceived;

        Task ResolveAsync(ResponseMessageViewModel messageResponses, CancellationToken cancellationToken);
    }

    public class MessageResponseResolver : IMessageResponseResolver
    {
        private readonly IDomainModelBridgeService _domainModelBridgeService;
        private readonly IPlanService _planService;
        private readonly IOrderService _orderService;
        private readonly ICustomFieldPreferencesService _customFieldPreferencesService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IGeneralPreferenceService _generalPreferenceService;
        private readonly ILocalizationService _localizationService;

        public event EventHandler<MessageResponseEventArgs<Plan>> OnSendPlansMessageResponseReceived;
        public event EventHandler<MessageResponseEventArgs<Order>> OnSendOrdersMessageResponseReceived;
        public event EventHandler<MessageResponseEventArgs<string>> OnFreeFormMessageResponseReceived;
		public event EventHandler<MessageResponseEventArgs<string>> OnDataRefreshMessageReceived;

        public MessageResponseResolver(IDomainModelBridgeService domainModelBridgeService, 
            IPlanService planService,
            IOrderService orderService,
            ICustomFieldPreferencesService customFieldPreferencesService, 
            IAuthenticationProvider authenticationProvider,
            IGeneralPreferenceService generalPreferenceService,
            ILocalizationService localizationService)
        {
            _domainModelBridgeService = domainModelBridgeService;
            _planService = planService;
            _orderService = orderService;
            _customFieldPreferencesService = customFieldPreferencesService;
            _authenticationProvider = authenticationProvider;
            _generalPreferenceService = generalPreferenceService;
            _localizationService = localizationService;
        }

        public async Task ResolveAsync(ResponseMessageViewModel responseMessageViewModel, CancellationToken cancellationToken)
        {
            if (responseMessageViewModel == null)
            {
                //Could also publish a failure message in this case to the subscriber
                return;
            }

            var subscriberId = _authenticationProvider.SubscriberId;

            foreach (var messageResponse in responseMessageViewModel.Messages)
            {
                switch (messageResponse.MessageType)
                {
                    case MessageType.SendDriverPlan:
                        var planDriverPlanViewModel = JsonConvert.DeserializeObject<PlanDriverPlanViewModel>(messageResponse.MessageData);
                        if (planDriverPlanViewModel != null)
                        {
                            var plan = _domainModelBridgeService.BridgePlan(planDriverPlanViewModel);
                            var plans = new List<Plan> {plan};
                            var oldPlan = _planService.GetOldPlan(plan.Id);
                            var oldPlanOrderIds = _planService.GetOldPlanOrderIds(plan.Id);
                            string message = null;
                            if (oldPlan != null)
                            {
                                message = ResolvePlanMessage(plan, oldPlan, oldPlanOrderIds);
                            }
                            await _planService.DeletePlansWithOrdersLocallyAsync(plans, cancellationToken);
                            await _planService.SavePlansWithOrdersLocallyAsync(plans, cancellationToken);
                            foreach (var p in plans)
                            {
                                _planService.SaveOldPlan(p);
                            }
                            if (OnFreeFormMessageResponseReceived != null && !string.IsNullOrWhiteSpace(message))
                            {
                                OnFreeFormMessageResponseReceived(this, new MessageResponseEventArgs<string>(new String[] { message }));
                            }
                            if (OnSendPlansMessageResponseReceived != null)
                            {
                                OnSendPlansMessageResponseReceived(this, new MessageResponseEventArgs<Plan>(plans));
                            }
							if (OnDataRefreshMessageReceived != null)
                            {
                                OnDataRefreshMessageReceived(this, new MessageResponseEventArgs<string>(null));
                            }
                        }
                        break;
                    //case MessageType.FreeForm:
                    //    var message = JsonConvert.DeserializeObject<string>(messageResponse.MessageData);
                    //    if (OnFreeFormMessageResponseReceived != null)
                    //    {
                    //        OnFreeFormMessageResponseReceived(this, new MessageResponseEventArgs<string>(new String[]{message}));
                    //    }
                    //    break;
                    //case MessageType.SendPlans:
                    //    var planDriverPlanViewModels = JsonConvert.DeserializeObject<IEnumerable<PlanDriverPlanViewModel>>(messageResponse.MessageData);
                    //    var plans = new List<Plan>();
                    //    foreach (var planDriverPlanViewModel in planDriverPlanViewModels)
                    //    {
                    //        var plan = await _planService.GetPlanLocallyAsync(planDriverPlanViewModel.UniqueId, cancellationToken);
                    //        if (plan != null)
                    //        {
                    //            plan = _domainModelBridgeService.BridgePlan(planDriverPlanViewModel, plan);
                    //            plan.Hash = string.Empty;
                    //            plan = await _planService.SavePlanAsync(plan, false, cancellationToken);

                    //            plans.Add(plan);
                    //        }
                    //    }
                    //    if (OnSendPlansMessageResponseReceived != null)
                    //    {
                    //        OnSendPlansMessageResponseReceived(this, new MessageResponseEventArgs<Plan>(plans));
                    //    }
                    //    break;
                    //case MessageType.SendOrders:
                    //    var orderViewModels = JsonConvert.DeserializeObject<IEnumerable<OrderViewModel>>(messageResponse.MessageData);
                    //    //TODO - See if we can use a mass GetByOrderIds somehow
                    //    var originalOrders = new List<Order>();
                    //    foreach (var orderViewModel in orderViewModels)
                    //    {
                    //        var localOrder = await _orderService.GetOrderLocallyAsync(orderViewModel.Id, cancellationToken);
                    //        if (localOrder != null)
                    //        {
                    //            originalOrders.Add(localOrder);
                    //        }
                    //    }
                    //    var orders = _domainModelBridgeService.BridgeOrders(orderViewModels, originalOrders);
                    //    foreach (var order in orders)
                    //    {
                    //        await _orderService.SaveOrderAsync(order, false, cancellationToken);
                    //    }

                    //    if (OnSendOrdersMessageResponseReceived != null)
                    //    {
                    //        OnSendOrdersMessageResponseReceived(this, new MessageResponseEventArgs<Order>(orders));
                    //    }
                    //    break;
                    case MessageType.SendCustomFieldPreferences:
                        var customFieldPreferencesViewModel = JsonConvert.DeserializeObject<IEnumerable<CustomFieldSchemaViewModel>>(messageResponse.MessageData);
                        var customFieldPreferences =
                            Mapper.Map<IEnumerable<CustomFieldSchemaViewModel>, IEnumerable<CustomFieldPreference>>(customFieldPreferencesViewModel);
                        foreach (var customFieldPreference in customFieldPreferences)
                        {
                            customFieldPreference.SubscriberId = subscriberId;
                            await _customFieldPreferencesService.SaveLocallyAsync(customFieldPreference, cancellationToken);
                        }
                        break;
                    case MessageType.SendGeneralPreferences:
                        var generalPreferencesViewModel = JsonConvert.DeserializeObject<GeneralPrefsViewModel>(messageResponse.MessageData);
                        await _generalPreferenceService
                            .SaveAsync(subscriberId, Mapper.Map<GeneralPrefsViewModel, GeneralPreference>(generalPreferencesViewModel), cancellationToken);
                        break;
                }
            }
        }

        private string ResolvePlanMessage(Plan newPlan, Plan oldPlan, List<string> oldPlanOrderIds)
        {
            var ordersRemovedCount = 0;
            var message = string.Empty;
            var ordersRemoved = new List<string>();
            var ordersAdded = new List<string>();
            foreach (var oldOrder in oldPlan.Orders)
            {
                var matchingNewOrder =
                    newPlan.Orders.FirstOrDefault(x => x.Id == oldOrder.Id);
                if (matchingNewOrder == null)
                {
                    ++ordersRemovedCount;
                    if (ordersRemovedCount == 1)
                    {
                        message += "The following " + _localizationService.Orders + " have been removed.\r\n";
                    }
                    //Order has been removed
                    ordersRemoved.Add(oldOrder.Id);
                    message += _localizationService.Order + " #" + oldOrder.Number + ".\r\n";
                }
            }

            var ordersAddedCount = 0;
            foreach (var newOrder in newPlan.Orders)
            {
                var matchingOldOrder =
                    oldPlan.Orders.FirstOrDefault(x => x.Id == newOrder.Id);
                if (matchingOldOrder == null)
                {
                    ++ordersAddedCount;
                    if (ordersAddedCount == 1)
                    {
                        if (ordersRemovedCount >= 1)
                        {
                            message += "\r\n";
                        }
                        message += "The following " + _localizationService.Orders + " have been added.\r\n";
                    }
                    //Order has been added
                    ordersAdded.Add(newOrder.Id);
                    message += _localizationService.Order + " #" + newOrder.Number + ".\r\n";
                }
            }

            var newOrderIds = newPlan.Orders.Select(x => x.Id).ToList();
            var oldOrderIds = oldPlanOrderIds;
            var sequenceChanged = false;
            for (var i = 0; i < newOrderIds.Count; i++)
            {
                var oldOrderIdIndex = oldOrderIds.IndexOf(newOrderIds[i]);
                if (oldOrderIdIndex != i && !ordersAdded.Contains(newOrderIds[i]))
                {
                    if (!sequenceChanged)
                    {
                        message += "\r\nThe " + _localizationService.OrderNumber + " sequence has changed.";
                        sequenceChanged = true;
                    }

                }
            }

            return message;
        }
    }

    public class MessageResponseEventArgs<TMessageData> : EventArgs where TMessageData : class
    {
        public IEnumerable<TMessageData> MessageData { get; set; }

        public MessageResponseEventArgs(IEnumerable<TMessageData> messageData)
        {
            MessageData = messageData;
        }
    }
}
