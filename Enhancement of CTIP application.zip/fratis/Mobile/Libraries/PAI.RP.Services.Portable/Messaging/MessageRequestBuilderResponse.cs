﻿using System.Collections.Generic;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Messaging
{
    public class MessageRequestBuilderResponse
    {
        public RequestMessageViewModel RequestMessageViewModel { get; set; }
        public IEnumerable<Geolocation> GeolocationsToSend { get; set; }
    }
}
