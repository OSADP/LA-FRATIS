﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Newtonsoft.Json;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Portable.Bridge;
using PAI.RP.Services.Portable.Geography;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Setting;
using PAI.RP.Services.Portable.Subscribers;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Messaging
{
    public interface IMessageRequestBuilder
    {
        Task<RequestMessageViewModel> BuildAsync(CancellationToken cancellationToken);
    }

    public class MessageRequestBuilder : IMessageRequestBuilder
    {
        private readonly IGeolocationService _geolocationService;
        private readonly IUserSettingsService _userSettingsService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IOrderService _orderService;
        private readonly IDomainModelBridgeService _domainModelBridgeService;
        private readonly IPlanService _planService;
        private readonly ICustomFieldPreferencesService _customFieldPreferencesService;
        private readonly IGeneralPreferenceService _generalPreferenceService;

        public MessageRequestBuilder(IGeolocationService geolocationService, IUserSettingsService userSettingsService,
            IAuthenticationProvider authenticationProvider, IOrderService orderService,
            IDomainModelBridgeService domainModelBridgeService, IPlanService planService,
            ICustomFieldPreferencesService customFieldPreferencesService, IGeneralPreferenceService generalPreferenceService)
        {
            _geolocationService = geolocationService;
            _userSettingsService = userSettingsService;
            _authenticationProvider = authenticationProvider;
            _orderService = orderService;
            _domainModelBridgeService = domainModelBridgeService;
            _planService = planService;
            _customFieldPreferencesService = customFieldPreferencesService;
            _generalPreferenceService = generalPreferenceService;
        }

        public async Task<RequestMessageViewModel> BuildAsync(CancellationToken cancellationToken)
        {
            var messages = new List<MessageViewModel>();
            //var utcNowDate = DateTime.UtcNow.Date;
            var nowDate = DateTime.Now.Date;
            var requestMessageViewModel = new RequestMessageViewModel{Messages = messages};
            var userSettings = 
                await _userSettingsService.GetLocalUserSettings(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, cancellationToken);
            var localGeolocations = 
                await _geolocationService.GetLocallyByUserAfterLastSynchronizationDateAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, cancellationToken);
            //var localPlans = (await _planService.GetPlansForUserLocallyAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, utcNowDate, cancellationToken)).ToList();
            var localPlans = (await _planService.GetPlansForUserLocallyAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, nowDate, cancellationToken)).ToList();
            //var localOrders =
            //    (await _orderService.GetOrdersOnOrBeyondPlanExecutionDateLocallyAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, utcNowDate, cancellationToken)).ToList();
            var customFieldPrefs = await _customFieldPreferencesService.GetAllAsync(_authenticationProvider.SubscriberId, cancellationToken);
            var generalPreference = await _generalPreferenceService.GetAsync(_authenticationProvider.SubscriberId, cancellationToken);

            var geolocationsViewModel = new GeolocationsViewModel
            {
                SubscriberId = _authenticationProvider.SubscriberId,
                UserId = _authenticationProvider.UserId,
                Geolocations =
                    localGeolocations.Select(
                        localGeolocation =>
                            new GeolocationViewModel
                            {
                                Lat = localGeolocation.Latitude,
                                Lon = localGeolocation.Longitude,
                                T = localGeolocation.TimeStamp,
                                Accuracy = localGeolocation.Accuracy,
                                Speed = localGeolocation.Speed
                            }).ToList()
            };
            //var planDriverPlanViewModels = localPlans.Where(x => x.Hash == Hash.Hash.DirtyHashMarker).Select(x => _domainModelBridgeService.BridgePlan(x)).ToList();
            //var orderHashViewModels = localOrders.Where(x => x.Hash != Hash.Hash.DirtyHashMarker).Select(x => new OrderHashViewModel
            //{
            //    OrderId = x.Id,
            //    Hash = x.Hash
            //}).ToList();
            //var orderViewModels = _domainModelBridgeService.BridgeOrders(localOrders.Where(x => x.Hash == Hash.Hash.DirtyHashMarker)).ToList();
            var customFieldPrefsHashViewModel = Mapper.Map<IEnumerable<CustomFieldPreference>, IEnumerable<CustomFieldPrefHashViewModel>>(customFieldPrefs);
            var dirtyPlanDriverPlanViewModels = localPlans.Where(x => x.Hash == Hash.Hash.DirtyHashMarker || x.Orders.Any(y => y.Hash == Hash.Hash.DirtyHashMarker)).Select(x => _domainModelBridgeService.BridgePlan(x)).ToList();
            var cleanPlanDriverPlanViewModels = localPlans.Where(x => dirtyPlanDriverPlanViewModels.All(y => y.Id != x.Id)).Select(x => _domainModelBridgeService.BridgePlan(x)).ToList();

            messages.Add(new MessageViewModel
            {
                MessageType = MessageType.SendGeolocations,
                MessageData = JsonConvert.SerializeObject(geolocationsViewModel),
                LatestTimeStamp = DateTime.Now
            });

            //if (planDriverPlanViewModels.Count > 0)
            //{
            //    messages.Add(new MessageViewModel
            //    {
            //        MessageType = MessageType.SendPlans,
            //        MessageData = JsonConvert.SerializeObject(planDriverPlanViewModels)
            //    });
            //}
            //if (orderHashViewModels.Count > 0)
            //{
            //    messages.Add(new MessageViewModel
            //    {
            //        MessageType = MessageType.SendOrdersHashCheck,
            //        MessageData = JsonConvert.SerializeObject(orderHashViewModels)
            //    });
            //}
            //if (orderViewModels.Count > 0)
            //{
            //    messages.Add(new MessageViewModel
            //    {
            //        MessageType = MessageType.SendOrders,
            //        MessageData = JsonConvert.SerializeObject(orderViewModels)
            //    });
            //}
            messages.AddRange(dirtyPlanDriverPlanViewModels.Select(dirtyPlanDriverPlanViewModel => new MessageViewModel
            {
                MessageType = MessageType.SendDriverPlan,
                MessageData = JsonConvert.SerializeObject(dirtyPlanDriverPlanViewModel),
                LatestTimeStamp = DateTime.Now
            }));
            foreach (var cleanPlanDriverPlanViewModel in cleanPlanDriverPlanViewModels)
            {
                messages.Add(new MessageViewModel
                {
                    MessageType = MessageType.SendDriverPlanHashCheck,
                    MessageData = JsonConvert.SerializeObject(cleanPlanDriverPlanViewModel),
                    LatestTimeStamp = DateTime.Now
                 });
            }
            if (customFieldPrefsHashViewModel.Any())
            {
                messages.Add(new MessageViewModel
                {
                    MessageType = MessageType.SendCustomFieldPreferencesHash,
                    MessageData = JsonConvert.SerializeObject(customFieldPrefsHashViewModel),
                    LatestTimeStamp = DateTime.Now
                });
            }
            if (generalPreference != null)
            {
                messages.Add(new MessageViewModel
                {
                    MessageType = MessageType.SendGeneralPreferencesHash,
                    MessageData = JsonConvert.SerializeObject(Mapper.Map<GeneralPreference, GeneralPrefsHashViewModel>(generalPreference)),
                    LatestTimeStamp = DateTime.Now
                });
            }

            requestMessageViewModel.LastRequestDate = userSettings == null ? null : userSettings.LastSynchronizationDate;

            return requestMessageViewModel;
        }
    }
}
