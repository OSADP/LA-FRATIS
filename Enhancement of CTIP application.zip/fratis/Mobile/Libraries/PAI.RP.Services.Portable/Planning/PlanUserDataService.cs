﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Cache.Portable;
using PAI.RP.Services.Persistence.Portable;

namespace PAI.RP.Services.Portable.Planning
{
    public interface IPlanUserDataService : IUserDatedDataService<Plan>
    {
        
    }

    public class PlanUserDataService : UserDatedDataService<Plan>, IPlanUserDataService
    {
        public PlanUserDataService(IUserDataServiceBaseAsync<Plan> userDataServiceBase, ICacheService<Plan> cacheService,
            Subscribers.IUserSettingsService userSettingsService)
            : base(userDataServiceBase, cacheService, userSettingsService)
        {
        }
    }
}
