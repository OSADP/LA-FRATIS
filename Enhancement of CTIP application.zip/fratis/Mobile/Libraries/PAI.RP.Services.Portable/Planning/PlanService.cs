﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Portable.Bridge;
using PAI.RP.Services.Portable.Customer;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Threading;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Planning
{
    public interface IPlanService
    {
        bool APlanIsTracking(IEnumerable<Plan> plans);
        bool PlanIsTracking(Plan plan);
        bool PlanCanBeStarted(Plan plan);
        Task<bool> PlanContainsIncompletedOrdersAsync(string planId, CancellationToken cancellationToken);
        Plan GetOldPlan(string oldPlanId);
        List<string> GetOldPlanOrderIds(string oldPlanId);
        Plan SaveOldPlan(Plan oldPlan);

        Task<Plan> GetPlanLocallyAsync(string planId, CancellationToken cancellationToken);
        Task<Plan> StartPlanAsync(Plan plan, CancellationToken cancellationToken);
        Task<Plan> ClosePlanAsync(Plan plan, CancellationToken cancellationToken);
        Task<Plan> SavePlanAsync(Plan plan, bool applyDirtyHashMarker, CancellationToken cancellationToken);
        Task<IEnumerable<Plan>> SavePlansWithOrdersLocallyAsync(IEnumerable<Plan> plans,
            CancellationToken cancellationToken);
        Task DeletePlansWithOrdersLocallyAsync(IEnumerable<Plan> plans, CancellationToken token);
        Task<IEnumerable<Order>> GetAllOrdersForThePlanAsync(string planId, CancellationToken cancellationToken);
        Task<IEnumerable<Plan>> GetPlansForUserLocallyAsync(string subscriberId, string userId, DateTime? afterUtcDate, CancellationToken cancellationToken);
        Task<IEnumerable<Plan>> GetPlansForDriverAsync(DateTime? afterUtcDate, bool localLookup, CancellationToken cancellationToken);
    }

    public class PlanService : IPlanService
    {
        private readonly IPlanUserDataService _planUserDataService;
        private readonly Rest.Portable.Planning.IPlanService _restPlanService;
        private readonly IUserDatedDataService<Order> _orderUserDataService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IDomainModelBridgeService _domainModelBridgeService;
        private readonly ICustomerService _customerService;
		private readonly ILockManager _lockManager;

        private readonly Dictionary<string, Plan> _oldPlanDict = new Dictionary<string, Plan>();
        //TODO - This is needed because of a wierd bug where the plan.Orders list on the first dictionary sometimes retrieves the old plan orders out of order.
        //TODO - Fix this at some point!
        private readonly Dictionary<string, List<string>> _oldPlanOrderIds = new Dictionary<string, List<string>>(); 

        public PlanService(IPlanUserDataService planUserDataService,
            Rest.Portable.Planning.IPlanService restPlanService,
            IUserDatedDataService<Order> orderUserDataService, IAuthenticationProvider authenticationProvider,
            IDomainModelBridgeService domainModelBridgeService, ICustomerService customerService,
			ILockManager lockManager)
        {
            _planUserDataService = planUserDataService;
            _restPlanService = restPlanService;
            _orderUserDataService = orderUserDataService;
            _authenticationProvider = authenticationProvider;
            _domainModelBridgeService = domainModelBridgeService;
            _customerService = customerService;
			_lockManager = lockManager;
        }

        public bool APlanIsTracking(IEnumerable<Plan> plans)
        {
            return plans.Any(PlanIsTracking);
        }

        public bool PlanIsTracking(Plan plan)
        {
            return plan.ExecutionDate.Date == DateTime.Now.Date && plan.Status == PlanStatus.InProgress;
        }

        public bool PlanCanBeStarted(Plan plan)
        {
            return plan.ExecutionDate.Date == DateTime.Now.Date && plan.Status == PlanStatus.Received;
        }

        public async Task<bool> PlanContainsIncompletedOrdersAsync(string planId, CancellationToken cancellationToken)
        {
            var orders = await GetAllOrdersForThePlanAsync(planId, cancellationToken);
            return orders.Any(x => x.Status != OrderStatus.Completed && x.Status != OrderStatus.Deferred);
        }

        public async Task<Plan> GetPlanLocallyAsync(string planId, CancellationToken cancellationToken)
        {
            var result = await _planUserDataService.GetByIdAsync(planId, cancellationToken);
            if (result == null)
            {
                return null;
            }

            //Assign the orders to the plan retrieved
            var response = await GetAllOrdersForThePlanLocallyAsync(result.Id, cancellationToken);
            result.Orders = response.Orders;
            result.UncommittedOrders = response.UncommittedOrders;

            return result;
        }

        public async Task<Plan> StartPlanAsync(Plan plan, CancellationToken cancellationToken)
        {
            plan.Status = PlanStatus.InProgress;
            var planStatusTimes = plan.PlanStatusTimes.ToList();
            planStatusTimes.Add(new PlanStatusTime
            {
                UserId = _authenticationProvider.UserId,
                Status = PlanStatus.InProgress,
                TimeStamp = DateTime.Now
            });
            plan.PlanStatusTimes = planStatusTimes;

            var result = await SavePlanAsync(plan, cancellationToken);

            return result;
        }

        public async Task<Plan> ClosePlanAsync(Plan plan, CancellationToken cancellationToken)
        {
            plan.Status = PlanStatus.Completed;
            var planStatusTimes = plan.PlanStatusTimes.ToList();
            planStatusTimes.Add(new PlanStatusTime
            {
                UserId = _authenticationProvider.UserId,
                Status = PlanStatus.Completed,
                TimeStamp = DateTime.Now
            });
            plan.PlanStatusTimes = planStatusTimes;

            var result = await SavePlanAsync(plan, cancellationToken);

            return result;
        }

        private async Task<Plan> SavePlanAsync(Plan plan, CancellationToken cancellationToken)
        {
            return await SavePlanAsync(plan, true, cancellationToken);
        }

        public async Task<Plan> SavePlanAsync(Plan plan, bool applyDirtyHashMarker, CancellationToken cancellationToken)
        {
            if (applyDirtyHashMarker)
            {
                plan.Hash = Hash.Hash.DirtyHashMarker;
            }
            
			Plan result = plan;
            try
            {
                _lockManager.GetLock(SlimLockManager.MessageSyncLock);
                result = await _planUserDataService.SaveAsync(plan, cancellationToken);
            }
            catch (Exception exception)
            {
                //Swallow the error
            }
            try
            {
                _lockManager.ReleaseLock(SlimLockManager.MessageSyncLock);
            }
            catch (Exception exception)
            {
                //No lock obtained to release
            }

            return result;
        }

        public Plan GetOldPlan(string oldPlanId)
        {
            Plan oldPlan;
            if (_oldPlanDict.TryGetValue(oldPlanId, out oldPlan))
            {
                return oldPlan;
            }
            return null;
        }

        //TODO - This is needed because of a wierd bug where the plan.Orders list on the first dictionary sometimes retrieves the old plan orders out of order.
        //TODO - Fix this at some point!
        public List<string> GetOldPlanOrderIds(string oldPlanId)
        {
            List<string> oldPlanOrderIds;
            if (_oldPlanOrderIds.TryGetValue(oldPlanId, out oldPlanOrderIds))
            {
                return oldPlanOrderIds;
            }
            return new List<string>();
        }

        public Plan SaveOldPlan(Plan oldPlan)
        {
            if (_oldPlanDict.ContainsKey(oldPlan.Id))
            {
                _oldPlanDict[oldPlan.Id] = oldPlan;
                _oldPlanOrderIds[oldPlan.Id] = oldPlan.Orders.Select(x => x.Id).ToList();
            }
            else
            {
                _oldPlanDict.Add(oldPlan.Id, oldPlan);
                _oldPlanOrderIds.Add(oldPlan.Id, oldPlan.Orders.Select(x => x.Id).ToList());
            }

            return oldPlan;
        }

        private async Task<OrdersResponse> GetAllOrdersForThePlanLocallyAsync(string planId, CancellationToken cancellationToken)
        {
            var plan = await _planUserDataService.GetByIdAsync(planId, cancellationToken);
            var allOrders = await _orderUserDataService.GetAsync(x => x.PlanId == planId, null, cancellationToken);
            var orders = allOrders.Where(x => plan.OrderIds.Contains(x.Id));
            var uncommittedOrders = allOrders.Where(x => plan.UncommittedOrderIds.Contains(x.Id));

            //Assign customer to the orders
            foreach (var order in orders)
            {
                order.Customer = await _customerService.GetByIdAsync(order.CustomerId, cancellationToken);
            }
            foreach (var uncommittedOrder in uncommittedOrders)
            {
                uncommittedOrder.Customer = await _customerService.GetByIdAsync(uncommittedOrder.CustomerId, cancellationToken);
            }

            return new OrdersResponse{Orders = orders, UncommittedOrders = uncommittedOrders};
        }

        public async Task<IEnumerable<Order>> GetAllOrdersForThePlanAsync(string planId, CancellationToken cancellationToken)
        {
            var orderResponse = await GetAllOrdersForThePlanLocallyAsync(planId, cancellationToken);
            var orders = orderResponse.Orders;
            if (!orders.Any())
            {
                var plans = await GetPlansForDriverAsync(null, true, cancellationToken);
                var plan = plans.FirstOrDefault(x => x.Id == planId);

                orders = plan != null ? plan.Orders : new List<Order>();
            }

            return orders;
        }

        private async Task<IEnumerable<PlanDriverPlanViewModel>> GetPlansForDriverRestCallAsync(string driverId, DateTime? afterUtcDate, CancellationToken cancellationToken)
        {
            return await _restPlanService.GetByDriverAsync(driverId, afterUtcDate, cancellationToken);
        }

        public async Task<IEnumerable<Plan>> GetPlansForUserLocallyAsync(string subscriberId, string userId, DateTime? afterUtcDate, CancellationToken cancellationToken)
        {
            List<Expression<Func<Plan, bool>>> predicates = null;
            if (afterUtcDate.HasValue)
            {
                predicates = new List<Expression<Func<Plan, bool>>> { x => x.ExecutionDate >= afterUtcDate.Value || x.Status == PlanStatus.InProgress };
            }
            var plans = await _planUserDataService.GetByUserAsync(subscriberId, userId, predicates, null, cancellationToken);
            //Assign the orders to the appropriate plans after retrieving them from the database
            foreach (var plan in plans)
            {
                var orderResponse = await GetAllOrdersForThePlanLocallyAsync(plan.Id, cancellationToken);
                plan.Orders = orderResponse.Orders;
                plan.UncommittedOrders = orderResponse.UncommittedOrders;
            }

            return plans;
        }

        public async Task<IEnumerable<Plan>> SavePlansWithOrdersLocallyAsync(IEnumerable<Plan> plans,
            CancellationToken cancellationToken)
        {
            plans = await _planUserDataService.SaveAsync(plans, cancellationToken);
            var customers = plans.SelectMany(x => x.Orders).Select(x => x.Customer).Where(x => x != null && !string.IsNullOrWhiteSpace(x.Id)).Distinct(new CustomerEqualityComparer());
            await _customerService.SaveLocallyAsync(customers, cancellationToken);
            foreach (var plan in plans)
            {
                var uncommittedOrders = plan.UncommittedOrders;
                if (uncommittedOrders != null && uncommittedOrders.Any())
                {
                    foreach (var uncommittedOrder in uncommittedOrders)
                    {
                        uncommittedOrder.PlanId = plan.Id;
                    }
                    await _orderUserDataService.SaveAsync(uncommittedOrders, cancellationToken);
                }

                var orders = plan.Orders;
                if (orders != null && orders.Any())
                {
                    foreach (var order in orders)
                    {
                        order.PlanId = plan.Id;
                    }
                    await _orderUserDataService.SaveAsync(orders, cancellationToken);
                }
            }

            return plans;
        }

        private async Task DeletePlansWithOrdersForUserLocallyAsync(string subscriberId, string userId, CancellationToken token)
        {
            var plansToDelete = await _planUserDataService.GetByUserAsync(subscriberId, userId, token);
            await DeletePlansWithOrdersLocallyAsync(plansToDelete, token);
        }

        public async Task DeletePlansWithOrdersLocallyAsync(IEnumerable<Plan> plans, CancellationToken token)
        {
            var planIdsToDelete = plans.Select(x => x.Id);
            var ordersToDelete = await _orderUserDataService.GetAsync(x => planIdsToDelete.Contains(x.PlanId), null, token);
            var orderIdsToDelete = ordersToDelete.Select(x => x.Id);

            await _planUserDataService.DeleteAsync(planIdsToDelete, token);
            await _orderUserDataService.DeleteAsync(orderIdsToDelete, token);
        }

        public async Task<IEnumerable<Plan>> GetPlansForDriverAsync(DateTime? afterUtcDate, bool localLookup, CancellationToken cancellationToken)
        {
            IEnumerable<Plan> plans = new List<Plan>();
            if (localLookup)
            {
                plans = await GetPlansForUserLocallyAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, afterUtcDate, cancellationToken);
            }
            if (!localLookup || !plans.Any())
            {
                var planDriverPlanViewModels = await GetPlansForDriverRestCallAsync(_authenticationProvider.DriverId, afterUtcDate, cancellationToken);
                if (planDriverPlanViewModels != null)
                {
                    await DeletePlansWithOrdersForUserLocallyAsync(_authenticationProvider.SubscriberId, _authenticationProvider.UserId, cancellationToken);
                }
                if (planDriverPlanViewModels.Any())
                {
                    plans = _domainModelBridgeService.BridgePlans(planDriverPlanViewModels);
                    plans = await SavePlansWithOrdersLocallyAsync(plans, cancellationToken);
                    foreach (var p in plans)
                    {
                        SaveOldPlan(p);
                    }
                }
            }

            return plans;
        }

        private class CustomerEqualityComparer : IEqualityComparer<Domain.Portable.StorageCompatible.Customer>
        {
            public bool Equals(Domain.Portable.StorageCompatible.Customer x, Domain.Portable.StorageCompatible.Customer y)
            {
                return x.Id == y.Id;
            }

            public int GetHashCode(Domain.Portable.StorageCompatible.Customer obj)
            {
                return obj.Id.GetHashCode();
            }
        }
    }
}
