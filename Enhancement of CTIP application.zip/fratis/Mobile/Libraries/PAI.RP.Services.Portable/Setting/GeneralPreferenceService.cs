﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Setting
{

    public interface IGeneralPreferenceService
    {
        Task<GeneralPreference> GetAsync(string subscriberId, CancellationToken cancellationToken);

        Task<GeneralPreference> SaveAsync(string subscriberId, GeneralPreference generalPreference,
            CancellationToken cancellationToken);
    }

    public class GeneralPreferenceService : IGeneralPreferenceService
    {
        private readonly IDataService<GeneralPreference> _generalPreferenceDataService;
        private readonly Rest.Portable.Setting.IGeneralPreferenceServiceService _generalPreferenceRestService;

        public GeneralPreferenceService(IDataService<GeneralPreference> generalPreferenceDataService,
            Rest.Portable.Setting.IGeneralPreferenceServiceService generalPreferenceRestService)
        {
            _generalPreferenceDataService = generalPreferenceDataService;
            _generalPreferenceRestService = generalPreferenceRestService;
        }

        public async Task<GeneralPreference> GetAsync(string subscriberId, CancellationToken cancellationToken)
        {
            var generalPreference = (await _generalPreferenceDataService.GetAsync(x => x.SubscriberId == subscriberId, null, cancellationToken)).FirstOrDefault();
            if (generalPreference == null)
            {
                try
                {
                    var settingViewModel = await _generalPreferenceRestService.GetAsync(cancellationToken);
                    if (settingViewModel != null)
                    {
                        generalPreference = MapGeneralPreferences(subscriberId, settingViewModel);
                        generalPreference = await _generalPreferenceDataService.SaveAsync(generalPreference, cancellationToken);
                    }
                }
                catch (Exception exception)
                {
                    //Swallow the error
                }
            }

            return generalPreference;
        }

        public async Task<GeneralPreference> SaveAsync(string subscriberId, GeneralPreference generalPreference, CancellationToken cancellationToken)
        {
            generalPreference.SubscriberId = subscriberId;
            return await _generalPreferenceDataService.SaveAsync(generalPreference, cancellationToken);
        }

        private GeneralPreference MapGeneralPreferences(string subscriberId, SettingViewModel settingViewModel)
        {
            var generalPreference = JsonConvert.DeserializeObject<GeneralPreference>(settingViewModel.Value.ToString());
            generalPreference.SubscriberId = subscriberId;

            return generalPreference;
        }
    }
}
