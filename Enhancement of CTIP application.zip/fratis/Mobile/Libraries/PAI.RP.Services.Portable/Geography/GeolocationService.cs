﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Portable.Geography
{
    public interface IGeolocationService
    {
        Task<IEnumerable<Geolocation>> GetLocallyByUserAfterLastSynchronizationDateAsync(string subscriberId,
            string userId, CancellationToken cancellationToken);
        Task<IEnumerable<Geolocation>> GetLocallyByUserAsync(string subscriberId, string userId, CancellationToken cancellationToken);
        Task<IEnumerable<Geolocation>> GetLocallyAsync(Expression<Func<Geolocation, bool>> predicate,
            OrderByRequest<Geolocation> orderBy, CancellationToken cancellationToken);
        Task<Geolocation> SaveLocallyAsync(Geolocation geolocation, CancellationToken cancellationToken);
        Task<IEnumerable<Geolocation>> SaveLocallyAsync(IEnumerable<Geolocation> geolocations, CancellationToken cancellationToken);
        Task DeleteLocallyAsync(IEnumerable<string> ids, CancellationToken cancellationToken);
    }

    public class GeolocationService : IGeolocationService
    {
        private readonly IUserRestService<Geolocation> _userRestService;
        private readonly IUserDatedDataService<Geolocation> _userDataService;

        public GeolocationService(IUserRestService<Geolocation> userRestService, IUserDatedDataService<Geolocation> userDataService)
        {
            _userRestService = userRestService;
            _userDataService = userDataService;
        }

        public async Task<IEnumerable<Geolocation>> GetLocallyByUserAfterLastSynchronizationDateAsync(string subscriberId, 
            string userId, CancellationToken cancellationToken)
        {
            return await _userDataService.GetByUserAfterLastSynchronizationDateAsync(subscriberId, userId, cancellationToken);
        }

        public async Task<IEnumerable<Geolocation>> GetLocallyByUserAsync(string subscriberId, string userId, CancellationToken cancellationToken)
        {
            return await _userDataService.GetByUserAsync(subscriberId, userId, cancellationToken);
        }

        public async Task<IEnumerable<Geolocation>> GetLocallyAsync(Expression<Func<Geolocation, bool>> predicate,
            OrderByRequest<Geolocation> orderBy, CancellationToken cancellationToken)
        {
            return await _userDataService.GetAsync(predicate, orderBy, cancellationToken);
        }

        public async Task<Geolocation> SaveLocallyAsync(Geolocation geolocation, CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(geolocation, cancellationToken);
        }

        public async Task<IEnumerable<Geolocation>> SaveLocallyAsync(IEnumerable<Geolocation> geolocations, CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(geolocations, cancellationToken);
        }

        public async Task DeleteLocallyAsync(IEnumerable<string> ids, CancellationToken cancellationToken)
        {
            await _userDataService.DeleteAsync(ids, cancellationToken);
        }
    }
}
