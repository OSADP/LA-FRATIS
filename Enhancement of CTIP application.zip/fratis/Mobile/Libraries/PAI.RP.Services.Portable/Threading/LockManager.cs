﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace PAI.RP.Services.Portable.Threading
{
    public interface ILockManager
    {
        void GetLock(string lockName);
        void GetLock(string lockName, TimeSpan timeout);
        void ReleaseLock(string lockName);
    }

    public class SlimLockManager : ILockManager
    {
        public const string MessageSyncLock = "MessageSync";

        private readonly IDictionary<string, ReaderWriterLockSlim> _lockSlimDictionary = new Dictionary<string, ReaderWriterLockSlim>();

        public void GetLock(string lockName)
        {
            GetLock(lockName, TimeSpan.FromMilliseconds(-1));
        }

        public void GetLock(string lockName, TimeSpan timeout)
        {
            if (!_lockSlimDictionary.ContainsKey(lockName))
            {
                _lockSlimDictionary.Add(lockName, new ReaderWriterLockSlim());
            }
            _lockSlimDictionary[lockName].EnterWriteLock();
        }

        public void ReleaseLock(string lockName)
        {
            if (_lockSlimDictionary.ContainsKey(lockName))
            {
                _lockSlimDictionary[lockName].ExitWriteLock();
            }
        }
    }
}
