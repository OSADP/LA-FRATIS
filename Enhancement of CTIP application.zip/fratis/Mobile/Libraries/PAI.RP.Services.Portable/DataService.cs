﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Services.Cache.Portable;
using PAI.RP.Services.Persistence.Portable;

namespace PAI.RP.Services.Portable
{
    public interface IDataService<TEntity> 
        where TEntity : class, IEntity, IMobileStorageCompatible
    {
        Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken);
        Task<IEnumerable<TEntity>> GetAsync(IEnumerable<Expression<Func<TEntity, bool>>> predicates, 
            IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken);
        Task<IEnumerable<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate, 
            OrderByRequest<TEntity> orderByRequest, CancellationToken cancellationToken);
        Task<TEntity> SaveAsync(TEntity entity, CancellationToken cancellationToken);
        Task<IEnumerable<TEntity>> SaveAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken);
        Task DeleteAsync(string id, CancellationToken cancellationToken);
        Task DeleteAsync(IEnumerable<string> ids, CancellationToken cancellationToken);
    }

    public class DataService<TEntity> : IDataService<TEntity> 
        where TEntity : class, IEntity, IMobileStorageCompatible
    {
        private readonly IDataServiceBaseAsync<TEntity> _dataServiceBase;
        private readonly ICacheService<TEntity> _cacheService;

        public DataService(IDataServiceBaseAsync<TEntity> dataServiceBase, ICacheService<TEntity> cacheService)
        {
            _dataServiceBase = dataServiceBase;
            _cacheService = cacheService;
        }

        public async Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken)
        {
            //Check cache first
            var entity = _cacheService.GetById(id);
            //TEntity entity = null;
            if (entity == null)
            {
                entity = await _dataServiceBase.GetByIdAsync(id, cancellationToken);
                if (entity != null)
                {
                    //Save the entity to the cache
                    _cacheService.Add(entity);
                }
            }

            return entity;
        }

        public async Task<IEnumerable<TEntity>> GetAsync(IEnumerable<Expression<Func<TEntity, bool>>> predicates, 
            IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken)
        {
            //Check cache first
            var entities = predicates == null ? _cacheService.Get() : _cacheService.Get(predicates);
            if (orderByRequests != null)
            {
                var orderByCount = 0;
                foreach (var orderByRequest in orderByRequests.Where(orderByRequest => orderByRequest != null && orderByRequest.Expression != null))
                {
                    ++orderByCount;
                    if (orderByCount == 1)
                    {
                        entities = orderByRequest.Direction == OrderByDirection.Ascending
                            ? entities.OrderBy(orderByRequest.Expression.Compile()).ToList()
                            : entities.OrderByDescending(orderByRequest.Expression.Compile()).ToList();
                    }
                    else
                    {
                        entities = orderByRequest.Direction == OrderByDirection.Ascending
                            ? ((IOrderedEnumerable<TEntity>)entities).ThenBy(orderByRequest.Expression.Compile()).ToList()
                            : ((IOrderedEnumerable<TEntity>)entities).ThenByDescending(orderByRequest.Expression.Compile()).ToList();
                    }
                }
            }

            //IEnumerable<TEntity> entities = new List<TEntity>();
            if (!entities.Any())
            {
                var result = await _dataServiceBase.GetAsync(predicates, orderByRequests, cancellationToken);
                if (result.Count > 0)
                {
                    //Save the entities to the cache
                    _cacheService.Add(result);
                    entities = result;
                }
            }

            return entities;
        }

        public async Task<IEnumerable<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate, 
            OrderByRequest<TEntity> orderByRequest, CancellationToken cancellationToken)
        {
            return await GetAsync(new Expression<Func<TEntity, bool>>[1]{predicate}, new OrderByRequest<TEntity>[1]{orderByRequest}, cancellationToken);
        }

        public async Task<TEntity> SaveAsync(TEntity entity, CancellationToken cancellationToken)
        {
            entity = await _dataServiceBase.SaveAsync(entity, cancellationToken).ConfigureAwait(false);
            _cacheService.Save(entity);
            return entity;
        }

        public async Task<IEnumerable<TEntity>> SaveAsync(IEnumerable<TEntity> entities, CancellationToken cancellationToken)
        {
            entities = await _dataServiceBase.SaveAsync(entities, cancellationToken);
            _cacheService.Save(entities);
            return entities;
        }

        public async Task DeleteAsync(string id, CancellationToken cancellationToken)
        {
            await _dataServiceBase.DeleteAsync(id, cancellationToken);
            _cacheService.Remove(id);
        }

        public async Task DeleteAsync(IEnumerable<string> ids, CancellationToken cancellationToken)
        {
            await _dataServiceBase.DeleteAsync(ids, cancellationToken);
            _cacheService.Remove(ids);
        }
    }

    public interface IUserDataService<TEntity> : IDataService<TEntity> 
        where TEntity : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible
    {
        Task<IEnumerable<TEntity>> GetByUserAsync(string subscriberId, string userId, CancellationToken cancellationToken);
        Task<IEnumerable<TEntity>> GetByUserAsync(string subscriberId, string userId,
            IEnumerable<Expression<Func<TEntity, bool>>> predicates,
            IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken);
    }

    public class UserDataService<TEntity> : DataService<TEntity>, IUserDataService<TEntity> 
        where TEntity : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible
    {
        private readonly IUserDataServiceBaseAsync<TEntity> _userDataServiceBase;
        private readonly ICacheService<TEntity> _cacheService;

        public UserDataService(IUserDataServiceBaseAsync<TEntity> userDataServiceBase, ICacheService<TEntity> cacheService)
            : base(userDataServiceBase, cacheService)
        {
            _userDataServiceBase = userDataServiceBase;
            _cacheService = cacheService;
        }

        public virtual async Task<IEnumerable<TEntity>> GetByUserAsync(string subscriberId, string userId, CancellationToken cancellationToken)
        {
            return await GetAsync(x => x.SubscriberId == subscriberId && x.UserId == userId, null, cancellationToken);
        }

        public virtual async Task<IEnumerable<TEntity>> GetByUserAsync(string subscriberId, string userId, 
            IEnumerable<Expression<Func<TEntity, bool>>> predicates,
            IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken)
        {
            List<Expression<Func<TEntity, bool>>> allPredicates = null;
            if (predicates != null)
            {
                allPredicates = predicates.ToList();
                allPredicates.Add(x => x.SubscriberId == subscriberId && x.UserId == userId);
            }
            
            return await GetAsync(allPredicates, orderByRequests, cancellationToken);
        }
    }

    public interface IUserDatedDataService<TEntity> : IUserDataService<TEntity>
        where TEntity : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible, IDatedEntity
    {
        Task<IEnumerable<TEntity>> GetByUserAfterLastSynchronizationDateAsync(string subscriberId, string userId, 
            CancellationToken cancellationToken);
    }

    public class UserDatedDataService<TEntity> : UserDataService<TEntity>, IUserDatedDataService<TEntity>
        where TEntity : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible, IDatedEntity
    {
        private readonly Subscribers.IUserSettingsService _userSettingsService;

        public UserDatedDataService(IUserDataServiceBaseAsync<TEntity> userDataServiceBase,
            ICacheService<TEntity> cacheService, Subscribers.IUserSettingsService userSettingsService)
            : base(userDataServiceBase, cacheService)
        {
            _userSettingsService = userSettingsService;
        }

        public virtual async Task<IEnumerable<TEntity>> GetByUserAfterLastSynchronizationDateAsync(string subscriberId, string userId, 
            CancellationToken cancellationToken)
        {
            var userSettings = await _userSettingsService.GetLocalUserSettings(subscriberId, userId, cancellationToken);
            DateTime? lastSynchronizationDate = userSettings == null ? null : userSettings.LastSynchronizationDate;

            var result = (await GetByUserAsync(subscriberId, userId, null, null, cancellationToken)).ToList();

            if (lastSynchronizationDate.HasValue)
            {
                result = result.Where(x =>
                    x.LastModifiedDate.HasValue
                        ? x.LastModifiedDate.Value > lastSynchronizationDate.Value
                        : x.CreatedDate > lastSynchronizationDate.Value).ToList();
            }

            return result;
        }
    }
}
