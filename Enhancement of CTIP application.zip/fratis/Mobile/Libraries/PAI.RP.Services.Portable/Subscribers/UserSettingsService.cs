﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Portable.Subscribers
{
    public interface IUserSettingsService
    {
        Task<UserSettings> GetLocalUserSettings(string subscriberId, string userId, CancellationToken cancellationToken);
        Task<UserSettings> SaveLocallyAsync(UserSettings userSettings, CancellationToken cancellationToken);
        Task<IEnumerable<UserSettings>> SaveLocallyAsync(IEnumerable<UserSettings> userSettings,
            CancellationToken cancellationToken);
    }

    public class UserSettingsService : IUserSettingsService
    {
        private readonly IUserDataService<UserSettings> _userDataService;

        public UserSettingsService(IUserDataService<UserSettings> userDataService)
        {
            _userDataService = userDataService;
        }

        public async Task<UserSettings> GetLocalUserSettings(string subscriberId, string userId, CancellationToken cancellationToken)
        {
            return (await _userDataService.GetByUserAsync(subscriberId, userId, null, null, cancellationToken)).FirstOrDefault();
        }

        public async Task<UserSettings> SaveLocallyAsync(UserSettings userSettings, CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(userSettings, cancellationToken);
        }

        public async Task<IEnumerable<UserSettings>> SaveLocallyAsync(IEnumerable<UserSettings> userSettings,
            CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(userSettings, cancellationToken);
        }
    }
}
