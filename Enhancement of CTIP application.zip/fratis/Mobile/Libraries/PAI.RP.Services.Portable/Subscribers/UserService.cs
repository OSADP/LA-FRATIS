﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Subscribers
{
    public interface IUserService
    {
        Task<PasswordChangeResultViewModel> ChangePasswordAsync(PasswordChangeRequestViewModel requestViewModel, CancellationToken cancellationToken);
    }

    public class UserService : IUserService
    {
        private readonly Rest.Portable.Subscribers.IUserService _restUserService;

        public UserService(Rest.Portable.Subscribers.IUserService restUserService)
        {
            _restUserService = restUserService;
        }

        public async Task<PasswordChangeResultViewModel> ChangePasswordAsync(PasswordChangeRequestViewModel requestViewModel, CancellationToken cancellationToken)
        {
            return await _restUserService.ChangePasswordAsync(requestViewModel, cancellationToken);
        }
    }
}
