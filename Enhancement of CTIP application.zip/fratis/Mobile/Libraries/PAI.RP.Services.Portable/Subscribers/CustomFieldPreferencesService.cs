﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Subscribers
{
    public interface ICustomFieldPreferencesService
    {
        Task<CustomFieldPreference> SaveLocallyAsync(CustomFieldPreference entity, CancellationToken cancellationToken);

        Task<IEnumerable<CustomFieldPreference>> GetAllAsync(string subscriberId, CancellationToken cancellationToken);

        Task<IEnumerable<CustomFieldPreference>> GetByEntityTypeAsync(string subscriberId, string entityType,
            CancellationToken cancellationToken);
    }

    public class CustomFieldPreferencesService : ICustomFieldPreferencesService
    {
        private readonly IDataService<CustomFieldPreference> _customFieldDataService;
        private readonly Rest.Portable.Subscribers.ICustomFieldPreferencesService _customFieldRestService;

        public CustomFieldPreferencesService(IDataService<CustomFieldPreference> customFieldDataService, Rest.Portable.Subscribers.ICustomFieldPreferencesService customFieldRestService)
        {
            _customFieldDataService = customFieldDataService;
            _customFieldRestService = customFieldRestService;
        }

        public async Task<CustomFieldPreference> SaveLocallyAsync(CustomFieldPreference entity, CancellationToken cancellationToken)
        {
            return await _customFieldDataService.SaveAsync(entity, cancellationToken);
        }

        public async Task<IEnumerable<CustomFieldPreference>> GetAllAsync(string subscriberId, CancellationToken cancellationToken)
        {
            var customFields = await _customFieldDataService.GetAsync(x => x.SubscriberId == subscriberId, null, cancellationToken);
            if (!customFields.Any())
            {
                try
                {
                    var customFieldSchemaViewModels = await _customFieldRestService.GetAllAsync(cancellationToken);
                    if (customFieldSchemaViewModels.Any())
                    {
                        customFields = MapCustomFields(subscriberId, customFieldSchemaViewModels);
                        customFields = await _customFieldDataService.SaveAsync(customFields, cancellationToken);
                    }
                }
                catch (Exception exception)
                {
                    //Swallow error, most likely a web connection failure exception if the user has no internet
                }
            }

            return customFields;
        }

        public async Task<IEnumerable<CustomFieldPreference>> GetByEntityTypeAsync(string subscriberId, string entityType, CancellationToken cancellationToken)
        {
            var customFields = await _customFieldDataService.GetAsync(x => x.SubscriberId == subscriberId && x.EntityType == entityType, null, cancellationToken);
            if (!customFields.Any())
            {
                try
                {
                    var customFieldSchemaViewModels = await _customFieldRestService.GetByEntityTypeAsync(entityType, cancellationToken);
                    if (customFieldSchemaViewModels.Any())
                    {
                        customFields = MapCustomFields(subscriberId, customFieldSchemaViewModels);
                        customFields = await _customFieldDataService.SaveAsync(customFields, cancellationToken);
                    }
                }
                catch (Exception exception)
                {
                    //Swallow error, most likely a web connection failure exception if the user has no internet
                }
            }

            return customFields;
        }

        private IEnumerable<CustomFieldPreference> MapCustomFields(string subscriberId, IEnumerable<CustomFieldSchemaViewModel> customFieldSchemaViewModels)
        {
            var customFieldPreferences = Mapper.Map<IEnumerable<CustomFieldSchemaViewModel>, IEnumerable<CustomFieldPreference>>(customFieldSchemaViewModels);
            foreach (var customFieldPreference in customFieldPreferences)
            {
                customFieldPreference.SubscriberId = subscriberId;
            }

            return customFieldPreferences;
        }
    }
}
