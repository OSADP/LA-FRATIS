﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data;
using PAI.RP.Services.Cache.Portable;
using PAI.RP.Services.Rest.Portable;

namespace PAI.RP.Services.Portable
{
    public interface IRestService<TEntity> where TEntity : class, IEntity
    {
        Task<TEntity> GetByIdAsync<TEntitityViewModel>(string id, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task<TEntity> SaveAsync<TEntitityViewModel>(TEntity entity, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task<IEnumerable<TEntity>> SaveAsync<TEntitityViewModel>(IEnumerable<TEntity> entities, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity;

        Task DeleteAsync(string id, CancellationToken cancellationToken);
    }

    public class RestService<TEntity> : IRestService<TEntity> where TEntity : class, IEntity
    {
        private readonly IEntityRestServiceBase<TEntity> _entityRestServiceBase;
        private readonly ICacheService<TEntity> _cacheService;

        public RestService(IEntityRestServiceBase<TEntity> entityRestServiceBase, ICacheService<TEntity> cacheService)
        {
            _entityRestServiceBase = entityRestServiceBase;
            _cacheService = cacheService;
        }

        public async Task<TEntity> GetByIdAsync<TEntitityViewModel>(string id, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            //Check cache first
            var entity = _cacheService.GetById(id);
            if (entity == null)
            {
                entity = await _entityRestServiceBase.GetByIdAsync<TEntitityViewModel>(id, null, cancellationToken);
                if (entity != null)
                {
                    //Save the entity to the cache and local DB
                    _cacheService.Add(entity);
                }
            }

            return entity;
        }

        public async Task<TEntity> SaveAsync<TEntitityViewModel>(TEntity entity, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            var result = await _entityRestServiceBase.SaveAsync<TEntitityViewModel>(entity, cancellationToken);
            _cacheService.Save(result);

            return result;
        }

        public async Task<IEnumerable<TEntity>> SaveAsync<TEntitityViewModel>(IEnumerable<TEntity> entities, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity
        {
            var result = await _entityRestServiceBase.SaveAsync<TEntitityViewModel>(entities, cancellationToken);
            _cacheService.Save(result);

            return result;
        }

        public async Task DeleteAsync(string id, CancellationToken cancellationToken)
        {
            var result = await _entityRestServiceBase.DeleteAsync(id, cancellationToken);
            //TODO - Set a specific format for success response or ensure this is the proper protocol
            if (!string.IsNullOrWhiteSpace(result) && result.ToLower() == "true")
            {
                _cacheService.Remove(id);
            }
        }
    }

    public interface IUserRestService<TEntity> : IRestService<TEntity> where TEntity : class, IEntity, ISubscriber, IUser
    {
        Task<IEnumerable<TEntity>> GetByUserAsync<TEntitityViewModel>(string subscriberId, string userId, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity, ISubscriber, IUser;
    }

    public class UserRestService<TEntity> : RestService<TEntity>, IUserRestService<TEntity> where TEntity : class, IEntity, ISubscriber, IUser
    {
        private readonly IUserRestServiceBase<TEntity> _userRestServiceBase;
        private readonly ICacheService<TEntity> _cacheService;

        public UserRestService(IUserRestServiceBase<TEntity> userRestServiceBase, ICacheService<TEntity> cacheService)
            : base(userRestServiceBase, cacheService)
        {
            _userRestServiceBase = userRestServiceBase;
            _cacheService = cacheService;
        }

        public async Task<IEnumerable<TEntity>> GetByUserAsync<TEntitityViewModel>(string subscriberId, string userId, string extendedRequestUrl, CancellationToken cancellationToken)
            where TEntitityViewModel : class, IEntity, ISubscriber, IUser
        {
            //Check cache first
            var entities = _cacheService.Get(x => x.SubscriberId == subscriberId && x.UserId == userId);
            if (!entities.Any())
            {
                entities = await _userRestServiceBase.GetByUserAsync<TEntitityViewModel>(userId, extendedRequestUrl, cancellationToken);
                if (entities.Any())
                {
                    //Save the entities to the cache
                    _cacheService.Add(entities);
                }
            }

            return entities;
        }
    }
}
