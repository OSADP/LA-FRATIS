﻿using System.Collections.Generic;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Portable.Orders
{
    public class OrdersResponse
    {
        public IEnumerable<Order> Orders { get; set; }
        public IEnumerable<Order> UncommittedOrders { get; set; }
    }
}
