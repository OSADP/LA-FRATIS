﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Cache.Portable;
using PAI.RP.Services.Portable.Customer;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Messaging;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Threading;
using TinyIoC;

namespace PAI.RP.Services.Portable.Orders
{
    public interface IOrderService
    {
        bool OrderIsInHaystack(Order order, IEnumerable<Order> orderHaystack);
        Task<bool> OrderIsNextToStartAsync(Order order, CancellationToken cancellationToken);
        Task<ResponseSlim> OrderIsReadOnlyAsync(Order order, CancellationToken cancellationToken);
        Task<bool> OrderIsTrackingAsync(Order order, CancellationToken cancellationToken);
        Task<bool> AnotherOrderIsAlreadyInProgressAsync(Order order, CancellationToken cancellationToken);
        Task<IEnumerable<Order>> OtherOrdersAlreadyInProgressAsync(Order order, CancellationToken cancellationToken);

        Task<IEnumerable<Order>> OtherOrdersAlreadyEnRouteAsync(Order order, CancellationToken cancellationToken);

        Task<bool> AnotherRouteStopIsAlreadyInProgressAsync(Order order, CancellationToken cancellationToken);

        Task<bool> AnotherRouteStopIsAlreadyEnRouteAsync(Order order, CancellationToken cancellationToken);

        Task<IList<RouteStop>> GetAllRouteStopsForTheOrderAsync(Order order, CancellationToken cancellationToken);

        Task<IEnumerable<Order>> GetOrdersOnOrBeyondPlanExecutionDateLocallyAsync(string subscriberId, string userId,
            DateTime executionDate, CancellationToken cancellationToken);
        Task<Order> GetOrderLocallyAsync(string orderId, CancellationToken cancellationToken);
        Task<IEnumerable<Order>> GetAllOrdersForThePlanAsync(string planId, CancellationToken cancellationToken);
        Task<bool> AnotherRouteStopIsAlreadyActive(Order order, CancellationToken cancellationToken);

        Task<Order> EnRouteOrderAsync(Order order, CancellationToken cancellationToken);
        Task<Order> StartOrderAsync(Order order, CancellationToken cancellationToken);
        Task<Order> CompleteOrderAsync(Order order, CancellationToken cancellationToken);
        Task<Order> DeferOrderAsync(Order order, CancellationToken cancellationToken);
        Task<Order> SaveOrderAsync(Order order, CancellationToken cancellationToken);
        Task<Order> InProgressRouteStop(Order order, CancellationToken cancellationToken);
        Task<Order> CompleteRouteStop(Order order, CancellationToken cancellationToken);
        Task<Order> EnRouteRouteStop(Order order, CancellationToken cancellationToken);

    }

    public class OrderService : IOrderService
    {
        private readonly IPlanService _planService;
        private readonly IUserDatedDataService<Plan> _planUserDataService;
        private readonly IUserDatedDataService<Order> _orderUserDataService;
        private readonly ICacheService<Plan> _planCacheService;
        private readonly Rest.Portable.Orders.IOrderService _restOrderService;
        private readonly ICustomerService _customerService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly ILockManager _lockManager;
        private readonly ILocalizationService _localizationService;

        public OrderService(IPlanService planService, IUserDatedDataService<Plan> planUserDataService,
            IUserDatedDataService<Order> orderUserDataService, ICacheService<Plan> planCacheService,
            Rest.Portable.Orders.IOrderService restOrderService, ICustomerService customerService,
            IAuthenticationProvider authenticationProvider, ILockManager lockManager, ILocalizationService localizationService)
        {
            _planService = planService;
            _planUserDataService = planUserDataService;
            _orderUserDataService = orderUserDataService;
            _planCacheService = planCacheService;
            _restOrderService = restOrderService;
            _customerService = customerService;
            _authenticationProvider = authenticationProvider;
            _lockManager = lockManager;
            _localizationService = localizationService;
        }

        public async Task<Order> EnRouteOrderAsync(Order order, CancellationToken cancellationToken)
        {
            order.Status = OrderStatus.EnRoute;

            var orderStatusTimes = new List<OrderStatusTime>(order.OrderStatusTimes)
            {
                new OrderStatusTime
                {
                    UserId = _authenticationProvider.UserId,
                    Status = OrderStatus.EnRoute,
                    TimeStamp = DateTime.Now
                }
            };
            order.OrderStatusTimes = orderStatusTimes;

            var result = await SaveOrderAsync(order, cancellationToken);

            return result;
        }

        public async Task<Order> InProgressRouteStop(Order order, CancellationToken cancellationToken)
        {
            
            var routeStops = order.RouteStops;
            var enRouteRouteStop = routeStops.First(x => x.RouteStopStatus == RouteStopStatus.EnRoute);

            if (routeStops.Any(t => t.RouteStopStatus == RouteStopStatus.InProgress))
            {
                return await Task.Run(() => order, cancellationToken);
            }

            enRouteRouteStop.RouteStopStatus = RouteStopStatus.InProgress;

            var index = routeStops.IndexOf(enRouteRouteStop);

            order.RouteStops.RemoveAt(index);

            order.RouteStops.Insert(index, enRouteRouteStop);
            return await Task.Run(() => order, cancellationToken);
        }

        public async Task<Order> CompleteRouteStop(Order order, CancellationToken cancellationToken)
        {
            var routeStops = order.RouteStops;
            var inProgressRouteStop = routeStops.First(x => x.RouteStopStatus == RouteStopStatus.InProgress);

            

            inProgressRouteStop.RouteStopStatus = RouteStopStatus.Completed;

            var index = routeStops.IndexOf(inProgressRouteStop);

            order.RouteStops.RemoveAt(index);

            order.RouteStops.Insert(index, inProgressRouteStop);
            return await Task.Run(() => order, cancellationToken);
        }

        public async Task<Order> EnRouteRouteStop(Order order, CancellationToken cancellationToken)
        {
            var routeStops = order.RouteStops;
            var activeRouteStop = routeStops.First(x => x.RouteStopStatus == RouteStopStatus.Active || x.RouteStopStatus == RouteStopStatus.Invalid);

            

            activeRouteStop.RouteStopStatus = RouteStopStatus.EnRoute;

            var index = routeStops.IndexOf(activeRouteStop);

            order.RouteStops.RemoveAt(index);

            order.RouteStops.Insert(index, activeRouteStop);
            return await Task.Run(() => order, cancellationToken);
        }

        private Order SetOrderInProgress(Order order)
        {
            order.Status = OrderStatus.InProgress;
            return order;
        }

        public bool OrderIsInHaystack(Order order, IEnumerable<Order> orderHaystack)
        {
            return orderHaystack.Any(x => x.Id == order.Id);
        }

        public async Task<bool> OrderIsNextToStartAsync(Order order, CancellationToken cancellationToken)
        {
            var allOrdersUnderThePlan = await GetAllOrdersForThePlanAsync(order.PlanId, cancellationToken);
            var firstReceivedOrderInQueue = allOrdersUnderThePlan.FirstOrDefault(x => x.Status == OrderStatus.Received);

            return firstReceivedOrderInQueue != null && firstReceivedOrderInQueue.Id == order.Id;
        }

        public async Task<IEnumerable<Order>> OtherOrdersAlreadyEnRouteAsync(Order order, CancellationToken cancellationToken)
        {
            var allOrdersUnderThePlan = await GetAllOrdersForThePlanAsync(order.PlanId, cancellationToken);
            return allOrdersUnderThePlan.Where(x => x.Status == OrderStatus.EnRoute && x.Id != order.Id);
        }

        public async Task<ResponseSlim> OrderIsReadOnlyAsync(Order order, CancellationToken cancellationToken)
        {
            var responseSlim = new ResponseSlim();
            if (order.Status == OrderStatus.Completed)
            {
                //Completed Orders are Read Only
                responseSlim.Errors.Add("Action disabled. The " + _localizationService.Order + " has been completed.");
                return responseSlim;
            }
            var plan = await _planUserDataService.GetByIdAsync(order.PlanId, cancellationToken);
            if (plan == null)
            {
                //Plan was not found.
                responseSlim.Errors.Add("Action disabled. The " + _localizationService.Plan + " was not found.");
                return responseSlim;
            }
            if (plan.ExecutionDate.Date != DateTime.Now.Date && plan.Status != PlanStatus.InProgress)
            {
                //Plan must be for today
                responseSlim.Errors.Add("Action disabled. The " + _localizationService.Plan + " must be for today.");
                return responseSlim;
            }
            if (plan.Status != PlanStatus.InProgress)
            {
                //Plan must be in progress
                responseSlim.Errors.Add("Action disabled. The " + _localizationService.Plan + " must be started.");
                return responseSlim;
            }

            return responseSlim;
        }

        

        public async Task<bool> OrderIsTrackingAsync(Order order, CancellationToken cancellationToken)
        {
            var plan = await _planUserDataService.GetByIdAsync(order.PlanId, cancellationToken);
            return _planService.PlanIsTracking(plan);
        }

        public async Task<bool> AnotherOrderIsAlreadyInProgressAsync(Order order, CancellationToken cancellationToken)
        {
            var allOrdersUnderThePlan = await GetAllOrdersForThePlanAsync(order.PlanId, cancellationToken);
            return allOrdersUnderThePlan.Any(x => x.Status == OrderStatus.InProgress && x.Id != order.Id);
        }

        public async Task<bool> AnotherRouteStopIsAlreadyInProgressAsync(Order order, CancellationToken cancellationToken)
        {
            var allRouteStopsUnderOrder = await GetAllRouteStopsForTheOrderAsync(order, cancellationToken);
            return allRouteStopsUnderOrder.Any(x => x.RouteStopStatus == RouteStopStatus.InProgress);
        }

        public async Task<bool> AnotherRouteStopIsAlreadyEnRouteAsync(Order order, CancellationToken cancellationToken)
        {
            var allRouteStopsUnderOrder = await GetAllRouteStopsForTheOrderAsync(order, cancellationToken);
            return allRouteStopsUnderOrder.Any(x => x.RouteStopStatus == RouteStopStatus.EnRoute);
        }

        public async Task<bool> AnotherRouteStopIsAlreadyCompletedAsync(Order order, CancellationToken cancellationToken)
        {
            var allRouteStopsUnderOrder = await GetAllRouteStopsForTheOrderAsync(order, cancellationToken);
            return allRouteStopsUnderOrder.Any(x => x.RouteStopStatus == RouteStopStatus.Completed);
        }

        public async Task<bool> AnotherRouteStopIsAlreadyActive(Order order, CancellationToken cancellationToken)
        {
            var allRouteStopsUnderOrder = await GetAllRouteStopsForTheOrderAsync(order, cancellationToken);
            return allRouteStopsUnderOrder.Any(x => x.RouteStopStatus == RouteStopStatus.Active);
        }

        public async Task<IEnumerable<Order>> OtherOrdersAlreadyInProgressAsync(Order order, CancellationToken cancellationToken)
        {
            var allOrdersUnderThePlan = await GetAllOrdersForThePlanAsync(order.PlanId, cancellationToken);
            return allOrdersUnderThePlan.Where(x => x.Status == OrderStatus.InProgress && x.Id != order.Id);
        }

        public async Task<IEnumerable<Order>> GetOrdersOnOrBeyondPlanExecutionDateLocallyAsync(string subscriberId, string userId,
            DateTime executionDate, CancellationToken cancellationToken)
        {
            var localPlans = await _planService.GetPlansForUserLocallyAsync(subscriberId, userId, executionDate, cancellationToken);

            return localPlans.SelectMany(x => x.Orders);
        }

        public async Task<Order> GetOrderLocallyAsync(string orderId, CancellationToken cancellationToken)
        {
            var order = await _orderUserDataService.GetByIdAsync(orderId, cancellationToken);
            if (order == null)
            {
                return null;
            }

            //Assign customer to the order
            order.Customer = await _customerService.GetByIdAsync(order.CustomerId, cancellationToken);
            order.RouteStops = order.RouteStops.OrderBy(x => x.SortOrder).ToList();
            return order;
        }

        public async Task<IEnumerable<Order>> GetAllOrdersForThePlanAsync(string planId, CancellationToken cancellationToken)
        {
            return await _planService.GetAllOrdersForThePlanAsync(planId, cancellationToken);
        }

        public async Task<IList<RouteStop>> GetAllRouteStopsForTheOrderAsync(Order order, CancellationToken cancellationToken)
        {
            var routeStops = order.RouteStops;
            return await Task.Run(() => routeStops, cancellationToken);
        }

        public async Task<Order> StartOrderAsync(Order order, CancellationToken cancellationToken)
        {            
            order.Status = OrderStatus.InProgress;
            var orderStatusTimes = new List<OrderStatusTime>(order.OrderStatusTimes)
                {
                    new OrderStatusTime
                    {
                        UserId = _authenticationProvider.UserId,
                        Status = OrderStatus.InProgress,
                        TimeStamp = DateTime.Now
                    }
                };
            order.OrderStatusTimes = orderStatusTimes;

            var result = await SaveOrderAsync(order, cancellationToken);

            return result;
        }

        public async Task<Order> CompleteOrderAsync(Order order, CancellationToken cancellationToken)
        {
            order.Status = OrderStatus.Completed;
            var orderStatusTimes = new List<OrderStatusTime>(order.OrderStatusTimes)
            {
                new OrderStatusTime
                {
                    UserId = _authenticationProvider.UserId,
                    Status = OrderStatus.Completed,
                    TimeStamp = DateTime.Now
                }
            };
            order.OrderStatusTimes = orderStatusTimes;

            var result = await SaveOrderAsync(order, cancellationToken);
            var planContainsIncompletedOrders = await _planService.PlanContainsIncompletedOrdersAsync(order.PlanId, cancellationToken);
            if (!planContainsIncompletedOrders)
            {
                var plan = await _planUserDataService.GetByIdAsync(order.PlanId, cancellationToken);
                await _planService.ClosePlanAsync(plan, cancellationToken);
            }

            return result;
        }

        public async Task<Order> DeferOrderAsync(Order order, CancellationToken cancellationToken)
        {
            order.Status = OrderStatus.Deferred;

            var orderStatusTimesToAdd = new List<OrderStatusTime>();
            var timeStamp = DateTime.Now;
            if (order.OrderStatusTimes.All(x => x.Status != OrderStatus.InProgress))
            {
                orderStatusTimesToAdd.Add(new OrderStatusTime
                {
                    UserId = _authenticationProvider.UserId,
                    Status = OrderStatus.InProgress,
                    TimeStamp = timeStamp
                });
            }
            orderStatusTimesToAdd.Add(new OrderStatusTime
            {
                UserId = _authenticationProvider.UserId,
                Status = OrderStatus.Deferred,
                TimeStamp = timeStamp
            });
            var orderStatusTimes = new List<OrderStatusTime>(order.OrderStatusTimes);
            orderStatusTimes.AddRange(orderStatusTimesToAdd);
            order.OrderStatusTimes = orderStatusTimes;

            var result = await SaveOrderAsync(order, cancellationToken);
            var planContainsIncompletedOrders = await _planService.PlanContainsIncompletedOrdersAsync(order.PlanId, cancellationToken);
            if (!planContainsIncompletedOrders)
            {
                var plan = await _planUserDataService.GetByIdAsync(order.PlanId, cancellationToken);
                await _planService.ClosePlanAsync(plan, cancellationToken);
            }

            return result;
        }

        public async Task<Order> SaveOrderAsync(Order order, CancellationToken cancellationToken)
        {
            Order result = order;
            try
            {
                //TODO - This is needed to prevent a circular dependency between the Message Service > MessageRequestBuilder/MessageResponseResolver > OrderService
                //TODO - See if we can avoid this somehow in the future?
                var messageService = TinyIoCContainer.Current.Resolve<IMessageService>();

                _lockManager.GetLock(SlimLockManager.MessageSyncLock);
                result = await SaveOrderLocallyAsync(order, true, cancellationToken);
                await messageService.SynchronizeAsync(cancellationToken);
            }
            catch (Exception exception)
            {
                //Failed to synchronize
                //Swallow error
            }
            try
            {
                _lockManager.ReleaseLock(SlimLockManager.MessageSyncLock);
            }
            catch (Exception exception)
            {
                //No lock obtained to release
            }

            return result;
        }

        public async Task<Order> SaveOrderLocallyAsync(Order order, bool applyDirtyHashMarker, CancellationToken cancellationToken)
        {
            if (applyDirtyHashMarker)
            {
                order.Hash = Hash.Hash.DirtyHashMarker;
            }
            var result = await _orderUserDataService.SaveAsync(order, cancellationToken);
            //TODO - Verify if we need this anymore since we automatically hydrate our objects we retrieve from the services
            UpdatePlanCache(order);

            return result;
        }

        /// <summary>
        /// TODO - May need to remove this method, as the other methods that get the plan, also hydrate the Orders property on the plan automatically.
        /// </summary>
        /// <param name="order"></param>
        private void UpdatePlanCache(Order order)
        {
            var cachedPlan = _planCacheService.GetById(order.PlanId);
            var cachedPlanOrders = cachedPlan.Orders.ToList();

            cachedPlanOrders.Remove(cachedPlanOrders.FirstOrDefault(x => x.Id == order.Id));
            _planCacheService.Remove(order.PlanId);
            cachedPlanOrders.Add(order);
            cachedPlan.Orders = cachedPlanOrders;
            _planCacheService.Add(cachedPlan);
        }
    }
}
