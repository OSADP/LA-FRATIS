﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PAI.RP.Services.Portable.Customer
{
    public interface ICustomerService
    {
        Task<Domain.Portable.StorageCompatible.Customer> GetByIdAsync(string id, CancellationToken cancellationToken);

        Task<Domain.Portable.StorageCompatible.Customer> SaveLocallyAsync(
            Domain.Portable.StorageCompatible.Customer customer, CancellationToken cancellationToken);

        Task<IEnumerable<Domain.Portable.StorageCompatible.Customer>> SaveLocallyAsync(
            IEnumerable<Domain.Portable.StorageCompatible.Customer> customers, CancellationToken cancellationToken);
    }

    public class CustomerService : ICustomerService
    {
        private readonly IDataService<Domain.Portable.StorageCompatible.Customer> _userDataService;

        public CustomerService(IDataService<Domain.Portable.StorageCompatible.Customer> userDataService)
        {
            _userDataService = userDataService;
        }

        public async Task<Domain.Portable.StorageCompatible.Customer> GetByIdAsync(string id, CancellationToken cancellationToken)
        {
            return await _userDataService.GetByIdAsync(id, cancellationToken);
        }

        public async Task<Domain.Portable.StorageCompatible.Customer> SaveLocallyAsync(
            Domain.Portable.StorageCompatible.Customer customer, CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(customer, cancellationToken);
        }

        public async Task<IEnumerable<Domain.Portable.StorageCompatible.Customer>> SaveLocallyAsync(
            IEnumerable<Domain.Portable.StorageCompatible.Customer> customers, CancellationToken cancellationToken)
        {
            return await _userDataService.SaveAsync(customers, cancellationToken);
        }
    }
}
