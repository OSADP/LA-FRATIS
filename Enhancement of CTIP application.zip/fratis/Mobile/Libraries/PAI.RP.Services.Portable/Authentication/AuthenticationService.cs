﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Services.Rest.Portable.Model;

namespace PAI.RP.Services.Portable.Authentication
{
    public interface IAuthenticationService
    {
        Task<PasswordChangeResultViewModel> ResetPasswordAsync(string username, CancellationToken cancellationToken);
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly Rest.Portable.Authentication.IAuthenticationService _restAuthenticationService;

        public AuthenticationService(Rest.Portable.Authentication.IAuthenticationService restAuthenticationService)
        {
            _restAuthenticationService = restAuthenticationService;
        }

        public async Task<PasswordChangeResultViewModel> ResetPasswordAsync(string username, CancellationToken cancellationToken)
        {
            return await _restAuthenticationService.ResetPasswordAsync(username, cancellationToken);
        }
    }
}
