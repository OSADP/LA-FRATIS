﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using PAI.Common.Core.Data;

namespace PAI.RP.Services.Cache.Portable
{
    public interface ICacheService<TEntity> where TEntity : class, IEntity
    {
        IEnumerable<TEntity> Get();
        IEnumerable<TEntity> Get(IEnumerable<Expression<Func<TEntity, bool>>> wherePredicates);
        IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> wherePredicate);
        TEntity GetById(string id);
        /// <summary>
        /// Replaces all current entries of the specified entity type with the provided set of entries of the same specified entity type.
        /// </summary>
        /// <param name="entities"></param>
        void Set(IEnumerable<TEntity> entities);
        void Add(IEnumerable<TEntity> entities);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        void Add(TEntity entity);
        /// <summary>
        /// Adds or replaces the entities if they exist
        /// </summary>
        /// <param name="entities"></param>
        void Save(IEnumerable<TEntity> entities);
        /// <summary>
        /// Adds or replaces the entity if it exists
        /// </summary>
        /// <param name="entity"></param>
        void Save(TEntity entity);
        void Remove(IEnumerable<string> ids);
        void Remove(string id);
        /// <summary>
        /// Removes all entries of the specified entity type
        /// </summary>
        void Clear();
    }

    public class CacheService<TEntity> : ICacheService<TEntity> where TEntity : class, IEntity
    {
        public IEnumerable<TEntity> Get()
        {
            return Entities<TEntity>.Get();
        }

        public IEnumerable<TEntity> Get(IEnumerable<Expression<Func<TEntity, bool>>> wherePredicates)
        {
            IEnumerable<TEntity> entities = Entities<TEntity>.Get();
            if (wherePredicates != null)
            {
                foreach (var wherePredicate in wherePredicates.Where(x => x != null))
                {
                    entities = entities.Where(wherePredicate.Compile()).ToList();
                }
            }
            return entities;
        }

        public IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> wherePredicate)
        {
            return Get(new Expression<Func<TEntity, bool>>[1]{wherePredicate});
        }

        public TEntity GetById(string id)
        {
            return Get(x => x.Id == id).FirstOrDefault();
        }

        public void Set(IEnumerable<TEntity> entities)
        {
            Entities<TEntity>.Set(entities);
        }

        public void Add(IEnumerable<TEntity> entities)
        {
            Entities<TEntity>.Add(entities);
        }

        public void Add(TEntity entity)
        {
            Entities<TEntity>.Add(entity);
        }

        /// <summary>
        /// Adds or replaces the entities if they exist
        /// </summary>
        public void Save(IEnumerable<TEntity> entities)
        {
            Entities<TEntity>.Save(entities);
        }

        /// <summary>
        /// Adds or replaces the entity if it exists
        /// </summary>
        public void Save(TEntity entity)
        {
            Entities<TEntity>.Save(entity);
        }

        public void Remove(IEnumerable<string> ids)
        {
            Entities<TEntity>.Remove(ids);
        }

        public void Remove(string id)
        {
            Entities<TEntity>.Remove(id);
        }

        public void Clear()
        {
            Entities<TEntity>.Clear();
        }
    }
}
