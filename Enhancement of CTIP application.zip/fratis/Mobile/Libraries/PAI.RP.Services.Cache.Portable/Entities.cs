﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.Common.Core.Data;

namespace PAI.RP.Services.Cache.Portable
{
    public static class Entities<T> where T : class, IEntity
    {
        //TODO - Refactor to just an IList<T>, don't need the EntityDictionary since the Generic class is instanced per generic type
        private static readonly IDictionary<Type, ICollection<T>> EntityDictionary = new Dictionary<Type, ICollection<T>>();

        private static Object _lock = new Object();

        public static ICollection<T> Get()
        {
            lock (_lock)
            {
                ICollection<T> entities;
                return EntityDictionary.TryGetValue(typeof(T), out entities) ? entities : new List<T>();
            }
        }

        public static void Set(IEnumerable<T> entities)
        {
            lock (_lock)
            {
                if (EntityDictionary.ContainsKey(typeof(T)))
                {
                    EntityDictionary[typeof(T)] = new List<T>(entities);
                }
                else
                {
                    EntityDictionary.Add(typeof(T), new List<T>(entities));
                }
            }
        }

        public static void Add(IEnumerable<T> entities)
        {
            lock (_lock)
            {
                if (EntityDictionary.ContainsKey(typeof(T)))
                {
                    foreach (var entity in entities)
                    {
                        EntityDictionary[typeof(T)].Add(entity);
                    }
                }
                else
                {
                    EntityDictionary.Add(typeof(T), new List<T>(entities));
                }
            }
        }

        public static void Add(T entity)
        {
            Add(new T[1] { entity });
        }

        /// <summary>
        /// Adds or replaces the entities if they exist
        /// </summary>
        public static void Save(IEnumerable<T> entities)
        {
            Remove(entities.Select(x => x.Id));
            Add(entities);
        }

        /// <summary>
        /// Adds or replaces the entity if it exists
        /// </summary>
        public static void Save(T entity)
        {
            Remove(entity.Id);
            Add(new T[1] { entity });
        }

        public static void Remove(T entity)
        {
            Remove(entity.Id);
        }

        public static void Remove(IEnumerable<string> ids)
        {
            lock (_lock)
            {
                if (EntityDictionary.ContainsKey(typeof(T)))
                {
                    var entitiesToRemove = EntityDictionary[typeof(T)].Where(x => ids.Contains(x.Id)).ToList();
                    foreach (var entity in entitiesToRemove)
                    {
                        EntityDictionary[typeof(T)].Remove(entity);
                    }
                }
            }
        }

        public static void Remove(string id)
        {
            Remove(new string[1] { id });
        }

        public static void Clear()
        {
            lock (_lock)
            {
                if (EntityDictionary.ContainsKey(typeof(T)))
                {
                    EntityDictionary.Remove(typeof(T));
                }
            }
        }
    }
}
