﻿namespace PAI.RP.Domain.Portable
{
    public interface IAuthenticationProvider
    {
        string TokenString { get; set; }
        string SubscriberId { get; set; }
        string UserId { get; set; }
        string Username { get; set; }
        string DriverId { get; set; }
    }

    public class AuthenticationProvider : IAuthenticationProvider
    {
        public string TokenString { get; set; }
        public string SubscriberId { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }
        public string DriverId { get; set; }
    }
}
