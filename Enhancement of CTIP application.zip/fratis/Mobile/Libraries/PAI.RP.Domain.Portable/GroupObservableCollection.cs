﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace PAI.RP.Domain.Portable
{
    public class GroupObservableCollection<T> : ObservableCollection<T>
    {
        public string Key { get; set; }

        public GroupObservableCollection()
        {
        }

        public GroupObservableCollection(IEnumerable<T> collection)
            : base(collection)
        {
        }
    }
}
