﻿using System;

namespace PAI.RP.Domain.Portable
{
    [Flags]
    public enum PlanStatus
    {
        NotSent = 0,
        Received = 1,
        InProgress = 2,
        Completed = 3
    }
}
