﻿namespace PAI.RP.Domain.Portable
{
    public static class UserAuthentication
    {
        public static IAuthenticationProvider AuthenticationProvider { get; set; }

        public static string SubscriberId
        {
            get { return AuthenticationProvider != null ? AuthenticationProvider.SubscriberId : null; }
        }

        public static string UserId
        {
            get { return AuthenticationProvider != null ? AuthenticationProvider.UserId : null; }
        }

        public static string Username
        {
            get { return AuthenticationProvider != null ? AuthenticationProvider.Username : null; }
        }

        public static string DriverId
        {
            get { return AuthenticationProvider != null ? AuthenticationProvider.DriverId : null; }
        }

        public static bool ShowDiscalimer { get; set; }

        public static bool RemotePlansFetched { get; set; }

        public static bool IsLoggedIn
        {
            get
            {
                return !string.IsNullOrWhiteSpace(AuthenticationProvider.TokenString) &&
                       !string.IsNullOrWhiteSpace(UserId) && !string.IsNullOrWhiteSpace(SubscriberId);
            }
        }
    }
}
