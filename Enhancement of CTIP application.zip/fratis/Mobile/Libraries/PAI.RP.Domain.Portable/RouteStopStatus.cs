﻿namespace PAI.RP.Domain.Portable
{
    public enum RouteStopStatus
    {
        Invalid = 0,
        Active = 1,
        EnRoute = 2,
        InProgress = 3,
        Completed = 4,
        Deferred = 5 
    }
}