﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class Plan : EntityBase, ISubscriber, IUser, IDatedEntity
    {
        public Plan()
        {
            Orders = new List<Order>();
            UncommittedOrders = new List<Order>();
            PlanStatusTimes = new List<PlanStatusTime>();
        }

        public string UniqueId { get; set; }

        public string SubscriberId { get; set; }

        public string UserId { get; set; }

        public string DriverId { get; set; }

        [Ignore]
        public IEnumerable<Order> Orders { get; set; }

        /// <summary>
        /// Obtained from the PlanDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<string> OrderIds { get; set; }

        [Ignore]
        public IEnumerable<Order> UncommittedOrders { get; set; }

        /// <summary>
        /// Obtained from the PlanDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<string> UncommittedOrderIds { get; set; }

        public string Name { get; set; }

        public PlanStatus Status { get; set; }

        /// <summary>
        /// Obtained from the PlanDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<PlanStatusTime> PlanStatusTimes { get; set; }

        public DateTime? StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? LastModifiedDate { get; set; }

        public DateTime ExecutionDate { get; set; }

        /// <summary>
        /// Gets or sets the total travel distance in miles
        /// </summary>
        public double TotalTravelDistance { get; set; }

        /// <summary>
        /// Gets or sets whether this plan is user created
        /// </summary>
        public virtual bool UserCreated { get; set; }

        /// <summary>
        /// Gets or sets whether this plan was modified
        /// </summary>
        public virtual bool UserModified { get; set; }

        public string Hash { get; set; }

        /// <summary>
        /// Due to the limitations of relational databases such as SQL/SQLite, Derived Types must be stored in secondary relational tables.
        /// To get around creating secondary relational tables, the Derived Data types are stored in this DerivedData string property in JSON format
        /// and should be serialized and deserialized using the PlanDerivedData class structure.
        /// </summary>
        public string DerivedData { get; set; }
    }

    /// <summary>
    /// Class format for the DerivedData string property of the Plan class. Use this class as the template for JSON serialization/deserialization
    /// of the DerivedData string property of the Plan class. See Plan.DerivedData property for additional info. 
    /// </summary>
    public class PlanDerivedData
    {
        public IEnumerable<string> OrderIds { get; set; }
        public IEnumerable<string> UncommittedOrderIds { get; set; }
        public IEnumerable<PlanStatusTime> PlanStatusTimes { get; set; }
    }
}
