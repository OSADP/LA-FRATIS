﻿using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class GeneralPreference : EntityBase, ISubscriber
    {
        public string SubscriberId { get; set; }

        /// <summary>
        /// Frequency in milliseconds
        /// </summary>
        public int TrackingFrequency { get; set; }

        public MapNavigationPreference MapNavigationPreference { get; set; }

        public string Hash { get; set; }
    }
}