﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class UserSettings : EntityBase, ISubscriber, IUser
    {
        public string SubscriberId { get; set; }
        public string UserId { get; set; }
        public DateTime? LastSynchronizationDate { get; set; }
    }
}
