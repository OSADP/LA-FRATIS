﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class Geolocation : EntityBase, ISubscriber, IUser, IDatedEntity
    {
        public string SubscriberId { get; set; }
        public string UserId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public DateTime TimeStamp { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        //TODO - Remove after GPS testing
        public double? Accuracy { get; set; }
        public double? Speed { get; set; }
    }
}
