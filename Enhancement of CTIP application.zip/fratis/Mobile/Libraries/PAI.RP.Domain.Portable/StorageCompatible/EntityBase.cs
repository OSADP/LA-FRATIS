﻿using PAI.Common.Core.Data;
using PAI.Common.Core.Data.Portable;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class EntityBase : IEntity, IMobileStorageCompatible
    {
        [PrimaryKey]
        public string Id { get; set; }
    }
}