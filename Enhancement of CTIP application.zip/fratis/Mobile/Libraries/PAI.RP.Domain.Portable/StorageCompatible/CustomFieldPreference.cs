﻿using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class CustomFieldPreference : EntityBase, ISubscriber
    {
        public string SubscriberId { get; set; }
        public string EntityType { get; set; }
        public int SortIndex { get; set; }
        public string PropertyName { get; set; }
        public string DisplayName { get; set; }
        public string ValueType { get; set; }
        public string Hash { get; set; }
    }
}
