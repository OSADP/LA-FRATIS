﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class Order : EntityBase, ISubscriber, IUser, IDatedEntity
    {
        public string SubscriberId { get; set; }

        public string UserId { get; set; }

        public string PlanId { get; set; }

        public string DriverId { get; set; }

        public string Number { get; set; }

        //TODO - Remove this after passing viewModels
        public int SequenceNumber { get; set; }

        public OrderStatus Status { get; set; }

        public string Priority { get; set; }

        public string Description { get; set; }

        /// <summary>
        /// Obtained from the OrderDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<OrderStatusTime> OrderStatusTimes { get; set; }

        /// <summary>
        /// Obtained from the OrderDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<OrderNote> Notes { get; set; }

        /// <summary>
        /// Obtained from the OrderDerivedData
        /// </summary>
        [Ignore]
        public IEnumerable<OrderLocation> Locations { get; set; }

        public string CustomerId { get; set; }

        [Ignore]
        public Customer Customer { get; set; }

        [Ignore]
        public IList<RouteStop> RouteStops { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? LastModifiedDate { get; set; }

        public DateTime? ScheduledDate { get; set; }

        public OrderType OrderType { get; set; }

        public string LoadUnit { get; set; }

        public double? Unit { get; set; }

        public string ReferenceNumber { get; set; }

        //TODO - Remove this from the Order after testing and it will be in the Order Auditing Table
        public DateTime? ActualArrivalTime { get; set; }

        //TODO - Remove this from the Order after testing and it will be in the Order Auditing Table
        public DateTime? ActualDepartureTime { get; set; }

        public string Hash { get; set; }

        /// <summary>
        /// Obtained from the OrderDerivedData
        /// </summary>
        [Ignore]
        public Dictionary<string, object> CustomFields { get; set; }

        /// <summary>
        /// Due to the limitations of relational databases such as SQL/SQLite, Derived Types must be stored in secondary relational tables.
        /// To get around creating secondary relational tables, the Derived Data types are stored in this DerivedData string property in JSON format
        /// and should be serialized and deserialized using the OrderDerivedData class structure.
        /// </summary>
        public string DerivedData { get; set; }

        public string PickupNumber { get; set; }

        public string BookingNumber { get; set; }

        public string BillOfLading { get; set; }

        public string ConsigneeName { get; set; }

        public string ShipperName { get; set; }

        public string ContainerOwner { get; set; }

        public string ContainerNumber { get; set; }
        public string Container { get; set; }

        public string ChassisOwner { get; set; }

        public string Chassis { get; set; }

        public string ChassisNumber { get; set; }

        public string CustomField1 { get; set; }

        public string CustomField2 { get; set; }
        public string CustomField3 { get; set; }
        public string CustomField4 { get; set; }
        public string CustomField5 { get; set; }
    }

    /// <summary>
    /// Class format for the DerivedData string property of the Order class. Use this class as the template for JSON serialization/deserialization
    /// of the DerivedData string property of the Order class. See Order.DerivedData property for additional info. 
    /// </summary>
    public class OrderDerivedData
    {
        public IEnumerable<OrderStatusTime> OrderStatusTimes { get; set; }
        public IEnumerable<OrderNote> Notes { get; set; }
        public IEnumerable<OrderLocation> Locations { get; set; }
        public Dictionary<string, object> CustomFields { get; set; }
        public IList<RouteStop> RouteStops { get; set; }
    }
}
