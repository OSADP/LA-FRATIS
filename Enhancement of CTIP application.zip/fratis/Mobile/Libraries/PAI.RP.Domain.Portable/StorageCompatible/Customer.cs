﻿using System.Collections.Generic;
using PAI.Common.Core.Data;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class Customer : EntityBase, ISubscriber
    {
        public string SubscriberId { get; set; }

        /// <summary>
        /// Gets or sets the customer name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the customer number
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets the customer phone number
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Obtained from the CustomerDerivedData
        /// </summary>
        [Ignore]
        public List<Tag> Tags { get; set; }

        /// <summary>
        /// Gets or sets the customer e-mail address
        /// </summary>
        public string Email { get; set; }

        //Location Fields that are flattened from the Restful ViewModel
        #region Location Properties
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Line3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        #endregion

        /// <summary>
        /// Obtained from the CustomerDerivedData
        /// </summary>
        [Ignore]
        public Dictionary<string, object> CustomFields { get; set; }

        /// <summary>
        /// Due to the limitations of relational databases such as SQL/SQLite, Derived Types must be stored in secondary relational tables.
        /// To get around creating secondary relational tables, the Derived Data types are stored in this DerivedData string property in JSON format
        /// and should be serialized and deserialized using the CustomerDerivedData class structure.
        /// </summary>
        public string DerivedData { get; set; }
    }

    /// <summary>
    /// Class format for the DerivedData string property of the Customer class. Use this class as the template for JSON serialization/deserialization
    /// of the DerivedData string property of the Customer class. See Customer.DerivedData property for additional info. 
    /// </summary>
    public class CustomerDerivedData
    {
        public List<Tag> Tags { get; set; }
        public Dictionary<string, object> CustomFields { get; set; }
    }
}
