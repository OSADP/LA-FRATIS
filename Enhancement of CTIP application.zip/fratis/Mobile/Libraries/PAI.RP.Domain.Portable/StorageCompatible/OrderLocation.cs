﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class OrderLocation : EntityBase, ISubscriber
    {
        public string SubscriberId { get; set; }

        public string OrderId { get; set; }

        [Ignore]
        public Order Order { get; set; }

        public string CustomerId { get; set; }

        [Ignore]
        public Customer Customer { get; set; }

        public IEnumerable<TimeWindow> TimeWindows { get; set; }

        public TimeSpan ServiceTime { get; set; }

        // not part of current scrum - will implement when we get the user story
        //public OrderAction Action { get; set; }

        public string Line1 { get; set; }

        public string Line2 { get; set; }

        public string Line3 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }
    }
}
