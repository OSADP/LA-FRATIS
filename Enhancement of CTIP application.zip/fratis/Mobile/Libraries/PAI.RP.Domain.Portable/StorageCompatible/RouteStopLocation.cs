﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using SQLite.Net.Attributes;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class RouteStopLocation : EntityBase, ISubscriber
    {

        public string DisplayName { get; set; }

        public string WebFleetId { get; set; }

        public double? Longitude { get; set; }

        public double? Latitude { get; set; }

        public string StreetAddress { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public string Address { get; set; }
        public string SubscriberId { get; set; }
    }
}
