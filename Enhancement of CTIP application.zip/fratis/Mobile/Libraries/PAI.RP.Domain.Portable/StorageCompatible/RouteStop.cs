﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable.StorageCompatible
{
    public class RouteStop
    {
        public int JobId { get; set; }
        public int SortOrder { get; set; }

        public RouteStopLocation Location { get; set; }
        public RouteStopStatus RouteStopStatus { get; set; }
        public long WindowStart { get; set; }

        public int? StopActionId { get; set; }
        public virtual DateTime? WindowStartDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowStart) : DateTime.UtcNow.Date.AddTicks(WindowStart);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);
                var dt = new DateTime(WindowStart);
                return dt;
            }
        }

        public long WindowEnd { get; set; }

        public virtual DateTime? WindowEndDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowEnd) : DateTime.UtcNow.Date.AddTicks(WindowEnd);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);

                var dt = new DateTime(WindowEnd);
                return dt;
            }
        }

        public TimeSpan ServiceTime { get; set; }

        /// <summary>
        /// Gets or sets the stop delay in ticks
        /// </summary>
        public virtual long? StopDelay { get; set; }

        public DateTime? CreatedDate { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public DateTime? EstimatedETA { get; set; }

        public DateTime? ActualETA { get; set; }
        public string Id { get; set; }
        public string SubscriberId { get; set; }
        public string UserId { get; set; }
       
    }
}