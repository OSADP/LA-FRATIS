﻿using System;

namespace PAI.RP.Domain.Portable
{
    public class OrderStatusTime
    {
        public string UserId { get; set; }
        public OrderStatus Status { get; set; }
        public DateTime TimeStamp { get; set; }
    }
}
