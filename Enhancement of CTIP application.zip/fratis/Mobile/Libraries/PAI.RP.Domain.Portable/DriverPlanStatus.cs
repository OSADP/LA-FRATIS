﻿using System;

namespace PAI.RP.Domain.Portable
{
    [Flags]
    public enum DriverPlanStatus
    {
        NotSent = 0,
        Received = 1,
        InProgress = 2,
        Completed = 3
    }
}
