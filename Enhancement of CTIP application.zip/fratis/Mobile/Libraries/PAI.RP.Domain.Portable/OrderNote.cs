﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable
{
    public class OrderNote : IUser
    {
        public string UserId { get; set; }

        public string UserName { get; set; }

        public string Note { get; set; }

        public DateTime TimeStamp { get; set; }
    }
}
