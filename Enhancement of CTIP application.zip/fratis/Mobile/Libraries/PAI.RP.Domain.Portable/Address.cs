﻿namespace PAI.RP.Domain.Portable
{
    public class Address
    {
        public double Latitude { get; set; }

        public double Longitude { get; set; }

        /// <summary>
        /// Gets or sets address line 1
        /// </summary>
        public string Line1 { get; set; }

        /// <summary>
        /// Gets or sets address line 2
        /// </summary>
        public string Line2 { get; set; }

        /// <summary>
        /// Gets or sets address line 3
        /// </summary>
        public string Line3 { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public string Zip { get; set; }
    }
}
