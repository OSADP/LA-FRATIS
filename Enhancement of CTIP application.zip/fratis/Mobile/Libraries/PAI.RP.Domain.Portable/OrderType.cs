﻿namespace PAI.RP.Domain.Portable
{
    // TODO - should not be hard coded, should be dynamic - for discussion   ajh
    public enum OrderType
    {
        Service,
        PickUpDropOff
    }
}
