﻿namespace PAI.RP.Domain.Portable
{
    public interface IRestClientProvider
    {
        string BaseUrl { get; set; }
        string ApiVersion { get; set; }
    }

    public class RestClientProvider : IRestClientProvider
    {
        public string BaseUrl { get; set; }
        public string ApiVersion { get; set; }
    }
}
