﻿using System;
using System.Collections.Generic;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Domain.Portable
{
    //TODO - REMOVE THIS AFTER SERVER SIDE IS IMPLEMENTED
    public class TempRestPlans
    {
        public TempRestPlans()
        {
            var orders = new TempRestOrders().Orders;

            _plans = new List<Plan>
            {
                new Plan
                {
                    Id = "11ggf123",
                    SubscriberId = "53e1257c2a8fd01764c2fcd6",
                    UserId = "53ee9abb2a8fd313009c0126",
                    Name = "Plan 1",
                    Orders = orders,
                    Status = PlanStatus.Received,
                    CreatedDate = DateTime.Now,
                    LastModifiedDate = null,
                }
            };
        }

        private readonly IList<Plan> _plans;
        public IList<Plan> Plans
        {
            get { return _plans; }
        }
    }
}