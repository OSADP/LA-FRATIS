﻿namespace PAI.RP.Domain.Portable
{
    public enum OrderStatus
    {
        Unspecified = 0,
        Received = 1,
        InProgress = 2,
        Completed = 3,
        Deferred = 4,
        EnRoute = 6
    }
}
