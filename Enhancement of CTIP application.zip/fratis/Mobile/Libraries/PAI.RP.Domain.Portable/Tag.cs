﻿namespace PAI.RP.Domain.Portable
{
    public class Tag
    {
        public string Text { get; set; }
    }
}
