﻿using System.Collections.Generic;

namespace PAI.RP.Domain.Portable
{
    public class ResponseSlim
    {
        private IList<string> _errors = new List<string>();
        public IList<string> Errors
        {
            get { return _errors; }
            set { _errors = value; }
        }

        public bool HasErrors
        {
            get { return Errors.Count > 0; }
        }
    }
}
