﻿namespace PAI.RP.Domain.Portable
{
    public enum MapNavigationPreference
    {
        PromptMapChoice = 1,
        NativeMap = 2,
        GoogleMap = 3,
        AppleMap = 4,
        BingMap = 5,
        CoPilotMap = 6,
        NokiaMap = 7
    }
}
