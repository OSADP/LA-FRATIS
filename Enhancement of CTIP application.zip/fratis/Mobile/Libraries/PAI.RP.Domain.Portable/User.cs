﻿using System;
using PAI.Common.Core.Data;

namespace PAI.RP.Domain.Portable
{
    public class User : SubscriberEntityBase, IDatedEntity
    {
        /// <summary>
        /// Gets or sets the user's username
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets the e-mail address for the given user
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the password
        /// </summary>
        public string Password { get; set; }

        public string Salt { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? LastModifiedDate { get; set; }
    }
}
