﻿using System;

namespace PAI.RP.Domain.Portable
{
    public class PlanStatusTime
    {
        public string UserId { get; set; }
        public PlanStatus Status { get; set; }
        public DateTime TimeStamp { get; set; }
    }
}
