﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data;
using PAI.Common.Core.Data.Portable;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IDataServiceBaseAsync<T> where T : class, IEntity, IMobileStorageCompatible
    {
        Task<IList<T>> GetAsync(IEnumerable<Expression<Func<T, bool>>> predicates, IEnumerable<OrderByRequest<T>> orderByRequests, CancellationToken cancellationToken);
        Task<IList<T>> GetAsync(Expression<Func<T, bool>> predicate, OrderByRequest<T> orderByRequest, CancellationToken cancellationToken);
        Task<T> GetByIdAsync(string id, CancellationToken token);
        Task<T> SaveAsync(T entity, CancellationToken token);
        Task<IEnumerable<T>> SaveAsync(IEnumerable<T> entities, CancellationToken token);
        Task DeleteAsync(T entity, CancellationToken token);
        Task DeleteAsync(string id, CancellationToken token);
        Task DeleteAsync(IEnumerable<string> ids, CancellationToken token);
    }

    public abstract class DataServiceBaseAsync<T> : IDataServiceBaseAsync<T> where T : class, IEntity, IMobileStorageCompatible
    {
        private readonly IRepository<T> _repository;

        protected DataServiceBaseAsync(IRepository<T> repository)
        {
            _repository = repository;
        }

        public virtual async Task<IList<T>> GetAsync(IEnumerable<Expression<Func<T, bool>>> predicates,
            IEnumerable<OrderByRequest<T>> orderByRequests, CancellationToken cancellationToken)
        {
            return await _repository.GetAsync(predicates, orderByRequests, cancellationToken);
        }

        public virtual async Task<IList<T>> GetAsync(Expression<Func<T, bool>> predicate, OrderByRequest<T> orderByRequest,
            CancellationToken cancellationToken)
        {
            return await _repository.GetAsync(predicate, orderByRequest, cancellationToken);
        }

        public virtual async Task<T> GetByIdAsync(string id, CancellationToken token)
        {
            return await _repository.GetByIdAsync(id, token);
        }

        public virtual async Task<T> SaveAsync(T entity, CancellationToken token)
        {
            await SaveAsync(new T[1] {entity}, token).ConfigureAwait(false);

            return entity;
        }

        public virtual async Task<IEnumerable<T>> SaveAsync(IEnumerable<T> entities, CancellationToken token)
        {
            foreach (var entity in entities)
            {
                //TODO - Use get by Ids instead and then use a linq firstOrDefault to check against null
                var datedEntity = entity as IDatedEntity;
                if (string.IsNullOrWhiteSpace(entity.Id))
                {
                    entity.Id = Guid.NewGuid().ToString();
                    if (datedEntity != null)
                    {
                        datedEntity.CreatedDate = DateTime.Now;
                    }
                    await _repository.InsertAsync(entity, token);
                }
                else if ((await _repository.GetByIdAsync(entity.Id, token)) == null)
                {
                    if (datedEntity != null)
                    {
                        datedEntity.CreatedDate = DateTime.Now;
                    }
                    await _repository.InsertAsync(entity, token);
                }
                else
                {
                    if (datedEntity != null)
                    {
                        datedEntity.LastModifiedDate = DateTime.Now;
                    }
                    await _repository.UpdateAsync(entity, token);
                }
            }

            return entities;
        }

        public async Task DeleteAsync(T entity, CancellationToken token)
        {
            await _repository.DeleteAsync(entity, token);
        }

        public async Task DeleteAsync(string id, CancellationToken token)
        {
            await _repository.DeleteAsync(id, token);
        }

        public async Task DeleteAsync(IEnumerable<string> ids, CancellationToken token)
        {
            await _repository.DeleteAsync(ids, token);
        }
    }

    public interface IUserDataServiceBaseAsync<T> : IDataServiceBaseAsync<T> 
        where T : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible
    {
        Task<IEnumerable<T>> GetByUserAsync(string subscriberId, string userId,
            IEnumerable<Expression<Func<T, bool>>> predicates,
            IEnumerable<OrderByRequest<T>> orderByRequests, CancellationToken cancellationToken);
    }

    public abstract class UserDataServiceBaseAsync<T> : DataServiceBaseAsync<T>, IUserDataServiceBaseAsync<T>
        where T : class, IEntity, ISubscriber, IUser, IMobileStorageCompatible
    {
        protected UserDataServiceBaseAsync(IRepository<T> repository) : base(repository)
        {
        }

        public virtual async Task<IEnumerable<T>> GetByUserAsync(string subscriberId, string userId,
            IEnumerable<Expression<Func<T, bool>>> predicates,
            IEnumerable<OrderByRequest<T>> orderByRequests, CancellationToken cancellationToken)
        {
            List<Expression<Func<T, bool>>> allPredicates = null;
            if (predicates != null)
            {
                allPredicates = predicates.ToList();
                allPredicates.Add(x => x.SubscriberId == subscriberId && x.UserId == userId);
            }

            return await GetAsync(allPredicates, orderByRequests, cancellationToken);
        }
    }
}
