﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface ICustomFieldPreferencesService : IDataServiceBaseAsync<CustomFieldPreference>
    {
    }

    public class CustomFieldPreferencesService : DataServiceBaseAsync<CustomFieldPreference>, ICustomFieldPreferencesService
    {
        private readonly IRepository<CustomFieldPreference> _repository;

        public CustomFieldPreferencesService(IRepository<CustomFieldPreference> repository)
            : base(repository)
        {
            _repository = repository;
        }

        public override async Task<IEnumerable<CustomFieldPreference>> SaveAsync(IEnumerable<CustomFieldPreference> entities, CancellationToken token)
        {
            foreach (var customFieldPreference in entities)
            {
                var subscriberId = customFieldPreference.SubscriberId;
                var entityType = customFieldPreference.EntityType;
                var propertyName = customFieldPreference.PropertyName;
                var res = (await GetAsync(x => x.SubscriberId == subscriberId && x.EntityType == entityType && x.PropertyName == propertyName, null, token)).FirstOrDefault();
                if (res == null)
                {
                    customFieldPreference.Id = Guid.NewGuid().ToString();
                    await _repository.InsertAsync(customFieldPreference, token);
                }
                else
                {
                    customFieldPreference.Id = res.Id;
                    await _repository.UpdateAsync(customFieldPreference, token);
                }
            }

            return entities;
        }
    }
}
