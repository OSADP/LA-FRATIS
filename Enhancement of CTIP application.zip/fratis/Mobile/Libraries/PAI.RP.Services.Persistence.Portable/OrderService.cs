﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IOrderService : IUserDataServiceBaseAsync<Order>
    {
    }

    public class OrderService : UserDataServiceBaseAsync<Order>, IOrderService
    {
        public OrderService(IRepository<Order> repository)
            : base(repository)
        {
        }

        private static void ExtractDerivedDataToEntity(Order order)
        {
            if (order != null)
            {
                var orderDerivedData = JsonConvert.DeserializeObject<OrderDerivedData>(order.DerivedData);
                order.Notes = orderDerivedData.Notes;
                order.Locations = orderDerivedData.Locations;
                order.CustomFields = orderDerivedData.CustomFields;
                order.OrderStatusTimes = orderDerivedData.OrderStatusTimes;
                order.RouteStops = orderDerivedData.RouteStops;
            }
        }

        private static void CompressEntityToDerivedData(Order order)
        {
            if (order != null)
            {
                var derivedData = new OrderDerivedData
                {
                    Notes = order.Notes,
                    Locations = order.Locations,
                    CustomFields = order.CustomFields,
                    OrderStatusTimes = order.OrderStatusTimes,
                    RouteStops = order.RouteStops
                };
                order.DerivedData = JsonConvert.SerializeObject(derivedData);
            }
        }

        public override async Task<IList<Order>> GetAsync(IEnumerable<Expression<Func<Order, bool>>> predicates,
            IEnumerable<OrderByRequest<Order>> orderByRequests, CancellationToken cancellationToken)
        {
            var orders = await base.GetAsync(predicates, orderByRequests, cancellationToken);
            foreach (var order in orders)
            {
                ExtractDerivedDataToEntity(order);
            }

            return orders;
        }

        public override async Task<IList<Order>> GetAsync(Expression<Func<Order, bool>> predicate, OrderByRequest<Order> orderByRequest,
            CancellationToken cancellationToken)
        {
            var orders = await base.GetAsync(predicate, orderByRequest, cancellationToken);
            foreach (var order in orders)
            {
                ExtractDerivedDataToEntity(order);
            }

            return orders;
        }

        public override async Task<IEnumerable<Order>> GetByUserAsync(string subscriberId, string userId,
            IEnumerable<Expression<Func<Order, bool>>> predicates, IEnumerable<OrderByRequest<Order>> orderByRequests,
            CancellationToken cancellationToken)
        {
            var orders = await base.GetByUserAsync(subscriberId, userId, predicates, orderByRequests, cancellationToken);
            foreach (var order in orders)
            {
                ExtractDerivedDataToEntity(order);
            }

            return orders;
        }

        public override async Task<Order> GetByIdAsync(string id, CancellationToken token)
        {
            var order = await base.GetByIdAsync(id, token);
            ExtractDerivedDataToEntity(order);

            return order;
        }

        public override async Task<IEnumerable<Order>> SaveAsync(IEnumerable<Order> entities, CancellationToken token)
        {
            foreach (var entity in entities)
            {
                CompressEntityToDerivedData(entity);
            }

            return await base.SaveAsync(entities, token);
        } 
    }
}
