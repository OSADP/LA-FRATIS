﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IUserSettingsService : IUserDataServiceBaseAsync<UserSettings>
    {
    }

    public class UserSettingsService : UserDataServiceBaseAsync<UserSettings>, IUserSettingsService
    {
        public UserSettingsService(IRepository<UserSettings> repository) : base(repository)
        {
        }

        private async Task<UserSettings> GetUserSettings(string subscriberId, string userId, CancellationToken cancellationToken)
        {
            return (await GetByUserAsync(subscriberId, userId, null, null, cancellationToken)).FirstOrDefault();
        }

        public async override Task<UserSettings> SaveAsync(UserSettings entity, CancellationToken token)
        {
            if (string.IsNullOrWhiteSpace(entity.SubscriberId) || string.IsNullOrWhiteSpace(entity.UserId))
            {
                throw new ArgumentException("Entity parameter must have a supplied SubscriberId and UserId.", "entity");
            }

            var userSettings = await GetUserSettings(entity.SubscriberId, entity.UserId, token);

            if (userSettings == null)
            {
                return await base.SaveAsync(entity, token);
            }
            userSettings.LastSynchronizationDate = entity.LastSynchronizationDate;
            return await base.SaveAsync(userSettings, token);
        }
    }
}
