﻿using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface ICustomerService : IDataServiceBaseAsync<Customer>
    {

    }

    public class CustomerService : DataServiceBaseAsync<Customer>, ICustomerService
    {
        public CustomerService(IRepository<Customer> repository)
            : base(repository)
        {
        }
    }
}
