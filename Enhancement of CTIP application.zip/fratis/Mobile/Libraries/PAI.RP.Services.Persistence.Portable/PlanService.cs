﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IPlanService : IUserDataServiceBaseAsync<Plan>
    {

    }

    public class PlanService : UserDataServiceBaseAsync<Plan>, IPlanService
    {
        public PlanService(IRepository<Plan> repository)
            : base(repository)
        {
        }

        private static void ExtractDerivedDataToEntity(Plan plan)
        {
            if (plan != null)
            {
                var derivedData = JsonConvert.DeserializeObject<PlanDerivedData>(plan.DerivedData);
                plan.OrderIds = derivedData.OrderIds;
                plan.UncommittedOrderIds = derivedData.UncommittedOrderIds;
                plan.PlanStatusTimes = derivedData.PlanStatusTimes;
            }
        }

        private static void CompressEntityToDerivedData(Plan plan)
        {
            if (plan != null)
            {
                var derivedData = new PlanDerivedData
                {
                    OrderIds = plan.OrderIds,
                    UncommittedOrderIds = plan.UncommittedOrderIds,
                    PlanStatusTimes = plan.PlanStatusTimes
                };
                plan.DerivedData = JsonConvert.SerializeObject(derivedData);
            }
        }

        public override async Task<IList<Plan>> GetAsync(IEnumerable<Expression<Func<Plan, bool>>> predicates,
            IEnumerable<OrderByRequest<Plan>> orderByRequests, CancellationToken cancellationToken)
        {
            var entities = await base.GetAsync(predicates, orderByRequests, cancellationToken);
            foreach (var entity in entities)
            {
                ExtractDerivedDataToEntity(entity);
            }

            return entities;
        }

        public override async Task<IList<Plan>> GetAsync(Expression<Func<Plan, bool>> predicate, OrderByRequest<Plan> orderByRequest,
            CancellationToken cancellationToken)
        {
            var entities = await base.GetAsync(predicate, orderByRequest, cancellationToken);
            foreach (var entity in entities)
            {
                ExtractDerivedDataToEntity(entity);
            }

            return entities;
        }

        public override async Task<IEnumerable<Plan>> GetByUserAsync(string subscriberId, string userId,
            IEnumerable<Expression<Func<Plan, bool>>> predicates, IEnumerable<OrderByRequest<Plan>> orderByRequests,
            CancellationToken cancellationToken)
        {
            var entities = await base.GetByUserAsync(subscriberId, userId, predicates, orderByRequests, cancellationToken);
            foreach (var entity in entities)
            {
                ExtractDerivedDataToEntity(entity);
            }

            return entities;
        }

        public override async Task<Plan> GetByIdAsync(string id, CancellationToken token)
        {
            var entity = await base.GetByIdAsync(id, token);
            ExtractDerivedDataToEntity(entity);

            return entity;
        }

        public override async Task<IEnumerable<Plan>> SaveAsync(IEnumerable<Plan> entities, CancellationToken token)
        {
            foreach (var entity in entities)
            {
                CompressEntityToDerivedData(entity);
            }

            return await base.SaveAsync(entities, token);
        } 
    }
}
