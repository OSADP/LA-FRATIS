﻿using System;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IGeolocationService : IUserDataServiceBaseAsync<Geolocation>
    {

    }

    public class GeolocationService : UserDataServiceBaseAsync<Geolocation>, IGeolocationService
    {
        public GeolocationService(IRepository<Geolocation> repository)
            : base(repository)
        {
        }
    }
}
