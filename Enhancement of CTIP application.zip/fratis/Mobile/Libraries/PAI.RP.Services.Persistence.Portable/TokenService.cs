﻿using System;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface ITokenService : IDataServiceBaseAsync<Token>
    {
        
    }

    public class TokenService : DataServiceBaseAsync<Token>, ITokenService
    {
        public TokenService(IRepository<Token> repository) : base(repository)
        {
        }
    }
}
