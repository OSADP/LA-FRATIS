﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;

namespace PAI.RP.Services.Persistence.Portable
{
    public interface IGeneralPreferenceService : IDataServiceBaseAsync<GeneralPreference>
    {
    }

    public class GeneralPreferenceService : DataServiceBaseAsync<GeneralPreference>, IGeneralPreferenceService
    {
        private readonly IRepository<GeneralPreference> _repository;

        public GeneralPreferenceService(IRepository<GeneralPreference> repository)
            : base(repository)
        {
            _repository = repository;
        }

        public override async Task<IEnumerable<GeneralPreference>> SaveAsync(IEnumerable<GeneralPreference> entities, CancellationToken token)
        {
            foreach (var generalPreference in entities)
            {
                var subscriberId = generalPreference.SubscriberId;
                var res = (await GetAsync(x => x.SubscriberId == subscriberId, null, token)).FirstOrDefault();
                if (res == null)
                {
                    generalPreference.Id = Guid.NewGuid().ToString();
                    await _repository.InsertAsync(generalPreference, token);
                }
                else
                {
                    generalPreference.Id = res.Id;
                    await _repository.UpdateAsync(generalPreference, token);
                }
            }

            return entities;
        }
    }
}
