﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Data;
using PAI.Common.Core.Data.Portable;
using SQLite.Net;
using SQLite.Net.Async;
using SQLite.Net.Interop;

namespace PAI.RP.Data.Portable
{
    public class SQLiteRepositoryAsync<TEntity> : IRepository<TEntity> where TEntity : class, IEntity, IMobileStorageCompatible, new()
    {
        private readonly SQLiteAsyncConnection _connection;
        private bool _tableCreated;

        public SQLiteRepositoryAsync(ISQLitePlatform sqLitePlatform, IPathConfig pathConfig)
        {
            _connection = new SQLiteAsyncConnection(() => new SQLiteConnectionWithLock(sqLitePlatform, new SQLiteConnectionString(pathConfig.DatabasePath, false)));
            _tableCreated = false;
        }

        private async Task CreateTableAsync()
        {
            if (!_tableCreated)
            {
                await _connection.CreateTableAsync<TEntity>();
                _tableCreated = true;
            }
        }

        public async Task<IList<TEntity>> GetAsync(IEnumerable<Expression<Func<TEntity, bool>>> predicates,
            IEnumerable<OrderByRequest<TEntity>> orderByRequests, CancellationToken cancellationToken)
        {
            //TODO - Test to make sure this works with multiple Where clauses and multiple OrderBy statements
            await CreateTableAsync();
            var query = _connection.Table<TEntity>();
            if (predicates != null)
            {
                foreach (var predicate in predicates.Where(x => x != null))
                {
                    query = query.Where(predicate);
                }
            }
            if (orderByRequests != null)
            {
                var orderByCount = 0;
                foreach (var orderByRequest in orderByRequests.Where(orderByRequest => orderByRequest != null && orderByRequest.Expression != null))
                {
                    ++orderByCount;
                    if (orderByCount == 1)
                    {
                        query = orderByRequest.Direction == OrderByDirection.Ascending
                            ? query.OrderBy(orderByRequest.Expression)
                            : query.OrderByDescending(orderByRequest.Expression);
                    }
                    else
                    {
                        query = orderByRequest.Direction == OrderByDirection.Ascending
                            ? query.ThenBy(orderByRequest.Expression)
                            : query.ThenByDescending(orderByRequest.Expression);
                    }
                }
            }
            return await query.ToListAsync();
        }

        public async Task<IList<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate,
            OrderByRequest<TEntity> orderByRequest, CancellationToken cancellationToken)
        {
            //TODO - Verify this method works
            return await GetAsync(new Expression<Func<TEntity, bool>>[1]{predicate}, new OrderByRequest<TEntity>[1]{orderByRequest}, cancellationToken);
        }

        public async Task<TEntity> GetByIdAsync(string id, CancellationToken token)
        {
            await CreateTableAsync();
            return await _connection.FindAsync<TEntity>(id);
        }

        public async Task<TEntity> GetOneByAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken token)
        {
            await CreateTableAsync();
            return await _connection.FindAsync(predicate);
        }

        public async Task<TEntity> InsertAsync(TEntity entity, CancellationToken token)
        {
            await CreateTableAsync();
            await _connection.InsertAsync(entity);
            return entity;
        }

        public async Task InsertAsync(IEnumerable<TEntity> entities, CancellationToken token)
        {
            await CreateTableAsync();
            await _connection.InsertAllAsync(entities);
        }

        public async Task<TEntity> UpdateAsync(TEntity entity, CancellationToken token)
        {
            await UpdateAsync(new TEntity[1] {entity}, token);

            return entity;
        }

        public async Task<IEnumerable<TEntity>> UpdateAsync(IEnumerable<TEntity> entities, CancellationToken token)
        {
            await CreateTableAsync();
            foreach (var entity in entities)
            {
                await _connection.UpdateAsync(entity);
            }
            return entities;
        }

        public async Task DeleteAsync(TEntity entity, CancellationToken token)
        {
            await CreateTableAsync();
            await _connection.DeleteAsync(entity);
        }

        public async Task DeleteAsync(string id, CancellationToken token)
        {
            await CreateTableAsync();
            await _connection.DeleteAsync<TEntity>(id);
        }

        public async Task DeleteAsync(IEnumerable<string> ids, CancellationToken token)
        {
            await CreateTableAsync();
            foreach (var id in ids)
            {
                await _connection.DeleteAsync<TEntity>(id);
            }
        }
    }
}
