using System;
using Android.Runtime;

namespace Com.Alk.Sdk
{
    public partial class AlkMsg
    {
        static IntPtr id_Msg_TripAddStopWithHouseNum_ILjava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_IIILjava_lang_String_Ljava_lang_String_Ljava_lang_String_I;
        // Metadata.xml XPath method reference: path="/api/package[@name='com.alk.sdk']/class[@name='AlkMsg']/method[@name='Msg_TripAddStopWithHouseNum' and count(parameter)=15 and parameter[1][@type='int'] and parameter[2][@type='java.lang.String'] and parameter[3][@type='java.lang.String'] and parameter[4][@type='java.lang.String'] and parameter[5][@type='java.lang.String'] and parameter[6][@type='java.lang.String'] and parameter[7][@type='java.lang.String'] and parameter[8][@type='java.lang.String'] and parameter[9][@type='int'] and parameter[10][@type='int'] and parameter[11][@type='int'] and parameter[12][@type='java.lang.String'] and parameter[13][@type='java.lang.String'] and parameter[14][@type='java.lang.String'] and parameter[15][@type='int']]"
        [Register("Msg_TripAddStopWithHouseNum", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)I", "")]
        public static int Msg_TripAddStopWithHouseNum(int p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, int p8, int p9, int p10, string p11, string p12, string p13, int p14)
        {
            if (id_Msg_TripAddStopWithHouseNum_ILjava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_IIILjava_lang_String_Ljava_lang_String_Ljava_lang_String_I == IntPtr.Zero)
                id_Msg_TripAddStopWithHouseNum_ILjava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_IIILjava_lang_String_Ljava_lang_String_Ljava_lang_String_I = JNIEnv.GetStaticMethodID(class_ref, "Msg_TripAddStopWithHouseNum", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)I");
            IntPtr native_p1 = JNIEnv.NewString(p1);
            IntPtr native_p2 = JNIEnv.NewString(p2);
            IntPtr native_p3 = JNIEnv.NewString(p3);
            IntPtr native_p4 = JNIEnv.NewString(p4);
            IntPtr native_p5 = JNIEnv.NewString(p5);
            IntPtr native_p6 = JNIEnv.NewString(p6);
            IntPtr native_p7 = JNIEnv.NewString(p7);
            IntPtr native_p11 = JNIEnv.NewString(p11);
            IntPtr native_p12 = JNIEnv.NewString(p12);
            IntPtr native_p13 = JNIEnv.NewString(p13);
            int __ret = JNIEnv.CallStaticIntMethod(class_ref, id_Msg_TripAddStopWithHouseNum_ILjava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_Ljava_lang_String_IIILjava_lang_String_Ljava_lang_String_Ljava_lang_String_I, new JValue(p0), new JValue(native_p1), new JValue(native_p2), new JValue(native_p3), new JValue(native_p4), new JValue(native_p5), new JValue(native_p6), new JValue(native_p7), new JValue(p8), new JValue(p9), new JValue(p10), new JValue(native_p11), new JValue(native_p12), new JValue(native_p13), new JValue(p14));
            JNIEnv.DeleteLocalRef(native_p1);
            JNIEnv.DeleteLocalRef(native_p2);
            JNIEnv.DeleteLocalRef(native_p3);
            JNIEnv.DeleteLocalRef(native_p4);
            JNIEnv.DeleteLocalRef(native_p5);
            JNIEnv.DeleteLocalRef(native_p6);
            JNIEnv.DeleteLocalRef(native_p7);
            JNIEnv.DeleteLocalRef(native_p11);
            JNIEnv.DeleteLocalRef(native_p12);
            JNIEnv.DeleteLocalRef(native_p13);
            return __ret;
        }
    }
}