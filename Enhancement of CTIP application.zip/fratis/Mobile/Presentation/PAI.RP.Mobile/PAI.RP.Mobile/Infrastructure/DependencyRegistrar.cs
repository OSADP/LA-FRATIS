﻿using PAI.Common.Core.Data.Portable;
using PAI.RP.Data.Portable;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Services.Controls;
using PAI.RP.Mobile.Views.Landscape;
using PAI.RP.Mobile.Views.Portrait;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Cache.Portable;
using PAI.RP.Services.Portable.Locale;
using TinyIoC;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Infrastructure
{
    public static class DependencyRegistrar
    {
        public static void Load()
        {
            var container = TinyIoCContainer.Current;
            UserAuthentication.AuthenticationProvider = new AuthenticationProvider();

            //Set the Vendor and Localization
            container.Register<IVendorType, VendorType>(new VendorType(VendorTypeOption.Rp));
            container.Register<ILocalizationService, LocalizationService>();

            //Pages
            container.Register<IPage, LoginPageLandscape>(PageType.Login.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            //container.Register<IPage, OrderRouteStopsLandscape>(PageType.OrderRouteStops.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            container.Register<IPage, LoginPagePortrait>(PageType.Login.ToString() + PageOrientation.Portrait.ToString()).AsMultiInstance();
            container.Register<IPage, DashboardLandscape>(PageType.Dashboard.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            container.Register<IPage, OrderPlansPageLandscape>(PageType.OrderPlans.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            container.Register<IPage, OrderPlansPagePortrait>(PageType.OrderPlans.ToString() + PageOrientation.Portrait.ToString()).AsMultiInstance();
            container.Register<IPage, OrdersPlanDetailPageLandscape>(PageType.OrdersPlanDetail.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            container.Register<IPage, OrdersPlanDetailPagePortrait>(PageType.OrdersPlanDetail.ToString() + PageOrientation.Portrait.ToString()).AsMultiInstance();
            container.Register<IPage, OrderDetailPageLandscape>(PageType.OrderDetail.ToString() + PageOrientation.Landscape.ToString()).AsMultiInstance();
            container.Register<IPage, OrderDetailPagePortrait>(PageType.OrderDetail.ToString() + PageOrientation.Portrait.ToString()).AsMultiInstance();
            container.Register<IPage, StartOrderReasonShared>(PageType.StartOrderReason.ToString() + PageOrientation.Shared.ToString()).AsMultiInstance();
            container.Register<IPage, ResetPasswordShared>(PageType.ResetPassword.ToString() + PageOrientation.Shared.ToString()).AsMultiInstance();
            container.Register<IPage, ChangePasswordShared>(PageType.ChangePassword.ToString() + PageOrientation.Shared.ToString()).AsMultiInstance();
            //TODO - Remove after CoPilot Integration Testing
            container.Register<IPage, CoPilotDemoShared>(PageType.CoPilotDemo.ToString() + PageOrientation.Shared.ToString()).AsMultiInstance();

            //Page Services
            container.Register<IPageService, LoginPageService>(PageType.Login.ToString()).AsMultiInstance();
            container.Register<IPageService, OrderPlansPageService>(PageType.OrderPlans.ToString()).AsMultiInstance();
            container.Register<IPageService, OrdersPlanDetailPageService>(PageType.OrdersPlanDetail.ToString()).AsMultiInstance();
            container.Register<IPageService, OrderDetailPageService>(PageType.OrderDetail.ToString()).AsMultiInstance();

            //Control Services
            container.Register<IPickerService<OrderStatus>, PickerService<OrderStatus>>().AsMultiInstance();
            container.Register<IPickerService<string>, PickerService<string>>().AsMultiInstance();

            //Repository
            container.Register<IRepository<Geolocation>, SQLiteRepositoryAsync<Geolocation>>();
            container.Register<IRepository<Plan>, SQLiteRepositoryAsync<Plan>>();
            container.Register<IRepository<Order>, SQLiteRepositoryAsync<Order>>();
            
            container.Register<IRepository<UserSettings>, SQLiteRepositoryAsync<UserSettings>>();
            container.Register<IRepository<CustomFieldPreference>, SQLiteRepositoryAsync<CustomFieldPreference>>();
            container.Register<IRepository<Customer>, SQLiteRepositoryAsync<Customer>>();
            container.Register<IRepository<GeneralPreference>, SQLiteRepositoryAsync<GeneralPreference>>();

            //Cache Services
            container.Register<ICacheService<Geolocation>, CacheService<Geolocation>>();
            container.Register<ICacheService<Plan>, CacheService<Plan>>();
            container.Register<ICacheService<Order>, CacheService<Order>>();
            container.Register<ICacheService<UserSettings>, CacheService<UserSettings>>();
            container.Register<ICacheService<CustomFieldPreference>, CacheService<CustomFieldPreference>>();
            container.Register<ICacheService<Customer>, CacheService<Customer>>();
            container.Register<ICacheService<GeneralPreference>, CacheService<GeneralPreference>>();

            //Data Services
            container.Register<RP.Services.Persistence.Portable.ITokenService, RP.Services.Persistence.Portable.TokenService>();
            container.Register<RP.Services.Persistence.Portable.IGeolocationService, RP.Services.Persistence.Portable.GeolocationService>();
            container.Register<RP.Services.Persistence.Portable.IUserDataServiceBaseAsync<Geolocation>, RP.Services.Persistence.Portable.GeolocationService>();
            container.Register<RP.Services.Persistence.Portable.IPlanService, RP.Services.Persistence.Portable.PlanService>();
            container.Register<RP.Services.Persistence.Portable.IUserDataServiceBaseAsync<Plan>, RP.Services.Persistence.Portable.PlanService>();
            container.Register<RP.Services.Persistence.Portable.IOrderService, RP.Services.Persistence.Portable.OrderService>();
            container.Register<RP.Services.Persistence.Portable.IUserDataServiceBaseAsync<Order>, RP.Services.Persistence.Portable.OrderService>();
            container.Register<RP.Services.Persistence.Portable.IUserSettingsService, RP.Services.Persistence.Portable.UserSettingsService>();
            container.Register<RP.Services.Persistence.Portable.IUserDataServiceBaseAsync<UserSettings>, RP.Services.Persistence.Portable.UserSettingsService>();
            container.Register<RP.Services.Persistence.Portable.ICustomFieldPreferencesService, RP.Services.Persistence.Portable.CustomFieldPreferencesService>();
            container.Register<RP.Services.Persistence.Portable.IDataServiceBaseAsync<CustomFieldPreference>, RP.Services.Persistence.Portable.CustomFieldPreferencesService>();
            container.Register<RP.Services.Persistence.Portable.IDataServiceBaseAsync<Customer>, RP.Services.Persistence.Portable.CustomerService>();
            container.Register<RP.Services.Persistence.Portable.IGeneralPreferenceService, RP.Services.Persistence.Portable.GeneralPreferenceService>();
            container.Register<RP.Services.Persistence.Portable.IDataServiceBaseAsync<GeneralPreference>, RP.Services.Persistence.Portable.GeneralPreferenceService>();

            //REST Services
            //To setup local develoment with emulator:
            //0. Comment out the //Dev and uncomment the Local IIS Dev below (BUT DONT COMMIT YOUR CHANGE, KEEP IT LOCALLY !!)
            //1. Port must be 44301
            //2. Go to .vs\config, edit the applicationhost.config file and add a new <binding> under <bindings> for PAI.FRATIS.SFL.Web application:
            //   <binding protocol="https" bindingInformation="44301:{your_computer_name}" />
            //   Substitute {your_computer_name} with your computer name.
            //3. If you have UAC or not an admin make sure the url acl is open for that url from step 2 (read more on the internet how to setup url acl)

            //container.Register<IRestClientProvider>(new RestClientProvider { BaseUrl = "https://desktop-t4nblq0:44301/", ApiVersion = "v1" });//Local IIS Dev
            //container.Register<IRestClientProvider>(new RestClientProvider { BaseUrl = "https://fratis.azurewebsites.net/", ApiVersion = "v1" });//Dev
            container.Register<IRestClientProvider>(new RestClientProvider { BaseUrl = "https://la.fratis.net/", ApiVersion = "v1" });//QA
            //container.Register<IRestClientProvider>(new RestClientProvider { BaseUrl = "https://fratisorlando.productivityapex.com/", ApiVersion = "v1" });//Production

            container.Register<RP.Services.Rest.Portable.IRestClientFactory, RP.Services.Rest.Portable.RestClientFactory>();
            container.Register<IAuthenticationProvider>((c,p) => UserAuthentication.AuthenticationProvider);
            container.Register<RP.Services.Rest.Portable.Customers.ICustomerService, RP.Services.Rest.Portable.Customers.CustomerService>();
            container.Register<RP.Services.Rest.Portable.Subscribers.IUserService, RP.Services.Rest.Portable.Subscribers.UserService>();
            container.Register<RP.Services.Rest.Portable.Planning.IPlanService, RP.Services.Rest.Portable .Planning.PlanService>();
            container.Register<RP.Services.Rest.Portable.IUserRestServiceBase<Plan>, RP.Services.Rest.Portable.Planning.PlanService>();
            container.Register<RP.Services.Rest.Portable.Orders.IOrderService, RP.Services.Rest.Portable.Orders.OrderService>();
            container.Register<RP.Services.Rest.Portable.IUserRestServiceBase<Order>, RP.Services.Rest.Portable.Orders.OrderService>();
            container.Register<RP.Services.Rest.Portable.Geography.IGeolocationService, RP.Services.Rest.Portable.Geography.GeolocationService>();
            container.Register<RP.Services.Rest.Portable.IUserRestServiceBase<Geolocation>, RP.Services.Rest.Portable.Geography.GeolocationService>();
            container.Register<RP.Services.Rest.Portable.Authentication.IAuthenticationService, RP.Services.Rest.Portable.Authentication.AuthenticationService>();
            container.Register<RP.Services.Rest.Portable.Messaging.IMessageService, RP.Services.Rest.Portable.Messaging.MessageService>();
            container.Register<RP.Services.Rest.Portable.Subscribers.ICustomFieldPreferencesService, RP.Services.Rest.Portable.Subscribers.CustomFieldPreferencesService>();
            container.Register<RP.Services.Rest.Portable.IEntityRestServiceBase<CustomFieldPreference>, RP.Services.Rest.Portable.Subscribers.CustomFieldPreferencesService>();
            container.Register<RP.Services.Rest.Portable.Setting.IGeneralPreferenceServiceService, RP.Services.Rest.Portable.Setting.GeneralPreferenceService>();
            container.Register<RP.Services.Rest.Portable.IEntityRestServiceBase<GeneralPreference>, RP.Services.Rest.Portable.Setting.GeneralPreferenceService>();

            //App Services
            var alkMsg = DependencyService.Get<IAlkMsg>();
            container.Register<IAlkMsg>(alkMsg);
            var geolocator = DependencyService.Get<IGeolocator>();
            container.Register<IGeolocator>(geolocator);
            container.Register<IGeolocatorService, GeolocatorService>();
            var nativeMap = DependencyService.Get<INativeMap>();
            container.Register<INativeMap>(nativeMap);
            var localNotification = DependencyService.Get<ILocalNotification>();
            container.Register<ILocalNotification>(localNotification);
            container.Register<IPollingService, PollingService>();
            container.Register<IMapperService, MapperService>();
            container.Register<RP.Services.Portable.IUserDatedDataService<Geolocation>, RP.Services.Portable.UserDatedDataService<Geolocation>>();
            container.Register<RP.Services.Portable.IUserRestService<Geolocation>, RP.Services.Portable.UserRestService<Geolocation>>();
            container.Register<RP.Services.Portable.IUserDatedDataService<Plan>, RP.Services.Portable.UserDatedDataService<Plan>>();
            container.Register<RP.Services.Portable.IUserRestService<Plan>, RP.Services.Portable.UserRestService<Plan>>();
            container.Register<RP.Services.Portable.IUserDatedDataService<Order>, RP.Services.Portable.UserDatedDataService<Order>>();
            container.Register<RP.Services.Portable.IUserRestService<Order>, RP.Services.Portable.UserRestService<Order>>();
            container.Register<RP.Services.Portable.IUserDataService<UserSettings>, RP.Services.Portable.UserDataService<UserSettings>>();
            container.Register<RP.Services.Portable.IDataService<CustomFieldPreference>, RP.Services.Portable.DataService<CustomFieldPreference>>();
            container.Register<RP.Services.Portable.IRestService<CustomFieldPreference>, RP.Services.Portable.RestService<CustomFieldPreference>>();
            container.Register<RP.Services.Portable.IDataService<GeneralPreference>, RP.Services.Portable.DataService<GeneralPreference>>();
            container.Register<RP.Services.Portable.IRestService<GeneralPreference>, RP.Services.Portable.RestService<GeneralPreference>>();
            container.Register<RP.Services.Portable.IDataService<Customer>, RP.Services.Portable.DataService<Customer>>();
            container.Register<RP.Services.Portable.Planning.IPlanService, RP.Services.Portable.Planning.PlanService>();
            container.Register<RP.Services.Portable.Planning.IPlanUserDataService, RP.Services.Portable.Planning.PlanUserDataService>();
            container.Register<RP.Services.Portable.Orders.IOrderService, RP.Services.Portable.Orders.OrderService>();            
            container.Register<RP.Services.Portable.Geography.IGeolocationService, RP.Services.Portable.Geography.GeolocationService>();
            container.Register<RP.Services.Portable.Subscribers.IUserSettingsService, RP.Services.Portable.Subscribers.UserSettingsService>();
            container.Register<RP.Services.Portable.Subscribers.ICustomFieldPreferencesService, RP.Services.Portable.Subscribers.CustomFieldPreferencesService>();
            container.Register<RP.Services.Portable.Setting.IGeneralPreferenceService, RP.Services.Portable.Setting.GeneralPreferenceService>();
            container.Register<RP.Services.Portable.Customer.ICustomerService, RP.Services.Portable.Customer.CustomerService>();
            container.Register<IStyleService, StyleService>();
            container.Register<IServerProviderService, ServerProviderService>();
            container.Register<RP.Services.Portable.Messaging.IMessageService, RP.Services.Portable.Messaging.MessageService>();
            container.Register<RP.Services.Portable.Messaging.IMessageRequestBuilder, RP.Services.Portable.Messaging.MessageRequestBuilder>();
            container.Register<RP.Services.Portable.Messaging.IMessageResponseResolver, RP.Services.Portable.Messaging.MessageResponseResolver>();
            container.Register<RP.Services.Portable.Bridge.IDomainModelBridgeService, RP.Services.Portable.Bridge.DomainModelBridgeService>();
            container.Register<RP.Services.Portable.Authentication.IAuthenticationService, RP.Services.Portable.Authentication.AuthenticationService>();
            container.Register<RP.Services.Portable.Subscribers.IUserService, RP.Services.Portable.Subscribers.UserService>();
			container.Register<RP.Services.Portable.Threading.ILockManager, RP.Services.Portable.Threading.SlimLockManager>();
        }
    }
}
