﻿using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Rest.Portable.Model;
using CustomerViewModel = PAI.RP.Mobile.Model.CustomerViewModel;
using OrderLocationViewModel = PAI.RP.Mobile.Model.OrderLocationViewModel;
using OrderNoteViewModel = PAI.RP.Mobile.Model.OrderNoteViewModel;
using OrderStatusTimeViewModel = PAI.RP.Mobile.Model.OrderStatusTimeViewModel;
using OrderViewModel = PAI.RP.Mobile.Model.OrderViewModel;
using PasswordChangeResultViewModel = PAI.RP.Mobile.Model.PasswordChangeResultViewModel;
using PlanViewModel = PAI.RP.Mobile.Model.PlanViewModel;
using TimeWindowViewModel = PAI.RP.Mobile.Model.TimeWindowViewModel;

namespace PAI.RP.Mobile.Infrastructure
{
    public static class AutoMapperProfile
    {
        public static void CreateMappings()
        {
            Mapper.CreateMap<Customer, CustomerViewModel>();
            Mapper.CreateMap<CustomerViewModel, Customer>();

            Mapper.CreateMap<RouteStopLocation, LocationModelSlim>();
            Mapper.CreateMap<LocationModelSlim, RouteStopLocation>();

            Mapper.CreateMap<Customer, RP.Services.Rest.Portable.Model.CustomerViewModel>()
                .ForMember(x => x.Tags, x => x.Ignore())
                .ForSourceMember(x => x.Tags, x => x.Ignore())
                .ForMember(x => x.Location, x => x.Ignore());
            
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.CustomerViewModel, Customer>()
                .ForSourceMember(x => x.Tags, x => x.Ignore())
                .ForMember(x => x.Tags, x => x.Ignore())
                .ForSourceMember(x => x.Location, x => x.Ignore());

            Mapper.CreateMap<Plan, PlanViewModel>();
            Mapper.CreateMap<PlanViewModel, Plan>();

            Mapper.CreateMap<PlanStatusTime, RP.Services.Rest.Portable.Model.PlanDriverPlanStatusStampViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.PlanDriverPlanStatusStampViewModel, PlanStatusTime>();

            Mapper.CreateMap<Order, OrderViewModel>();
            Mapper.CreateMap<OrderViewModel, Order>();

            Mapper.CreateMap<RouteStop, RP.Services.Rest.Portable.Model.RouteStopViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.RouteStopViewModel, RouteStop>();

            Mapper.CreateMap<RouteStop, PAI.RP.Mobile.Model.RouteStopViewModel> ();
            Mapper.CreateMap<PAI.RP.Mobile.Model.RouteStopViewModel, RouteStop>();

            Mapper.CreateMap<LocationModelSlim, OrderLocation>();
            Mapper.CreateMap<OrderLocation, LocationModelSlim>();

            Mapper.CreateMap<Order, RP.Services.Rest.Portable.Model.OrderViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.OrderViewModel, Order>();

            Mapper.CreateMap<OrderViewModel, RP.Services.Rest.Portable.Model.PlanOrderViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.PlanOrderViewModel, OrderViewModel>();

            Mapper.CreateMap<Order, RP.Services.Rest.Portable.Model.PlanOrderViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.PlanOrderViewModel, Order>();

            Mapper.CreateMap<OrderNote, OrderNoteViewModel>();
            Mapper.CreateMap<OrderNoteViewModel, OrderNote>();

            Mapper.CreateMap<OrderNote, RP.Services.Rest.Portable.Model.OrderNoteViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.OrderNoteViewModel, OrderNote>();

            Mapper.CreateMap<OrderLocation, OrderLocationViewModel>();
            Mapper.CreateMap<OrderLocationViewModel, OrderLocation>();

            Mapper.CreateMap<OrderLocation, RP.Services.Rest.Portable.Model.OrderLocationViewModel>()
                //Map Service time manually
                .ForSourceMember(x => x.ServiceTime, x => x.Ignore())
                .ForMember(x => x.ServiceTime, x => x.Ignore());
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.OrderLocationViewModel, OrderLocation>()
                //Map Service time manually
                .ForSourceMember(x => x.ServiceTime, x => x.Ignore())
                .ForMember(x => x.ServiceTime, x => x.Ignore());

            Mapper.CreateMap<TimeWindow, TimeWindowViewModel>();
            Mapper.CreateMap<TimeWindowViewModel, TimeWindow>();

            Mapper.CreateMap<TimeWindow, RP.Services.Rest.Portable.Model.TimeWindowViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.TimeWindowViewModel, TimeWindow>();

            Mapper.CreateMap<CustomFieldPreference, RP.Services.Rest.Portable.Model.CustomFieldSchemaViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.CustomFieldSchemaViewModel, CustomFieldPreference>();

            Mapper.CreateMap<CustomFieldPreference, RP.Services.Rest.Portable.Model.CustomFieldPrefHashViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.CustomFieldPrefHashViewModel, CustomFieldPreference>();

            Mapper.CreateMap<OrderStatusTime, OrderStatusTimeViewModel>();
            Mapper.CreateMap<OrderStatusTimeViewModel, OrderStatusTime>();

            Mapper.CreateMap<OrderStatusTime, RP.Services.Rest.Portable.Model.OrderStatusTimeViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.OrderStatusTimeViewModel, OrderStatusTime>();

            Mapper.CreateMap<GeneralPreference, RP.Services.Rest.Portable.Model.SettingViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.SettingViewModel, GeneralPreference>();

            Mapper.CreateMap<GeneralPreference, RP.Services.Rest.Portable.Model.GeneralPrefsHashViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.GeneralPrefsHashViewModel, GeneralPreference>();

            Mapper.CreateMap<GeneralPreference, RP.Services.Rest.Portable.Model.GeneralPrefsViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.GeneralPrefsViewModel, GeneralPreference>();

            Mapper.CreateMap<PasswordChangeResultViewModel, RP.Services.Rest.Portable.Model.PasswordChangeResultViewModel>();
            Mapper.CreateMap<RP.Services.Rest.Portable.Model.PasswordChangeResultViewModel, PasswordChangeResultViewModel>();
        }
    }
}
