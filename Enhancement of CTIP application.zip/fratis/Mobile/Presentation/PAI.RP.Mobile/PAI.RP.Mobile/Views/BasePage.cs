﻿using System;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views
{
    public abstract class BasePage : ContentPage, IPage
    {
        public Page PageContext { get; set; }
        public PageType PageType { get; set; }
        public PageOrientation PageOrientation { get; set; }
        public double ScreenWidth { get; set; }
        public double ScreenHeight { get; set; }

        private readonly IGeolocator _geolocator;
        private readonly IStyleService _styleService;

        protected BasePage(IGeolocator geolocator, IStyleService styleService, ILocalizationService localizationService)
        {
            //Must assign the services and some setup before calling InitComponent() because the OnChildAdded() method fires directly after InitComponent()
            _geolocator = geolocator;
            _styleService = styleService;
            PageContext = this;
            InitComponent();

            //TODO - Create a localization for this title
            Title = localizationService.AppName;
            Icon = null;
            ToolbarItems.Add(new ToolbarItem("Settings", "", () => DisplayAlert(null, "Settings page coming soon.", "OK")));

            //TODO - Change all of the control font colors to black before applying this white background to the pages
            if (PageType != PageType.Login)
            {
                BackgroundColor = Color.FromRgb(238, 238, 238);
            }
        }

        public virtual async Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            //Default Implementation does nothing to the page
        }

        protected override void OnChildAdded(Element child)
        {
            base.OnChildAdded(child);

            if (PageType != PageType.Login)
            {
                _styleService.StylizeElement(child);
            }
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);

            ScreenWidth = width;
            ScreenHeight = height;
        }

        protected abstract void InitComponent();

        protected async Task<bool> TurnOnGpsAlert()
        {
            if (_geolocator.IsGeolocationAvailable && _geolocator.IsGeolocationEnabled)
            {
                return false;
            }

            await DisplayAlert("Please Enable GPS", "Please enable your GPS.", "OK");
            return true;
        }
    }
}