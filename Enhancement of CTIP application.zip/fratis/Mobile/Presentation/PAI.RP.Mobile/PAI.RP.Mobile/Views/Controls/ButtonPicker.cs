using System.Linq;
using System;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Views.Controls
{
    public class ButtonPicker : Picker
    {
    }
}