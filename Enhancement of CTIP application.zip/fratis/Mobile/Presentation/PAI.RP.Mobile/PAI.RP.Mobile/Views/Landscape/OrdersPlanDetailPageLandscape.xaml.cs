﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;


namespace PAI.RP.Mobile.Views.Landscape
{
    public partial class OrdersPlanDetailPageLandscape : OrdersPlanDetailPageShared
    {
        private Plan _entity;
        private readonly IPlanService _planService;
        private readonly IMapperService _mapperService;

        public OrdersPlanDetailPageLandscape(Plan entity, IGeolocator geolocator, IStyleService styleService
            , ILocalizationService localizationService, IMapperService mapperService,
            IOrderService orderService, IPlanService planService)
            : base(entity, geolocator, styleService, localizationService, mapperService, planService)
        {
            _entity = entity;
            _planService = planService;
            _mapperService = mapperService;
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrdersPlanDetail;
            PageOrientation = PageOrientation.Landscape;
            InitializeComponent();
        }
    }
}
