﻿using System;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Landscape
{
    public partial class LoginPageLandscape : LoginPageShared
    {
        private readonly IServerProviderService _serverProviderService;

        public LoginPageLandscape(IGeolocator geolocator,
            IStyleService styleService, ILocalizationService localizationService, IGeolocatorService geolocatorService, IServerProviderService serverProviderService) 
            : base(geolocator, styleService, localizationService, geolocatorService, serverProviderService)
        {
            _serverProviderService = serverProviderService;
        }

        protected override void InitComponent()
        {
            PageType = PageType.Login;
            PageOrientation = PageOrientation.Landscape;
            InitializeComponent();
        }

        private void ServerPicker_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedServer = ServerPicker.Items[ServerPicker.SelectedIndex];

            _serverProviderService.LoadServer(selectedServer);
        }

        public Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
