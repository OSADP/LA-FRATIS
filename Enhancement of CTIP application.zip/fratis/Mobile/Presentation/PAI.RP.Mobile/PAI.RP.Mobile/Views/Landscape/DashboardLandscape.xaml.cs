﻿using System;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Landscape
{
    public partial class DashboardLandscape : DashboardShared
    {
        public DashboardLandscape(IGeolocator geolocator, IStyleService styleService, ILocalizationService localizationService) 
            : base(geolocator, styleService, localizationService)
        {
        }

        protected override void InitComponent()
        {
            PageType = PageType.Dashboard;
            PageOrientation = PageOrientation.Landscape;
            InitializeComponent();
        }
    }
}
