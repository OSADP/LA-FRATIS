﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Landscape
{
    public partial class OrderPlansPageLandscape : OrderPlansPageShared
    {
        public OrderPlansPageLandscape(IGeolocator geolocator, RP.Services.Portable.Planning.IPlanService planRestService, 
            IStyleService styleService, ILocalizationService localizationService)
            : base(geolocator, planRestService, styleService, localizationService)
        {
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrderPlans;
            PageOrientation = PageOrientation.Landscape;
            InitializeComponent();
        }
    }    
}