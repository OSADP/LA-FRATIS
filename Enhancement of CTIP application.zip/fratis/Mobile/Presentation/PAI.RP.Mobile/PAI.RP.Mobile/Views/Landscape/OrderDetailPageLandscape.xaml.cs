﻿using System;
using System.Linq;
using System.Threading;
using AutoMapper;
using AutoMapper.Mappers;
using PAI.RP.Compatibility.Portable;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Subscribers;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Landscape
{
    public partial class OrderDetailPageLandscape : OrderDetailPageShared
    {
        private readonly Order _entity;
        private readonly IPlanService _planService;
        private readonly IOrderService _orderService;
        private readonly IMapperService _mapperService;
        private IAlkMsg _alkMsg;
        //public Label EtaLabel;

        public OrderDetailPageLandscape(Order entity, IGeolocator geolocator, IStyleService styleService,
            ILocalizationService localizationService, IPlanService planService, IOrderService orderService,
            ICustomFieldPreferencesService customFieldPreferencesService, IAuthenticationProvider authenticationProvider, IMapperService mapperService)
            : base(entity, geolocator, styleService, localizationService, planService, orderService, customFieldPreferencesService, authenticationProvider, mapperService)
        {
            _entity = entity;
            _planService = planService;
            _orderService = orderService;
            _mapperService = mapperService;
            _alkMsg = TinyIoC.TinyIoCContainer.Current.Resolve<IAlkMsg>();

            //EtaLabel = this.FindByName<Label>("EtaLabel");
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrderDetail;
            PageOrientation = PageOrientation.Landscape;
            InitializeComponent();
        }
       
        private async void RouteStopList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;
            
            

            if (await TurnOnGpsAlert()) return;

            var routeStopViewModel = (RouteStopViewModel)e.SelectedItem;
            var routeStop = Mapper.Map<RouteStopViewModel, RouteStop>(routeStopViewModel);
            var order = await _orderService.GetOrderLocallyAsync(_entity.Id, CancellationToken.None);
            var routeStops = await _orderService.GetAllRouteStopsForTheOrderAsync(order, CancellationToken.None);
            var allOrders = await _orderService.GetAllOrdersForThePlanAsync(_entity.PlanId, CancellationToken.None);
            var currentPlan = await _planService.GetPlanLocallyAsync(order.PlanId, CancellationToken.None);

            

            if (allOrders.Where(x => x.Status != OrderStatus.Completed && x.Id != routeStop.JobId.ToString()).Any(orders => orders.RouteStops.Any(x => x.RouteStopStatus >= RouteStopStatus.EnRoute)))
            {
                await DisplayAlert("WARNING", "There are other orders already In Progress. Please complete them before executing another Order", "Accept", "Cancel");
                return;
            }

            if (routeStopViewModel.SortOrder > 1)
            {
                var previousRouteStopIndex = routeStopViewModel.SortOrder - 1;
                var previousRouteStop = routeStops[previousRouteStopIndex - 1];
                if (previousRouteStop.RouteStopStatus != RouteStopStatus.Completed)
                {
                    await DisplayAlert("WARNING", "You cant execute out of sequence Stops", "Accept", "Cancel");
                    return;
                }
            }

            
            if (routeStopViewModel.RouteStopStatus == RouteStopStatus.Active)
            {

                if (currentPlan.Status == PlanStatus.Received)
                {                    
                        await
                            DisplayAlert("READ ONLY", "You can only view this plan since you have not started it", "OK",
                                "CANCEL");
                    return;

                }

                var goToRouteStop =
                    await DisplayAlert("Go to stop", "Would you like to go to your stop", "Yes", "No");
                if (!goToRouteStop) return;

                var result = await _orderService.EnRouteRouteStop(order, CancellationToken.None);
                var anyRouteStopsEnRoute =
                    await _orderService.AnotherRouteStopIsAlreadyEnRouteAsync(result, CancellationToken.None);
                var allRouteStops = await _orderService.GetAllRouteStopsForTheOrderAsync(result, CancellationToken.None);

                if (anyRouteStopsEnRoute && !allRouteStops.Any(x => x.RouteStopStatus >= RouteStopStatus.InProgress))
                {
                    result.Status = OrderStatus.EnRoute;

                }
                await _orderService.SaveOrderAsync(result, CancellationToken.None);
            }



            else if (routeStopViewModel.RouteStopStatus == RouteStopStatus.EnRoute)
            {
                var startRouteStop =
                       await DisplayAlert("Start stop", "Would you like to start your stop", "Yes", "No");

                if (!startRouteStop) return;
                var result = await _orderService.InProgressRouteStop(order, CancellationToken.None);
                var anyInProgressRouteStops = await _orderService.AnotherRouteStopIsAlreadyInProgressAsync(order,
                    CancellationToken.None);

                if (anyInProgressRouteStops)
                {
                    result.Status = OrderStatus.InProgress;
                    await _orderService.StartOrderAsync(result, CancellationToken.None);
                }

                await _orderService.SaveOrderAsync(result, CancellationToken.None);




            }

            else if (routeStopViewModel.RouteStopStatus == RouteStopStatus.InProgress)
            {

                var completeRouteStop =
                       await DisplayAlert("Complete stop", "Would you like to complete your stop", "Yes", "No");

                if (!completeRouteStop) return;

                var result = await _orderService.CompleteRouteStop(order, CancellationToken.None);
                await _orderService.SaveOrderAsync(result, CancellationToken.None);

                var allRouteStops =
                    await _orderService.GetAllRouteStopsForTheOrderAsync(order, CancellationToken.None);



                if (allRouteStops.All(x => x.RouteStopStatus == RouteStopStatus.Completed))
                {
                    result.Status = OrderStatus.Completed;
                    await _orderService.CompleteOrderAsync(result, CancellationToken.None);

                }
            }
        }

        //private void RequestEtaAndDistance(object sender, EventArgs e)
        //{
        //    var success = _alkMsg.RequestEtaDistance();
        //    new Timer(() =>
        //    {
        //        // ReSharper disable once ConvertToLambdaExpression
        //        Device.BeginInvokeOnMainThread(() =>
        //        {
        //            var totalEta = _alkMsg.TotalEta;
        //            var totalDistance = _alkMsg.TotalDistance;
        //            if (totalEta.HasValue && totalDistance.HasValue && success > 0)
        //            {
        //                EtaLabel.Text = "Total ETA: " + totalEta.Value.TotalMinutes + " minutes\r\n" + "Total Distance: " + totalDistance.Value;
        //            }
        //            else
        //            {
        //                EtaLabel.Text = "Could not acquire ETA and Distance from CoPilot.";
        //            }
        //        });
        //    }, TimeSpan.FromMilliseconds(-1)).Start(TimeSpan.FromSeconds(2));
        //}


    }
}
