﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Planning;
using Xamarin.Forms;
using XLabs;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Shared
{
    public abstract class OrdersPlanDetailPageShared : BasePage
    {
        protected Label UsernameLabel;

        protected ListView OrderPlanListView;
        protected StackLayout DrayageLayout;
        protected Label ShipperLabel;
        protected Label ConsigneeLabel;
        protected Label ContainerNumberLabel;
        protected readonly IOrdersPlanDetailPageService OrdersPlanDetailPageService;
        private readonly Plan _plan;
        private readonly Order _order;
        private readonly ILocalizationService _localizationService;
        private readonly IMapperService _mapperService;
        private readonly IPlanService _planService;
        private bool _isDrayage;


        protected OrdersPlanDetailPageShared(Plan plan, IGeolocator geolocator,
            IStyleService styleService, ILocalizationService localizationService, IMapperService mapperService, IPlanService planService)
            : base(geolocator, styleService, localizationService)
        {
            _plan = plan;
            _localizationService = localizationService;
            _mapperService = mapperService;
            _planService = planService;
            BackgroundColor = Color.FromRgb(3, 11, 31);
            OrderPlanListView = this.FindByName<ListView>("OrderPlanListView");
            DrayageLayout = this.FindByName<StackLayout>("DrayageLayout");
            
            OrdersPlanDetailPageService = (IOrdersPlanDetailPageService)PageManagementService.GetNewPageService(this);

        }

        

        public override async Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            var plan = await _planService.GetPlanLocallyAsync(_plan.Id, cancellationToken);
            var orders = plan.Orders;
                                    
            var updatedPlan = _mapperService.MapPlanWithOrdersToViewModel(plan);
            var bindingContext = new ObservableCollection<OrderViewModel>(updatedPlan.Orders);
            this.BindingContext = bindingContext;
            if (orders.Any(x => x.RouteStops.Count > 1))
            {
                _isDrayage = true;

            }
            
        }

        protected async void ClosePlan(object sender, EventArgs e)
        {
            if (await TurnOnGpsAlert()) return;

            await OrdersPlanDetailPageService.ClosePlanAsync(_plan, CancellationToken.None);
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            
            await RefreshDataAsync(CancellationToken.None);
        }


        protected async void OrderPlanListOnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;
            OrderPlanListView.SelectedItem = null;
            if (await TurnOnGpsAlert()) return;

            var orderViewModel = ((OrderViewModel)e.SelectedItem);
            var order = Mapper.Map<OrderViewModel, Order>(orderViewModel);

            await OrdersPlanDetailPageService.GoToOder(order);
        }


    }
}
