﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Services.Controls;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Views.Shared
{
    public partial class StartOrderReasonShared : IPage
    {
        public Page PageContext { get; set; }
        public PageType PageType { get; set; }
        public PageOrientation PageOrientation { get; set; }

        private readonly OrderViewModel _viewModel;
        private readonly IPickerService<string> _reasonPickerService;

        public StartOrderReasonShared(OrderViewModel viewModel, ILocalizationService localizationService)
        {
            InitializeComponent();

            PageContext = this;
            PageType = PageType.StartOrderReason;
            PageOrientation = PageOrientation.Shared;
            _viewModel = viewModel;
            this.BindingContext = _viewModel;

            OutOfSequenceLocaleLabel.Text = "You have selected to START " + localizationService.Order + " " + _viewModel.Number + " out of sequence.";
            StateReasonLocaleLabel.Text = "Please state a reason before starting the " + localizationService.Order + ".";

            _reasonPickerService = PickerService<string>.Get(ReasonPicker, new List<string>{"Reason 1", "Reason 2", "Reason 3"}, x => x);
        }

        public Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private async void StartOrder(object sender, EventArgs e)
        {
            if (_reasonPickerService.SelectedIndex >= 0)
            {
                _viewModel.StartOrderReason = _reasonPickerService.SelectedItem;
                await this.Navigation.PopModalAsync();
            }
        }

        private async void CancelOrder(object sender, EventArgs e)
        {
            await this.Navigation.PopModalAsync();
        }
    }
}
