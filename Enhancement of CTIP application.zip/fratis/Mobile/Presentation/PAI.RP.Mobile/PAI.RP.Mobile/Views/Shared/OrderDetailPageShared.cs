﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Controls;
using PAI.RP.Mobile.Services;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Subscribers;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;
using OrderLocationViewModel = PAI.RP.Mobile.Model.OrderLocationViewModel;
using OrderNoteViewModel = PAI.RP.Mobile.Model.OrderNoteViewModel;
using OrderViewModel = PAI.RP.Mobile.Model.OrderViewModel;

namespace PAI.RP.Mobile.Views.Shared
{
    public abstract class OrderDetailPageShared : BasePage
    {
        private readonly IGeolocator _geolocator;
        private readonly IStyleService _styleService;
        private readonly ILocalizationService _localizationService;
        private readonly IPlanService _planService;
        private readonly IOrderService _orderService;
        private readonly ICustomFieldPreferencesService _customFieldPreferencesService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IMapperService _mapperService;
       

        protected User CurrentUser;

        protected IOrderDetailPageService OrderDetailPageService;
        protected OrderViewModel ViewModel;
        protected Label PlanExecutionDateLabel;
        protected Label PriorityColoredBox1;
        public Image OrderStatusImage1; 
        //public Label NotificationSentLabel;
        protected StackLayout TopHeaderContainer;
        protected Label AddressLabel;
        protected Button SaveNoteBtn;
        protected CustomButton NavigateButton;
        //public CustomButton DeferButton;
        public CustomButton EnRouteStartCompleteButton;
        //protected CustomButton UpdateLocationButton;
        protected Label UpdateLocationLabel;
        //public Button NotifyCustomerButton;
        protected StackLayout TabLayout; 
        protected ScrollView ScrollViewContainer;
        protected StackLayout ContentContainer;
        protected StackLayout SummaryContentContainer;
        protected StackLayout AdditionalContentContainer;
        protected StackLayout NotesContentContainer;
        protected StackLayout StatisticsContentContainer;
        protected StackLayout NotesLabelContainer;
        protected StackLayout RouteStopsContainer;
        protected StackLayout RouteStopsContentContainer;
        protected CustomEditor NotesEditor;
        protected Image CustomerImage;
        protected Image PhoneImage;
        protected Image EmailImage;
        protected Image LocationImage;
        protected Label LocationLabel;
        protected Label TimeWindowLabel;
        protected StackLayout SummaryTab;
        protected Image SummaryArrow;
        protected StackLayout RouteStopsTab;
        protected Image RouteStopsArrow;
        protected StackLayout AdditionalTab;
        protected Image AdditionalArrow;
        protected StackLayout NotesTab;
        protected Image NotesArrow;
        protected StackLayout StatisticsTab;
        protected Image StatisticsArrow;
        protected StackLayout StaticContentContainer;
        protected StackLayout StaticDynamicContentDivider;
        protected StackLayout TabContentDivider;
        protected ListView RouteStopList;
        protected StackLayout ButtonContainer;
        protected ActivityIndicator LoadingIndicator;
        public Label StartTimeLabel;
        public Label CompletedTimeLabel;
        public Label ActualServiceTimeLabel;
        public Frame StaticContentFrame;
        public Frame ButtonContentFrame;
        private bool _drayage;
        private OrderLocationViewModel _tempOrderLocation;
        private readonly string _planId;
        private readonly string _orderId;
        private readonly int _sequenceNumber;
        
        private Plan _plan;
        private Order _order;
        private IEnumerable<CustomFieldPreference> _customFieldPreferences;
        private IEnumerable<int> _routeStopSequenceNumber;
        private const double Column0Width = 250;

        protected OrderDetailPageShared(Order order, IGeolocator geolocator, IStyleService styleService, ILocalizationService localizationService,
            IPlanService planService, IOrderService orderService, ICustomFieldPreferencesService customFieldPreferencesService, 
            IAuthenticationProvider authenticationProvider, IMapperService mapperService)
            : base(geolocator, styleService, localizationService)
        {
            _geolocator = geolocator;
            _styleService = styleService;
            _localizationService = localizationService;
            _planService = planService;
            _orderService = orderService;
            _customFieldPreferencesService = customFieldPreferencesService;
            _authenticationProvider = authenticationProvider;
            _mapperService = mapperService;
            

            RouteStopList = this.FindByName<ListView>("RouteStopList");
            PlanExecutionDateLabel = this.FindByName<Label>("PlanExecutionDateLabel");
            PriorityColoredBox1 = this.FindByName<Label>("PriorityColoredBox1");
            OrderStatusImage1 = this.FindByName<Image>("OrderStatusImage1");
            //NotificationSentLabel = this.FindByName<Label>("NotificationSentLabel");
            TopHeaderContainer = this.FindByName<StackLayout>("TopHeaderContainer");
            AddressLabel = this.FindByName<Label>("AddressLabel");
            NavigateButton = this.FindByName<CustomButton>("NavigateButton");
            EnRouteStartCompleteButton = this.FindByName<CustomButton>("EnRouteStartCompleteButton");
            //DeferButton = this.FindByName<CustomButton>("DeferButton");
            //UpdateLocationButton = this.FindByName<CustomButton>("UpdateLocationButton");
            UpdateLocationLabel = this.FindByName<Label>("UpdateLocationLabel");
            //NotifyCustomerButton = this.FindByName<Button>("NotifyCustomerButton");
            TabLayout = this.FindByName<StackLayout>("TabLayout");
            ScrollViewContainer = this.FindByName<ScrollView>("ScrollViewContainer");
            ContentContainer = this.FindByName<StackLayout>("ContentContainer");
            SummaryContentContainer = this.FindByName<StackLayout>("SummaryContentContainer");
            AdditionalContentContainer = this.FindByName<StackLayout>("AdditionalContentContainer");
            NotesContentContainer = this.FindByName<StackLayout>("NotesContentContainer");
            StatisticsContentContainer = this.FindByName<StackLayout>("StatisticsContentContainer");
            RouteStopsContentContainer = this.FindByName<StackLayout>("RouteStopsContentContainer");
            NotesLabelContainer = this.FindByName<StackLayout>("NotesLabelContainer");
            NotesEditor = this.FindByName<CustomEditor>("NotesEditor");
            CustomerImage = this.FindByName<Image>("CustomerImage");
            PhoneImage = this.FindByName<Image>("PhoneImage");
            EmailImage = this.FindByName<Image>("EmailImage");
            LocationImage = this.FindByName<Image>("LocationImage");
            LocationLabel = this.FindByName<Label>("LocationLabel");
            TimeWindowLabel = this.FindByName<Label>("TimeWindowLabel");
            SummaryTab = this.FindByName<StackLayout>("SummaryTab");
            SummaryArrow = this.FindByName<Image>("SummaryArrow");
            AdditionalTab = this.FindByName<StackLayout>("AdditionalTab");
            AdditionalArrow = this.FindByName<Image>("AdditionalArrow");
            NotesTab = this.FindByName<StackLayout>("NotesTab");
            NotesArrow = this.FindByName<Image>("NotesArrow");
            RouteStopsTab = this.FindByName<StackLayout>("RouteStopsTab");
            RouteStopsArrow = this.FindByName<Image>("RouteStopsArrow");
            StatisticsTab = this.FindByName<StackLayout>("StatisticsTab");
            StatisticsArrow = this.FindByName<Image>("StatisticsArrow");
            StaticContentContainer = this.FindByName<StackLayout>("StaticContentContainer");
            StaticDynamicContentDivider = this.FindByName<StackLayout>("StaticDynamicContentDivider");
            TabContentDivider = this.FindByName<StackLayout>("TabContentDivider");
            StaticContentFrame = this.FindByName<Frame>("StaticContentFrame");
            ButtonContentFrame = this.FindByName<Frame>("ButtonContentFrame");

            ButtonContainer = this.FindByName<StackLayout>("ButtonContainer");
            LoadingIndicator = this.FindByName<ActivityIndicator>("LoadingIndicator");

            ConfigureTabs();
            //AddDividers();

            _planId = order.PlanId;
            _orderId = order.Id;
            _sequenceNumber = order.SequenceNumber;
            _routeStopSequenceNumber = order.RouteStops.Select(x => x.SortOrder + 1);


        }

        public override async Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            _plan = await _planService.GetPlanLocallyAsync(_planId, cancellationToken);
            _order = await _orderService.GetOrderLocallyAsync(_orderId, CancellationToken.None);
            
            
            if (_order == null)
            {
                //Order does not exist, so navigate back
                await PageContext.Navigation.PopAsync();
                return;
            }
            _drayage = _order.RouteStops.Count() > 1;
            if (_drayage)
            {
                
                StaticContentContainer.IsVisible = false;
                StaticContentFrame.IsVisible = false;
                ButtonContainer.IsVisible = true;
                ButtonContentFrame.IsVisible = true;
            }

            _order.SequenceNumber = _sequenceNumber;

            _customFieldPreferences = await _customFieldPreferencesService.GetByEntityTypeAsync(_authenticationProvider.SubscriberId, "Order", CancellationToken.None);

            //TODO - Pass in and use the OrderLocationViewModel instead and gather general order information from the Order Nav property on it
            //TODO - Remove after Integration
            _tempOrderLocation = new OrderLocationViewModel
            {
                OrderId = _order.Id,
                Order = _mapperService.MapRouteStopsToOrderViewModel(_order),
            };

            
            this.BindingContext = _tempOrderLocation;
            
            ViewModel = _tempOrderLocation.Order;

            AddTopHeaderContent();
            AddFixedContent();
            AddSummaryContent();
            AddAdditionalContent();
            AddNotesContent();
            AddStatisticsContainer();
            
            //ConfigureLocalization();
            //ConfigureStyleOptions();

            OrderDetailPageService =
                (IOrderDetailPageService)PageManagementService.GetNewPageService(this, new Dictionary<string, object>
                    {
                        {"pageContext", this},
                        {"order", _order},
                        {"plan", _plan}
                    });
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            //var buttonWidthRequest = ScreenWidth*0.25;
            //UpdateLocationButton.WidthRequest = buttonWidthRequest;
            //StartCompleteButton.WidthRequest = buttonWidthRequest;
            //DeferButton.WidthRequest = buttonWidthRequest;
            //NavigateButton.WidthRequest = buttonWidthRequest;
		
            await RefreshDataAsync(CancellationToken.None);
            if (_drayage)
            {
                SetVisibleContentContainer("routeStops");
                EnRouteStartCompleteButton.IsVisible = false;
                NavigateButton.IsVisible = true;
                return;
            }
            SummaryTab.IsVisible = false;
            SummaryArrow.IsVisible = false;
            RouteStopsTab.IsVisible = false;
            RouteStopsArrow.IsVisible = false;
            SetVisibleContentContainer("statistics");
            
        }

        private void AddTopHeaderContent()
        {
            if (_plan != null)
            {
                PlanExecutionDateLabel.Text = _plan.ExecutionDate.ToString("MM/dd/yy");
            }
        }

        private void ConfigureTabs()
        {
            SummaryTab.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => SetVisibleContentContainer("summary")),
                NumberOfTapsRequired = 1
            });
            SummaryArrow.Aspect = Aspect.AspectFit;
            SummaryArrow.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.GreaterThanArrow.png");
            AdditionalTab.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => SetVisibleContentContainer("additional")),
                NumberOfTapsRequired = 1
            });
            AdditionalArrow.Aspect = Aspect.AspectFit;
            AdditionalArrow.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.GreaterThanArrow.png");
            NotesTab.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => SetVisibleContentContainer("notes")),
                NumberOfTapsRequired = 1
            });
            NotesArrow.Aspect = Aspect.AspectFit;
            NotesArrow.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.GreaterThanArrow.png");
            StatisticsTab.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => SetVisibleContentContainer("statistics")),
                NumberOfTapsRequired = 1
            });
            StatisticsArrow.Aspect = Aspect.AspectFit;
            StatisticsArrow.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.GreaterThanArrow.png");

            RouteStopsTab.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => SetVisibleContentContainer("routeStops")),
                NumberOfTapsRequired = 1
            });
            RouteStopsArrow.Aspect = Aspect.AspectFit;
            RouteStopsArrow.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.GreaterThanArrow.png");
        }

        //private void AddDividers()
        //{
        //    for (int i = 0; i <= TabLayout.Children.Count; i = i + 2)
        //    {
        //        TabLayout.Children.Insert(i, _styleService.GetNewHorizontalDivider(LayoutOptions.FillAndExpand));
        //    }
        //    StaticDynamicContentDivider.Children.Add(_styleService.GetNewHorizontalDivider(LayoutOptions.FillAndExpand));
        //    TabContentDivider.Children.Add(_styleService.GetNewVerticalDivider(LayoutOptions.FillAndExpand));
            
        //}

        private void AddFixedContent()
        {
            if (string.IsNullOrWhiteSpace(_order.Customer.Name))
            {
                CustomerImage.IsVisible = false;
            }
            else
            {
                CustomerImage.Aspect = Aspect.AspectFit;
                CustomerImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Customer.png");
            }
            if (string.IsNullOrWhiteSpace(_order.Customer.PhoneNumber))
            {
                PhoneImage.IsVisible = false;
            }
            else
            {
                PhoneImage.Aspect = Aspect.AspectFit;
                PhoneImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Phone.png");
            }
            if (string.IsNullOrWhiteSpace(_order.Customer.Email))
            {
                EmailImage.IsVisible = false;
            }
            else
            {
                EmailImage.Aspect = Aspect.AspectFit;
                EmailImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.AtSymbol.png");
            }
            LocationImage.Aspect = Aspect.AspectFit;
            LocationImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.MapMarker.png");
            if (ViewModel.Locations != null && ViewModel.Locations.Any())
            {
                var location = ViewModel.Locations.First();
                LocationLabel.Text = location.Line1 + ", " + location.City + ", " + location.State + ", " +  location.Zip;
                TimeWindowLabel.Text = location.TimeWindowsDisplay;
            }
        }

        private void AddSummaryContent()
        {
            var defaultFontSize = Font.SystemFontOfSize(20);

            SummaryContentContainer.Children.Clear();
            if (_drayage)
            {
                SummaryContentContainer.Children.Add(new StackLayout
                {
                    Orientation = StackOrientation.Vertical,
                    Children =
                    {

                        new Label
                        {
                            Text = "Pickup Number:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.PickupNumber,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = "Booking Number:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.BookingNumber,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Bill of Lading:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.BillOfLading,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Consignee Name:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ConsigneeName,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Shipper Name:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ShipperName,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = "Container Owner:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ContainerOwner,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Container Size:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.Container,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = "Container Number:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ContainerNumber,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Chassis Owner:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ChassisOwner,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Chassis Size:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.Chassis,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        },

                        new Label
                        {
                            Text = "Chassis Number:",
                            Font = defaultFontSize,
                            TextColor = Color.Black
                        },
                        new Label
                        {
                            Text = ViewModel.ChassisNumber,
                            Font = Font.SystemFontOfSize(14),
                            TextColor = Color.Black
                        }


                    }
                });
            }
        }

        private void AddAdditionalContent()
        {
            var defaultFontSize = Font.SystemFontOfSize(20);

            AdditionalContentContainer.Children.Add(new StackLayout
            {
                Orientation = StackOrientation.Vertical,
                Children =
                {

                    new Label
                    {
                        Text = "Custom Field 1:",
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = ViewModel.CustomField1,
                        Font = Font.SystemFontOfSize(14),
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = "Custom Field 2:",
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = ViewModel.CustomField2,
                        Font = Font.SystemFontOfSize(14),
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = "Custom Field 3:",
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = ViewModel.CustomField3,
                        Font = Font.SystemFontOfSize(14),
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = "Custom Field 4:",
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = ViewModel.CustomField4,
                        Font = Font.SystemFontOfSize(14),
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = "Custom Field 5:",
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },

                    new Label
                    {
                        Text = ViewModel.CustomField5,
                        Font = Font.SystemFontOfSize(14),
                        TextColor = Color.Black
                    },

                }
            });
        }

        private IEnumerable<Label> GetLabelsFromOrderNote(OrderNoteViewModel orderNoteViewModel)
        {
            //TODO - Make a UserService and get the User by UserId so we can replace UserName = "You"
            var userName = _authenticationProvider.UserId == orderNoteViewModel.UserId ? "You" : orderNoteViewModel.UserName;
            return new List<Label>
            {
                new Label {Text = orderNoteViewModel.Note, HeightRequest = 25, TextColor = Color.Black},
                new Label
                {
                    Text = userName + " " + orderNoteViewModel.TimeStamp.ToLocalTime().ToString("MM/dd/yy h:mm tt"),
                    TextColor = Color.Black
                },
            };
        }

        private IList<Label> GetLabelsFromRouteStops(IList<RouteStopViewModel> routeStopViewModels)
        {
            var addressLabels = new List<Label>();
            
            foreach (var routeStopViewModel in routeStopViewModels)
            {
                var latitudeLabel = new Label()
                {
                    Text = routeStopViewModel.Location.Latitude.ToString(),
                    TextColor = Color.Black

                };
                addressLabels.Add(latitudeLabel);
                var longitudeLabel = new Label()
                {
                    Text = routeStopViewModel.Location.Longitude.ToString(),
                    TextColor = Color.Black
                };
                addressLabels.Add(longitudeLabel);

            }


            return addressLabels;
        }

        private void AddNotesContent()
        {
            var defaultFontSize = Font.SystemFontOfSize(20);

            NotesEditor = new CustomEditor
            {
                //WidthRequest = 100,
                HeightRequest = 150,
            };
            SaveNoteBtn = new Button { Text = "Save", WidthRequest = 100};
            SaveNoteBtn.Clicked += OnNoteSaved;
            var saveNoteBtnContainer = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Padding = new Thickness(0, 10, 10, 0),
                Children =
                {
                    new Label
                    {
                        Text = "Notes:",
                        VerticalOptions = LayoutOptions.End,
                        YAlign = TextAlignment.End,
                        TextColor = Color.Black
                    },
                    new Label
                    {
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        TextColor = Color.Black
                    },
                    SaveNoteBtn
                }
            };
            var noteLabels = new List<Label>();
            foreach (var orderNote in ViewModel.Notes)
            {
                noteLabels.AddRange(GetLabelsFromOrderNote(orderNote));
            }
            NotesLabelContainer = new StackLayout
            {
                Orientation = StackOrientation.Vertical,
            };
            foreach (var noteLabel in noteLabels)
            {
                NotesLabelContainer.Children.Insert(0, noteLabel);
            }
            NotesContentContainer.Children.Clear();
            NotesContentContainer.Children.Add(new StackLayout
            {
                Orientation = StackOrientation.Vertical,
                Children =
                {
                    saveNoteBtnContainer,
                    NotesEditor,
                    NotesLabelContainer
                }
            });
            _styleService.StylizeElement(NotesContentContainer);
        }

        

        

        private void AddStatisticsContainer()
        {
            var defaultFontSize = Font.SystemFontOfSize(20);

            StatisticsContentContainer.Children.Clear();
            StartTimeLabel = new Label
            {
                XAlign = TextAlignment.Center,
                YAlign = TextAlignment.Center,
                Font = defaultFontSize,
                TextColor = Color.Black
            };
            StatisticsContentContainer.Children.Add(new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Children =
                {
                    new Label
                    {
                        Text = "Start Time:",
                        WidthRequest = Column0Width,
                        XAlign = TextAlignment.Start,
                        YAlign = TextAlignment.Center,
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },
                    StartTimeLabel
                }
            });

            CompletedTimeLabel = new Label
            {
                XAlign = TextAlignment.Center,
                YAlign = TextAlignment.Center,
                Font = defaultFontSize,
                TextColor = Color.Black
            };
            StatisticsContentContainer.Children.Add(new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Children =
                {
                    new Label
                    {
                        Text = "End Time:",
                        WidthRequest = Column0Width,
                        XAlign = TextAlignment.Start,
                        YAlign = TextAlignment.Center,
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },
                    CompletedTimeLabel
                }
            });

            ActualServiceTimeLabel = new Label
            {
                XAlign = TextAlignment.Center,
                YAlign = TextAlignment.Center,
                Font = defaultFontSize,
                TextColor = Color.Black
            };
            StatisticsContentContainer.Children.Add(new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Children =
                {
                    new Label
                    {
                        Text = "Actual Service Time:",
                        WidthRequest = Column0Width,
                        XAlign = TextAlignment.Start,
                        YAlign = TextAlignment.Center,
                        Font = defaultFontSize,
                        TextColor = Color.Black
                    },
                    ActualServiceTimeLabel
                }
            });
        }

        //private void ConfigureLocalization()
        //{
        //    var priorityValue = ViewModel.PriorityDisplay;
        //    if (_localizationService.Vendor == VendorTypeOption.SanAntonio)
        //    {
        //        priorityValue = ViewModel.InspectionPriority;
        //    }
        //    PriorityColoredBox1.Text = priorityValue;
        //}

        //private void ConfigureStyleOptions()
        //{
        //    //Set Style options
        //    //TODO - Move the logic into central location
        //    //TODO - Change between RP and COSA the color scheme for Priority and Inspection Priority fields
        //    if (PriorityColoredBox1.Text == "1")
        //    {
        //        PriorityColoredBox1.BackgroundColor = _styleService.DarkRed;
        //    }
        //    else if (PriorityColoredBox1.Text == "2")
        //    {
        //        PriorityColoredBox1.BackgroundColor = _styleService.LightOrange;
        //    }
        //    else if (PriorityColoredBox1.Text == "3")
        //    {
        //        PriorityColoredBox1.BackgroundColor = _styleService.DarkYellow;
        //    }
        //    else if (PriorityColoredBox1.Text == "4")
        //    {
        //        PriorityColoredBox1.BackgroundColor = Color.Green;
        //    }

        //    _styleService.StylizeElement(ContentContainer);
        //    TopHeaderContainer.BackgroundColor = _styleService.Black;
        //    SetTextColorInsideContainer(TopHeaderContainer, Color.White);
        //    NavigateButton.BackgroundColor = _styleService.LightBlue;
        //    StartCompleteButton.BackgroundColor = _styleService.LightGreen;
        //    DeferButton.BackgroundColor = _styleService.LightRed;
        //    UpdateLocationButton.BackgroundColor = _styleService.LightBlue;
        //    TabLayout.BackgroundColor = _styleService.Black;
        //    SetTextColorInsideContainer(TabLayout, Color.White);
        //    //PriorityColoredBox1.TextColor = Color.Black;
        //    StaticContentContainer.BackgroundColor = _styleService.LightGray;
        //    ContentContainer.BackgroundColor = Color.White;
        //    ButtonContainer.BackgroundColor = _styleService.LightGray;

        //    //Set Priority Text Color
        //    PriorityColoredBox1.TextColor = _styleService.LighterGray;
        //}

        private void SetTextColorInsideContainer(IViewContainer<View> container, Color textColor)
        {
            foreach (var child in container.Children)
            {
                var anotherContainer = child as IViewContainer<View>;
                if (anotherContainer != null)
                {
                    SetTextColorInsideContainer(anotherContainer, textColor);
                    continue;
                }
                var label = child as Label;
                if (label != null)
                {
                    label.TextColor = textColor;
                }
            }
        }

        private void SetVisibleContentContainer(string containerName)
        {
            if (containerName == "additional")
            {
                SummaryContentContainer.IsVisible = false;
                SummaryArrow.IsVisible = false;
                AdditionalContentContainer.IsVisible = true;
                AdditionalArrow.IsVisible = true;
                NotesContentContainer.IsVisible = false;
                NotesArrow.IsVisible = false;
                StatisticsContentContainer.IsVisible = false;
                StatisticsArrow.IsVisible = false;
                RouteStopsContentContainer.IsVisible = false;
                RouteStopsArrow.IsVisible = false;
            }
            else if (containerName == "notes")
            {
                SummaryContentContainer.IsVisible = false;
                SummaryArrow.IsVisible = false;
                AdditionalContentContainer.IsVisible = false;
                AdditionalArrow.IsVisible = false;
                NotesContentContainer.IsVisible = true;
                NotesArrow.IsVisible = true;
                StatisticsContentContainer.IsVisible = false;
                StatisticsArrow.IsVisible = false;
                RouteStopsContentContainer.IsVisible = false;
                RouteStopsArrow.IsVisible = false;
            }
            else if (containerName == "statistics")
            {
                SummaryContentContainer.IsVisible = false;
                SummaryArrow.IsVisible = false;
                AdditionalContentContainer.IsVisible = false;
                AdditionalArrow.IsVisible = false;
                NotesContentContainer.IsVisible = false;
                NotesArrow.IsVisible = false;
                StatisticsContentContainer.IsVisible = true;
                StatisticsArrow.IsVisible = true;
                RouteStopsContentContainer.IsVisible = false;
                RouteStopsArrow.IsVisible = false;
            }
            else if(containerName == "routeStops")
            {
                
                SummaryContentContainer.IsVisible = false;
                SummaryArrow.IsVisible = false;
                AdditionalContentContainer.IsVisible = false;
                AdditionalArrow.IsVisible = false;
                NotesContentContainer.IsVisible = false;
                NotesArrow.IsVisible = false;
                StatisticsContentContainer.IsVisible = false;
                StatisticsArrow.IsVisible = false;
                RouteStopsContentContainer.IsVisible = true;
                RouteStopsArrow.IsVisible = true;
            }

            else
            {
                SummaryContentContainer.IsVisible = true;
                SummaryArrow.IsVisible = true;
                AdditionalContentContainer.IsVisible = false;
                AdditionalArrow.IsVisible = false;
                NotesContentContainer.IsVisible = false;
                NotesArrow.IsVisible = false;
                StatisticsContentContainer.IsVisible = false;
                StatisticsArrow.IsVisible = false;
                RouteStopsContentContainer.IsVisible = false;
                RouteStopsArrow.IsVisible = false;
            }
        }

        

        protected async void OnNoteSaved(object sender, EventArgs eventArgs)
        {
            AlterActionState(false);
            if (!string.IsNullOrWhiteSpace(NotesEditor.Text))
            {
                //TODO - Make a UserService and get the User by UserId so we can replace UserName = "You"
                var orderNoteViewModel = new OrderNoteViewModel
                {
                    Note = NotesEditor.Text,
                    //TimeStamp = DateTime.UtcNow,
                    TimeStamp = DateTime.Now,
                    UserId = _authenticationProvider.UserId,
                };
                ViewModel.Notes.Add(orderNoteViewModel);
                var noteLabels = GetLabelsFromOrderNote(orderNoteViewModel);
                foreach (var noteLabel in noteLabels)
                {
                    NotesLabelContainer.Children.Insert(0, noteLabel);
                }
                NotesEditor.Text = string.Empty;
                _styleService.StylizeElement(NotesLabelContainer);
                var order = Mapper.Map<OrderViewModel, Order>(ViewModel);

                await _orderService.SaveOrderAsync(order, CancellationToken.None);
            }
            AlterActionState(true);
        }

        protected async void StartCompleteOrder(object sender, EventArgs e)
        {
            AlterActionState(false);
            if (OrderDetailPageService != null)
            {
                if (await TurnOnGpsAlert()) return;

                await OrderDetailPageService.StartRouteStopAsync(CancellationToken.None);
                UpdateInterfaceState();
            }
            AlterActionState(true);
        }

        protected async void EnRouteOrder(object sender, EventArgs e)
        {
            AlterActionState(false);
            if (OrderDetailPageService != null)
            {
                if (await TurnOnGpsAlert()) return;
                if (_order.Status == OrderStatus.InProgress)
                {
                    var routeStop = _order.RouteStops.FirstOrDefault();
                    routeStop.RouteStopStatus = RouteStopStatus.InProgress;
                    await _orderService.CompleteRouteStop(_order, CancellationToken.None);
                    await _orderService.CompleteOrderAsync(_order, CancellationToken.None);
                    UpdateInterfaceState();
                    AlterActionState(true);
                    return;
                }
                await OrderDetailPageService.EnRouteStopAsync(CancellationToken.None);

                UpdateInterfaceState();
            }
            AlterActionState(true);
        }

        protected void Navigate(object sender, EventArgs e)
        {            
            var order = _tempOrderLocation.Order;
            if (order.Locations != null && order.Locations.Any())
            {
                var routeStops = ViewModel.RouteStops;

                if (routeStops.Any(x => x.RouteStopStatus == RouteStopStatus.EnRoute))
                {
                    OrderDetailPageService.OpenNativeMap(routeStops);

                }
                else
                {
                    DisplayAlert("Warning", "You have no Route Stops En Route", "Ok", "Cancel");
                }
            }            
        }

        protected async void UpdateLocation(object sender, EventArgs e)
        {
            AlterActionState(false);
            if (await TurnOnGpsAlert()) return;

            var updateLocationText = "Failed to Update Location";
            var locationUpdateSuccess = false;
            try
            {
                var position = await _geolocator.GetPositionAsync(CancellationToken.None);
                if (position != null)
                {
                    var firstLocation = _order.Locations.FirstOrDefault();
                    if (firstLocation != null)
                    {
                        firstLocation.Latitude = position.Latitude;
                        firstLocation.Longitude = position.Longitude;
                        await _orderService.SaveOrderAsync(_order, CancellationToken.None);
                        updateLocationText = "Location Updated";
                        locationUpdateSuccess = true;
                    }
                }
                else
                {
                    updateLocationText = "Failed to retrieve geolocation";
                }
            }
            catch (Exception exception)
            {
                //Swallow error
            }
            if (!locationUpdateSuccess)
            {
                UpdateLocationLabel.Text = updateLocationText;
                UpdateLocationLabel.IsVisible = true;
            }
            AlterActionState(true);
        }

        protected async void NotifyCustomer(object sender, EventArgs e)
        {
            AlterActionState(false);
            if (OrderDetailPageService != null)
            {
                if (await TurnOnGpsAlert()) return;

                await OrderDetailPageService.NotifyCustomerAsync(CancellationToken.None);
            }
            AlterActionState(true);
        }

        private void UpdateInterfaceState()
        {
            _tempOrderLocation.Order.Status = _order.Status;
            //Re-alignment fix
            //UpdateLocationButton.Text = "Update Location";
            NavigateButton.Text = "Navigate";
        }

        private void AlterActionState(bool enableActions)
        {
            NavigationPage.SetHasBackButton(this, enableActions);
            OrderStatusImage1.IsVisible = enableActions;
            LoadingIndicator.IsVisible = !enableActions;
            LoadingIndicator.IsRunning = !enableActions;

            if (SaveNoteBtn != null)
            {
                SaveNoteBtn.IsEnabled = enableActions;
            }
            NavigateButton.IsEnabled = enableActions;
            //DeferButton.IsEnabled = enableActions;
            EnRouteStartCompleteButton.IsEnabled = enableActions;
            //UpdateLocationButton.IsEnabled = enableActions;
        }



    }
}
