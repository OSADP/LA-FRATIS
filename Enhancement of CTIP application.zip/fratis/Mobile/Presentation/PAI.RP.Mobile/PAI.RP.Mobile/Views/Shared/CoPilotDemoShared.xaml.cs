﻿using System;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Compatibility.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Views.Shared
{
    public partial class CoPilotDemoShared : IPage
    {
        public Page PageContext { get; set; }
        public PageType PageType { get; set; }
        public PageOrientation PageOrientation { get; set; }

        private IAlkMsg _alkMsg;

        public CoPilotDemoShared()
        {
            InitializeComponent();

            PageContext = this;
            PageType = PageType.CoPilotDemo;
            PageOrientation = PageOrientation.Shared;

            _alkMsg = TinyIoC.TinyIoCContainer.Current.Resolve<IAlkMsg>();
        }

        public Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        //private async void OpenCoPilot(object sender, EventArgs e)
        //{
        //    var mapping = TinyIoC.TinyIoCContainer.Current.Resolve<INativeMap>();
        //    mapping.OpenCoPilot();
        //}

        private async void OpenGoogleMaps(object sender, EventArgs e)
        {
            var mapping = TinyIoC.TinyIoCContainer.Current.Resolve<INativeMap>();
            mapping.Open();
        }

        private async void OpenGoogleMapsApi(object sender, EventArgs e)
        {
            
        }

        private async void StartupMessaging(object sender, EventArgs e)
        {
            if (_alkMsg.Msg_IsConnected() <= 0 && _alkMsg.Msg_HasStarted() <= 0)
            {
                //TODO - Need to setup callback functionality
                var result = _alkMsg.Msg_StartUp(null, null, true, true, true);
            }
        }

        private async void AddStopLocation(object sender, EventArgs e)
        {
            //TODO - Need to map ActionEnum actionCode
            //TODO - Need to map MessageId
            //TODO - Replace 222's with the mappings once implemented
            if (_alkMsg.Msg_IsConnected() == 1 && _alkMsg.Msg_HasStarted() == 1)
            {
                var tripId = _alkMsg.Msg_TripLoad(222, 0, 222);
                _alkMsg.Msg_TripAddStopWithHouseNum(tripId, "Test Stop 1",
                    "1",
                    "Golden Knights Circle",
                    "Orlando",
                    "",//Dont include state
                    "32817",
                    "",//Dont include jurisdiction
                    0, 0, //Lat Long not included for the time being
                    222, null, null, null, 1);
                _alkMsg.Msg_SendTrip(tripId, -1, -1, 222);
                _alkMsg.Msg_ParserDelete(tripId);
            }
        }

        private async void StartupMessagingAndAddStopLocation(object sender, EventArgs e)
        {
            //TODO - CoPilot must be opened before starting this method.
            //TODO - See if it is possible to have copilot already open before entering this method somehow
            StartupMessaging(sender, e);
            new Timer(async () =>
            {
                // ReSharper disable once ConvertToLambdaExpression
                Device.BeginInvokeOnMainThread(async () =>
                {
                    AddStopLocation(sender, e);
                    //OpenCoPilot(sender, e);
                });
            }, TimeSpan.FromMilliseconds(-1)).Start(TimeSpan.FromSeconds(2));
        }

        private void RequestEtaAndDistance(object sender, EventArgs e)
        {
            var success = _alkMsg.RequestEtaDistance();
            new Timer(() =>
            {
                // ReSharper disable once ConvertToLambdaExpression
                Device.BeginInvokeOnMainThread(() =>
                {
                    var totalEta = _alkMsg.TotalEta;
                    var totalDistance = _alkMsg.TotalDistance;
                    if (totalEta.HasValue && totalDistance.HasValue && success > 0)
                    {
                        EtaDistanceLabel.Text = "Total ETA: " + totalEta.Value.TotalMinutes + " minutes\r\n" + "Total Distance: " + totalDistance.Value;
                    }
                    else
                    {
                        EtaDistanceLabel.Text = "Could not acquire ETA and Distance from CoPilot.";
                    }
                });
            }, TimeSpan.FromMilliseconds(-1)).Start(TimeSpan.FromSeconds(2));
        }
    }
}
