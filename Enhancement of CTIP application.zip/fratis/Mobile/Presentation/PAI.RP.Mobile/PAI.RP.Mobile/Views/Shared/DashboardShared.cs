﻿using System;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Domain;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Shared
{
    public abstract class DashboardShared : BasePage
    {
        protected Label TitleLabel1;
        protected Label TitleLabel2;
        protected StackLayout OrdersContainer;
        protected StackLayout NavigationContainer;
        protected Image OrdersImage;
        protected Image ParkingImage;
        protected Image NavigationImage;
        protected Image LogsImage;
        protected Image GasImage;
        protected Image WeatherImage;
        protected Label OrdersLocaleLabel;
        protected Label ParkingLabel;
        protected Label NavigationLabel;
        protected Label LogsLabel;
        protected Label GasLabel;
        protected Label WeatherLabel;

        protected DashboardShared(IGeolocator geolocator, IStyleService styleService, ILocalizationService localizationService) 
            : base(geolocator, styleService, localizationService)
        {
            TitleLabel1 = this.FindByName<Label>("TitleLabel1");
            TitleLabel2 = this.FindByName<Label>("TitleLabel2");
            OrdersContainer = this.FindByName<StackLayout>("OrdersContainer");
            NavigationContainer = this.FindByName<StackLayout>("NavigationContainer");
            OrdersImage = this.FindByName<Image>("OrdersImage");
            ParkingImage = this.FindByName<Image>("ParkingImage");
            NavigationImage = this.FindByName<Image>("NavigationImage");
            LogsImage = this.FindByName<Image>("LogsImage");
            GasImage = this.FindByName<Image>("GasImage");
            WeatherImage = this.FindByName<Image>("WeatherImage");
            OrdersLocaleLabel = this.FindByName<Label>("OrdersLocaleLabel");
            ParkingLabel = this.FindByName<Label>("ParkingLabel");
            NavigationLabel = this.FindByName<Label>("NavigationLabel");
            LogsLabel = this.FindByName<Label>("LogsLabel");
            GasLabel = this.FindByName<Label>("GasLabel");
            WeatherLabel = this.FindByName<Label>("WeatherLabel");

            //TODO - Localize this value from a KVP Dictionary
            TitleLabel1.Text = localizationService.AppName + " Dashboard";
            TitleLabel1.Font = Font.SystemFontOfSize(38, FontAttributes.Bold);
            TitleLabel2.HeightRequest = 40;

            OrdersLocaleLabel.Text = localizationService.Orders.ToUpper();

            OrdersLocaleLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);
            ParkingLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);
            NavigationLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);
            LogsLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);
            GasLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);
            WeatherLabel.Font = Font.SystemFontOfSize(23, FontAttributes.Bold);

            OrdersImage.Aspect = Aspect.AspectFit;
            OrdersImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Orders.png");
            OrdersImage.BackgroundColor = Color.FromRgb(103, 120, 33);
            ParkingImage.Aspect = Aspect.AspectFit;
            ParkingImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Parking.png");
            ParkingImage.BackgroundColor = Color.FromRgb(212, 85, 0);
            NavigationImage.Aspect = Aspect.AspectFit;
            NavigationImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Navigation.png");
            NavigationImage.BackgroundColor = Color.FromRgb(0, 68, 85);
            LogsImage.Aspect = Aspect.AspectFit;
            LogsImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Logs.png");
            LogsImage.BackgroundColor = Color.FromRgb(0, 68, 85);
            GasImage.Aspect = Aspect.AspectFit;
            GasImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Gas.png");
            GasImage.BackgroundColor = Color.FromRgb(103, 120, 33);
            WeatherImage.Aspect = Aspect.AspectFit;
            WeatherImage.Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Weather.png");
            WeatherImage.BackgroundColor = Color.FromRgb(212, 85, 0);

            OrdersContainer.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.OrderPlans).PageContext)),
                NumberOfTapsRequired = 1
            });

            NavigationContainer.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.CoPilotDemo).PageContext)),
                NumberOfTapsRequired = 1
            });
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);

            //OrdersContainer.Children.Add(new Image
            //{
            //    HorizontalOptions = LayoutOptions.Center,
            //    Aspect = Aspect.AspectFit,
            //    Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Orders.png"),
            //    BackgroundColor = Color.FromRgb(103, 120, 33),
            //    WidthRequest = width * 0.133
            //});

            //OrdersImage.WidthRequest = width * 0.133;
            //OrdersImage.HeightRequest = height * 0.236;
            //ParkingImage.WidthRequest = width * 0.133;
            //ParkingImage.HeightRequest = height * 0.236;
            //NavigationImage.WidthRequest = width * 0.133;
            //NavigationImage.HeightRequest = height * 0.236;
            //LogsImage.WidthRequest = width * 0.133;
            //LogsImage.HeightRequest = height * 0.236;
            //GasImage.WidthRequest = width * 0.133;
            //GasImage.HeightRequest = height * 0.236;
            //WeatherImage.WidthRequest = width * 0.133;
            //WeatherImage.HeightRequest = height * 0.236;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            //TODO - Create new views here for later

            //OrdersImage = new Image
            //{
            //    HorizontalOptions = LayoutOptions.Center,
            //    Aspect = Aspect.AspectFit,
            //    Source = ImageSource.FromResource("PAI.RP.Mobile.Images.Orders.png"),
            //    BackgroundColor = Color.FromRgb(103, 120, 33),
            //    WidthRequest = 50,
            //    HeightRequest = 50
            //};

            //OrdersImage.WidthRequest = 50;
            //OrdersImage.HeightRequest = 50;
        }
    }
}
