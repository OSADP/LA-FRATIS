﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Services.Portable.Subscribers;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Views.Shared
{
    public partial class ChangePasswordShared : IPage
    {
        private readonly IUserService _userService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly PasswordChangeRequestViewModel _changeRequestViewModel;

        public Page PageContext { get; set; }
        public PageType PageType { get; set; }
        public PageOrientation PageOrientation { get; set; }

        public ChangePasswordShared(IUserService userService, IAuthenticationProvider authenticationProvider, PasswordChangeRequestViewModel entity)
        {
            _userService = userService;
            _authenticationProvider = authenticationProvider;
            _changeRequestViewModel = entity;

            InitializeComponent();

            PageContext = this;
            PageType = PageType.ChangePassword;
            PageOrientation = PageOrientation.Shared;
        }

        public Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        protected async void OnBackButtonPress(object sender, EventArgs eventArgs)
        {
            await Navigation.PopAsync();
        }

        protected async void OnPasswordChange(object sender, EventArgs eventArgs)
        {
            ResponseMessageLabel.IsVisible = false;
            var password = PasswordEntry.Text ?? string.Empty;
            var password2 = Password2Entry.Text ?? string.Empty;
            var containsError = false;
            var responseMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(password2))
            {
                containsError = true;
                responseMessage = "Missing password.";
            }
            else if (password != password2)
            {
                containsError = true;
                responseMessage = "Passwords must match.";
            }

            if (!containsError)
            {
                try
                {
                    _changeRequestViewModel.Password = password;
                    _changeRequestViewModel.ConfirmPassword = password2;
                    var result = await _userService.ChangePasswordAsync(_changeRequestViewModel, CancellationToken.None);
                    if (result.IsSuccessful)
                    {
                        responseMessage = "New password set. Please re-login.";
                    }
                    else
                    {
                        containsError = true;
                        responseMessage = result.Errors.FirstOrDefault();
                    }
                }
                catch (WebException webException)
                {
                    //Network Connectivity Error
                    containsError = true;
                    responseMessage = "Ensure you have internet access.";
                }
                catch (Exception exception)
                {
                    containsError = true;
                    responseMessage = "Internal server error occurred.";
                }
            }

            ResponseMessageLabel.IsVisible = true;
            ResponseMessageLabel.Text = responseMessage;
            ResponseMessageLabel.TextColor = containsError ? Color.Red : Color.Green;
        }
    }
}
