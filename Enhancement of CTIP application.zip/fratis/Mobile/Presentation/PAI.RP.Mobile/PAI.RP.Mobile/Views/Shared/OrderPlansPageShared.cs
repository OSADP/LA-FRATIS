﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Landscape;
using PAI.RP.Mobile.Views.Portrait;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Shared
{
    public abstract class OrderPlansPageShared : BasePage
    {
        private readonly RP.Services.Portable.Planning.IPlanService _planService;
        private readonly IStyleService _styleService;
        private readonly ILocalizationService _localizationService;
        protected ListView OrderPlansListView;

        protected readonly IOrderPlansPageService OrderPlansPageService;


        protected OrderPlansPageShared(IGeolocator geolocator, RP.Services.Portable.Planning.IPlanService planService,
            IStyleService styleService, ILocalizationService localizationService)
            : base(geolocator, styleService, localizationService)
        {
            _planService = planService;
            _styleService = styleService;
            _localizationService = localizationService;
            OrderPlansListView = this.FindByName<ListView>("OrderPlansListView");
            BackgroundColor = Color.FromRgb(3, 11, 31);
            OrderPlansPageService = (IOrderPlansPageService)PageManagementService.GetNewPageService(this);
        }



        public override async Task RefreshDataAsync(CancellationToken cancellationToken)
        {

            IEnumerable<PlanViewModel> planViewModels;
            var transmissionSuccess = true;

            try
            {
                var localLookup = UserAuthentication.RemotePlansFetched;
                //var plans = await _planService.GetPlansForDriverAsync(DateTime.UtcNow.Date, localLookup, CancellationToken.None);
                var plans = await _planService.GetPlansForDriverAsync(DateTime.Now.Date, localLookup, CancellationToken.None);
                planViewModels = Mapper.Map<IEnumerable<Plan>, IEnumerable<PAI.RP.Mobile.Model.PlanViewModel>>(plans).OrderBy(x => x.ExecutionDate).ThenBy(y => y.Status);
            }

            catch (Exception exception)
            {
                //Could not acquire data
                transmissionSuccess = false;
                planViewModels = new List<PlanViewModel>();
            }

            var bindingContext = new ObservableCollection<PlanViewModel>(planViewModels);

            this.BindingContext = bindingContext;

            if (!transmissionSuccess)
            {
                await DisplayAlert("Data Retrieval Failure", "Failed to retrieve data. \nPlease ensure you have network connectivity.", "OK");
            }
            else
            {
                UserAuthentication.RemotePlansFetched = true;
            }

        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            await RefreshDataAsync(CancellationToken.None);
        }

        protected async void OrderPlanListOnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;
            OrderPlansListView.SelectedItem = null;
            if (await TurnOnGpsAlert()) return;

            var planViewModel = (PlanViewModel)e.SelectedItem;

            if (string.IsNullOrWhiteSpace(planViewModel.Id))
            {
                return;
            }

            var plan = Mapper.Map<PlanViewModel, Plan>(planViewModel);

            await OrderPlansPageService.GoToOdersPlanAsync(plan, CancellationToken.None);
        }

    }
}