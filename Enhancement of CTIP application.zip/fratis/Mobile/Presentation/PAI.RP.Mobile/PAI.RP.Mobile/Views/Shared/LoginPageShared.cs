﻿using System;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Shared
{
    public abstract class LoginPageShared : BasePage
    {
        private readonly IGeolocatorService _geolocatorService;
        private readonly IServerProviderService _serverProviderService;
        protected readonly LoginViewModel ViewModel;
        protected readonly ILoginPageService LoginPageService;
        protected Label TitleLabel1;
        protected Label TitleLabel2;
        protected Label ResetPasswordLabel;
        protected Image BackGroundImage;
        public Label OutputLabel;
        public ActivityIndicator LoadingIndicator;
        public Entry UsernameEntry;
        public Entry PasswordEntry;
        public Picker ServerPicker;

        protected LoginPageShared(IGeolocator geolocator, IStyleService styleService, 
            ILocalizationService localizationService, IGeolocatorService geolocatorService, IServerProviderService serverProviderService) 
            : base(geolocator, styleService, localizationService)
        {
            _geolocatorService = geolocatorService;
            _serverProviderService = serverProviderService;

            TitleLabel1 = this.FindByName<Label>("TitleLabel1");
            TitleLabel2 = this.FindByName<Label>("TitleLabel2");
            ResetPasswordLabel = this.FindByName<Label>("ResetPasswordLabel");
            BackGroundImage = this.FindByName<Image>("BackGroundImage");
            OutputLabel = this.FindByName<Label>("OutputLabel");
            LoadingIndicator = this.FindByName<ActivityIndicator>("LoadingIndicator");
            UsernameEntry = this.FindByName<Entry>("UsernameEntry");
            PasswordEntry = this.FindByName<Entry>("PasswordEntry");
            
            ViewModel = new LoginViewModel();

            this.BindingContext = ViewModel;
           

            //TODO - Create a localization for this title
            TitleLabel1.Text = "FRATIS Driver Application";
            TitleLabel1.HorizontalTextAlignment = TextAlignment.Center;
            TitleLabel1.Font = Font.SystemFontOfSize(35, FontAttributes.Bold);
            TitleLabel2.Text = "";
            TitleLabel2.Font = Font.SystemFontOfSize(22);
            
            LoginPageService = (ILoginPageService)PageManagementService.GetNewPageService(this);

            ResetPasswordLabel.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => LoginPageService.ResetPasswordAsync()),
                NumberOfTapsRequired = 1
            });
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            UserAuthentication.AuthenticationProvider.TokenString = string.Empty;
            UserAuthentication.AuthenticationProvider.SubscriberId = string.Empty;
            UserAuthentication.AuthenticationProvider.DriverId = string.Empty;
            UserAuthentication.AuthenticationProvider.UserId = string.Empty;
            UserAuthentication.AuthenticationProvider.Username = string.Empty;
            UserAuthentication.RemotePlansFetched = false;
            _geolocatorService.StopTracking();

            if (UserAuthentication.ShowDiscalimer)
            {
                
                UserAuthentication.ShowDiscalimer = false;
                await DisplayAlert("WARNING", string.Format("Do not attempt to use the FRATIS driver app while driving. Failure to pay full attention to the operation of your vehicle could result in an accident resulting in serious consequences." + Environment.NewLine + "You assume sole responsibility and risk of using this application."), "Agree");
            }
        }

        protected async void LogIn(object sender, EventArgs e)
        {
            if (await TurnOnGpsAlert()) return;

            //TODO - Remove this hard coded login
            //await LoginPageService.LogInAsync("test@rp.com", "demo", OutputLabel);
            await LoginPageService.LogInAsync(ViewModel.Username, ViewModel.Password, OutputLabel);
        }
    }
}
