﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Mobile.Domain;
using PAI.RP.Services.Portable.Authentication;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Views.Shared
{
    public partial class ResetPasswordShared : IPage
    {
        private readonly IAuthenticationService _authenticationService;

        public Page PageContext { get; set; }
        public PageType PageType { get; set; }
        public PageOrientation PageOrientation { get; set; }

        public ResetPasswordShared(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;

            InitializeComponent();

            PageContext = this;
            PageType = PageType.ResetPassword;
            PageOrientation = PageOrientation.Shared;
        }

        public Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        protected async void OnBackButtonPress(object sender, EventArgs eventArgs)
        {
            await Navigation.PopAsync();
        }

        protected async void OnPasswordReset(object sender, EventArgs eventArgs)
        {
            ResponseMessageLabel.IsVisible = false;
            var username = UsernameEntry.Text ?? string.Empty;

            if (string.IsNullOrWhiteSpace(username))
            {
                ResponseMessageLabel.IsVisible = true;
                ResponseMessageLabel.Text = "Please provide a username.";
                ResponseMessageLabel.TextColor = Color.Red;
                return;
            }

            var containsError = false;
            string responseMessage;
            try
            {
                var result = await _authenticationService.ResetPasswordAsync(username, CancellationToken.None);
                if (result.IsSuccessful)
                {
                    responseMessage = "Temporary password sent to the e-mail address on file.";
                }
                else
                {
                    containsError = true;
                    responseMessage = result.Errors.FirstOrDefault();
                }
            }
            catch (System.Net.WebException webException)
            {
                //Network Connectivity Error
                containsError = true;
                responseMessage = "Ensure you have internet access.";
            }
            catch (Exception exception)
            {
                containsError = true;
                responseMessage = "Internal server error occurred.";
            }

            ResponseMessageLabel.IsVisible = true;
            ResponseMessageLabel.Text = responseMessage;
            ResponseMessageLabel.TextColor = containsError ? Color.Red : Color.Green;
        }
    }
}
