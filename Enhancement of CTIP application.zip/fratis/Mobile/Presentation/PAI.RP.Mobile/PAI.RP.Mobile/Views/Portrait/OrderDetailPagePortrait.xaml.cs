﻿using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using PAI.RP.Services.Portable.Subscribers;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Portrait
{
    public partial class OrderDetailPagePortrait : OrderDetailPageShared
    {
        private readonly IMapperService _mapperService;
        

        public OrderDetailPagePortrait(Order entity, IGeolocator geolocator, IStyleService styleService, 
            ILocalizationService localizationService,IPlanService planService, IOrderService orderService,
            ICustomFieldPreferencesService customFieldPreferencesService, IAuthenticationProvider authenticationProvider, IMapperService mapperService)
            : base(entity, geolocator, styleService, localizationService, planService, orderService, customFieldPreferencesService, authenticationProvider, mapperService)
        {
            _mapperService = mapperService;
           
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrderDetail;
            PageOrientation = PageOrientation.Portrait;
            InitializeComponent();
        }
    }
}