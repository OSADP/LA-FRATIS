﻿using System.Collections.ObjectModel;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Portrait
{
    public partial class OrderPlansPagePortrait : OrderPlansPageShared
    {
        public OrderPlansPagePortrait(IGeolocator geolocator, RP.Services.Portable.Planning.IPlanService planRestService, 
            IStyleService styleService, ILocalizationService localizationService) 
            : base(geolocator, planRestService, styleService, localizationService)
        {
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrderPlans;
            PageOrientation = PageOrientation.Portrait;
            InitializeComponent();
        }
    }

    public class OrderPlansPortraitTemplate : ViewCell
    {
        public static IStyleService StyleService { get; set; }
        public static bool ContainsTitleHeader;
        public static double Width { get; set; }
        public static Collection<PlanViewModel> DataSource { get; set; }
        public static int DataSourceIndex { get; set; }

        public OrderPlansPortraitTemplate()
        {
            var dataItem = DataSource[DataSourceIndex];

            var fiftyPercentWidth = Width * 0.5d;

            var planNameLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            planNameLabel.SetBinding(Label.TextProperty, "Name");

            var planDateLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            planDateLabel.SetBinding(Label.TextProperty, "ExecutionDateDisplay");

            var assignedOrdersLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            assignedOrdersLabel.SetBinding(Label.TextProperty, new Binding("AssignedOrdersDisplay", stringFormat: ContainsTitleHeader ? null : "Orders: {0}"));

            var planestimatedMilesLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            planestimatedMilesLabel.SetBinding(Label.TextProperty, new Binding("TotalTravelDistanceDisplay", stringFormat: ContainsTitleHeader ? null : "Miles: {0}"));

            var contentRow = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Spacing = 0,
                Children =
                {
                    new StackLayout
                    {
                        Orientation = StackOrientation.Vertical,
                        Spacing = 0,
                        Children =
                        {
                            planNameLabel,
                            planDateLabel
                        }
                    },
                    new StackLayout
                    {
                        Orientation = StackOrientation.Vertical,
                        Spacing = 0,
                        Children =
                        {
                            assignedOrdersLabel,
                            planestimatedMilesLabel
                        }
                    }
                }
            };
            var divider = new BoxView { Color = Color.FromRgb(105, 105, 105), WidthRequest = Width, HeightRequest = 0.5 };
            var rowContainer = new StackLayout
            {
                Orientation = StackOrientation.Vertical,
                Spacing = 0,
                Children =
                {
                    contentRow,
                    divider
                }
            };

            if (ContainsTitleHeader)
            {
                ContainsTitleHeader = false;
                planNameLabel.Font = Font.SystemFontOfSize(24);
                planDateLabel.Font = Font.SystemFontOfSize(24);
                assignedOrdersLabel.Font = Font.SystemFontOfSize(24);
                planestimatedMilesLabel.Font = Font.SystemFontOfSize(24);
            }
            else
            {
                if (dataItem.Status == PlanStatus.Received)
                {
                    //Bold the text if the plan has not been started yet
                    planNameLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    planDateLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    assignedOrdersLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    planestimatedMilesLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                }
                else
                {
                    planNameLabel.Font = Font.SystemFontOfSize(18);
                    planDateLabel.Font = Font.SystemFontOfSize(18);
                    assignedOrdersLabel.Font = Font.SystemFontOfSize(18);
                    planestimatedMilesLabel.Font = Font.SystemFontOfSize(18);

                    //Set the background to gray if the plan has already been started
                    contentRow.BackgroundColor = Color.FromRgb(240, 240, 240);
                }
            }

            StyleService.StylizeElement(rowContainer);
            
            View = rowContainer;
            ++DataSourceIndex;
        }
    }
}
