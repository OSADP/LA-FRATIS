﻿using System.Collections.ObjectModel;
using System.Threading;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Planning;
using Xamarin.Forms;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Portrait
{
    public partial class OrdersPlanDetailPagePortrait : OrdersPlanDetailPageShared
    {
        private Plan _entity;
        private readonly IStyleService _styleService;
        private readonly RP.Services.Portable.Planning.IPlanService _planService;

        public OrdersPlanDetailPagePortrait(Plan entity, IGeolocator geolocator, IStyleService styleService
            , ILocalizationService localizationService, IMapperService mapperService,
            IOrderService orderService, IPlanService planService)
            : base(entity, geolocator, styleService, localizationService, mapperService, planService)
        {
            _entity = entity;
            _styleService = styleService;
            _planService = planService;
        }

        protected override void InitComponent()
        {
            PageType = PageType.OrdersPlanDetail;
            PageOrientation = PageOrientation.Portrait;
            InitializeComponent();
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            _entity = await _planService.GetPlanLocallyAsync(_entity.Id, CancellationToken.None);
            var planViewModel = Mapper.Map<Plan, PlanViewModel>(_entity);

            this.BindingContext = planViewModel;

            OrdersPlanDetailPortraitTemplate.StyleService = _styleService;
            OrdersPlanDetailPortraitTemplate.ContainsTitleHeader = false;
            OrdersPlanDetailPortraitTemplate.Width = ScreenWidth;
            OrdersPlanDetailPortraitTemplate.DataSource = planViewModel.Orders;
            OrdersPlanDetailPortraitTemplate.DataSourceIndex = 0;
            OrderPlanListView.ItemTemplate = new DataTemplate(typeof(OrdersPlanDetailPortraitTemplate));
        }
    }

    public class OrdersPlanDetailPortraitTemplate : ViewCell
    {
        public static IStyleService StyleService { get; set; }
        public static bool ContainsTitleHeader;
        public static double Width { get; set; }
        public static Collection<OrderViewModel> DataSource { get; set; }
        public static int DataSourceIndex { get; set; }

        public OrdersPlanDetailPortraitTemplate()
        {
            var dataItem = DataSource[DataSourceIndex];

            var fiftyPercentWidth = Width * 0.5d;

            var orderNumberLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            orderNumberLabel.SetBinding(Label.TextProperty, "Number");

            var orderStatusLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            orderStatusLabel.SetBinding(Label.TextProperty, "StatusDisplay");

            var orderDateLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            orderDateLabel.SetBinding(Label.TextProperty, "CreatedDateDisplay");

            var orderTypeLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            orderTypeLabel.SetBinding(Label.TextProperty, "OrderTypeDisplay");

            var customerNameLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            customerNameLabel.SetBinding(Label.TextProperty, "Customer.Name");

            var addressLabel = new Label { WidthRequest = fiftyPercentWidth, XAlign = TextAlignment.Center };
            addressLabel.SetBinding(Label.TextProperty, "Address");

            var contentRow = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Spacing = 0,
                Children =
                {
                    new StackLayout
                    {
                        Orientation = StackOrientation.Vertical,
                        Spacing = 0,
                        Children =
                        {
                            orderNumberLabel,
                            orderTypeLabel,
                            orderStatusLabel,
                        }
                    },
                    new StackLayout
                    {
                        Orientation = StackOrientation.Vertical,
                        Spacing = 0,
                        Children =
                        {
                            customerNameLabel,
                            addressLabel
                        }
                    }
                }
            };
            var divider = new BoxView { Color = Color.FromRgb(105, 105, 105), WidthRequest = Width, HeightRequest = 0.5 };
            var rowContainer = new StackLayout
            {
                Orientation = StackOrientation.Vertical,
                Spacing = 0,
                Children =
                {
                    contentRow,
                    divider
                }
            };

            if (ContainsTitleHeader)
            {
                ContainsTitleHeader = false;
                orderNumberLabel.Font = Font.SystemFontOfSize(23);
                orderStatusLabel.Font = Font.SystemFontOfSize(23);
                orderDateLabel.Font = Font.SystemFontOfSize(23);
                orderTypeLabel.Font = Font.SystemFontOfSize(23);
                customerNameLabel.Font = Font.SystemFontOfSize(23);
                addressLabel.Font = Font.SystemFontOfSize(23);
            }
            else
            {
                if (dataItem.Status == OrderStatus.Received)
                {
                    //Bold the text if the order has not been started yet
                    orderNumberLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    orderStatusLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    orderDateLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    orderTypeLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    customerNameLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                    addressLabel.Font = Font.SystemFontOfSize(19, FontAttributes.Bold);
                }
                else
                {
                    orderNumberLabel.Font = Font.SystemFontOfSize(18);
                    orderStatusLabel.Font = Font.SystemFontOfSize(18);
                    orderDateLabel.Font = Font.SystemFontOfSize(18);
                    orderTypeLabel.Font = Font.SystemFontOfSize(18);
                    customerNameLabel.Font = Font.SystemFontOfSize(18);
                    addressLabel.Font = Font.SystemFontOfSize(18);

                    //Set the background to gray if the order has already been started
                    contentRow.BackgroundColor = Color.FromRgb(240, 240, 240);
                }
            }

            View = rowContainer;
            ++DataSourceIndex;
        }
    }
}
