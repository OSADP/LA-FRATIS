﻿using System;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Views.Portrait
{
    public partial class LoginPagePortrait : LoginPageShared
    {
        private readonly IServerProviderService _serverProviderService;

        public LoginPagePortrait(IGeolocator geolocator, IStyleService styleService, ILocalizationService localizationService, IGeolocatorService geolocatorService, IServerProviderService serverProviderService)
            : base(geolocator, styleService, localizationService, geolocatorService, serverProviderService)
        {
            
        }

        protected override void InitComponent()
        {
            PageType = PageType.Login;
            PageOrientation = PageOrientation.Portrait;
            InitializeComponent();
        }
    }
}
