﻿using System;

namespace PAI.RP.Mobile.Domain
{
    public enum PageOrientation
    {
        Portrait = 1,
        Landscape = 2,
        Shared = 3
    }
}
