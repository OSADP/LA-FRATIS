﻿using System;

namespace PAI.RP.Mobile.Domain
{
    public enum PageType
    {
        Login = 1,
        OrderPlans = 2,
        OrdersPlanDetail = 3,
        OrderDetail = 4,
        StartOrderReason = 5,
        Dashboard = 6,
        ResetPassword = 7,
        ChangePassword = 8,
        OrderRouteStops = 9,
        CoPilotDemo = 50
    }
}