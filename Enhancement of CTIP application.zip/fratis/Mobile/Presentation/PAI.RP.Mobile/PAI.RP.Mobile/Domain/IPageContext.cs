﻿using System;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Domain
{
    public interface IPageContext
    {
        Page PageContext { get; set; }
    }
}