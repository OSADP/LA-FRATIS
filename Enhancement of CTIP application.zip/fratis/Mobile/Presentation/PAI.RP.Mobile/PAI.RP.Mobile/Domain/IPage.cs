﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace PAI.RP.Mobile.Domain
{
    /// <summary>
    /// Interface for a Xamarin.Forms.Page
    /// </summary>
    public interface IPage : IPageContext
    {
        PageType PageType { get; set; }
        PageOrientation PageOrientation { get; set; }
        /// <summary>
        /// Refreshes the data on the page
        /// </summary>
        /// <returns></returns>
        Task RefreshDataAsync(CancellationToken cancellationToken);
    }
}