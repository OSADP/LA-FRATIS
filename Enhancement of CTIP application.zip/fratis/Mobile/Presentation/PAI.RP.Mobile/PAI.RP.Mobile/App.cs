﻿using System;
using System.Linq;
using System.Threading;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Services;
using TinyIoC;
using Xamarin.Forms;
using XLabs.Platform.Mvvm;


namespace PAI.RP.Mobile
{
    public class App : Application
    {
        public App()
        {
            MainPage = GetMainPage();
        }

        /// <summary>
        /// Initializes the application.
        /// </summary>
        public static void Init()
        {
            var app = TinyIoCContainer.Current.Resolve<IXFormsApp>();
            if (app == null)
            {
                return;
            }

            app.Startup += (o, e) =>
            {
                //Startup
            };
            app.Closing += (o, e) =>
            {
                //Closing
            };
            app.Error += (o, e) =>
            {
                //Error
            };
            app.Initialize += (o, e) =>
            {
                //Init
            };
            app.Rotation += (o, e) =>
            {
                //Rotation
            };
            app.Resumed += (o, e) =>
            {
                //Resumed
            };
            app.Suspended += (o, e) =>
            {
                //Suspended
            };
        }

        private static Page GetMainPage()
        {
            UserAuthentication.ShowDiscalimer = true;
            var navPage = new NavigationPage(PageManagementService.GetNewPage(PageType.Login).PageContext);

            var pollingService = TinyIoCContainer.Current.Resolve<IPollingService>();
            var messageService = TinyIoCContainer.Current.Resolve<RP.Services.Portable.Messaging.IMessageService>();
            //var localizationService = TinyIoCContainer.Current.Resolve<ILocalizationService>();
            var localNotificationService = TinyIoCContainer.Current.Resolve<ILocalNotification>();
            messageService.MessageResponseResolver.OnFreeFormMessageResponseReceived += (sender, args) =>
            {
                var currentPage = navPage.CurrentPage;
                Device.BeginInvokeOnMainThread(async () =>
                {
                    var message = args.MessageData.FirstOrDefault();

                    

                    localNotificationService.Notify("", message);
                    await currentPage.DisplayAlert(null, message, "OK");
                });
            };
            messageService.MessageResponseResolver.OnDataRefreshMessageReceived += (sender, args) =>
            {
                var currentPage = navPage.CurrentPage;
                Device.BeginInvokeOnMainThread(async () =>
                {
                    var iPage = currentPage as IPage;
                    if (iPage != null)
                    {
                        await iPage.RefreshDataAsync(CancellationToken.None);
                    }
                });
            };
            //pollingService.OnError += (sender, s) =>
            //{
            //    var currentPage = navPage.CurrentPage;
            //    Device.BeginInvokeOnMainThread(async () =>
            //    {
            //        //do something
            //    });
            //};
            pollingService.Start();

            return navPage;
        }
    }
}