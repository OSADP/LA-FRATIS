﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

//Source: http://forums.xamarin.com/discussion/20608/fix-for-button-layout-bug-on-android
namespace PAI.RP.Mobile.Controls
{
    public class CustomButton : Button
    {
    }
}
