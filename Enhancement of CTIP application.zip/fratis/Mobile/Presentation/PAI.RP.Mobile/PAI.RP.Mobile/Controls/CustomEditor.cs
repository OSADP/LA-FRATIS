﻿using System;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Controls
{
    public class CustomEditor : Editor
    {
        public CustomEditor()
        {
            TextColor = Color.Black;
            BackgroundColor = Color.White;
            BorderColor = Color.Black;
            BorderThickness = 1;
        }

        public Color TextColor { get; set; }
        public Color BorderColor { get; set; }
        public int BorderThickness { get; set; }
    }
}
