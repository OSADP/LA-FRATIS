﻿namespace PAI.RP.Mobile.Services
{
    public interface ILocalNotification
    {
        void Notify(string title, string body);
    }
}