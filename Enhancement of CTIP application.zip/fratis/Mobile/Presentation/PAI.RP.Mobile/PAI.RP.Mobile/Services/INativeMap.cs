﻿using System;
using System.Collections.Generic;
using PAI.RP.Mobile.Model;

namespace PAI.RP.Mobile.Services
{
    public interface INativeMap
    {
        double LatitudeCenterPoint { get; set; }
        double LongitudeCenterPoint { get; set; }
        int ZoomLevel { get; set; }
        void Open();
        void OpenCoPilot(IList<RouteStopViewModel> routeStops);
    }
}
