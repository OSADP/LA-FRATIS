﻿using System;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Services.Portable.Geography;
using PAI.RP.Services.Portable.Setting;
using XLabs.Platform.Services.Geolocation;

namespace PAI.RP.Mobile.Services
{
    public interface IGeolocatorService
    {
        Task StartTrackingAsync(CancellationToken cancellationToken);
        void StopTracking();
    }

    public class GeolocatorService : IGeolocatorService
    {
        private readonly IGeolocator _geolocator;
        private readonly IGeolocationService _geolocationService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly IGeneralPreferenceService _generalPreferenceService;

        private DateTime? _lastGeolocationCaptureTime;
        private TimeSpan _trackingFrequency;

        public GeolocatorService(IGeolocator geolocator, IGeolocationService geolocationService,
            IAuthenticationProvider authenticationProvider, IGeneralPreferenceService generalPreferenceService)
        {
            _geolocator = geolocator;
            _geolocationService = geolocationService;
            _authenticationProvider = authenticationProvider;
            _generalPreferenceService = generalPreferenceService;
            _geolocator.PositionChanged += GeolocatorOnPositionChanged;
            _geolocator.PositionError += GeolocatorOnPositionError;
        }

        private async void GeolocatorOnPositionError(object sender, PositionErrorEventArgs positionErrorEventArgs)
        {
            //ERROR
        }

        private async void GeolocatorOnPositionChanged(object sender, PositionEventArgs positionEventArgs)
        {
            if (_authenticationProvider == null ||
                string.IsNullOrWhiteSpace(_authenticationProvider.SubscriberId) ||
                string.IsNullOrWhiteSpace(_authenticationProvider.UserId) ||
                string.IsNullOrWhiteSpace(_authenticationProvider.DriverId))
            {
                return;
            }

            //var timeStamp = DateTime.UtcNow;
            var timeStamp = DateTime.Now;
            if (_lastGeolocationCaptureTime.HasValue && timeStamp.Subtract(_lastGeolocationCaptureTime.Value) < _trackingFrequency)
            {
                return;
            }
            _lastGeolocationCaptureTime = timeStamp;

            var latitude = positionEventArgs.Position.Latitude;
            var longitude = positionEventArgs.Position.Longitude;
            var accuracy = positionEventArgs.Position.Accuracy;
            var speed = positionEventArgs.Position.Speed;

            await _geolocationService.SaveLocallyAsync(new Geolocation
            {
                SubscriberId = _authenticationProvider.SubscriberId,
                UserId = _authenticationProvider.UserId,
                Latitude = latitude,
                Longitude = longitude,
                TimeStamp = timeStamp,
                Accuracy = accuracy,
                Speed = speed
            }, CancellationToken.None);
        }

        public async Task StartTrackingAsync(CancellationToken cancellationToken)
        {
            if (_authenticationProvider == null || string.IsNullOrWhiteSpace(_authenticationProvider.SubscriberId))
            {
                return;
            }

            if (!_geolocator.IsListening)
            {
                var generalPreference = await _generalPreferenceService.GetAsync(_authenticationProvider.SubscriberId, cancellationToken);
                if (generalPreference != null && generalPreference.TrackingFrequency > 0)
                {
                    _trackingFrequency = TimeSpan.FromMilliseconds(generalPreference.TrackingFrequency);
                    //_geolocator.StartListening((uint)generalPreference.TrackingFrequency, 0, false);
                }
                else
                {
                    //Default to 10 seconds if there is an issue retrieving the generalPreference
                    _trackingFrequency = TimeSpan.FromSeconds(10);
                }

                //TODO - Figure out why this is only tracking every 20 seconds when specifying minTime <20 seconds!
                //TODO - May need to implement a custom tracking service of our own!
                if (_trackingFrequency < TimeSpan.FromSeconds(20))
                {
                    _geolocator.StartListening(0, 0, false);
                }
                else
                {
                    _geolocator.StartListening((uint)_trackingFrequency.TotalMilliseconds, 0, false);
                }
            }
        }

        public void StopTracking()
        {
            if (_geolocator.IsListening)
            {
                _geolocator.StopListening();
            }
            _lastGeolocationCaptureTime = null;
        }
    }
}