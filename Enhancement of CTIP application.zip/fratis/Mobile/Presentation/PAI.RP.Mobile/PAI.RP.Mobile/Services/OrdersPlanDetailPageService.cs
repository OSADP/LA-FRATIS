﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Model;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Planning;

namespace PAI.RP.Mobile.Services
{
    public interface IOrdersPlanDetailPageService : IPageService
    {
        Task ClosePlanAsync(Plan plan, CancellationToken cancellationToken);
        Task GoToOder(Order order);
    }

    public class OrdersPlanDetailPageService : PageService, IOrdersPlanDetailPageService
    {
        private readonly IGeolocatorService _geolocatorService;
        private readonly IPlanService _planService;
        private readonly ILocalizationService _localizationService;
        private readonly string _planLocale;

        public OrdersPlanDetailPageService(IGeolocatorService geolocatorService, IPlanService planService, ILocalizationService localizationService)
        {
            _geolocatorService = geolocatorService;
            _planService = planService;
            _localizationService = localizationService;
            PageType = PageType.OrdersPlanDetail;

            _planLocale = _localizationService.Plan;
        }

        public async Task ClosePlanAsync(Plan plan, CancellationToken cancellationToken)
        {
            //Prompt user for verification
            var closePlan = await PageContext.DisplayAlert("Close " + _planLocale + plan.Name + "?",
                                                                  "Are you sure you want to close " + _planLocale + " " +
                                                                  plan.Name + 
                                                                  "? \nYou cannot edit any " + _localizationService.Orders + " after the " + _planLocale + " is closed.",
                                                                  "YES",
                                                                  "NO");
            if (closePlan)
            {
                if (await _planService.PlanContainsIncompletedOrdersAsync(plan.Id, cancellationToken))
                {
                    // Cannot close the plan when any of the orders on the plan have not been completed
                    await PageContext.DisplayAlert("Cannot Close " + _planLocale + " " + plan.Name,
                                                       _planLocale + " " + plan.Name + 
                                                       " cannot be closed because there are still active orders in this " + _planLocale + ".",
                                                       "OK");
                }
                else
                {
                    _geolocatorService.StopTracking();
                    // Set the Plan status to closed
                    await _planService.ClosePlanAsync(plan, cancellationToken);
                }
            }
        }

        public async Task GoToOder(Order order)
        {           
            await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.OrderDetail, order).PageContext);
        }
    }
}
