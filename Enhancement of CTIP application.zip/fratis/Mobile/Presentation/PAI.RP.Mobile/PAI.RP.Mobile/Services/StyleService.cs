﻿using PAI.RP.Mobile.Controls;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Services
{
    public interface IStyleService
    {
        Color Black { get; }
        Color LightBlue { get; }
        Color LightGray { get; }
        Color LightRed { get; }
        Color LightOrange { get; }
        Color LightGreen { get; }
        Color DarkYellow { get; }
        Color LighterGray { get; }
        Color DarkRed { get; }
        Color Green { get; }
        void StylizeElement(Element element);
        BoxView GetNewHorizontalDivider(double? width = null);
        BoxView GetNewHorizontalDivider(LayoutOptions horizontalOptions);
        BoxView GetNewHorizontalDivider(LayoutOptions horizontalOptions, double lineThickness);
        BoxView GetNewVerticalDivider(LayoutOptions verticalOptions);
        BoxView GetNewVerticalDivider(LayoutOptions verticalOptions, double lineThickness);
    }

    public class StyleService : IStyleService
    {
        public Color Black
        {
            get { return Color.FromRgb(32, 32, 32); }
        }

        public Color DarkYellow
        {
            get { return Color.FromRgb(245, 210, 0); }
        }

        public Color LightBlue
        {
            get { return Color.FromRgb(0, 99, 128); }
        }

        public Color LightGray
        {
            get { return Color.FromRgb(240, 240, 240); }
        }

        public Color DarkRed
        {
            get { return Color.FromRgb(220, 0, 0); }
        }

        public Color LighterGray
        {
            get { return Color.FromRgb(249, 249, 246); }
        }

        public Color LightRed
        {
            get { return Color.FromRgb(127, 63, 63); }
        }

        public Color LightOrange
        {
            get { return Color.FromRgb(247, 107, 26); }
        }

        public Color LightGreen
        {
            get { return Color.FromRgb(63, 126, 71); }
        }

        public Color Green
        {
            get { return Color.Green; }
        }

        public void StylizeElement(Element element)
        {
            if (element is Layout<View>)
            {
                var children = ((Layout<View>)element).Children;
                foreach (var child in children)
                {
                    StylizeElement(child);
                }
            }
            else if (element is ContentView)
            {
                var child = ((ContentView)element).Content;
                StylizeElement(child);
            }
            else if (element is ScrollView)
            {
                var child = ((ScrollView)element).Content;
                StylizeElement(child);
            }
            //else if (element is Label)
            //{
            //    var label = (Label)element;
            //    label.TextColor = Color.Black;
            //    label.FontSize = 20;
            //}
            else if (element is Entry)
            {
                var entry = (Entry)element;
                entry.TextColor = Color.Black;
                //entry.BackgroundColor = Color.Red;
            }
            else if (element is CustomEditor)
            {
                var customEditor = (CustomEditor) element;
                customEditor.BorderColor = Color.FromRgb(105, 105, 105);
                customEditor.BackgroundColor = LightGray;
                customEditor.TextColor = Color.Black;
                customEditor.BorderThickness = 1;
            }
            else if (element is Editor)
            {
                var editor = (Editor)element;
            }
            else if (element is Button)
            {
                var button = (Button)element;
                button.TextColor = Color.White;
                button.BackgroundColor = LightRed;
                button.BorderColor = Color.Black;
            }
        }

        public BoxView GetNewHorizontalDivider(double? width = null)
        {
            var boxView = GetDefaultHorizontalDivider();
            if (width.HasValue)
            {
                boxView.WidthRequest = width.Value;
            }

            return boxView;
        }

        public BoxView GetNewHorizontalDivider(LayoutOptions horizontalOptions)
        {
            var boxView = GetDefaultHorizontalDivider();
            boxView.HorizontalOptions = horizontalOptions;

            return boxView;
        }

        public BoxView GetNewHorizontalDivider(LayoutOptions horizontalOptions, double lineThickness)
        {
            var boxView = GetDefaultHorizontalDivider();
            boxView.HorizontalOptions = horizontalOptions;
            boxView.HeightRequest = lineThickness;

            return boxView;
        }

        public BoxView GetNewVerticalDivider(LayoutOptions verticalOptions)
        {
            var boxView = GetDefaultVerticalDivider();
            boxView.VerticalOptions = verticalOptions;

            return boxView;
        }

        public BoxView GetNewVerticalDivider(LayoutOptions verticalOptions, double lineThickness)
        {
            var boxView = GetDefaultVerticalDivider();
            boxView.VerticalOptions = verticalOptions;
            boxView.WidthRequest = lineThickness;

            return boxView;
        }

        private BoxView GetDefaultHorizontalDivider()
        {
            return new BoxView { Color = Color.FromRgb(105, 105, 105), HeightRequest = 0.5 };
        }

        private BoxView GetDefaultVerticalDivider()
        {
            return new BoxView { Color = Color.FromRgb(105, 105, 105), WidthRequest = 0.5 };
        }
    }
}
