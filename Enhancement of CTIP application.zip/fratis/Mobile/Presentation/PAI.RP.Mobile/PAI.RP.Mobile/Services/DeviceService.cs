﻿using System;
using TinyIoC;
using XLabs.Platform.Device;

namespace PAI.RP.Mobile.Services
{
    public static class DeviceService
    {
        /// <summary>
        /// Obtains the device object
        /// </summary>
        /// <returns>Device Object</returns>
        public static IDevice Get()
        {
            return TinyIoCContainer.Current.Resolve<IDevice>();
        }
    }
}
