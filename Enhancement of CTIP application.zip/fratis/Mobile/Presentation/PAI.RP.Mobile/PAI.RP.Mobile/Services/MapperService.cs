﻿using System.Collections.ObjectModel;
using System.Linq;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Model;

namespace PAI.RP.Mobile.Services
{
    public interface IMapperService
    {
        PlanViewModel MapPlanWithOrdersToViewModel(Plan plan);
        OrderViewModel MapRouteStopsToOrderViewModel(Order order);
    }

    public class MapperService : IMapperService
    {
        public PlanViewModel MapPlanWithOrdersToViewModel(Plan plan)
        {
            var planViewModel = Mapper.Map<Plan, PlanViewModel>(plan);
            if (planViewModel.Orders != null)
            {
                var executedOrdersReordered = planViewModel.Orders.Where(x => x.Status >= OrderStatus.InProgress).OrderByOrderStatusTimeViewModels().ToList();
                var unexecutedOrders = planViewModel.Orders.Where(x => x.Status < OrderStatus.InProgress).ToList();
                 
                var i = 1;
                foreach (var executedOrder in executedOrdersReordered)
                {
                    for (int j = 1; j < executedOrder.RouteStops.Count; j++)
                    {
                        var routeStops = executedOrder.RouteStops[j];
                        
                    }              
                    executedOrder.SequenceNumber = i;
                    ++i;
                }
                foreach (var unexecutedOrder in unexecutedOrders)
                {
                    for (int j = 1; j < unexecutedOrder.RouteStops.Count; j++)
                    {
                        var routeStops = unexecutedOrder.RouteStops[j];
                        
                    }
                    unexecutedOrder.SequenceNumber = i;
                    ++i;
                }

                planViewModel.Orders = new ObservableCollection<OrderViewModel>();
                //Start with unexecuted orders at the start of the list
                foreach (var unexecutedOrder in unexecutedOrders)
                {
                    planViewModel.Orders.Add(unexecutedOrder);
                }
                //Add the executed orders at the end of the list
                foreach (var executedOrder in executedOrdersReordered)
                {
                    planViewModel.Orders.Add(executedOrder);
                }

                //Move the In Progress Orders to the top of the list
                var inProgressOrders = planViewModel.Orders.Where(x => x.Status == OrderStatus.InProgress).OrderByOrderStatusTimeViewModels().ToList();
                i = 0;
                foreach (var inProgressOrder in inProgressOrders)
                {
                    planViewModel.Orders.Remove(inProgressOrder);
                    planViewModel.Orders.Insert(i, inProgressOrder);
                    ++i;
                }
            }

            return planViewModel;
        }

        public OrderViewModel MapRouteStopsToOrderViewModel(Order order)
        {
            var orderViewModel = Mapper.Map<Order, OrderViewModel>(order);
            if (orderViewModel.RouteStops != null)
            {
                var j = 1;
                for (int i = 0; i < orderViewModel.RouteStops.Count; i++)
                {
                    
                    orderViewModel.RouteStops[i].SortOrder = j;
                    j++;
                }
            }
            return orderViewModel;

        }
    }
}
