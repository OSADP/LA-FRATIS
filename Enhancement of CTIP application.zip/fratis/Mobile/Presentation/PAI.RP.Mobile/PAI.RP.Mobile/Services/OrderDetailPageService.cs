﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using PAI.RP.Domain.Portable;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Orders;
using PAI.RP.Services.Portable.Setting;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;
using OrderLocationViewModel = PAI.RP.Mobile.Model.OrderLocationViewModel;
using OrderViewModel = PAI.RP.Mobile.Model.OrderViewModel;

namespace PAI.RP.Mobile.Services
{
    public interface IOrderDetailPageService : IPageService
    {
        void OpenNativeMap(IList<PAI.RP.Mobile.Model.RouteStopViewModel> routeStops);
        void OpenGoogleMaps(double addressLatitude, double addressLongitude);
        Task StartCompleteOrderAsync(CancellationToken cancellationToken);
        Task StartOrderAsync(CancellationToken cancellationToken);
        Task CompleteOrderAsync(CancellationToken cancellationToken);
        Task DeferOrderAsync(CancellationToken cancellationToken);
        Task NotifyCustomerAsync(CancellationToken cancellationToken);
        Task StartRouteStopAsync(CancellationToken cancellationToken);

        Task EnRouteStopAsync(CancellationToken cancellationToken);



    }

    public class OrderDetailPageService : PageService, IOrderDetailPageService
    {
        private Order _order;
        private readonly Plan _plan;
        private readonly INativeMap _nativeMap;
        private readonly IOrderService _orderService;
        private readonly ILocalizationService _localizationService;
        private readonly IStyleService _styleService;
        private readonly IGeneralPreferenceService _generalPreferenceService;
        private readonly IAuthenticationProvider _authenticationProvider;
        private readonly string _orderLocale;

        private OrderViewModel _orderViewModel;

        public OrderDetailPageService(IPageContext pageContext, Order order, Plan plan, INativeMap nativeMap,
            IOrderService orderService, ILocalizationService localizationService, IStyleService styleService,
            IGeneralPreferenceService generalPreferenceService, IAuthenticationProvider authenticationProvider)
        {
            PageType = PageType.OrderDetail;
            PageContext = pageContext.PageContext;
            _order = order;
            _plan = plan;
            _nativeMap = nativeMap;
            _orderService = orderService;
            _localizationService = localizationService;
            _styleService = styleService;
            _generalPreferenceService = generalPreferenceService;
            _authenticationProvider = authenticationProvider;

            _orderLocale = _localizationService.Order;
            _orderViewModel = Mapper.Map<Order, OrderViewModel>(order);
            UpdateInterfaceState();
        }

        public async Task StartCompleteOrderAsync(CancellationToken cancellationToken)
        {
            var routeStops = _order.RouteStops;
            if (_order.Status == OrderStatus.Received)
            {

                await StartOrderAsync(CancellationToken.None);
            }
            else if (_order.Status == OrderStatus.InProgress)
            {
                await CompleteOrderAsync(CancellationToken.None);
            }
        }

        private bool IsOrderPendingRemovalFromPlan()
        {
            return !_orderService.OrderIsInHaystack(_order, _plan.UncommittedOrders);
        }

        public async Task StartRouteStopAsync(CancellationToken cancellationToken)
        {
            if (await _orderService.AnotherRouteStopIsAlreadyInProgressAsync(_order, cancellationToken))
            {
                await PageContext.DisplayAlert("Cannot START Stop",
                                               "Cannot START because there is another Stop In Progress",
                                               "OK");
                return;
            }

            await _orderService.InProgressRouteStop(_order, cancellationToken);
            await _orderService.StartOrderAsync(_order, cancellationToken);

        }

        public async Task EnRouteStopAsync(CancellationToken cancellationToken)
        {
            if (await _orderService.AnotherRouteStopIsAlreadyEnRouteAsync(_order, cancellationToken))
            {
                await PageContext.DisplayAlert("Cannot GO Stop",
                                               "Cannot GO because there is another Stop En Route",
                                               "OK");
                return;
            }

            await _orderService.EnRouteRouteStop(_order, cancellationToken);
            await _orderService.StartOrderAsync(_order, cancellationToken);
        }

        public async Task StartOrderAsync(CancellationToken cancellationToken)
        {
            if (IsOrderPendingRemovalFromPlan())
            {
                await PageContext.DisplayAlert("Cannot START " + _orderLocale + " " + _order.Number,
                                               "Cannot START " + _orderLocale + " " + _order.Number + " because it has been removed from your assignments.",
                                               "OK");
                return;
            }

            var responseSlim = await _orderService.OrderIsReadOnlyAsync(_order, cancellationToken);
            if (responseSlim.HasErrors)
            {
                await DisplayAlertPromptAsync(responseSlim.Errors.FirstOrDefault());

                return;
            }

            var otherOrdersAlreadyInProgress = (await _orderService.OtherOrdersAlreadyInProgressAsync(_order, cancellationToken)).ToList();
            if (otherOrdersAlreadyInProgress.Count > 0)
            {
                // Cannot start the order if another order is already in progress under the plan
                var otherOrderAlreadyInProgress = otherOrdersAlreadyInProgress.FirstOrDefault();

                await PageContext.DisplayAlert("Cannot START " + _orderLocale + " " + _order.Number,
                                               "Cannot START " + _orderLocale + " " + _order.Number + " because " + _orderLocale + " " +
                                               otherOrderAlreadyInProgress.Number + " is already in progress.",
                                               "OK");
                return;
            }

            if (_order.Status == OrderStatus.Received)
            {
                //TODO - Edit and tailor this page to look like the styling of the other pages
                //if (!_orderService.OrderIsNextToStart(_viewModel) && string.IsNullOrWhiteSpace(_viewModel.StartOrderReason))
                //{
                //    await PageContext.Navigation.PushModalAsync(PageManagementService.GetNewPage(PageType.StartOrderReason, _viewModel).PageContext);
                //    return;
                //}
                var startOrder = await PageContext.DisplayAlert("Start " + _orderLocale + "?",
                                                                  "Are you sure you want to START " + _orderLocale + " " + _order.Number + "?",
                                                                  "YES",
                                                                  "NO");

                if (startOrder)
                {

                    _order = await _orderService.StartOrderAsync(_order, cancellationToken);
                    UpdateInterfaceState();


                }
            }
        }

        public async Task CompleteOrderAsync(CancellationToken cancellationToken)
        {
            var orderPendingRemovalFromPlan = !_orderService.OrderIsInHaystack(_order, _plan.UncommittedOrders);
            if (orderPendingRemovalFromPlan)
            {
                await PageContext.DisplayAlert("Cannot COMPLETE " + _orderLocale + " " + _order.Number,
                                               "Cannot COMPLETE " + _orderLocale + " " + _order.Number + " because it has been removed from your assignments.",
                                               "OK");
                return;
            }

            var responseSlim = await _orderService.OrderIsReadOnlyAsync(_order, cancellationToken);
            if (responseSlim.HasErrors)
            {
                await DisplayAlertPromptAsync(responseSlim.Errors.FirstOrDefault());

                return;
            }

            if (_order.Status == OrderStatus.InProgress)
            {
                var completeOrder = await PageContext.DisplayAlert("Complete " + _orderLocale + "?",
                    "Are you sure you want to COMPLETE " + _orderLocale + " " + _order.Number +
                    "?\nYou cannot restart this " + _orderLocale + " once it is completed.",
                    "YES",
                    "NO");
                if (completeOrder)
                {
                    _order = await _orderService.CompleteOrderAsync(_order, cancellationToken);
                    UpdateInterfaceState();
                }
            }
        }

        public async Task DeferOrderAsync(CancellationToken cancellationToken)
        {
            var orderPendingRemovalFromPlan = !_orderService.OrderIsInHaystack(_order, _plan.UncommittedOrders);
            if (orderPendingRemovalFromPlan)
            {
                await PageContext.DisplayAlert("Cannot DEFER " + _orderLocale + " " + _order.Number,
                                               "Cannot DEFER " + _orderLocale + " " + _order.Number + " because it has been removed from your assignments.",
                                               "OK");
                return;
            }

            var responseSlim = await _orderService.OrderIsReadOnlyAsync(_order, cancellationToken);
            if (responseSlim.HasErrors)
            {
                await DisplayAlertPromptAsync(responseSlim.Errors.FirstOrDefault());

                return;
            }

            var deferOrder = await PageContext.DisplayAlert("Defer " + _orderLocale + "?",
                "Are you sure you want to DEFER " + _orderLocale + " " + _order.Number +
                "?",
                "YES",
                "NO");
            if (deferOrder)
            {
                _order = await _orderService.DeferOrderAsync(_order, cancellationToken);
                UpdateInterfaceState();
            }
        }

        public async void OpenNativeMap(IList<PAI.RP.Mobile.Model.RouteStopViewModel> routeStops)
        {
            

            var generalPref = await _generalPreferenceService.GetAsync(_authenticationProvider.SubscriberId, CancellationToken.None);
            switch (generalPref.MapNavigationPreference)
            {
                case MapNavigationPreference.PromptMapChoice:
                    var nativeMapSelected = await PageContext.DisplayAlert("Map Selection",
                                                                  "Which map would you like to open for navigation?",
                                                                  "Native Map",
                                                                  "CoPilot Map");
                    if (nativeMapSelected)
                    {
                        _nativeMap.Open();
                    }
                    else
                    {
                        _nativeMap.OpenCoPilot(routeStops);
                    }
                    break;
                case MapNavigationPreference.CoPilotMap:
                    _nativeMap.OpenCoPilot(routeStops);
                    break;
                default:
                    _nativeMap.Open();
                    break;
            }
        }

        public async void OpenGoogleMaps(double addressLatitude, double addressLongitude)
        {
            _nativeMap.LatitudeCenterPoint = addressLatitude;
            _nativeMap.LongitudeCenterPoint = addressLongitude;

            var nativeMapSelected = await PageContext.DisplayAlert("Map Selection",
                                                                  "Which map would you like to open for navigation?",
                                                                  "Native Map",
                                                                  "CoPilot Map");
            if (nativeMapSelected)
            {
                _nativeMap.Open();
            }

        }

        public async Task NotifyCustomerAsync(CancellationToken cancellationToken)
        {
            var notifyCustomer = await PageContext.DisplayAlert("Notify Customer?",
                                                                  "Do you want to notify the customer with your ETA?",
                                                                  "YES",
                                                                  "NO");
            if (notifyCustomer)
            {
                var context = (OrderDetailPageShared)PageContext;
                //context.NotificationSentLabel.Text = "Notification Sent: " + DateTime.Now.ToString("h:mm tt");
            }
        }

        private async Task DisplayAlertPromptAsync(string alertMessage)
        {
            await PageContext.DisplayAlert("Attention", alertMessage, "OK");
        }

        private void UpdateInterfaceState()
        {
            _orderViewModel = Mapper.Map<Order, OrderViewModel>(_order);
            var context = (OrderDetailPageShared)PageContext;

            context.OrderStatusImage1.Aspect = Aspect.AspectFit;
            context.OrderStatusImage1.Source = ImageSource.FromResource(IsOrderPendingRemovalFromPlan() ?
                "PAI.RP.Mobile.Images.Reject.png" : _orderViewModel.StatusImageFilename);
            context.StartTimeLabel.Text = _orderViewModel.ActualArrivalTimeWithEmptyDashesDisplay;
            context.CompletedTimeLabel.Text = _orderViewModel.ActualDepartureTimeWithEmptyDashesDisplay;
            context.ActualServiceTimeLabel.Text = _orderViewModel.ActualServiceTimeDisplay;

            //var orderIsReadOnly = _orderService.OrderIsReadOnlyAsync(_order);
            if (_order.Status == OrderStatus.Received)
            {
                if (_order.RouteStops.Count() == 1)
                {
                    //context.OrderStatusImage1.IsVisible = false;
                    context.EnRouteStartCompleteButton.Text = "Start";
                    context.EnRouteStartCompleteButton.IsVisible = true;
                    context.EnRouteStartCompleteButton.BackgroundColor = Color.FromHex("#FFA500");
                    //context.StartCompleteButton.IsEnabled = !orderIsReadOnly;
                    //context.DeferButton.IsVisible = true;
                    //context.DeferButton.IsEnabled = !orderIsReadOnly;
                }
            }
            else if (_order.Status == OrderStatus.EnRoute)
            {
                if (_order.RouteStops.Count() == 1)
                {
                    //context.OrderStatusImage1.IsVisible = true;
                    context.EnRouteStartCompleteButton.Text = "Start";
                    context.EnRouteStartCompleteButton.IsVisible = true;
                    //context.StartCompleteButton.IsEnabled = !orderIsReadOnly;
                    //context.DeferButton.IsVisible = true;
                    //context.DeferButton.IsEnabled = !orderIsReadOnly;                  
                 }
            }
            
            else if (_order.Status == OrderStatus.InProgress)
            {
                if (_order.RouteStops.Count() == 1)
                {
                    //context.OrderStatusImage1.IsVisible = true;
                    context.EnRouteStartCompleteButton.IsVisible = true;
                    context.EnRouteStartCompleteButton.IsEnabled = true;
                    context.EnRouteStartCompleteButton.Text = "Complete";
                    context.EnRouteStartCompleteButton.BackgroundColor = Color.Red;
                    //context.DeferButton.IsVisible = true;
                    //context.DeferButton.IsEnabled = false;
                    //context.DeferButton.HeightRequest = 100;
                }
            }
            else if (_order.Status == OrderStatus.Completed)
            {
                if (_order.RouteStops.Count() == 1)
                {
                    //context.OrderStatusImage1.IsVisible = true;
                    context.EnRouteStartCompleteButton.Text = "Completed";
                    context.EnRouteStartCompleteButton.IsVisible = true;
                    context.EnRouteStartCompleteButton.IsEnabled = false;
                    context.EnRouteStartCompleteButton.BackgroundColor = Color.Green;
                    //context.EnRouteStartCompleteButton.HeightRequest = 100;
                    //context.DeferButton.IsVisible = false;
                    //context.DeferButton.IsEnabled = false;
                }
            }
        }
    }
}
