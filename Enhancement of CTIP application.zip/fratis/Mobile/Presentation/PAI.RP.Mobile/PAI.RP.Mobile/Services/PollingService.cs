﻿using System;
using System.Threading;
using PAI.RP.Compatibility.Portable;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Portable.Messaging;
using PAI.RP.Services.Portable.Threading;

namespace PAI.RP.Mobile.Services
{
    public interface IPollingService
    {
        void Start();
        event EventHandler<Exception> OnError;
    }

    public class PollingService : IPollingService
    {
        private readonly IMessageService _messageService;
        private readonly IAuthenticationProvider _authenticationProvider;
		private readonly ILockManager _lockManager;

        private Timer _timer;

        public event EventHandler<Exception> OnError;

        public PollingService(IMessageService messageService, IAuthenticationProvider authenticationProvider, ILockManager lockManager)
        {
            _messageService = messageService;
            _authenticationProvider = authenticationProvider;
			_lockManager = lockManager;
        }

        public void Start()
        {
            //TODO - Change this polling timer to decrease polling rate.
            new Timer(OnPollTick, TimeSpan.FromSeconds(20)).Start(TimeSpan.FromSeconds(30));
        }

        private async void OnPollTick()
        {
            //User has to be logged in to perform any polling actions
            if (_authenticationProvider == null ||
                string.IsNullOrWhiteSpace(_authenticationProvider.TokenString) ||
                string.IsNullOrWhiteSpace(_authenticationProvider.SubscriberId) ||
                string.IsNullOrWhiteSpace(_authenticationProvider.UserId))
            {
                return;
            }

            try
            {
                _lockManager.GetLock(SlimLockManager.MessageSyncLock);
                var syncTask = _messageService.SynchronizeAsync(CancellationToken.None);
                syncTask.Wait();
            }
            catch (Exception exception)
            {
                //Error
                if (OnError != null)
                {
                    OnError(this, exception);
                }
            }
            try
            {
                _lockManager.ReleaseLock(SlimLockManager.MessageSyncLock);
            }
            catch (Exception exception)
            {
                //No lock obtained to release
            }
        }
    }
}
