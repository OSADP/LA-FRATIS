﻿using System;
using System.Collections.Generic;
using System.IO;
using TinyIoC;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Services.Controls
{
    public interface IPickerService<TDataSource>
    {
        Picker Picker { get; }
        int SelectedIndex { get; }
        TDataSource SelectedItem { get; }

        void AddItem(TDataSource item);
        void AddItems(IEnumerable<TDataSource> items);
        void SelectItem(TDataSource item);
    }

    public class PickerService<TDataSource> : IPickerService<TDataSource>
    {
        private readonly Picker _picker;
        private readonly IList<TDataSource> _dataSource = new List<TDataSource>();
        private readonly Func<TDataSource, string> _displayFunction;

        public Picker Picker 
        {
            get { return _picker; }
        }

        public int SelectedIndex
        {
            get { return _picker.SelectedIndex; }
        }

        public TDataSource SelectedItem
        {
            get
            {
                if (_dataSource.Count == 0)
                {
                    throw new InvalidDataException("DataSource cannot be empty.");
                }

                return _picker.SelectedIndex >= 0 ? _dataSource[_picker.SelectedIndex] : _dataSource[0];
            }
        }

        public PickerService(Picker picker, Func<TDataSource, string> displayFunction)
        {
            _picker = picker;
            _displayFunction = displayFunction;
            _picker.SelectedIndexChanged += OnSelectedIndexChanged;
            _picker.SelectedIndex = -1;
        }

        public PickerService(Picker picker, IEnumerable<TDataSource> dataSource, Func<TDataSource, string> displayFunction)
        {
            _picker = picker;
            _displayFunction = displayFunction;

            AddItems(dataSource);
            _picker.SelectedIndexChanged += OnSelectedIndexChanged;
            _picker.SelectedIndex = -1;
        }

        private void OnSelectedIndexChanged(object sender, EventArgs eventArgs)
        {
            //if (_picker.SelectedIndex >= 0)
            //{
            //    _picker.Title = _displayFunction(SelectedItem);
            //}
        }

        public void AddItem(TDataSource item)
        {
            _picker.Items.Add(_displayFunction(item));
            _dataSource.Add(item);
        }

        public void AddItems(IEnumerable<TDataSource> items)
        {
            foreach (var item in items)
            {
                AddItem(item);
            }
        }

        public void SelectItem(TDataSource item)
        {
            if (_dataSource.Count == 0)
            {
                throw new InvalidDataException("DataSource cannot be empty.");
            }

            var itemDisplayName = _displayFunction(item);
            var i = 0;
            foreach (var dataSourceItem in _dataSource)
            {
                if (_displayFunction(dataSourceItem) == itemDisplayName)
                {
                    _picker.SelectedIndex = i;
                    return;
                }
                ++i;
            }

            _picker.SelectedIndex = -1;
        }

        public static IPickerService<TDataSource> Get(Picker picker, IEnumerable<TDataSource> dataSource, Func<TDataSource, string> displayFunction)
        {
            return
                TinyIoCContainer.Current.Resolve<IPickerService<TDataSource>>(new NamedParameterOverloads
                    {
                        {"picker", picker},
                        {"dataSource", dataSource},
                        {"displayFunction", displayFunction}
                    });
        }

        public static IPickerService<TDataSource> Get(Picker picker, Func<TDataSource, string> displayFunction)
        {
            return
                TinyIoCContainer.Current.Resolve<IPickerService<TDataSource>>(new NamedParameterOverloads
                    {
                        {"picker", picker},
                        {"displayFunction", displayFunction}
                    });
        }
    }
}
