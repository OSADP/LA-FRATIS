﻿using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable;

namespace PAI.RP.Mobile.Services
{
    public interface IServerProviderService
    {
        void LoadServer(string server);
    }
    public class ServerProviderService : IServerProviderService
    {
        private readonly IRestClientProvider _restClientProvider;
        public ServerProviderService(IRestClientProvider restClientProvider)
        {
            _restClientProvider = restClientProvider;
        }

        public void LoadServer(string server)
        {

            switch (server)
            {
                case "Local":
                    _restClientProvider.BaseUrl = "https://desktop-t4nblq0:44301/";
                    _restClientProvider.ApiVersion = "v1";
                    return;
                case "QA":
                    _restClientProvider.BaseUrl = "https://qa.fratis.net/";
                    _restClientProvider.ApiVersion = "v1";
                    return;
                case "Production":
                    _restClientProvider.BaseUrl = "https://la.fratis.net/";
                    _restClientProvider.ApiVersion = "v1";
                    return;
                   
            }
            
        }
    }
}