﻿using System;
using System.Collections.Generic;
using PAI.Common.Core.Data;
using PAI.RP.Mobile.Domain;
using TinyIoC;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Services
{
    public static class PageManagementService
    {
        /// <summary>
        /// Gets a new page by pageType and provides namedParameterOverloads if available
        /// </summary>
        /// <param name="pageType"></param>
        /// <param name="namedParameterOverloads"></param>
        /// <returns>A new page based on the provided pageType and namedParameterOverloads</returns>
        private static IPage InternalGetNewPage(PageType pageType, NamedParameterOverloads namedParameterOverloads)
        {
            PageOrientation pageOrientation;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                pageOrientation = PageOrientation.Portrait;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                pageOrientation = PageOrientation.Landscape;
            }
            else
            {
                throw new NotSupportedException("Device.Idiom type not supported.");
            }
            //TODO - Remove this after the Portrait Layouts have been completed for the phone
            pageOrientation = PageOrientation.Landscape;

            IPage newPage;
            //Attempt to retrieve orientation specific page first, otherwise retrieve the shared page orientation
            var pageOrientationSpecific = pageType.ToString() + pageOrientation.ToString();
            var sharedOrientation = pageType.ToString() + PageOrientation.Shared.ToString();

            IPage page;
            if (namedParameterOverloads == null)
            {
                page = TinyIoCContainer.Current.TryResolve<IPage>(pageOrientationSpecific, out newPage)
                           ? newPage
                           : TinyIoCContainer.Current.Resolve<IPage>(sharedOrientation);
            }
            else
            {
                page = TinyIoCContainer.Current.TryResolve<IPage>(pageOrientationSpecific, namedParameterOverloads, out newPage)
                           ? newPage
                           : TinyIoCContainer.Current.Resolve<IPage>(sharedOrientation, namedParameterOverloads);
            }

            return page;
        }

        /// <summary>
        /// Gets a new page by pageType
        /// </summary>
        /// <param name="pageType"></param>
        /// <returns>A new page based on the provided pageType</returns>
        public static IPage GetNewPage(PageType pageType)
        {
            return InternalGetNewPage(pageType, null);
        }

        public static IPage GetNewPage<TEntity>(PageType pageType, TEntity entity) where TEntity : class
        {
            return InternalGetNewPage(pageType, new NamedParameterOverloads { { "entity", entity } });
        }

        /// <summary>
        /// Gets the page service for the provided page.
        /// </summary>
        /// <param name="page"></param>
        /// <param name="constructorArguments"></param>
        /// <returns>The appropriate page service based on the provided page.</returns>
        public static IPageService GetNewPageService(IPage page, IDictionary<string, object> constructorArguments = null)
        {
            IPageService pageService;
            if (constructorArguments == null || constructorArguments.Count == 0)
            {
                pageService = TinyIoCContainer.Current.Resolve<IPageService>(page.PageType.ToString());
            }
            else
            {
                pageService = TinyIoCContainer.Current.Resolve<IPageService>(page.PageType.ToString(),
                                                                             NamedParameterOverloads.FromIDictionary(constructorArguments));
            }
            pageService.PageContext = page.PageContext;
            pageService.PageOrientation = page.PageOrientation;

            return pageService;
        }
    }
}
