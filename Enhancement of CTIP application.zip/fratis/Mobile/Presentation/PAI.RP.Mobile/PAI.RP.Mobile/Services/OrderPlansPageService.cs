﻿using System;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable.StorageCompatible;
using PAI.RP.Mobile.Domain;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Planning;

namespace PAI.RP.Mobile.Services
{
    public interface IOrderPlansPageService : IPageService
    {
        Task GoToOdersPlanAsync(Plan plan, CancellationToken cancellationToken);
    }

    public class OrderPlansPageService : PageService, IOrderPlansPageService
    {
        private readonly IPlanService _planService;
        private readonly ILocalizationService _localizationService;

        public OrderPlansPageService(IPlanService planService, ILocalizationService localizationService)
        {
            _planService = planService;
            _localizationService = localizationService;
            PageType = PageType.OrderPlans;
        }

        public async Task GoToOdersPlanAsync(Plan plan, CancellationToken cancellationToken)
        {
            if (_planService.PlanCanBeStarted(plan))
            {
                var setPlanInProgressStatus =
                    await PageContext.DisplayAlert(null,
                                                   "Do you want to start today's " + _localizationService.Plan + "?", 
                                                   "YES",
                                                   "NO");
                if (setPlanInProgressStatus)
                {
                    await _planService.StartPlanAsync(plan, cancellationToken);
                }
            }

            await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.OrdersPlanDetail, plan).PageContext);
        }
    }
}
