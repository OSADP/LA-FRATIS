﻿using System.Collections.Generic;
using System.Linq;
using PAI.RP.Mobile.Model;

namespace PAI.RP.Mobile.Services
{
    public sealed class OrderStatusTimeViewModelSequenceComparer : IComparer<IEnumerable<OrderStatusTimeViewModel>>
    {
        public int Compare(IEnumerable<OrderStatusTimeViewModel> x, IEnumerable<OrderStatusTimeViewModel> y)
        {
            if (x != null && y != null)
            {
                var lastOrderStatusTimeX = x.LastOrDefault();
                var lastOrderStatusTimeY = y.LastOrDefault();

                if (lastOrderStatusTimeX != null && lastOrderStatusTimeY != null)
                {
                    if (lastOrderStatusTimeX.TimeStamp < lastOrderStatusTimeY.TimeStamp)
                    {
                        return -1;
                    }
                    else if (lastOrderStatusTimeX.TimeStamp > lastOrderStatusTimeY.TimeStamp)
                    {
                        return 1;
                    }
                }
            }

            return 0;
        }
    }

    public static class OrderViewModelExt
    {
        public static IOrderedEnumerable<OrderViewModel> OrderByOrderStatusTimeViewModels(this IEnumerable<OrderViewModel> orderList)
        {
            return orderList.OrderBy(x => x.OrderStatusTimes, new OrderStatusTimeViewModelSequenceComparer());
        }
    }
}
