﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Mobile.Domain;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Services
{
    public interface IPageService : IPage
    {
    }

    public abstract class PageService : IPageService
    {
        public Page PageContext { get; set; }

        public PageType PageType { get; set; }

        public PageOrientation PageOrientation { get; set; }

        protected PageService()
        {
            
        }

        public virtual async Task RefreshDataAsync(CancellationToken cancellationToken)
        {
            //Default Implementation does nothing to the page
        }
    }
}
