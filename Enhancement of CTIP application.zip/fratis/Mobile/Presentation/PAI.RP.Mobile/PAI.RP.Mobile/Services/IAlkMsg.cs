﻿using System;

namespace PAI.RP.Mobile.Services
{
    public interface IAlkMsg
    {
        TimeSpan? TotalEta { get; }
        double? TotalDistance { get; }

        int RequestEtaDistance();
        int Msg_StartUp(string functionName, string configDir, bool isProLicensed, bool isSdkLicensed,
            bool startConnection);
        int Msg_ShutDown();
        int Msg_HasStarted();
        int Msg_IsConnected();
        int Msg_SendAppExit(int lConfirm, int lDestId);
        int Msg_TripLoad(int actionCode, int tripId, int lMsgId);
        int Msg_TripAddStopWithHouseNum(int tripId, string stopName, string houseNumber, string address, string city,
            string state, string zipCode, string jurisdiction, int lLat, int lLon, int lMsgId, string pNorthing,
            string pEasting, string gridSquareAbbrev, int lStop);
        int Msg_SendTrip(int tripId, int lDestId, int lSrcId, int lMsgId);
        void Msg_ParserDelete(int tripId);
    }
}