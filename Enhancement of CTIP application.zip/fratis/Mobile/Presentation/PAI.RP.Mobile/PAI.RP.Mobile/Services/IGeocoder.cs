﻿using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Domain.Portable;

namespace PAI.RP.Mobile.Services
{
    public interface IGeocoder
    {
        Task<Address> ReverseGeocodeAsync(double latitude, double longitude, CancellationToken cancellationToken);
    }
}