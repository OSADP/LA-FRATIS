﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.Common.Core.Extensions;
using PAI.RP.Domain.Portable;
using PAI.RP.Mobile.Domain;
using PAI.RP.Mobile.Views.Shared;
using PAI.RP.Services.Portable.Locale;
using PAI.RP.Services.Portable.Messaging;
using PAI.RP.Services.Portable.Threading;
using PAI.RP.Services.Rest.Portable.Authentication;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Services
{
    public interface ILoginPageService : IPageService
    {
        Task LogInAsync(string username, string password, Label outputLabel);
        Task ResetPasswordAsync();
    }

    public class LoginPageService : PageService, ILoginPageService
    {
        private readonly IGeolocatorService _geolocatorService;
        private readonly IAuthenticationService _authenticationService;
        private readonly IVendorType _vendorType;
        private readonly ILocalizationService _localizationService;
        private readonly ILockManager _lockManager;
        private readonly IMessageService _messageService;

        public LoginPageService(IGeolocatorService geolocatorService, IAuthenticationService authenticationService,
            IVendorType vendorType, ILocalizationService localizationService, ILockManager lockManager, IMessageService messageService)
        {
            _geolocatorService = geolocatorService;
            _authenticationService = authenticationService;
            _vendorType = vendorType;
            _localizationService = localizationService;
            _lockManager = lockManager;
            _messageService = messageService;
            PageType = PageType.Login;
        }

        public async Task LogInAsync(string username, string password, Label outputLabel)
        {
            ToggleLoadIndicator(true);
            var otherError = false;
            var networkError = false;
            var unauthorizedError = false;
            //Do some validation before login
            AuthenticationResponseViewModel authenticationResponse;
            //TODO - Instead of try catches, have the baseRestServices return a RestResponse object with errors and the data result
            try
            {
                authenticationResponse = await _authenticationService.AuthenticateAsync(username, password);
            }
            catch (System.Net.WebException webException)
            {
                //Network Connectivity Error
                authenticationResponse = null;
                networkError = true;
            }
            catch (Exception exception)
            {
                if (exception.IsHttpStatusCodeUnauthorized())
                {
                    unauthorizedError = true;
                    authenticationResponse = null;
                }
                else
                {
                    otherError = true;
                    authenticationResponse = null;
                }
            }

            if (authenticationResponse != null && 
                authenticationResponse.User != null &&
                !string.IsNullOrWhiteSpace(authenticationResponse.Token) &&
                !string.IsNullOrWhiteSpace(authenticationResponse.DriverId))
            {
                //Login Validation Successfull, proceed to Order Plans
                UserAuthentication.AuthenticationProvider.TokenString = authenticationResponse.Token;
                UserAuthentication.AuthenticationProvider.SubscriberId = authenticationResponse.User != null
                    ? authenticationResponse.User.SubscriberIds.FirstOrDefault()
                    : null;
                UserAuthentication.AuthenticationProvider.UserId = authenticationResponse.User != null
                    ? authenticationResponse.User.Id
                    : null;
                UserAuthentication.AuthenticationProvider.Username = authenticationResponse.Username;
                UserAuthentication.AuthenticationProvider.DriverId = authenticationResponse.DriverId;

                var synchronized = false;
                //Synchronize upon login first
                try
                {
                    _lockManager.GetLock(SlimLockManager.MessageSyncLock);
                    await _messageService.SynchronizeAsync(CancellationToken.None);
                    synchronized = true;
                }
                catch (Exception exception)
                {
                    //TODO - Log the message failure exception thrown
                    Debug.WriteLine("SynchronizeAsync Call Exception = {0}", exception.Message);
                }
                finally
                {
                    _lockManager.ReleaseLock(SlimLockManager.MessageSyncLock);
                }
                //catch (Exception exception)
                //{
                //    //No lock obtained to release
                //}

                if (synchronized)
                {
                    //Start Geolocation Tracking
                    await _geolocatorService.StartTrackingAsync(CancellationToken.None);

                    if (authenticationResponse.User.IsPasswordChangeRequired)
                    {
                        var changeRequest = new PasswordChangeRequestViewModel
                        {
                            Username = authenticationResponse.Username,
                            OldPassword = password
                        };
                        await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.ChangePassword, changeRequest).PageContext);
                    }                    
                    else
                    {
                        await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.OrderPlans).PageContext);
                    }
                    outputLabel.Text = string.Empty;
                }
                else
                {
                    outputLabel.Text = "Synchronization failed. Please try again.";
                    outputLabel.TextColor = Color.Red;
                }
            }
            else if (authenticationResponse != null && authenticationResponse.User != null && authenticationResponse.User.IsDisabled)
            {
                outputLabel.Text = "User account is disabled. Please contact your administrator for details.";
                outputLabel.TextColor = Color.Red;
            }
            else if (authenticationResponse != null && string.IsNullOrWhiteSpace(authenticationResponse.DriverId))
            {
                outputLabel.Text = "User is not an associated " + _localizationService.Driver + ".";
                outputLabel.TextColor = Color.Red;
            }
            else if (otherError)
            {
                outputLabel.Text = "Error occurred while logging in.";
                outputLabel.TextColor = Color.Red;
            }
            else if (networkError)
            {
                outputLabel.Text = "Internet connection not found.";
                outputLabel.TextColor = Color.Red;
            }
            else if (unauthorizedError)
            {
                outputLabel.Text = "Unauthorized.";
                outputLabel.TextColor = Color.Red;
            }
            else
            {
                outputLabel.Text = "Incorrect username or password.";
                outputLabel.TextColor = Color.Red;
            }
            ToggleLoadIndicator(false);
        }

        public async Task ResetPasswordAsync()
        {
            await PageContext.Navigation.PushAsync(PageManagementService.GetNewPage(PageType.ResetPassword).PageContext);
        }

        private void ToggleLoadIndicator(bool isLoading)
        {
            var loginPageShared = (LoginPageShared) PageContext;
            loginPageShared.LoadingIndicator.IsRunning = isLoading;
            loginPageShared.LoadingIndicator.IsVisible = isLoading;
            if (isLoading)
            {
                loginPageShared.OutputLabel.TextColor = Color.White;
                loginPageShared.OutputLabel.Text = "Logging in...";
            }
            loginPageShared.UsernameEntry.IsVisible = !isLoading;
            loginPageShared.PasswordEntry.IsVisible = !isLoading;
        }
    }
}
