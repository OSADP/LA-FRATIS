﻿namespace PAI.RP.Mobile.Services
{
    public interface IContext
    {
        string ApplicationVersionNumber { get; }
        string ApplicationVersionName { get; }
    }
}
