﻿using System;

namespace PAI.RP.Mobile.Model
{
    public class TimeWindowViewModel
    {
        private string _startTimeDisplayInShortTimePattern;
        public string StartTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_startTimeDisplayInShortTimePattern) ? StartTime.ToString("h:mm tt") : _startTimeDisplayInShortTimePattern; }
            set { _startTimeDisplayInShortTimePattern = value; }
        }

        public DateTime StartTime { get; set; }

        private string _endTimeDisplayInShortTimePattern;
        public string EndTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_endTimeDisplayInShortTimePattern) ? EndTime.ToString("h:mm tt") : _endTimeDisplayInShortTimePattern; }
            set { _endTimeDisplayInShortTimePattern = value; }
        }

        public DateTime EndTime { get; set; }
    }
}
