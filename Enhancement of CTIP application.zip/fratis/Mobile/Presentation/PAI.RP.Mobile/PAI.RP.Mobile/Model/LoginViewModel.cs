﻿namespace PAI.RP.Mobile.Model
{
    public class LoginViewModel : ObservableViewModel
    {
        private string _username;
        public string Username
        {
            get { return _username; }
            set
            {
                if (value == _username)
                {
                    return;
                }
                _username = value;
                OnPropertyChanged();
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                if (value == _password)
                {
                    return;
                }
                _password = value;
                OnPropertyChanged();
            }
        }
    }
}
