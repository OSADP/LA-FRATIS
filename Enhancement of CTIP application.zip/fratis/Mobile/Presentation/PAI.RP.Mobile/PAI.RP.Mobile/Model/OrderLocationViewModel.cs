﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PAI.RP.Mobile.Model
{
    public class OrderLocationViewModel : ObservableViewModel
    {
        public string OrderId { get; set; }

        public OrderViewModel Order { get; set; }

        public string CustomerId { get; set; }

        public CustomerViewModel Customer { get; set; }

        public IEnumerable<TimeWindowViewModel> TimeWindows { get; set; }

        public TimeSpan ServiceTime { get; set; }

        public string Line1 { get; set; }

        public string Line2 { get; set; }

        public string Line3 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }

        private string _addressDisplay;
        public string AddressDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_addressDisplay))
                {
                    var addressDisplaySb = new StringBuilder();
                    if (!string.IsNullOrWhiteSpace(Line1))
                    {
                        addressDisplaySb.Append(Line1);
                    }
                    if (!string.IsNullOrWhiteSpace(City))
                    {
                        addressDisplaySb.Append("\r\n" + City);
                    }
                    if (!string.IsNullOrWhiteSpace(State))
                    {
                        addressDisplaySb.Append(", " + State);
                    }
                    if (!string.IsNullOrWhiteSpace(Zip))
                    {
                        addressDisplaySb.Append(" " + Zip);
                    }

                    return addressDisplaySb.ToString();
                }
                else
                {
                    return _addressDisplay;
                }
            }
            set { _addressDisplay = value; }
        }

        public string TimeWindowsDisplay
        {
            get
            {
                if (TimeWindows != null && TimeWindows.Any())
                {
                    var timeWindowsSb = new StringBuilder();
                    var i = 0;
                    foreach (var timeWindow in TimeWindows)
                    {
                        if (i > 0)
                        {
                            timeWindowsSb.Append("\r\n");
                        }
                        timeWindowsSb.Append(timeWindow.StartTimeDisplayInShortTimePattern);
                        timeWindowsSb.Append(" - ");
                        timeWindowsSb.Append(timeWindow.EndTimeDisplayInShortTimePattern);
                        ++i;
                    }

                    return timeWindowsSb.ToString();
                }
                return string.Empty;
            }
        }
    }
}
