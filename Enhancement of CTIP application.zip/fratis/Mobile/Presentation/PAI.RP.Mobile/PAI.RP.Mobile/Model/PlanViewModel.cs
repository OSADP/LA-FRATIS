﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using PAI.Common.Core.Data;
using PAI.RP.Domain.Portable;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Model
{
    public class PlanViewModel : ObservableViewModel, IEntity, ISubscriber, IUser, IDatedEntity
    {
        private string _id;
        public string Id
        {
            get { return _id; }
            set
            {
                if (value == _id)
                {
                    return;
                }
                _id = value;
                OnPropertyChanged();
            }
        }

        private string _subscriberId;
        public string SubscriberId
        {
            get { return _subscriberId; }
            set
            {
                if (value == _subscriberId)
                {
                    return;
                }
                _subscriberId = value;
                OnPropertyChanged();
            }
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                if (value == _userId)
                {
                    return;
                }
                _userId = value;
                OnPropertyChanged();
            }
        }

        public string UniqueId { get; set; }

        public string DriverId { get; set; }

        public IEnumerable<PlanStatusTime> PlanStatusTimes { get; set; }

        public ObservableCollection<OrderViewModel> Orders { get; set; }

        public IEnumerable<string> OrderIds { get; set; }

        public IEnumerable<OrderViewModel> UncommittedOrders { get; set; }

        public IEnumerable<string> UncommittedOrderIds { get; set; }

        private double _totalTravelDistance;
        public double TotalTravelDistance
        {
            get { return _totalTravelDistance; }
            set
            {
                _totalTravelDistance = value;
                OnPropertyChanged();
            }
        }

        private string _totalTravelDistanceDisplay;
        public string TotalTravelDistanceDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_totalTravelDistanceDisplay))
                {
                    return Math.Round(_totalTravelDistance, 2, MidpointRounding.AwayFromZero).ToString();
                }
                return _totalTravelDistanceDisplay;
            }
            set { _totalTravelDistanceDisplay = value; }
        }

        private string _assignedOrdersDisplay;
        public string AssignedOrdersDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_assignedOrdersDisplay))
                {
                    return Orders != null ? Orders.Count.ToString() : "0";
                }
                return _assignedOrdersDisplay;
            }
            set { _assignedOrdersDisplay = value; }
        }

        private string _completedOrdersDisplay;
        public string CompletedOrdersDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_completedOrdersDisplay))
                {
                    return Orders != null ? Orders.Count(x => x.Status == OrderStatus.Completed).ToString() : "0";
                }
                return _completedOrdersDisplay;
            }
            set { _completedOrdersDisplay = value; }
        }

        private string _deferredOrdersDisplay;
        public string DeferredOrdersDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_deferredOrdersDisplay))
                {
                    return Orders != null ? Orders.Count(x => x.Status == OrderStatus.Deferred).ToString() : "0";
                }
                return _deferredOrdersDisplay;
            }
            set { _deferredOrdersDisplay = value; }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name)
                {
                    return;
                }
                _name = value;
                OnPropertyChanged();
            }
        }

        private string _statusDisplay;
        public string StatusDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_statusDisplay))
                {
                    if (_status == PlanStatus.InProgress)
                    {
                        return "In Progress";
                    }
                    return _status.ToString();
                }
                return _statusDisplay;
            }
            set { _statusDisplay = value; }
        }

        public ImageSource PlanStatusImage
        {
            get
            {
                switch (_status)
                {
                    case PlanStatus.Received:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.ReceivedPlan.png");
                    case PlanStatus.InProgress:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.InProgressPlan.png");
                    case PlanStatus.Completed:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.CompletedPlan.png");
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }
        public string StatusImageFilename
        {
            get
            {
                switch (_status)
                {
                    case PlanStatus.Received:
                        return "PAI.RP.Mobile.Images.ReceivedPlan.png";
                    case PlanStatus.InProgress:
                        return "PAI.RP.Mobile.Images.InProgressPlan.png";
                    case PlanStatus.Completed:
                        return "PAI.RP.Mobile.Images.CompletedPlan.png";
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }

        private PlanStatus _status;
        public PlanStatus Status
        {
            get { return _status; }
            set
            {
                if (value == _status)
                {
                    return;
                }
                _status = value;
                OnPropertyChanged();
            }
        }

        private string _createdDateDisplay;
        public string CreatedDateDisplay
        {
            get { return string.IsNullOrWhiteSpace(_createdDateDisplay) ? _createdDate.ToLocalTime().ToString("MM/dd/yy") : _createdDateDisplay; }
            set { _createdDateDisplay = value; }
        }

        private DateTime _createdDate;
        public DateTime CreatedDate
        {
            get { return _createdDate; }
            set
            {
                if (value == _createdDate)
                {
                    return;
                }
                _createdDate = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _lastModifiedDate;
        public DateTime? LastModifiedDate
        {
            get { return _lastModifiedDate; }
            set
            {
                if (value == _lastModifiedDate)
                {
                    return;
                }
                _lastModifiedDate = value;
                OnPropertyChanged();
            }
        }

        private string _executionDateDisplay;
        public string ExecutionDateDisplay
        {
            get { return string.IsNullOrWhiteSpace(_executionDateDisplay) ? _executionDate.Date.ToString("MM/dd/yy") : _executionDateDisplay; }
            set { _executionDateDisplay = value; }
        }

        private DateTime _executionDate;
        public DateTime ExecutionDate
        {
            get { return _executionDate; }
            set
            {
                if (value == _executionDate)
                {
                    return;
                }
                _executionDate = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _startTime;
        public DateTime? StartTime
        {
            get { return _startTime; }
            set
            {
                if (value.Equals(_startTime))
                {
                    return;
                }
                _startTime = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _endTime;
        public DateTime? EndTime
        {
            get { return _endTime; }
            set
            {
                if (value.Equals(_endTime))
                {
                    return;
                }
                _endTime = value;
                OnPropertyChanged();
            }
        }

        public string Hash { get; set; }

        public string Data { get; set; }
    }
}
