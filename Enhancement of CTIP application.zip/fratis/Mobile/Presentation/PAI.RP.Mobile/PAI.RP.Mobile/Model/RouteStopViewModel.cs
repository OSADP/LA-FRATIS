﻿using System;
using PAI.Common.Core.Data;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Model
{
    public class RouteStopViewModel
    {
        public int JobId { get; set; }

        public int? StopActionId { get; set; }
        public int SortOrder { get; set; }
        public LocationModelSlim Location { get; set; }
        public RouteStopStatus RouteStopStatus
        {
            get
            {
                return _routeStopStatus;
               
            }
            set
            {
                _routeStopStatus = value;
                

            }
        }
        public long WindowStart { get; set; }

        private RouteStopStatus _routeStopStatus;

        public ImageSource RouteStopStatusImage
        {
            get
            {                
                switch (_routeStopStatus)
                {
                    case RouteStopStatus.Invalid:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.Reject.png");
                    case RouteStopStatus.Active:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.ReceivedOrder.png");
                    case RouteStopStatus.EnRoute:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.EnRoute.png");
                    case RouteStopStatus.InProgress:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.InProgressOrder.png");
                    case RouteStopStatus.Completed:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.CompletedOrder.png");
                    case RouteStopStatus.Deferred:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.DeferredOrder.png");
                    default:
                        throw new ArgumentOutOfRangeException();
                }
               
            }
        }
        public DateTime WindowStartDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowStart) : DateTime.UtcNow.Date.AddTicks(WindowStart);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);
                var dt = new DateTime(WindowStart);
                return dt;
            }
        }

        private string _startTimeDisplayInShortTimePattern;
        public string StartTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_startTimeDisplayInShortTimePattern) ? WindowStartDateTime.ToString("h:mm tt") : _startTimeDisplayInShortTimePattern; }
            set { _startTimeDisplayInShortTimePattern = value; }
        }

        public long WindowEnd { get; set; }

        public DateTime WindowEndDateTime
        {
            get
            {
                //var dt = Job != null && Job.DueDate.HasValue ?
                //    Job.DueDate.Value.Date.AddTicks(WindowEnd) : DateTime.UtcNow.Date.AddTicks(WindowEnd);

                //return new DateTime(dt.Ticks, DateTimeKind.Local);

                var dt = new DateTime(WindowEnd);
                return dt;
            }
        }

        private string _endTimeDisplayInShortTimePattern;
        public string EndTimeDisplayInShortTimePattern
        {
            get { return string.IsNullOrWhiteSpace(_endTimeDisplayInShortTimePattern) ? WindowEndDateTime.ToString("h:mm tt") : _endTimeDisplayInShortTimePattern; }
            set { _endTimeDisplayInShortTimePattern = value; }
        }

        public TimeSpan ServiceTime { get; set; }

        /// <summary>
        /// Gets or sets the stop delay in ticks
        /// </summary>
        public virtual long? StopDelay { get; set; }

        public DateTime? CreatedDate { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public DateTime? EstimatedETA { get; set; }

        public DateTime? ActualETA { get; set; }
       
        
    }
}