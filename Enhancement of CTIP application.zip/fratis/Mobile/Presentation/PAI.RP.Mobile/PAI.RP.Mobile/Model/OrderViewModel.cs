﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using PAI.Common.Core.Data;
using PAI.Common.Core.Extensions;
using PAI.RP.Domain.Portable;
using PAI.RP.Services.Rest.Portable.Model;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Model
{
    public class OrderViewModel : ObservableViewModel, IEntity, ISubscriber, IUser, IDatedEntity
    {
        private string _id;
        public string Id
        {
            get { return _id; }
            set
            {
                if (value == _id)
                {
                    return;
                }
                _id = value;
                OnPropertyChanged();
            }
        }

        private string _subscriberId;
        public string SubscriberId
        {
            get { return _subscriberId; }
            set
            {
                if (value == _subscriberId)
                {
                    return;
                }
                _subscriberId = value;
                OnPropertyChanged();
            }
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                if (value == _userId)
                {
                    return;
                }
                _userId = value;
                OnPropertyChanged();
            }
        }

        

        private string _planId;
        public string PlanId
        {
            get { return _planId; }
            set
            {
                if (value == _planId)
                {
                    return;
                }
                _planId = value;
                OnPropertyChanged();
            }
        }

        public PlanViewModel Plan { get; set; }

        private string _number;
        public string Number
        {
            get { return _number; }
            set
            {
                if (value == _number)
                {
                    return;
                }
                _number = value;
                OnPropertyChanged();
            }
        }

        private string _sequenceNumberDisplay;
        public string SequenceNumberDisplay
        {
            get { return string.IsNullOrWhiteSpace(_sequenceNumberDisplay) ? _sequenceNumber.ToString() : _sequenceNumberDisplay; }
            set { _sequenceNumberDisplay = value; }
        }

        private int _sequenceNumber;
        public int SequenceNumber
        {
            get { return _sequenceNumber; }
            set
            {
                if (value == _sequenceNumber)
                {
                    return;
                }
                _sequenceNumber = value;
                OnPropertyChanged();
            }
        }

        private string _statusDisplay;
        public string StatusDisplay
        {
            get { return string.IsNullOrWhiteSpace(_statusDisplay) ? _status.UppercaseSpaceFormat() : _statusDisplay; }
            set { _statusDisplay = value; }
        }

        public ImageSource OrderStatusImage
        {
            get
            {
                switch (_status)
                {
                    
                    case OrderStatus.Received:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.ReceivedOrder.png");
                    case OrderStatus.EnRoute:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.EnRoute.png");
                    case OrderStatus.InProgress:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.InProgressOrder.png");
                    case OrderStatus.Completed:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.CompletedOrder.png");
                    case OrderStatus.Deferred:
                        return ImageSource.FromResource("PAI.RP.Mobile.Images.DeferredOrder.png");
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }
        public string StatusImageFilename
        {
            get
            {
                switch (_status)
                {
                    case OrderStatus.Received:
                        return "PAI.RP.Mobile.Images.ReceivedOrder.png";
                    case OrderStatus.InProgress:
                        return "PAI.RP.Mobile.Images.InProgressOrder.png";
                    case OrderStatus.EnRoute:
                        return "PAI.RP.Mobile.Images.EnRoute.png";
                    case OrderStatus.Completed:
                        return "PAI.RP.Mobile.Images.CompletedOrder.png";
                    case OrderStatus.Deferred:
                        return "PAI.RP.Mobile.Images.DeferredOrder.png";
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }

        private OrderStatus _status;
        public OrderStatus Status
        {
            get { return _status; }
            set
            {
                if (value == _status)
                {
                    return;
                }
                _status = value;
                OnPropertyChanged();
                OnPropertyChanged("StatusDisplay");
            }
        }

        private string _createdDateDisplay;
        public string CreatedDateDisplay
        {
            get { return string.IsNullOrWhiteSpace(_createdDateDisplay) ? _createdDate.ToLocalTime().ToString("MM/dd/yy") : _createdDateDisplay; }
            set { _createdDateDisplay = value; }
        }

        private DateTime _createdDate;
        public DateTime CreatedDate
        {
            get { return _createdDate; }
            set
            {
                if (value == _createdDate)
                {
                    return;
                }
                _createdDate = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _lastModifiedDate;
        public DateTime? LastModifiedDate
        {
            get { return _lastModifiedDate; }
            set
            {
                if (value == _lastModifiedDate)
                {
                    return;
                }
                _lastModifiedDate = value;
                OnPropertyChanged();
            }
        }

        public string NotificationSentDisplay
        {
            get { return _notificationSent ? "Yes" : "No"; }
        }

        private bool _notificationSent;
        public bool NotificationSent
        {
            get { return _notificationSent; }
            set
            {
                if (value == _notificationSent)
                {
                    return;
                }
                _notificationSent = value;
                OnPropertyChanged();
            }
        }

        private string _priorityDisplay;
        public string PriorityDisplay
        {
            get { return string.IsNullOrWhiteSpace(_priorityDisplay) ? _priority : _priorityDisplay; }
            set { _priorityDisplay = value; }
        }

        private string _priority;
        public string Priority
        {
            get { return _priority; }
            set
            {
                if (value == _priority)
                {
                    return;
                }
                _priority = value;
                OnPropertyChanged();
            }
        }

        private string _orderTypeDisplay;
        public string OrderTypeDisplay
        {
            get { return string.IsNullOrWhiteSpace(_orderTypeDisplay) ? OrderType.ToString() : _orderTypeDisplay; }
            set { _orderTypeDisplay = value; }
        }

        public OrderType OrderType { get; set; }

        public string ServiceTimeDisplay
        {
            //TODO - Change this and move the ServiceTimeDisplay into the Locations for each one
            get
            {
                if (Locations == null)
                {
                    return "--:--"; 
                }
                var firstLocation = Locations.FirstOrDefault();
                if (firstLocation == null || firstLocation.ServiceTime <= TimeSpan.Zero)
                {
                    return "--:--";
                }
                var serviceTime = firstLocation.ServiceTime;
                var totalHours = (int)Math.Floor(serviceTime.TotalHours);
                var minutes = serviceTime.Minutes;
                minutes = ActualServiceTime.Seconds >= 30 ? minutes + 1 : minutes;
                if (totalHours > 0)
                {
                    if (minutes > 0)
                    {
                        return totalHours.ToString() + " hr " + minutes.ToString() + " min";
                    }
                    return totalHours.ToString() + " hr";
                }
                return minutes.ToString() + " min";
            }
        }

        private bool _partialPass;
        public bool PartialPass
        {
            get { return _partialPass; }
            set
            {
                if (value == _partialPass)
                {
                    return;
                }
                _partialPass = value;
                OnPropertyChanged();
            }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set
            {
                if (value == _description)
                {
                    return;
                }
                _description = value;
                OnPropertyChanged();
            }
        }

        private string _startOrderReason;
        public string StartOrderReason
        {
            get { return _startOrderReason; }
            set
            {
                if (value == _startOrderReason)
                {
                    return;
                }
                _startOrderReason = value;
                OnPropertyChanged();
            }
        }

        public IList<OrderNoteViewModel> Notes { get; set; }

        public string Hash { get; set; }

        public IEnumerable<OrderLocationViewModel> Locations { get; set; }

        public CustomerViewModel Customer { get; set; }

        public IEnumerable<OrderStatusTimeViewModel> OrderStatusTimes { get; set; }

        private const string EmptyDashDisplay = "--:--";

        public DateTime? ActualArrivalTime
        {
            get
            {
                var result = OrderStatusTimes.LastOrDefault(x => x.Status == OrderStatus.InProgress);
                if (result != null)
                {
                    return result.TimeStamp;
                }
                return null;
            }
        }

        private string _actualArrivalTimeWithEmptyDashesDisplay;
        public string ActualArrivalTimeWithEmptyDashesDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_actualArrivalTimeWithEmptyDashesDisplay))
                {
                    return ActualArrivalTime.HasValue ? ActualArrivalTime.Value.ToLocalTime().ToString("h:mm tt") : EmptyDashDisplay;
                }
                return _actualArrivalTimeWithEmptyDashesDisplay;
            }
            set { _actualArrivalTimeWithEmptyDashesDisplay = value; }
        }

        public DateTime? ActualDepartureTime
        {
            get
            {
                var result = OrderStatusTimes.LastOrDefault(x => x.Status == OrderStatus.Completed || x.Status == OrderStatus.Deferred);
                if (result != null)
                {
                    return result.TimeStamp;
                }
                return null;
            }
        }

        private string _actualDepartureTimeWithEmptyDashesDisplay;
        public string ActualDepartureTimeWithEmptyDashesDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_actualDepartureTimeWithEmptyDashesDisplay))
                {
                    return ActualDepartureTime.HasValue ? ActualDepartureTime.Value.ToLocalTime().ToString("h:mm tt") : EmptyDashDisplay;
                }
                return _actualDepartureTimeWithEmptyDashesDisplay;
            }
            set { _actualDepartureTimeWithEmptyDashesDisplay = value; }
        }

        private string _actualServiceTimeDisplay;
        public string ActualServiceTimeDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_actualServiceTimeDisplay))
                {
                    if (ActualServiceTime <= TimeSpan.Zero)
                    {
                        return "--:--";
                    }
                    var totalHours = (int)Math.Floor(ActualServiceTime.TotalHours);
                    var minutes = ActualServiceTime.Minutes;
                    minutes = ActualServiceTime.Seconds >= 30 ? minutes + 1 : minutes;
                    if (totalHours > 0)
                    {
                        if (minutes > 0)
                        {
                            return totalHours.ToString() + " hr " + minutes.ToString() + " min";
                        }
                        return totalHours.ToString() + " hr";
                    }
                    return minutes.ToString() + " min";
                }
                return _actualServiceTimeDisplay;
            }
            set { _actualServiceTimeDisplay = value; }
        }

        public TimeSpan ActualServiceTime
        {
            get
            {
                if (ActualArrivalTime.HasValue && ActualDepartureTime.HasValue)
                {
                    return ActualDepartureTime.Value - ActualArrivalTime.Value;
                }
                return TimeSpan.Zero;
            }
        }

        public string ReferenceNumber { get; set; }

        public Dictionary<string, object> CustomFields { get; set; }


        public IList<RouteStopViewModel> RouteStops { get; set; } 
        #region Custom Field Properties

        public string InspectionType
        {
            get
            {
                return CustomFields.ContainsKey("inspectionType")
                    ? (string) CustomFields["inspectionType"]
                    : string.Empty;
            }
        }

        public string TypeOfWork
        {
            get
            {
                return CustomFields.ContainsKey("typeOfWork")
                    ? (string)CustomFields["typeOfWork"]
                    : string.Empty;
            }
        }

        public string DepartmentOfCommerce
        {
            get
            {
                return CustomFields.ContainsKey("departmentOfCommerce")
                    ? (string)CustomFields["departmentOfCommerce"]
                    : string.Empty;
            }
        }

        public string InspectionPriority
        {
            get
            {
                return CustomFields.ContainsKey("inspectionPriority")
                    ? (string)CustomFields["inspectionPriority"]
                    : string.Empty;
            }
        }

        public string PermitName
        {
            get
            {
                return CustomFields.ContainsKey("permitName")
                    ? (string)CustomFields["permitName"]
                    : string.Empty;
            }
        }

        public string PermitType
        {
            get
            {
                return CustomFields.ContainsKey("permitType")
                    ? (string)CustomFields["permitType"]
                    : string.Empty;
            }
        }

        public string InspectionOccurrence
        {
            get
            {
                return CustomFields.ContainsKey("inspectionOccurrence")
                    ? (string)CustomFields["inspectionOccurrence"]
                    : string.Empty;
            }
        }

        public string PickupNumber { get; set; }

        public string BookingNumber { get; set; }

        public string BillOfLading { get; set; }

        private string _consigneeNameDisplay;
        public string ConsigneeName {
            get
            {
                return RouteStops.Count() > 1 ? string.Format("C: " + _consigneeNameDisplay) : string.Empty;
            }
            set
            {
                _consigneeNameDisplay = value;
            }
        }

        private string _shipperNameDisplay;

        public string ShipperName
        {
            get
            {
                return RouteStops.Count() > 1 ? string.Format("S: " + _shipperNameDisplay) : string.Empty;
            }
            set
            {
                _shipperNameDisplay = value;
            } 
        }
        
        public string ContainerOwner { get; set;}

        private string _containerNumberDisplay;
        public string ContainerNumber
        {
            get
            {
                return RouteStops.Count() > 1 ? string.Format("C#: " + _containerNumberDisplay) : string.Empty;
            }
            set
            {
                _containerNumberDisplay = value;
            }
        }
        public string Container { get; set; }

        public string ChassisOwner { get; set; }

        public string Chassis { get; set; }

        public string ChassisNumber { get; set; }

        public string CustomField1 { get; set; }

        public string CustomField2 { get; set; }
        public string CustomField3 { get; set; }
        public string CustomField4 { get; set; }
        public string CustomField5 { get; set; }
        #endregion
    }
}
