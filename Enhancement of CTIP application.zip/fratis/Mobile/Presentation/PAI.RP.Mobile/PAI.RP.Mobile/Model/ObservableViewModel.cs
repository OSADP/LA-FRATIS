﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PAI.RP.Mobile.Model
{
    public abstract class ObservableViewModel : INotifyPropertyChanged // Interface required for Two-Way databinding in Xamarin.Forms
    {
        public event PropertyChangedEventHandler PropertyChanged; // Required by INotifyPropertyChanged

        /// <summary>
        ///   This is a helper method that will raise the PropertyChanged event when a property is changed.
        /// </summary>
        /// <param name="propertyName">Property name. If null, then this property will hold the name of the member that invoked it.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            ExplicitOnPropertyChanged(propertyName);
        }

        protected virtual void ExplicitOnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
