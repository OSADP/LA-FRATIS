﻿using System.Text;
using PAI.Common.Core.Data;

namespace PAI.RP.Mobile.Model
{
    public class CustomerViewModel : ObservableViewModel, IEntity
    {
        private string _id;
        public string Id
        {
            get { return _id; }
            set
            {
                if (value == _id)
                {
                    return;
                }
                _id = value;
                OnPropertyChanged();
            }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name)
                {
                    return;
                }
                _name = value;
                OnPropertyChanged();
            }
        }

        private string _addressDisplay;
        public string AddressDisplay
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_addressDisplay))
                {
                    var addressDisplaySb = new StringBuilder();
                    if (!string.IsNullOrWhiteSpace(Line1))
                    {
                        addressDisplaySb.Append(Line1);
                    }
                    if (!string.IsNullOrWhiteSpace(City))
                    {
                        addressDisplaySb.Append("\r\n" + City);
                    }
                    if (!string.IsNullOrWhiteSpace(State))
                    {
                        addressDisplaySb.Append(", " + State);
                    }
                    if (!string.IsNullOrWhiteSpace(Zip))
                    {
                        addressDisplaySb.Append(" " + Zip);
                    }

                    return addressDisplaySb.ToString();
                }
                else
                {
                    return _addressDisplay;
                }
            }
            set { _addressDisplay = value; }
        }

        public string CustomerNumber { get; set; }

        public string PhoneNumber { get; set; }

        public string Email { get; set; }

        public string Line1 { get; set; }

        public string Line2 { get; set; }

        public string Line3 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }
    }
}
