using System;
using Android.Content.PM;
using Xamarin.Forms;

namespace PAI.RP.Mobile.Droid.Services
{
    public static class UtilityService
    {
        public static bool IsAppInstalled(String packageName)
        {
            var packageManager = Forms.Context.PackageManager;
            var appInstalled = false;
            try
            {
                packageManager.GetPackageInfo(packageName, PackageInfoFlags.Activities);
                appInstalled = true;
            }
            catch (PackageManager.NameNotFoundException e)
            {
                appInstalled = false;
            }
            return appInstalled;
        }
    }
}