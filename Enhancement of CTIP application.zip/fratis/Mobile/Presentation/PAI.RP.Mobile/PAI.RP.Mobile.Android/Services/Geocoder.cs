using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PAI.RP.Mobile.Services;
using Xamarin.Forms;

[assembly: Dependency(typeof(PAI.RP.Mobile.Droid.Services.Geocoder))]
namespace PAI.RP.Mobile.Droid.Services
{
    public class Geocoder: IGeocoder
    {
        private Android.Locations.Geocoder _geocoder;

        public Geocoder()
        {
            _geocoder = new Android.Locations.Geocoder(Forms.Context);
        }

        public async Task<RP.Domain.Portable.Address> ReverseGeocodeAsync(double latitude, double longitude, CancellationToken cancellationToken)
        {
            RP.Domain.Portable.Address result = null;
            var androidAddresses = await _geocoder.GetFromLocationAsync(latitude, longitude, 1);
            if (androidAddresses != null)
            {
                var firstAndroidAddress = androidAddresses.FirstOrDefault();
                if (firstAndroidAddress != null)
                {
                    result = new RP.Domain.Portable.Address { Latitude = latitude, Longitude = longitude };
                    //TODO - Verify the line addresses are matching correctly
                    result.Line1 = firstAndroidAddress.GetAddressLine(0) ?? string.Empty;
                    result.City = firstAndroidAddress.GetAddressLine(1) ?? string.Empty;
                    result.State = firstAndroidAddress.GetAddressLine(2) ?? string.Empty;
                    result.Zip = firstAndroidAddress.GetAddressLine(3) ?? string.Empty;
                    //for (int i = 0; i < firstAndroidAddress.MaxAddressLineIndex; i++)
                    //{
                    //    var addressLine = firstAndroidAddress.GetAddressLine(i);
                    //    result.Line1 = addressLine;
                    //}
                }
            }

            return result;
        }
    }
}