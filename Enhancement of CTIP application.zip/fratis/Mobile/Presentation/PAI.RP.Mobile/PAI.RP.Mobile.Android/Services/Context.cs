using PAI.RP.Mobile.Services;
using Xamarin.Forms;

[assembly: Dependency(typeof(PAI.RP.Mobile.Droid.Services.Context))]
namespace PAI.RP.Mobile.Droid.Services
{
    public class Context : IContext
    {
        public string ApplicationVersionNumber { get; private set; }
        public string ApplicationVersionName { get; private set; }

        public Context()
        {
            var packageInfo = Forms.Context.PackageManager.GetPackageInfo(Forms.Context.PackageName, 0);
            ApplicationVersionNumber = packageInfo.VersionCode.ToString();
            ApplicationVersionName = packageInfo.VersionName;
        }
    }
}