using System;
using Android.App;
using PAI.RP.Mobile.Droid.Services;
using PAI.RP.Mobile.Services;
using Xamarin.Forms;

[assembly: Dependency(typeof(LocalNotification))]
namespace PAI.RP.Mobile.Droid.Services
{
    public class LocalNotification : ILocalNotification
    {
        private const int NotificationId = 1000;

        public void Notify(string title, string body)
        {
            var notificationBuilder = new Notification.Builder(Forms.Context)
                .SetContentTitle(title)
                .SetContentText(body)
                .SetSmallIcon(Resource.Drawable.Icon)
                .SetDefaults(NotificationDefaults.Sound);

            var notification = notificationBuilder.Build();

            var notificationManager = Forms.Context.GetSystemService(Android.Content.Context.NotificationService) as NotificationManager;

            notificationManager.Notify(NotificationId, notification);
        }
    }
}