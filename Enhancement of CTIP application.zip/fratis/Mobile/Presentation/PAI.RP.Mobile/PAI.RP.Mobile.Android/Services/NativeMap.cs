using System;
using System.Collections.Generic;
using Android.Content;
using PAI.RP.Compatibility.Portable;
using PAI.RP.Mobile.Droid.Services;
using PAI.RP.Mobile.Model;
using PAI.RP.Mobile.Services;
using Xamarin.Forms;
using Uri = Android.Net.Uri;


[assembly: Dependency(typeof(NativeMap))]
namespace PAI.RP.Mobile.Droid.Services
{
    public class NativeMap : INativeMap
    {
        private readonly IAlkMsg _alkMsg;

        public double LatitudeCenterPoint { get; set; }
        public double LongitudeCenterPoint { get; set; }
        public int ZoomLevel { get; set; }

        public NativeMap()
        {
            //TODO - Find a way to avoid this!
            _alkMsg = TinyIoC.TinyIoCContainer.Current.Resolve<IAlkMsg>();

            LatitudeCenterPoint = 28.60087552;
            LongitudeCenterPoint = -81.22195601;
            ZoomLevel = 15;
        }

        public void Open()
        {
            const string packageName = "com.google.android.apps.maps";
            if (UtilityService.IsAppInstalled(packageName))
            {
                var geoUri = Uri.Parse("geo:" + LatitudeCenterPoint + "," + LongitudeCenterPoint + "?z=" + ZoomLevel + "&q=" + LatitudeCenterPoint + "," + LongitudeCenterPoint);
                var mapIntent = new Intent(Intent.ActionView, geoUri);
                mapIntent.SetClassName(packageName, "com.google.android.maps.MapsActivity");
                Forms.Context.StartActivity(mapIntent);
            }
        }

        private void StartupMessaging()
        {
            if (_alkMsg.Msg_IsConnected() <= 0 && _alkMsg.Msg_HasStarted() <= 0)
            {
                //TODO - Need to setup callback functionality
                var result = _alkMsg.Msg_StartUp(null, null, true, true, true);
            }
        }

        private void OpenCoPilotMap(string packageName)
        {
            var coPilotIntent = new Intent(Intent.ActionMain);
            coPilotIntent.SetClassName(packageName, packageName + ".CopilotActivity");
            coPilotIntent.PutExtra("SDK_CLIENT_PACKAGE_NAME", "com.pai.rp");
            coPilotIntent.PutExtra("SDK_CLIENT_CLASS_NAME", "com.pai.rp.MainActivity");
            Forms.Context.StartActivity(coPilotIntent);
        }

        private void AddStopLocation(IList<RouteStopViewModel> routeStops)
        {
           
            if (_alkMsg.Msg_IsConnected() == 1 && _alkMsg.Msg_HasStarted() == 1)
            {
                var tripId = _alkMsg.Msg_TripLoad(222, 0, 222);
                for (var i = 0; i < routeStops.Count; i++)
                {

                    if (routeStops[i].RouteStopStatus != RP.Domain.Portable.RouteStopStatus.EnRoute)
                    {
                        continue;
                    }

                    int streetNum;
                    var streetNumber = string.Empty;
                    var addressWithoutStreetNumber = string.Empty;
                    var addressChunks = routeStops[i].Location.Address.Split(' ');
                    if (addressChunks.Length >= 2 && int.TryParse(addressChunks[0], out streetNum))
                    {
                        streetNumber = streetNum.ToString();
                        for (var j = 1; j < addressChunks.Length; j++)
                        {
                            addressWithoutStreetNumber += addressChunks[j] + " ";
                        }
                        addressWithoutStreetNumber = addressWithoutStreetNumber.TrimEnd(' ');
                    }

                    _alkMsg.Msg_TripAddStopWithHouseNum(tripId, routeStops[i].Location.DisplayName,
                        streetNumber,
                        addressWithoutStreetNumber,
                        routeStops[i].Location.City,
                        "",
                        routeStops[i].Location.Zip,
                        "",
                        0, 0,
                        222, null, null, null, 1);
                }

                _alkMsg.Msg_SendTrip(tripId, -1, -1, 222);
                _alkMsg.Msg_ParserDelete(tripId);

            }
        }

        public void OpenCoPilot(IList<RouteStopViewModel> location)
        {
            const string packageName = "com.alk.copilot";
            if (UtilityService.IsAppInstalled(packageName))
            {
                new Timer(() => Device.BeginInvokeOnMainThread(StartupMessaging), TimeSpan.FromMilliseconds(-1))
                    .Start(TimeSpan.FromSeconds(5));

                new Timer(() => Device.BeginInvokeOnMainThread(() => AddStopLocation(location)), TimeSpan.FromMilliseconds(-1))
                    .Start(TimeSpan.FromSeconds(7));

                var result = _alkMsg.RequestEtaDistance();

                OpenCoPilotMap(packageName);
            }
        }
    }
}