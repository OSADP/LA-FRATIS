using System;
using Android.App;
using Android.Content;
using Android.Views;

namespace PAI.RP.Mobile.Droid.Fragments
{
    public class CustomAlert : DialogFragment
    {
        private readonly string _title;
        private readonly string _positiveButtonMessage;
        private readonly EventHandler<DialogClickEventArgs> _positiveButtonClick;
        private readonly string _negativeButtonMessage;
        private readonly EventHandler<DialogClickEventArgs> _negativeButtonClick;
        private readonly View _view;

        public CustomAlert(string title, string positiveButtonMessage, EventHandler<DialogClickEventArgs> positiveButtonClick, string negativeButtonMessage, EventHandler<DialogClickEventArgs> negativeButtonClick, View view)
        {
            _title = title;
            _positiveButtonMessage = positiveButtonMessage;
            _positiveButtonClick = positiveButtonClick;
            _negativeButtonMessage = negativeButtonMessage;
            _negativeButtonClick = negativeButtonClick;
            _view = view;
        }

        public override Dialog OnCreateDialog(Android.OS.Bundle savedInstanceState)
        {
            var builder = new AlertDialog.Builder(Activity);
            if (!string.IsNullOrWhiteSpace(_title))
            {
                builder.SetTitle(_title);
            }
            if (!string.IsNullOrWhiteSpace(_positiveButtonMessage) && _positiveButtonClick != null)
            {
                builder.SetPositiveButton(_positiveButtonMessage, _positiveButtonClick);
            }
            if (!string.IsNullOrWhiteSpace(_negativeButtonMessage) && _negativeButtonClick != null)
            {
                builder.SetNegativeButton(_negativeButtonMessage, _negativeButtonClick);
            }
            if (_view != null)
            {
                builder.SetView(_view);
            }

            var customAlertDialog = builder.Create();
            if (string.IsNullOrWhiteSpace(_title))
            {
                customAlertDialog.Window.RequestFeature(WindowFeatures.NoTitle);
            }
            return customAlertDialog;
        }
    }
}