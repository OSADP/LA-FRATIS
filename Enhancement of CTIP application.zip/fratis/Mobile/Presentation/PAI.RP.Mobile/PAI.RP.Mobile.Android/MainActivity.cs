﻿using System;
using System.IO;
using Android.App;
using Android.Content.PM;
using Android.Gms.Analytics;
using Android.OS;
using PAI.Common.Core.Data.Portable;
using PAI.RP.Mobile.Infrastructure;
using SQLite.Net.Interop;
using SQLite.Net.Platform.XamarinAndroid;
using TinyIoC;
using Xamarin.Forms;
using XLabs.Forms;
using XLabs.Platform.Device;
using XLabs.Platform.Mvvm;

namespace PAI.RP.Mobile.Droid
{
    //TODO - Localize this name
    [Activity(Name = "com.pai.rp.MainActivity", Label = "Driver App", MainLauncher = true, ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize | ConfigChanges.Keyboard | ConfigChanges.KeyboardHidden)]
    public class MainActivity : XFormsApplicationDroid
    {
        /// <summary>
        /// Indicated if the application has been initialized
        /// </summary>
        private static bool _initialized;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            //http://www.mono-project.com/archived/usingtrustedrootsrespectfully/
            //TODO - Prompt the user to accept or reject the SSL certificate
            //For now, the application silently accepts the SSL cert which is BAD
            System.Net.ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, errors) => true;

            Xamarin.Forms.Forms.Init(this, bundle);

            if (!_initialized)
            {
                SetIoc();
                Com.Alk.Sdk.SharedLibraryLoader.LoadLibrary("alksdk", this);
            }

            App.Init();

            LoadApplication(new App());

            EnableGoogleAnalytics();
        }

        public override void OnBackPressed()
        {
            //Do nothing
        }

        private void EnableGoogleAnalytics()
        {
            //TODO - Use the google analytics for tracking and reporting
            var googleAnalytics = GoogleAnalytics.GetInstance(this);
            googleAnalytics.SetLocalDispatchPeriod(30);

            var tracker = googleAnalytics.NewTracker("UA-66156852-2");
            tracker.EnableExceptionReporting(true);
            tracker.EnableAdvertisingIdCollection(true);
            tracker.EnableAutoActivityTracking(true);
        }

        private void SetIoc()
        {
            //Loads up all of the dependencies
            var device = AndroidDevice.CurrentDevice;

            TinyIoCContainer.Current.Register<IDevice>(device);

            var app = new XFormsAppDroid();

            app.Init(this);

            TinyIoCContainer.Current.Register<IXFormsApp>(app);

            TinyIoCContainer.Current.Register<ISQLitePlatform>(new SQLitePlatformAndroid());

            var dbPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "rp.db");
            TinyIoCContainer.Current.Register<IPathConfig>(new PathConfig(dbPath));

            DependencyRegistrar.Load();

            AutoMapperProfile.CreateMappings();

            _initialized = true;
        }

        //public override void OnConfigurationChanged(Android.Content.Res.Configuration newConfig)
        //{
        //    base.OnConfigurationChanged(newConfig);
        //    switch (Device.Idiom)
        //    {
        //        case TargetIdiom.Phone:
        //            RequestedOrientation = ScreenOrientation.Portrait;
        //            break;
        //        case TargetIdiom.Tablet:
        //            RequestedOrientation = ScreenOrientation.Landscape;
        //            break;
        //    }
        //}
    }
}

