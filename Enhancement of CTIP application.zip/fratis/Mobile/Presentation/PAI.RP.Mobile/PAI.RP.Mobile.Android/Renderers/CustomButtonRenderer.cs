using System;
using Android.Runtime;
using PAI.RP.Mobile.Controls;
using PAI.RP.Mobile.Droid.Renderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

//Source: http://forums.xamarin.com/discussion/20608/fix-for-button-layout-bug-on-android
[assembly: ExportRenderer(typeof(CustomButton), typeof(CustomButtonRenderer))]
namespace PAI.RP.Mobile.Droid.Renderers
{
    public class CustomButtonRenderer : ButtonRenderer
    {
        private int _iterationCount = 1;
        protected override bool DrawChild(Android.Graphics.Canvas canvas, Android.Views.View child, long drawingTime)
        {
            if (_iterationCount <= 10)
            {
                ++_iterationCount;
                Control.Text = Control.Text;
            }
            else
            {
                _iterationCount = 1;
            }
            return base.DrawChild(canvas, child, drawingTime);
        }
    }
}