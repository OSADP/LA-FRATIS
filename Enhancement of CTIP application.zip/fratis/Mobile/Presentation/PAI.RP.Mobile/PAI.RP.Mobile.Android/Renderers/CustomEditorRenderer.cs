using System;
using Android.Graphics.Drawables;
using Android.Widget;
using PAI.RP.Mobile.Controls;
using PAI.RP.Mobile.Droid.Renderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(CustomEditor), typeof(CustomEditorRenderer))]
namespace PAI.RP.Mobile.Droid.Renderers
{
    public class CustomEditorRenderer : EditorRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {
            base.OnElementChanged((e));

            if (e.OldElement == null)
            {
                // perform initial setup
                var customEditor = e.NewElement as CustomEditor;
                if (customEditor != null)
                {
                    // lets get a reference to the native control
                    var nativeEditText = (EditText) Control;

                    var gradientDrawable = new GradientDrawable();
                    gradientDrawable.SetColor(customEditor.BackgroundColor.ToAndroid());
                    gradientDrawable.SetCornerRadius(0);
                    gradientDrawable.SetStroke(customEditor.BorderThickness, customEditor.BorderColor.ToAndroid());
                    nativeEditText.SetBackgroundDrawable(gradientDrawable);

                    //nativeEditText.SetBackgroundColor(customEditor.BackgroundColor.ToAndroid());
                    nativeEditText.SetTextColor(customEditor.TextColor.ToAndroid());
                }
            }
        }
    }
}