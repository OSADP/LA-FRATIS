﻿using Microsoft.Phone.Controls;
using PAI.RP.Mobile.Infrastructure;
using TinyIoC;
using Xamarin.Forms.Labs;

namespace PAI.RP.Mobile.WinPhone
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            Xamarin.Forms.Forms.Init();

            SetIoc();

            //TODO - Add this in after upgrading Xamarin Forms version
            //PAI.RP.Mobile.App.Init();

            //TODO - Add this in after upgrading Xamarin Forms version
            //LoadApplication(new App());
        }

        /// <summary>
        /// Must be called within a method to setup the windows device.
        /// Wierd quirk in windows that will cause a WPControl exception if not included in a method.
        /// </summary>
        private void SetIoc()
        {
            //Loads up all of the dependencies
            var device = WindowsPhoneDevice.CurrentDevice;

            TinyIoCContainer.Current.Register<IDevice>(device);

            DependencyRegistrar.Load();

            AutoMapperProfile.CreateMappings();
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}