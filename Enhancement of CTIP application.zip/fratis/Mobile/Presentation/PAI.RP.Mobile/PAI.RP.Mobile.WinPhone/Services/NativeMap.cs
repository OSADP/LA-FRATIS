﻿using System;
using System.Device.Location;
using Microsoft.Phone.Tasks;
using PAI.RP.Mobile.Services;
using PAI.RP.Mobile.WinPhone.Services;
using Xamarin.Forms;

[assembly: Dependency(typeof(NativeMap))]
namespace PAI.RP.Mobile.WinPhone.Services
{
    public class NativeMap : INativeMap
    {
        public double LatitudeCenterPoint { get; set; }
        public double LongitudeCenterPoint { get; set; }
        public int ZoomLevel { get; set; }

        public NativeMap()
        {
            LatitudeCenterPoint = 28.60087552;
            LongitudeCenterPoint = -81.22195601;
            ZoomLevel = 10;
        }

        public void Open()
        {
            //Omit the Center property to use the user's current location.
            var bingMapsTask = new BingMapsTask
            {
                Center = new GeoCoordinate(LatitudeCenterPoint, LongitudeCenterPoint),
                SearchTerm = LatitudeCenterPoint + "," + LongitudeCenterPoint,
                ZoomLevel = ZoomLevel
            };

            bingMapsTask.Show();
        }

        public void OpenCoPilot(string address, string city, string zip)
        {
            throw new NotImplementedException();
        }

        public void OpenCoPilot()
        {
            throw new NotImplementedException();
        }
    }
}
