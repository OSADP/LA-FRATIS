﻿namespace PAI.FRATIS.BackgroundMonitor.BackgroundWorkers
{
    public interface IBackgroundWorker
    {
    }
}
