﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using PAI.FRATIS.SFL.Domain.Geography;
using PAI.FRATIS.SFL.Services.Geography;
using PAI.FRATIS.Services.ExternalDistanceService;
using HourDistanceInfo = PAI.FRATIS.Domain.Geography.HourDistanceInfo;
using Location = PAI.FRATIS.Domain.Geography.Location;
using LocationDistance = PAI.FRATIS.Domain.Geography.LocationDistance;

namespace PAI.FRATIS.BackgroundMonitor.BackgroundWorkers
{
    /// <summary>
    /// Wrapper for background process to query an external distance
    /// service and update actual 
    /// </summary>
    internal class LocationDistanceUpdater : IBackgroundWorker
    {
        #region Constants

        private const int TimerDelayInSeconds = 10;

        #endregion

        #region Static Fields

        private static BackgroundWorker _backgroundWorker;

        #endregion

        #region Fields

        private readonly IExternalDistanceCalculator _externalDistanceCalculator;

        private readonly ILocationDistanceService _locationDistanceService;

        private Timer _timer;

        #endregion

        #region Constructors and Destructors

        public LocationDistanceUpdater(
            ILocationDistanceService locationDistanceService, IExternalDistanceCalculator externalDistanceCalculator)
        {
            _locationDistanceService = locationDistanceService;
            _externalDistanceCalculator = externalDistanceCalculator;

            InitializeBackgroundWorker();
            InitializeTimer();
        }

        #endregion

        #region Public Methods and Operators

        public static void TimerTick(Object stateInfo)
        {
            if (!_backgroundWorker.IsBusy)
            {
                _backgroundWorker.RunWorkerAsync();
            }
        }

        #endregion

        #region Methods

        private Location Convert(SFL.Domain.Geography.Location x)
        {
            return new Location
                {
                    Id = x.Id,
                    DisplayName = x.DisplayName,
                    Latitude = x.Latitude,
                    Longitude = x.Longitude,
                    City = x.City,
                    Email = x.Email,
                    IsDeleted = x.IsDeleted,
                    LegacyId = x.LegacyId,
                    Note = x.Note,
                    State = x.State,
                    Phone = x.Phone,
                    Address = x.Address,
                    WebFleetId = x.WebFleetId,
                    WaitingTime = x.WaitingTime,
                    Zip = x.Zip
                };
        }

        private SFL.Domain.Geography.Location Convert(Location x)
        {
            return new SFL.Domain.Geography.Location
                {
                    Id = x.Id,
                    DisplayName = x.DisplayName,
                    Latitude = x.Latitude,
                    Longitude = x.Longitude,
                    City = x.City,
                    Email = x.Email,
                    IsDeleted = x.IsDeleted,
                    LegacyId = x.LegacyId,
                    Note = x.Note,
                    State = x.State,
                    Phone = x.Phone,
                    Address = x.Address,
                    WebFleetId = x.WebFleetId,
                    WaitingTime = x.WaitingTime,
                    Zip = x.Zip
                };
        }

        private HourDistanceInfo Convert(SFL.Domain.Geography.HourDistanceInfo x)
        {
            return new HourDistanceInfo
                {
                    TravelTime = x.TravelTime
                };
        }

        private SFL.Domain.Geography.HourDistanceInfo Convert(HourDistanceInfo x)
        {
            return new SFL.Domain.Geography.HourDistanceInfo
                {
                    TravelTime = x.TravelTime
                };
        }

        private List<HourDistanceInfo> Convert(IEnumerable<SFL.Domain.Geography.HourDistanceInfo> x)
        {
            return x.Select(Convert).ToList();
        }

        private List<SFL.Domain.Geography.HourDistanceInfo> Convert(IEnumerable<HourDistanceInfo> x)
        {
            return x.Select(Convert).ToList();
        }

        private LocationDistance Convert(SFL.Domain.Geography.LocationDistance x)
        {
            return new LocationDistance
                {
                    CreatedDate = x.CreatedDate,
                    DayOfWeek = x.DayOfWeek,
                    DepartureDay = x.DepartureDay,
                    Distance = x.Distance,
                    EndLocation = Convert(x.EndLocation),
                    EndLocationId = x.EndLocationId,
                    Hour0 = Convert(x.Hour0),
                    Hour1 = Convert(x.Hour1),
                    Hour2 = Convert(x.Hour2),
                    Hour3 = Convert(x.Hour3),
                    Hour4 = Convert(x.Hour4),
                    Hour5 = Convert(x.Hour5),
                    Hour6 = Convert(x.Hour6),
                    Hour7 = Convert(x.Hour7),
                    Hour8 = Convert(x.Hour8),
                    Hour9 = Convert(x.Hour9),
                    Hour10 = Convert(x.Hour10),
                    Hour11 = Convert(x.Hour11),
                    Hour12 = Convert(x.Hour12),
                    Hour13 = Convert(x.Hour13),
                    Hour14 = Convert(x.Hour14),
                    Hour15 = Convert(x.Hour15),
                    Hour16 = Convert(x.Hour16),
                    Hour17 = Convert(x.Hour17),
                    Hour18 = Convert(x.Hour18),
                    Hour19 = Convert(x.Hour19),
                    Hour20 = Convert(x.Hour20),
                    Hour21 = Convert(x.Hour21),
                    Hour22 = Convert(x.Hour22),
                    Hour23 = Convert(x.Hour23),
                    Hours = Convert(x.Hours),
                    Id = x.Id,
                    ModifiedDate = x.ModifiedDate,
                    TravelTime = x.TravelTime,
                    StartLocation = Convert(x.StartLocation),
                    StartLocationId = x.StartLocationId
                };
        }

        private SFL.Domain.Geography.LocationDistance Convert(LocationDistance x, int subscriberId)
        {
            var result = new SFL.Domain.Geography.LocationDistance();
            result.Hours = Convert(x.Hours);
            result.CreatedDate = x.CreatedDate;
            result.DayOfWeek = x.DayOfWeek;
            result.DepartureDay = x.DepartureDay;
            result.Distance = x.Distance;
            result.EndLocation = Convert(x.EndLocation);
            result.EndLocationId = x.EndLocationId;
            result.Id = x.Id;
            result.ModifiedDate = x.ModifiedDate;
            result.TravelTime = x.TravelTime;
            result.StartLocation = Convert(x.StartLocation);
            result.StartLocationId = x.StartLocationId;
            result.SubscriberId = subscriberId;
            return result;
        }

        private void BackgroundWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            IList<SFL.Domain.Geography.LocationDistance> records = GetEmptyLocationDistanceRecords();

            //Console.WriteLine("Start Processing Pending For Updater");
            if (records.Count > 0)
            {
                Console.WriteLine("Fetching Travel Time Distances for {0} record(s)" + "\n", records.Count);
            }

            Action<int> updateRecord = recordIndex =>
            {
                try
                {
                    var swatch = new Stopwatch();
                    swatch.Start();
                    SFL.Domain.Geography.LocationDistance record = records[recordIndex];
                    Console.WriteLine("\tUpdating record " + record.Id);

                    var sflRecord = Convert(record);
                    var externalDistance = _externalDistanceCalculator.Get(sflRecord, DateTime.UtcNow.Date);

                    SFL.Domain.Geography.LocationDistance result = Convert(externalDistance, record.SubscriberId.Value);

                    Console.WriteLine("Response received");

                    if (result.IsComplete)
                    {
                        var domainRecord = _locationDistanceService.GetById(result.Id);
                        domainRecord.Hour0 = result.Hour0;
                        domainRecord.Hour1 = result.Hour1;
                        domainRecord.Hour2 = result.Hour2;
                        domainRecord.Hour3 = result.Hour3;
                        domainRecord.Hour4 = result.Hour4;
                        domainRecord.Hour5 = result.Hour5;
                        domainRecord.Hour6 = result.Hour6;
                        domainRecord.Hour7 = result.Hour7;
                        domainRecord.Hour8 = result.Hour8;
                        domainRecord.Hour9 = result.Hour9;
                        domainRecord.Hour10 = result.Hour10;
                        domainRecord.Hour11 = result.Hour11;
                        domainRecord.Hour12 = result.Hour12;
                        domainRecord.Hour13 = result.Hour13;
                        domainRecord.Hour14 = result.Hour14;
                        domainRecord.Hour15 = result.Hour15;
                        domainRecord.Hour16 = result.Hour16;
                        domainRecord.Hour17 = result.Hour17;
                        domainRecord.Hour18 = result.Hour18;
                        domainRecord.Hour19 = result.Hour19;
                        domainRecord.Hour20 = result.Hour20;
                        domainRecord.Hour21 = result.Hour21;
                        domainRecord.Hour22 = result.Hour22;
                        domainRecord.Hour23 = result.Hour23;
                        domainRecord.Distance = result.Distance;
                        domainRecord.TravelTime = result.TravelTime;
                        domainRecord.DayOfWeek = result.DayOfWeek;
                        domainRecord.DepartureDay = result.DepartureDay;
                        domainRecord.ModifiedDate = DateTime.Now;
                        _locationDistanceService.Update(result, true);
                    }
                    swatch.Stop();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            };

            const bool ParallelismEnabled = false;
            if (ParallelismEnabled)
            {
                Parallel.For(0, records.Count, updateRecord);
            }
            for (int i = 0; i < records.Count; i++)
            {
                updateRecord(i);
            }

            _locationDistanceService.SaveChanges();

            var t = _locationDistanceService.GetById(1163);
            if (records.Count > 0)
            {
                Console.WriteLine("Finished Fetching Travel Distances" + "\n", records.Count);
            }
            //Console.WriteLine("Finish Processing Pending For Updater");
        }

        private void BackgroundWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
        }

        private IList<SFL.Domain.Geography.LocationDistance> GetEmptyLocationDistanceRecords()
        {
            try
            {
                List<SFL.Domain.Geography.LocationDistance> records =
                    _locationDistanceService.SelectWithAll().Where(
                        p => p.ModifiedDate == null || p.Distance == null).Take(10).ToList();
                return records;
            }
            catch
            {
                return new List<SFL.Domain.Geography.LocationDistance>();
            }
        }

        private void InitializeBackgroundWorker()
        {
            _backgroundWorker = new BackgroundWorker();
            _backgroundWorker.DoWork += BackgroundWorkerDoWork;
            _backgroundWorker.RunWorkerCompleted += BackgroundWorkerRunWorkerCompleted;
        }

        private void InitializeTimer()
        {
            var timerCallback = new TimerCallback(TimerTick);
            _timer = new Timer(timerCallback, null, 0, TimerDelayInSeconds * 1000);
        }

        #endregion
    }
}