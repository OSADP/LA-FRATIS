﻿using System;
using System.Diagnostics;
using Ninject;
using Ninject.Extensions.Conventions;
using Ninject.Extensions.Factory;
using Ninject.Extensions.NamedScope;
using PAI.FRATIS.BackgroundMonitor.BackgroundWorkers;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.SFL.Common.Infrastructure.Data;
using PAI.FRATIS.SFL.Common.Infrastructure.Engine;
using PAI.FRATIS.SFL.Data;
using PAI.FRATIS.SFL.Services.Core.Caching;
using PAI.FRATIS.SFL.Services.Geography;
using PAI.FRATIS.SFL.Services.Orders;
using PAI.FRATIS.Services.ExternalDistanceService;

namespace PAI.FRATIS.BackgroundMonitor
{
    class Program
    {
        #region Public Properties

        public static IKernel Kernel { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// IoC Binding Registration
        /// </summary>
        private static void Initialize()
        {
            Kernel = EngineContext.Current.Kernel;

            Kernel.Bind(
                x => x.FromAssembliesMatching("PAI.*").SelectAllClasses().Excluding(typeof(Engine))
                    .BindDefaultInterfaces().Configure(b => b.InThreadScope()));

            Kernel.Rebind(typeof(IRepository<>))
                  .To(typeof(EfRepository<>))
                  .InThreadScope();

            Kernel.Rebind<IDbContext>()
                .To<DataContext>()
                .InParentScope();
                //.WithConstructorArgument("nameOrConnectionString", PAI.FRATIS.Infrastructure.ConnectionStringManager.ConnectionString);

            Kernel.Rebind<ICacheManager>().To<MemoryCacheManager>().InThreadScope();
            //Kernel.Rebind<IYusenFTPService>().To<YusenFTPService>().InThreadScope();
            Kernel.Bind<INokiaMapsServiceFactory>().ToFactory().InThreadScope();
            Kernel.Rebind<IExternalDistanceCalculator>().To<NokiaMapsDistanceCalculator>().InCallScope();
            Kernel.Rebind<ILocationDistanceService>().To<LocationDistanceService>().InCallScope();

            Kernel.Bind<ILocationDistanceService>()
                  .To<LocationDistanceService>()
                  .WhenInjectedExactlyInto<IBackgroundWorker>()
                  .InCallScope();

            Kernel.Bind<IJobService>()
                  .To<JobService>()
                  .WhenInjectedExactlyInto<ILocationService>()
                  .InCallScope();

            Kernel.Bind<IJobService>()
                  .To<JobService>()
                  .WhenInjectedExactlyInto<IBackgroundWorker>()
                  .InCallScope();

            Kernel.Bind<IRepository<LocationDistance>>()
                  .To<IRepository<LocationDistance>>()
                  .WhenInjectedExactlyInto<ILocationDistanceService>()
                  .InCallScope();

            Kernel.Bind<IRepository<Job>>()
                  .To<IRepository<Job>>()
                  .WhenInjectedExactlyInto<IJobService>()
                  .InCallScope();

            Kernel.Bind<IRepository<RouteStop>>()
                  .To<IRepository<RouteStop>>()
                  .WhenInjectedExactlyInto<IRouteStopService>()
                  .InCallScope();

            Kernel.Bind<IRouteStopService>()
                  .To<RouteStopService>()
                  .WhenInjectedExactlyInto<IBackgroundWorker>()
                  .InCallScope();

            Kernel.Bind<IRepository<LocationDistance>>()
                  .To<IRepository<LocationDistance>>()
                  .WhenInjectedExactlyInto<ILocationDistanceService>()
                  .InCallScope();

            Kernel.Bind<IRepository<RouteStop>>()
                  .To<IRepository<RouteStop>>()
                  .WhenInjectedExactlyInto<IRouteStopService>()
                  .InCallScope();

            Kernel.Bind<IRepository<LocationDistance>>()
                  .To<IRepository<LocationDistance>>()
                  .WhenInjectedExactlyInto<ILocationDistanceService>()
                  .InCallScope();

            Kernel.Rebind<IDbContext>()
                  .To<DataContext>();
                  //.InSingletonScope();
                  //.WithConstructorArgument("nameOrConnectionString", @"Server=54.221.219.71;Integrated Security=false;Database=pai_fratis_sfl_dev;User Id=fratismiami;Password=miamifratis2");


            //Kernel.Bind<IRepository<LocationDistance>>().To
            //<EfRepository<LocationDistance>>().WhenInjectedInto<LocationDistanceService>().InThreadScope();

            //Kernel.Bind<IRepository<LocationDistance>>().To
            //<EfRepository<LocationDistance>>().WhenInjectedInto<LocationDistanceService>().InThreadScope();

            //Kernel.Bind<LocationDistanceUpdater>().ToSelf();
            Kernel.Bind<LocationDistanceCreaterBW>().ToSelf();
            //Kernel.Bind<ContainerAvailabilityBW>().ToSelf();
        }

        private static void Main(string[] args)
        {
            Process thisProc = Process.GetCurrentProcess();
            thisProc.PriorityClass = ProcessPriorityClass.BelowNormal;
            Initialize();

            // start the background processes
            //Kernel.Get<LocationDistanceUpdater>();
            Kernel.Get<LocationDistanceCreaterBW>();
            //Kernel.Get<ContainerAvailabilityBW>();

            Console.WriteLine("Process running... press enter key to exit.");
            Console.ReadLine();
        }

        #endregion
    }
}
