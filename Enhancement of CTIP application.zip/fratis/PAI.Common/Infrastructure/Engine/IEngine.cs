using System;
using System.Collections.Generic;
using Ninject;

namespace PAI.FRATIS.SFL.Common.Infrastructure.Engine
{
    public interface IEngine
    {
        /// <summary>
        /// Gets the IoC Kernel
        /// </summary>
        IKernel Kernel { get; }

        /// <summary>
        /// Initializes the engine
        /// </summary>
        void Initialize();

        /// <summary>
        /// Gets an instance of the specified service.
        /// </summary>
        /// <typeparam name="T">The service to resolve.</typeparam>
        /// <returns>An instance of the service.</returns>
        [Obsolete("Limit the use of the Service Locator Pattern")]
        T Get<T>() where T : class;
        
        /// <summary>
        /// Gets an instance of the specified service.
        /// </summary>
        /// <returns>An instance of the service.</returns>
        [Obsolete("Limit the use of the Service Locator Pattern")]
        object Get(Type type);

        /// <summary>
        /// Gets all available instances of the specified service.
        /// </summary>
        /// <returns>A list of instances of the service.</returns>
        IEnumerable<object> GetAll(Type serviceType);

        /// <summary>
        /// Gets all available instances of the specified service.
        /// </summary>
        /// <returns>A list of instances of the service.</returns>
        IEnumerable<T> GetAll<T>();
    }
}