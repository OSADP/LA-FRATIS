using System;
using System.Collections.Generic;
using Ninject;

namespace PAI.FRATIS.SFL.Common.Infrastructure.Engine
{
    public class Engine : IEngine
    {
        public IKernel Kernel { get; private set; }

        public Engine() 
            : this (new StandardKernel())
        {
            // Initialize with the standard Ninject kernel
        }

        public Engine(IKernel kernel)
        {
            Kernel = kernel;
            Kernel.Bind<IEngine>().ToConstant(this);
        }

        public virtual void Initialize()
        {
        }

        /// <summary>
        /// Gets an instance of the specified service.
        /// </summary>
        /// <typeparam name="T">The service to resolve.</typeparam>
        /// <returns>An instance of the service.</returns>
        public T Get<T>() where T : class
        {
            return Kernel.Get<T>();
        }

        /// <summary>
        /// Gets an instance of the specified service.
        /// </summary>
        /// <returns>An instance of the service.</returns>
        public object Get(Type type)
        {
            return Kernel.Get(type);
        }

        /// <summary>
        /// Gets all available instances of the specified service.
        /// </summary>
        /// <returns>A list of instances of the service.</returns>
        public IEnumerable<object> GetAll(Type serviceType)
        {
            return Kernel.GetAll(serviceType);
        }

        /// <summary>
        /// Gets all available instances of the specified service.
        /// </summary>
        /// <returns>A list of instances of the service.</returns>
        public IEnumerable<T> GetAll<T>()
        {
            return Kernel.GetAll<T>();
        }
        
    }
}