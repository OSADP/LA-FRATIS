namespace PAI.FRATIS.SFL.Common
{
    /// <summary>
    /// Subscriber entity
    /// </summary>
    public interface ISubscriberEntity : IEntity
    {
        int SubscriberId { get; set; }
    }
}