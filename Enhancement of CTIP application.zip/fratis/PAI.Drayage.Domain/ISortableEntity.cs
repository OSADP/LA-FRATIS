namespace PAI.Drayage.Domain
{
    public interface ISortableEntity
    {
        int SortOrder { get; set; }
    }
}