using System;

namespace PAI.Drayage.Domain.Geography
{
    /// <summary>
    /// Represents a trip length between locations 
    /// This entity is used to store expensive trip lengths between locations
    /// </summary>
    public class LocationDistance : EntityBase, IDatedEntity
    {
        /// <summary>
        /// Gets or sets the start location
        /// </summary>
        public virtual Location StartLocation { get; set; }

        /// <summary>
        /// Gets or sets the end location
        /// </summary>
        public virtual Location EndLocation { get; set; }
        
        /// <summary>
        /// Gets or sets the distance (mi)
        /// </summary>
        public virtual double Distance { get; set; }

        /// <summary>
        /// Gets or sets the travel time in seconds
        /// </summary>
        public virtual long TravelTime { get; set; }

        /// <summary>
        /// Gets or sets the CreationDate
        /// </summary>
        public virtual DateTime CreationDate { get; set; }
        
        /// <summary>
        /// Gets or sets the UpdateDate
        /// </summary>
        public virtual DateTime UpdateDate { get; set; }
    }
}