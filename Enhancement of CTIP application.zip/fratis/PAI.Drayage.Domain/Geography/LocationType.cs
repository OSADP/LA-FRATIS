namespace PAI.Drayage.Domain.Geography
{
    public enum LocationType
    {
        Unassigned,
        DriverHome,
        Depot,
        Customer,
        Terminal
    }
}