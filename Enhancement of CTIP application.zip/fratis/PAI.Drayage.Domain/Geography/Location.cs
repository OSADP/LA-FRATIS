namespace PAI.Drayage.Domain.Geography
{
    /// <summary>
    /// Represents a geographical location
    /// </summary>
    public class Location : EntityBase
    {
        /// <summary>
        /// Gets or sets the Web Fleet Location Id
        /// </summary>
        public virtual string WebFleetLocationId { get; set; }

        /// <summary>
        /// Gets or sets the display name
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the address
        /// </summary>
        public virtual string Street { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public virtual string City { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public virtual State State { get; set; }

        /// <summary>
        /// Gets or sets the state id
        /// </summary>
        public virtual int StateId { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public virtual string Zip { get; set; }

        /// <summary>
        /// Gets or sets the longitude in degrees
        /// </summary>
        public virtual double? Longitude { get; set; }

        /// <summary>
        /// Gets or sets the latitude in degrees
        /// </summary>
        public virtual double? Latitude { get; set; }
        
        /// <summary>
        /// Gets or sets the GeoCodeResult
        /// </summary>
        public virtual GeoCodeResult GeoCodeResult { get; set; }

        /// <summary>
        /// Gets or sets the location type
        /// </summary>
        public LocationType LocationType { get; set; }

        /// <summary>
        /// Represents the location's default waiting/queue time in minutes
        /// </summary>
        public int? WaitingTime { get; set; }

        public virtual bool Deleted { get; set; }
    }
}