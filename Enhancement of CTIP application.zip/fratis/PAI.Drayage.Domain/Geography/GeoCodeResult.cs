namespace PAI.Drayage.Domain.Geography
{
    public enum GeoCodeResult
    {
        NotSet,
        GeoCoded,
        InvalidAddress
    }
}