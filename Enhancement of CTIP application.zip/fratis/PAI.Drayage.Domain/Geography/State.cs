namespace PAI.Drayage.Domain.Geography
{
    public class State : EntityBase
    {
        /// <summary>
        /// Gets or sets the abbreviation
        /// </summary>
        public virtual string Abbreviation { get; set; }

        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string Name { get; set; }
    }
}