﻿namespace PAI.Drayage.Domain.Logging
{
    public enum LogLevel
    {
        Debug=0,
        Trace=1,
        Information=2,
        Warning=3,
        Error=4,
        Fatal=5
    }
}