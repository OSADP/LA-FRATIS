﻿using System;
using PAI.Drayage.Domain.Users;

namespace PAI.Drayage.Domain.Logging
{
    public class LogEntry : EntityBase
    {
        /// <summary>
        /// Gets or sets the message
        /// </summary>
        public virtual LogLevel LogLevel { get; set; }

        /// <summary>
        /// Gets or sets the message
        /// </summary>
        public virtual string Message { get; set; }

        /// <summary>
        /// Gets or sets the full message
        /// </summary>
        public virtual string FullMessage { get; set; }
        
        /// <summary>
        /// Gets or sets the date and time of entry
        /// </summary>
        public virtual DateTime AuditDate { get; set; }

        /// <summary>
        /// Gets or sets the user
        /// </summary>
        public virtual User User { get; set; }
    }
}
