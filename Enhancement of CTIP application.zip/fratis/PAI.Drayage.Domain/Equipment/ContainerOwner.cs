namespace PAI.Drayage.Domain.Equipment
{
    public class ContainerOwner : EntityBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the allowed chassis owner
        /// </summary>
        public virtual ChassisOwner AllowedChassisOwner { get; set; }

        /// <summary>
        /// Gets or sets whether this it is domestic
        /// </summary>
        public virtual bool IsDomestic { get; set; }

    }
}