using System.Collections.Generic;

namespace PAI.Drayage.Domain.Equipment
{
   
    /// <summary>
    /// Represents a chassis
    /// </summary>
    public class Container : EntityBase
    {
        /// <summary>
        /// Gets or sets wheter is enabled
        /// </summary>
        public virtual bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string DisplayName { get; set; }
        
        /// <summary>
        /// Gets or sets whether this it is domestic
        /// </summary>
        public virtual bool IsDomestic { get; set; }

        /// <summary>
        /// Gets or sets the allowed chasssis
        /// </summary>
        private ICollection<Chassis> _allowedChassis;
        public virtual ICollection<Chassis> AllowedChassis
        {
            get
            {
                return _allowedChassis ?? (_allowedChassis = new List<Chassis>());
            }
            set
            {
                _allowedChassis = value;
            }
        }

    } 



}