namespace PAI.Drayage.Domain.Equipment
{
    public class DepotEquipmentAvailability : EntityBase
    {
        /// <summary>
        /// Gets or sets the Depot
        /// </summary>
        public virtual Depot Depot { get; set; }
        public virtual int? DepotId { get; set; }

        /// <summary>
        /// Gets or sets the container owner
        /// </summary>
        public virtual ContainerOwner ContainerOwner { get; set; }
        public virtual int? ContainerOwnerId { get; set; }

        /// <summary>
        /// Gets or sets the container type
        /// </summary>
        public virtual Container Container { get; set; }
        public virtual int? ContainerId { get; set; }

        /// <summary>
        /// Gets or sets the chassis owner
        /// </summary>
        public virtual ChassisOwner ChassisOwner { get; set; }
        public virtual int? ChassisOwnerId { get; set; }

        /// <summary>
        /// Gets or sets the ChassisType
        /// </summary>
        public virtual Chassis Chassis { get; set; }
        public virtual int? ChassisId { get; set; }
        
    }
}
