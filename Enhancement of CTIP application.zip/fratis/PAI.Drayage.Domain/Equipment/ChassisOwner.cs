namespace PAI.Drayage.Domain.Equipment
{
    public class ChassisOwner : EntityBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string DisplayName { get; set; }
    }
}