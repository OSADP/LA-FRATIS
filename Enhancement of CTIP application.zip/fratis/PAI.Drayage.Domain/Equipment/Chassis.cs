using System.Collections.Generic;

namespace PAI.Drayage.Domain.Equipment
{
    /// <summary>
    /// Represents a chassis
    /// </summary>
    public class Chassis : EntityBase
    {
        /// <summary>
        /// Gets or sets wheter is enabled
        /// </summary>
        public virtual bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the containers
        /// </summary>
        private ICollection<Container> _containers;
        public virtual ICollection<Container> Containers
        {
            get
            {
                return _containers ?? (_containers = new List<Container>());
            }
            set
            {
                _containers = value;
            }
        }
    }
}