using PAI.Drayage.Domain.Geography;

namespace PAI.Drayage.Domain.Equipment
{
    /// <summary>
    /// Represents a depot or station which 
    /// distributes/stores chassis and containers
    /// </summary>
    public class Depot : EntityBase
    {
        /// <summary>
        /// Gets or sets the Location
        /// </summary>
        public virtual Location Location { get; set; }
    }
}
