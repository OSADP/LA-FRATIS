﻿using System;
using System.Collections.Generic;
using PAI.Drayage.Domain.Orders;

namespace PAI.Drayage.Domain.Planning
{
    /// <summary>
    /// represents a PlanConfig
    /// </summary>
    public class PlanConfig : EntityBase, IDatedEntity
    {
        private ICollection<Driver> _drivers;
        private ICollection<Job> _jobs;
        
        /// <summary>
        /// Gets or sets Creation Date
        /// </summary>
        public virtual DateTime CreationDate { get; set; }

        /// <summary>
        /// Gets or sets Update Date
        /// </summary>
        public virtual DateTime UpdateDate { get; set; }

        /// <summary>
        /// Gets or sets Due Date provided upon Plan Creation
        /// </summary>
        public virtual DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets the default driver
        /// </summary>
        public virtual Driver DefaultDriver { get; set; }

        /// <summary>
        /// Gets or sets the drivers
        /// </summary>
        public virtual ICollection<Driver> Drivers
        {
            get { return _drivers ?? (_drivers = new List<Driver>()); }
            set { _drivers = value; }
        }
        
        /// <summary>
        /// Gets or sets the jobs
        /// </summary>
        public virtual ICollection<Job> Jobs
        {
            get { return _jobs ?? (_jobs = new List<Job>()); }
            set { _jobs = value; }
        }
    }
}
