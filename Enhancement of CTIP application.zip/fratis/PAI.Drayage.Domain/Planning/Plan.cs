﻿using System;
using System.Collections.Generic;
using PAI.Drayage.Domain.Orders;

namespace PAI.Drayage.Domain.Planning
{
    /// <summary>
    /// represents a plan
    /// </summary>
    public class Plan : EntityBase, IDatedEntity
    {
        /// <summary>
        /// Gets or sets the unique id for a run
        /// </summary>
        public virtual int Run { get; set; }

        /// <summary>
        /// Gets or sets whether this plan is user created
        /// </summary>
        public virtual bool UserCreated { get; set; }

        /// <summary>
        /// Gets or sets whether this plan was modified
        /// </summary>
        public virtual bool UserModified { get; set; }

        /// <summary>
        /// Gets or sets whether this plan was transmitted
        /// </summary>
        public virtual bool Transmitted { get; set; }

        /// <summary>
        /// Gets or sets the PlanConfig
        /// </summary>
        public virtual PlanConfig PlanConfig { get; set; }

        /// <summary>
        /// Gets or sets Creation Date
        /// </summary>
        public virtual DateTime CreationDate { get; set; }

        /// <summary>
        /// Gets or sets Update Date
        /// </summary>
        public virtual DateTime UpdateDate { get; set; }

        /// <summary>
        /// Gets or sets the driver plans
        /// </summary>
        private ICollection<PlanDriver> _driverPlans;
        public virtual ICollection<PlanDriver> DriverPlans
        {
            get
            {
                return _driverPlans ?? (_driverPlans = new List<PlanDriver>());
            }
            set
            {
                _driverPlans = value;
            }
        }


        /// <summary>
        /// Gets or sets the unassigned jobs
        /// </summary>
        private ICollection<Job> _unassignedJobs;
        public virtual ICollection<Job> UnassignedJobs
        {
            get
            {
                return _unassignedJobs ?? (_unassignedJobs = new List<Job>());
            }
            set
            {
                _unassignedJobs = value;
            }
        }

    }
}
