﻿using System.Collections.Generic;
using PAI.Drayage.Domain.Orders;

namespace PAI.Drayage.Domain.Planning
{
    public class PlanDriverJob : EntityBase, ISortableEntity
    {
        public virtual PlanDriver PlanDriver { get; set; }

        /// <summary>
        /// Gets or sets the Driver
        /// </summary>
        public virtual Job Job { get; set; }
        public virtual int JobId { get; set; }

        /// <summary>
        /// Gets or sets the sort order
        /// </summary>
        public virtual int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        private ICollection<RouteStop> _routeStops;
        public virtual ICollection<RouteStop> RouteStops
        {
            get
            {
                return _routeStops ?? (_routeStops = new List<RouteStop>());
            }
            set
            {
                _routeStops = value;
            }
        }
    }
}