﻿using System;
using System.Collections.Generic;
using PAI.Drayage.Domain.Orders;

namespace PAI.Drayage.Domain.Planning
{
    /// <summary>
    /// represents a driver plan
    /// </summary>
    public class PlanDriver : EntityBase
    {
        /// <summary>
        /// Gets or sets the Driver
        /// </summary>
        public virtual Driver Driver { get; set; }
        public virtual int DriverId { get; set; }

        private ICollection<PlanDriverJob> _jobPlans;
        /// <summary>
        /// Gets or sets the jobs
        /// </summary>
        public virtual ICollection<PlanDriverJob> JobPlans
        {
            get { return _jobPlans ?? (_jobPlans = new List<PlanDriverJob>()); }
            set { _jobPlans = value; }
        }


        /// <summary>
        /// Gets or sets the route segment metrics
        /// </summary>
        private ICollection<RouteSegmentMetric> _routeSegmentMetrics;
        public virtual ICollection<RouteSegmentMetric> RouteSegmentMetrics
        {
            get
            {
                return _routeSegmentMetrics ?? (_routeSegmentMetrics = new List<RouteSegmentMetric>());
            }
            set
            {
                _routeSegmentMetrics = value;
            }
        }

        public TimeSpan? DepartureTime { get; set; }

    }
}
