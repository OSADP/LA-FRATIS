﻿using System;
using PAI.Drayage.Domain.Orders;

namespace PAI.Drayage.Domain.Planning
{
    public enum TruckState
    {
        Bobtail = 0x2,
        Chassis = 0x4,
        Empty = 0x8,
        Loaded = 0x20
    }

    public class RouteSegmentMetric : EntityBase, ISortableEntity
    {
        /// <summary>
        /// Gets or sets the PlanDriver
        /// </summary>
        public virtual PlanDriver PlanDriver { get; set; }
        public virtual int? PlanDriverId { get; set; }

        /// <summary>
        /// Gets or sets the start stop
        /// </summary>
        public virtual RouteStop StartStop { get; set; }
        public virtual int? StartStopId { get; set; }

        /// <summary>
        /// Gets or sets the end stop
        /// </summary>
        public virtual RouteStop EndStop { get; set; }
        public virtual int? EndStopId { get; set; }
        
        /// <summary>
        /// Gets or sets the truck state
        /// </summary>
        public virtual TruckState TruckState { get; set; }

        /// <summary>
        /// Gets or sets the start time of this segment
        /// </summary>
        public virtual long? StartTime { get; set; } 

        /// <summary>
        /// Gets or sets the wait time
        /// </summary>
        public virtual long TotalIdleTime { get; set; }

        /// <summary>
        /// Gets or sets the execution time
        /// </summary>
        public virtual long TotalExecutionTime { get; set; }

        /// <summary>
        /// Gets or sets the total time
        /// </summary>
        public virtual long TotalTravelTime { get; set; }

        /// <summary>
        /// Gets or sets the distance (mi)
        /// </summary>
        public virtual double TotalTravelDistance { get; set; }

        /// <summary>
        /// Gets or sets the SortOrder
        /// </summary>
        public virtual int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the Departure Time for the first stop
        /// </summary>
        public TimeSpan? DepartureTime { get; set; }

        /// <summary>
        /// Gets or sets the total queue time.
        /// </summary>
        public long TotalQueueTime { get; set; }
    }

}
