﻿using System;

namespace PAI.Drayage.Domain.Users
{
    /// <summary>
    /// Represents an user
    /// </summary>
    public class User : EntityBase
    {
        /// <summary>
        /// Gets or sets the user name
        /// </summary>
        public virtual string Username { get; set; }
        
        /// <summary>
        /// Gets or sets the password
        /// </summary>
        public virtual string Password { get; set; }

        /// <summary>
        /// Gets or sets the password salt
        /// </summary>
        public virtual string PasswordSalt { get; set; }

        /// <summary>
        /// Gets or sets the password format
        /// </summary>
        public virtual PasswordFormat PasswordFormat { get; set; }
        
        /// <summary>
        /// Gets or sets a value indicating the consecutive failed logins
        /// </summary>
        public virtual int FailedLogins { get; set; }

        /// <summary>
        /// Gets or sets a value indicating the timestamp they they are locked until
        /// </summary>
        public virtual DateTime? LockedUntil { get; set; }

        /// <summary>
        /// Gets or sets whether the User is active
        /// </summary>
        public virtual bool Active { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the User has been deleted
        /// </summary>
        public virtual bool Deleted { get; set; }

        /// <summary>
        /// Gets or sets the last IP address
        /// </summary>
        public virtual string LastIpAddress { get; set; }

        /// <summary>
        /// Gets or sets the date and time of entity creation
        /// </summary>
        public virtual DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the date and time of last login
        /// </summary>
        public virtual DateTime? LastLoginDate { get; set; }

        /// <summary>
        /// Gets or sets the date and time of last activity
        /// </summary>
        public virtual DateTime LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets the TimeZone of the user
        /// </summary>
        public virtual string TimeZoneId { get; set; }

        /// <summary>
        /// Gets or sets the IsAdmin
        /// </summary>
        public virtual bool IsAdmin { get; set; }


        public User()
        {
            CreatedOn = DateTime.UtcNow;
            LastActivityDate = DateTime.UtcNow;
        }
    }
}
