﻿using System;

namespace PAI.Drayage.Domain.Users
{
    public class UserHistory : EntityBase
    {
        public virtual int? UserId { get; set; }

        public DateTime? TimeStamp { get; set; }

        public string IpAddress { get; set; }

        public string UserLocation { get; set; }
    }
}
