using System;

namespace PAI.Drayage.Domain
{
    public interface IDatedEntity
    {
        DateTime CreationDate { get; set; }
        DateTime UpdateDate { get; set; }
    }
}