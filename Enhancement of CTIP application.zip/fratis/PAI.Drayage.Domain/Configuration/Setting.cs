﻿namespace PAI.Drayage.Domain.Configuration
{

    /// <summary>
    /// Represents a store setting
    /// </summary>
    public class Setting : EntityBase
    {
        /// <summary>
        /// Default Contructor
        /// </summary>
        public Setting()
        {
        }
        
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public Setting(string name, string value)
        {
            Name = name;
            Value = value;
        }

        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string Name { get; set; }

        /// <summary>
        /// Gets or sets the value
        /// </summary>
        public virtual string Value { get; set; }

        /// <summary>
        /// Returns the name of the Setting
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Name;
        }

    }
}
