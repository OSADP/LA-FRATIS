using System;
using PAI.Drayage.Domain.Geography;

namespace PAI.Drayage.Domain.Orders
{
    /// <summary>
    /// Represents a route stop
    /// </summary>
    public class RouteStop : EntityBase, ISortableEntity
    {
        /// <summary>
        /// Gets or sets the associated order 
        /// </summary>
        public virtual Job Job { get; set; }
        public virtual int? JobId { get; set; }

        /// <summary>
        /// Gets or sets the sort order
        /// </summary>
        public virtual int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets whether this is a dynamic stop
        /// </summary>
        public bool IsDynamicStop { get; set; }

        /// <summary>
        /// Gets or sets stop action
        /// </summary>
        public virtual StopAction StopAction { get; set; }
        public virtual int? StopActionId { get; set; }
        
        /// <summary>
        /// Gets or sets the location
        /// </summary>
        public virtual Location Location { get; set; }

        /// <summary>
        /// Gets or sets the location id
        /// </summary>
        public virtual int? LocationId { get; set; }

        /// <summary>
        /// Gets or sets the start window in ticks
        /// </summary>
        //public virtual long? WindowStart
        //{
        //    get { return WindowStartTime != null ? (long?) WindowStartTime.Value.Ticks : null; }
        //    set
        //    {
        //        if (value.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            WindowStartTime = new TimeSpan(value.Value);
        //        }
        //    }
        //}

        /// <summary>
        /// Gets or sets the end of window in ticks
        /// </summary>
        //public virtual long? WindowEnd
        //{
        //    get { return WindowEndTime != null ? (long?)WindowEndTime.Value.Ticks : null; }
        //    set
        //    {
        //        if (value.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            WindowEndTime = new TimeSpan(value.Value);
        //        }
        //    }
        //}

        /// <summary>
        /// Gets or sets the start window as a DateTime representation
        /// Only the hour and minutes of DateTime are used to deduce the start time
        /// </summary>
        public virtual DateTime? WindowStartDateTime { get; set; }

        /// <summary>
        /// Gets or sets the end window as a DateTime representation
        /// Only the hour and minutes of DateTime are used to deduce the end time
        /// </summary>
        public virtual DateTime? WindowEndDateTime { get; set; }

        /// <summary>
        /// Gets or sets the stop delay in ticks
        /// </summary>
        public virtual long? StopDelay { get; set; }


        //public TimeSpan? WindowStartTime
        //{
        //    get
        //    {
        //        if (WindowStartDateTime.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            // Window Date Time should be greater than the Due Date
        //            if (WindowStartDateTime.Value < Job.DueDate.Value)
        //                WindowStartDateTime =
        //                    new DateTime(Job.DueDate.Value.Ticks).AddHours(WindowStartDateTime.Value.Hour)
        //                                                         .AddMinutes(WindowStartDateTime.Value.Minute);
        //            return WindowStartDateTime.Value.Subtract(Job.DueDate.Value);
        //        }
        //        return null;
        //    }
        //    set
        //    {
        //        if (value.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            WindowStartDateTime = Job.DueDate.Value.AddTicks(value.Value.Ticks);
        //        }
        //        else
        //        {
        //            WindowStartDateTime = null;
        //        }
        //    }
        //}

        //public TimeSpan? WindowEndTime
        //{
        //    get
        //    {
        //        if (WindowEndDateTime.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            // Window Date Time should be greater than the Due Date
        //            if (WindowEndDateTime.Value < Job.DueDate.Value)
        //                WindowEndDateTime =
        //                    new DateTime(Job.DueDate.Value.Ticks).AddHours(WindowEndDateTime.Value.Hour)
        //                                                         .AddMinutes(WindowEndDateTime.Value.Minute);

        //            return WindowEndDateTime.Value.Subtract(Job.DueDate.Value);
        //        }
        //        return null;
        //    }
        //    set
        //    {
        //        if (value.HasValue && Job != null && Job.DueDate.HasValue)
        //        {
        //            WindowEndDateTime = Job.DueDate.Value.AddTicks(value.Value.Ticks);
        //        }
        //        else
        //        {
        //            WindowEndDateTime = null;
        //        }
        //    }
        //}
    }
}