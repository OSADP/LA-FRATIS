namespace PAI.Drayage.Domain.Orders
{
    public enum JobStatus
    {
        Invalid,
        Pending,
        Transmitted
    }
}