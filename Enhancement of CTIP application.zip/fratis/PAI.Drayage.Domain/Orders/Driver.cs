using System;
using System.Collections.Generic;
using PAI.Drayage.Domain.Geography;
using PAI.Drayage.Domain.Planning;

namespace PAI.Drayage.Domain.Orders
{
    /// <summary>
    /// Represents a driver
    /// </summary>
    public class Driver : EntityBase
    {
        /// <summary>
        /// Gets or sets the display name
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the starting location
        /// </summary>
        public virtual Location StartingLocation { get; set; }

        /// <summary>
        /// Gets or sets the starting location id
        /// </summary>
        public virtual int? StartingLocationId { get; set; }
        
        /// <summary>
        /// Gets or sets the earliest start time
        /// </summary>
        public virtual DateTime EarliestStartTime { get; set; }

        /// <summary>
        /// Gets or sets the available duty time
        /// </summary>
        public virtual double AvailableDutyHours { get; set; }

        /// <summary>
        /// Gets or sets the available driving time
        /// </summary>
        public virtual double AvailableDrivingHours { get; set; }
        
        /// <summary>
        /// Gets or sets the WebFleetVehicleId
        /// </summary>
        public virtual string WebFleetDriverId { get; set; }

        /// <summary>
        /// Gets or sets the WebFleetVehicleId
        /// </summary>
        public virtual string WebFleetVehicleId { get; set; }
        
        public virtual ICollection<PlanConfig> PlanConfigs { get; set; }

        public virtual bool IsDummyDriver { get; set; }

        public virtual bool Deleted { get; set; }

        public string Tags { get; set; }

        public double Load { get; set; }
    }
}