using System;
using System.Collections.Generic;
using PAI.Drayage.Domain.Equipment;
using PAI.Drayage.Domain.Planning;

namespace PAI.Drayage.Domain.Orders
{
    /// <summary>
    /// Represents a drayage job
    /// </summary>
    public class Job : EntityBase
    {
        /// <summary>
        /// Gets or sets the order number
        /// </summary>
        public virtual string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets whether this job was transmitted
        /// </summary>
        public bool IsTransmitted { get; set; }
        
        /// <summary>
        /// Gets or sets the job due date
        /// </summary>
        public virtual DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets the chassis
        /// </summary>
        public virtual Chassis Chassis { get; set; }
        public virtual int? ChassisId { get; set; }

        /// <summary>
        /// Gets or sets the chassis
        /// </summary>
        public virtual ChassisOwner ChassisOwner { get; set; }
        public virtual int? ChassisOwnerId { get; set; }
        
        /// <summary>
        /// Gets or sets the container
        /// </summary>
        public virtual Container Container { get; set; }
        public virtual int? ContainerId { get; set; }

        /// <summary>
        /// Gets or sets the container
        /// </summary>
        public virtual ContainerOwner ContainerOwner { get; set; }
        public virtual int? ContainerOwnerId { get; set; }
        
        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        private ICollection<RouteStop> _routeStops;
        public virtual ICollection<RouteStop> RouteStops
        {
            get
            {
                return _routeStops ?? (_routeStops = new List<RouteStop>());
            }
            set
            {
                _routeStops = value;
            }
        }

        /// <summary>
        /// Gets or sets the pick number
        /// </summary>
        public virtual string PickNumber { get; set; }

        /// <summary>
        /// Gets or sets the pick number
        /// </summary>
        public virtual string BookingNumber { get; set; }

        /// <summary>
        /// Gets or sets the pick number
        /// </summary>
        public virtual string Notes { get; set; }

        /// <summary>
        /// Gets or sets the JobStatus
        /// </summary>
        public virtual JobStatus JobStatus { get; set; }
        
        public virtual ICollection<PlanConfig> PlanConfigs { get; set; }

        public virtual bool Deleted { get; set; }

        
    }
}
