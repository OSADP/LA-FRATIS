namespace PAI.Drayage.Domain.Orders
{
    /// <summary>
    /// Represents a stop action
    /// </summary>
    public class StopAction : EntityBase
    {
        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string Name { get; set; }

        /// <summary>
        /// Gets or sets the short name
        /// </summary>
        public virtual string ShortName { get; set; }
    }
}